"""Private synthetic Session exchange composition; public bridge stays blocked.

No engine starts here. A Session is only provided by a separately controlled
caller. This composition is not containment, provenance or launch approval.
"""
import hashlib,math,os,stat
from . import coding,coding_exchange,coding_review,coding_syntax
from .mock_coding import parse_proposal
from .policy import rules_for,json_equal
from .session import Session,check_journals
from .storage import Store

class SessionExchangeError(ValueError): pass

def run(*args,**kwargs):
    raise SessionExchangeError('session exchange disabled pending controlled runtime and review')

def _verify_store_lock(store, *, _store_fd=None):
    if type(store) is not Store or store.lock_fd is None:raise SessionExchangeError('session store lock required')
    if _store_fd is not None:
        current=coding._open_abs(store.root)
        try:coding._same_root(current,_store_fd)
        finally:os.close(current)
    held=os.fstat(store.lock_fd);named=os.lstat(store.lock)
    if not stat.S_ISREG(held.st_mode) or (held.st_dev,held.st_ino)!=(named.st_dev,named.st_ino):raise SessionExchangeError('session store lock changed')

def _verify_session(session, *, _store_fd=None):
    if type(session) is not Session:raise SessionExchangeError('expected Astra Session')
    store=session.store
    _verify_store_lock(store,_store_fd=_store_fd)
    if not json_equal(session.rules,rules_for([])):raise SessionExchangeError('all tools must be denied')
    saved=check_journals(store,session.work,session.rules)
    if saved is None or saved['sid']!=session.sid:raise SessionExchangeError('session journal mismatch')
    if store.read('task.json') is not None:raise SessionExchangeError('fresh session required')

def _eligible_prompt(raw,meta,secrets):
    """Apply the actual Session send constraints before approval and again before intent.

    The value is sensitive; only fixed categorical errors escape. The check is
    sampled, not proof of data safety or absence of other secrets. Exchange
    preparation remains usable offline with larger requests.
    """
    if (not isinstance(raw,bytes) or len(raw)>100_000 or
        hashlib.sha256(raw).hexdigest()!=meta['request_sha256']):
        raise SessionExchangeError('request does not fit Session prompt')
    try:text=raw.decode('utf-8')
    except UnicodeDecodeError:raise SessionExchangeError('request does not fit Session prompt') from None
    if not text.strip():raise SessionExchangeError('request does not fit Session prompt')
    if any(s and s in text for s in secrets):raise SessionExchangeError('prompt contains active credential')
    return text


def _validate_timing(deadline_seconds,poll_interval):
    # Match Session._prompt_once exactly; reject before approval or intent.
    if (type(deadline_seconds) not in (int,float) or not math.isfinite(deadline_seconds) or not 0<deadline_seconds<=600
        or type(poll_interval) not in (int,float) or not math.isfinite(poll_interval) or not 0<poll_interval<=600):
        raise SessionExchangeError('invalid Session timing')


def _preflight(task,ident,secrets,*,_root_fd):
    """Sample exact approved request and candidate before send consent."""
    root=coding_exchange._root(task);ex=tree=None
    try:
        coding._same_root(root,_root_fd)
        coding._lock(root);ex,meta=coding_exchange._exchange(root,ident)
        for name in ('claimed.json','session-intent.json'):
            try:os.stat(name,dir_fd=ex,follow_symlinks=False)
            except FileNotFoundError:pass
            else:raise SessionExchangeError('exchange already claimed or sent')
        state,manifest,history,tree=coding_exchange._snapshot(root)
        if state['revision']!=meta['revision'] or manifest!=meta['manifest'] or history['revisions'][-1]['manifest_sha256']!=meta['manifest_sha256']:
            raise SessionExchangeError('candidate revision changed')
        fd=os.open('request.json',coding.READ,dir_fd=ex)
        try:raw,_=coding._read(fd,400_000)
        finally:os.close(fd)
        coding._unlock(root)
        # Validate after the read-only snapshot lock is released. A deterministic
        # local refusal must not strand it; any later mutation is rechecked.
        _eligible_prompt(raw,meta,secrets)
        return meta
    finally:
        for fd in (tree,ex,root):
            if fd is not None:os.close(fd)

def _prepare_once(task,ident,session,expected,*,_root_fd):
    """Under candidate lock validate snapshot and persist pre-prompt intent."""
    root=coding_exchange._root(task);ex=tree=None
    try:
        coding._same_root(root,_root_fd)
        coding._lock(root)
        ex,meta=coding_exchange._exchange(root,ident)
        if meta!=expected:raise SessionExchangeError('approved exchange changed')
        for name in ('claimed.json','session-intent.json'):
            try:os.stat(name,dir_fd=ex,follow_symlinks=False)
            except FileNotFoundError:pass
            else:raise SessionExchangeError('exchange already claimed or sent')
        state,manifest,history,tree=coding_exchange._snapshot(root)
        if state['revision']!=meta['revision'] or manifest!=meta['manifest'] or history['revisions'][-1]['manifest_sha256']!=meta['manifest_sha256']:
            raise SessionExchangeError('candidate revision changed')
        fd=os.open('request.json',coding.READ,dir_fd=ex)
        try:raw,_=coding._read(fd,400_000)
        finally:os.close(fd)
        text=_eligible_prompt(raw,meta,session.secrets)
        intent={'version':1,'status':'prompt_outcome_unknown','request_sha256':meta['request_sha256'],
                'revision':meta['revision'],'manifest_sha256':meta['manifest_sha256'],'session_id':session.sid}
        coding._write_new(ex,'session-intent.json',coding._json_bytes(intent));os.fsync(ex)
        coding._unlock(root)
        return meta,text
    finally:
        for fd in (tree,ex,root):
            if fd is not None:os.close(fd)

def _record_response(task,ident,meta,session,result,*,_root_fd):
    """Persist bounded unredacted response, then sampled binding as commit marker."""
    journal=session.store.read('task.json');saved=session.store.read('session.json')
    if (not isinstance(journal,dict) or journal.get('status')!='succeeded' or journal.get('id')!=result.get('task_id')
        or journal.get('session')!=session.sid or not isinstance(saved,dict) or saved.get('sid')!=session.sid):
        raise SessionExchangeError('session outcome not settled')
    edits=parse_proposal(result,set(meta['paths']))
    raw=result['final_parts'][0]['text'].encode('utf-8')
    root=coding_exchange._root(task);ex=tree=None
    try:
        coding._same_root(root,_root_fd)
        coding._lock(root);ex,again=coding_exchange._exchange(root,ident)
        if again!=meta:raise SessionExchangeError('exchange changed')
        state,manifest,history,tree=coding_exchange._snapshot(root)
        if state['revision']!=meta['revision'] or manifest!=meta['manifest'] or history['revisions'][-1]['manifest_sha256']!=meta['manifest_sha256']:
            raise SessionExchangeError('candidate changed during prompt')
        intent=coding._load(ex,'session-intent.json')
        expected={'version':1,'status':'prompt_outcome_unknown','request_sha256':meta['request_sha256'],
                  'revision':meta['revision'],'manifest_sha256':meta['manifest_sha256'],'session_id':session.sid}
        if intent!=expected:raise SessionExchangeError('prompt intent changed')
        evidence={'version':1,'status':'sampled_settled_session_result','session_id':session.sid,
                  'task_id':journal['id'],'request_sha256':meta['request_sha256'],'response_sha256':hashlib.sha256(raw).hexdigest()}
        # The exact validated final text is private but may contain generated or
        # selected project data: no secrecy or authenticated origin is claimed.
        # Response is written and directory synced before the commit marker.
        coding._write_new(ex,'session-response.json',raw);os.fsync(ex)
        coding._write_new(ex,'session-result.json',coding._json_bytes(evidence));os.fsync(ex)
        coding._unlock(root)
        return edits,raw.decode('utf-8')
    finally:
        for fd in (tree,ex,root):
            if fd is not None:os.close(fd)

def _resume_pinned(task,ident,store,approve_candidate,*,review_paths=None,_root_fd,_store_fd):
    """Offline acceptance of a fully recorded response; no Session/network call.

    Refuses incomplete result, uncertainty, stale revision and any existing
    claim. Store lock must be explicitly acquired; stale locks are never removed.
    The response remains retained after approval/decline and is untrusted.
    """
    if not callable(approve_candidate):raise SessionExchangeError('candidate approval callback required')
    if review_paths is not None:
        if type(review_paths) is not list:raise SessionExchangeError('invalid review paths')
        coding_syntax._validate_paths(review_paths)
    _verify_store_lock(store,_store_fd=_store_fd)
    if not store.prompt_lock.acquire(blocking=False):raise SessionExchangeError('session operation already active')
    root=ex=tree=None
    try:
        saved=check_journals(store)
        journal=store.read('task.json')
        if saved is None or not json_equal(saved['rules'],rules_for([])) or not isinstance(journal,dict):
            raise SessionExchangeError('settled deny-all session required')
        root=coding_exchange._root(task);coding._same_root(root,_root_fd);coding._lock(root)
        ex,meta=coding_exchange._exchange(root,ident)
        if review_paths is not None and any(p not in meta['paths'] for p in review_paths):
            raise SessionExchangeError('review scope outside approved paths')
        try:os.stat('claimed.json',dir_fd=ex,follow_symlinks=False)
        except FileNotFoundError:pass
        else:raise SessionExchangeError('candidate already claimed; inspect, do not replay')
        intent=coding._load(ex,'session-intent.json');sample=coding._load(ex,'session-result.json')
        expected_intent={'version':1,'status':'prompt_outcome_unknown','request_sha256':meta['request_sha256'],
                         'revision':meta['revision'],'manifest_sha256':meta['manifest_sha256'],'session_id':saved['sid']}
        if intent!=expected_intent:raise SessionExchangeError('session intent mismatch')
        fd=os.open('session-response.json',coding.READ,dir_fd=ex)
        try:
            raw,st=coding._read(fd,coding.MAX_PATCH)
            if st.st_uid!=os.getuid() or st.st_mode&0o077:raise SessionExchangeError('response file not private')
        finally:os.close(fd)
        expected_sample={'version':1,'status':'sampled_settled_session_result','session_id':saved['sid'],
                         'task_id':journal['id'],'request_sha256':meta['request_sha256'],'response_sha256':hashlib.sha256(raw).hexdigest()}
        if sample!=expected_sample:raise SessionExchangeError('settled response binding mismatch')
        try:response=raw.decode('utf-8')
        except UnicodeDecodeError:raise SessionExchangeError('response not UTF-8') from None
        coding_exchange.parse_edits(response,set(meta['paths']))
        state,manifest,history,tree=coding_exchange._snapshot(root)
        if state['revision']!=meta['revision'] or manifest!=meta['manifest'] or history['revisions'][-1]['manifest_sha256']!=meta['manifest_sha256']:
            raise SessionExchangeError('candidate revision changed')
        coding._unlock(root)
        # Keep the cooperative Session prompt lock through the candidate claim
        # and approval so another local prompt cannot replace the sampled task.
        _verify_store_lock(store,_store_fd=_store_fd)
        def bound_approval(preview):
            approved=approve_candidate(preview)
            _verify_store_lock(store,_store_fd=_store_fd)
            return approved
        out=coding_exchange.accept(task,ident,response,bound_approval,
                                   _session_binding={'session_id':saved['sid'],'task_id':journal['id']},_expected_root_fd=_root_fd,
                                   _return_preclaim_refusal=True)
        if out['status']=='proposal_refused_before_claim':
            # Only the exchange's explicit no-claim, no-candidate-write path
            # can report this outcome. Recheck task and Session Store identities
            # before handing the owner a clean, non-replayable refusal.
            current=coding_exchange._root(task)
            try:coding._same_root(current,_root_fd)
            finally:os.close(current)
            _verify_store_lock(store,_store_fd=_store_fd)
            return {'status':'proposal_refused_before_claim','reason':out['reason'],
                    'session_id':saved['sid'],'task_id':journal['id'],
                    'request_sha256':meta['request_sha256'],'replay_authorized':False,
                    'source_applied':False,'code_executed':False,
                    'notice':'Recorded response retained; no resend or replacement is authorized.',
                    'review':{'status':'not_requested'}}
    finally:
        for fd in (tree,ex,root):
            if fd is not None:os.close(fd)
        store.prompt_lock.release()
    review={'status':'not_requested'}
    if review_paths is not None and out['status']=='candidate_revision_created':
        try:
            report=coding_review.review(task,review_paths,_expected_root_fd=_root_fd)
            if report.get('revision')!=out['result']['revision']:
                review={'status':'stale','candidate_revision':out['result']['revision'],'review_revision':report.get('revision')}
            else:
                review={'status':'completed','report':report}
        except Exception:
            # Candidate may already exist. Never retry the claimed operation or
            # report the candidate as absent if post-commit review fails.
            review={'status':'failed_or_uncertain','candidate_revision':out['result']['revision']}
    return {'status':out['status'],'candidate':out,'session_id':saved['sid'],'task_id':journal['id'],
            'request_sha256':meta['request_sha256'],'source_applied':False,'code_executed':False,'review':review}


def _run_pinned(task,ident,session,approve_send,approve_candidate,*,deadline_seconds=2,poll_interval=.01,review_paths=None,_root_fd,_store_fd):
    """Testable private path; not a public launcher and not independently reviewed.

    Deliberate one-shot intent remains even after clean result, denial, or crash;
    candidate approval is separate. Session owner must handle runtime cleanup.
    """
    if not callable(approve_send) or not callable(approve_candidate):raise SessionExchangeError('approval callbacks required')
    if review_paths is not None:
        if type(review_paths) is not list:raise SessionExchangeError('invalid review paths')
        coding_syntax._validate_paths(review_paths)
    _validate_timing(deadline_seconds,poll_interval)
    _verify_session(session,_store_fd=_store_fd)
    # The exchange request has already been separately prepared and shown.
    # User specifically consents to send THIS prompt to THIS session.
    approved=_preflight(task,ident,session.secrets,_root_fd=_root_fd)
    if review_paths is not None and any(p not in approved['paths'] for p in review_paths):raise SessionExchangeError('review scope outside approved paths')
    payload={'exchange_id':ident,'session_id':session.sid,'request_sha256':approved['request_sha256'],
             'revision':approved['revision'],'manifest_sha256':approved['manifest_sha256'],
             'selected_paths':list(approved['paths']),
             'notice':'Selected file contents will be sent to this session.'}
    before=coding._json_bytes(payload)
    if approve_send(payload) is not True:
        return {'status':'cancelled_before_prompt'}
    try: unchanged=coding._json_bytes(payload)==before
    except (TypeError,ValueError,UnicodeError,RecursionError):unchanged=False
    if not unchanged:raise SessionExchangeError('send approval payload changed; not sent')
    # Session.prompt normally obtains this same non-reentrant lock internally.
    # Hold it over freshness checking, intent, the actual single prompt, and the
    # response journal sample, then invoke _prompt_once without re-acquiring.
    if not session.store.prompt_lock.acquire(blocking=False):raise SessionExchangeError('session operation already active')
    try:
        _verify_session(session,_store_fd=_store_fd)
        meta,prompt=_prepare_once(task,ident,session,approved,_root_fd=_root_fd)
        _verify_store_lock(session.store,_store_fd=_store_fd)
        result=session._prompt_once(prompt,deadline_seconds=deadline_seconds,poll_interval=poll_interval)
        _verify_store_lock(session.store,_store_fd=_store_fd)
        if not isinstance(result,dict) or result.get('status')!='succeeded':raise SessionExchangeError('prompt outcome uncertain; no replay')
        _,response=_record_response(task,ident,meta,session,result,_root_fd=_root_fd)
        _verify_store_lock(session.store,_store_fd=_store_fd)
    finally:
        session.store.prompt_lock.release()
    return _resume_private(task,ident,session.store,approve_candidate,review_paths=review_paths,_expected_root_fd=_root_fd,_expected_store_fd=_store_fd)


def _resume_private(task,ident,store,approve_candidate,*,review_paths=None,_expected_root_fd=None,_expected_store_fd=None):
    task=coding._checked_abs(task);root=coding_exchange._root(task);store_fd=None
    try:
        if _expected_root_fd is not None:coding._same_root(root,_expected_root_fd)
        if type(store) is not Store:raise SessionExchangeError('session store required')
        store_fd=coding._open_abs(store.root)
        if _expected_store_fd is not None:coding._same_root(store_fd,_expected_store_fd)
        return _resume_pinned(task,ident,store,approve_candidate,review_paths=review_paths,_root_fd=root,_store_fd=store_fd)
    finally:
        if store_fd is not None:os.close(store_fd)
        os.close(root)


def _run_private(task,ident,session,approve_send,approve_candidate,*,deadline_seconds=2,poll_interval=.01,review_paths=None):
    task=coding._checked_abs(task);root=coding_exchange._root(task);store_fd=None
    try:
        if type(session) is not Session or type(session.store) is not Store:raise SessionExchangeError('session store required')
        store_fd=coding._open_abs(session.store.root)
        return _run_pinned(task,ident,session,approve_send,approve_candidate,deadline_seconds=deadline_seconds,poll_interval=poll_interval,review_paths=review_paths,_root_fd=root,_store_fd=store_fd)
    finally:
        if store_fd is not None:os.close(store_fd)
        os.close(root)
