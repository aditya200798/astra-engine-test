"""A one-shot, mock-only session -> reviewed local revision. No live engine."""
import json, os, re, secrets
from pathlib import Path
from . import coding
from .policy import config_for, rules_for
from .storage import Store
from .session import Session
from .transport import strict_json

class BridgeError(ValueError): pass

def parse_proposal(result, allowed):
    if not isinstance(result,dict) or result.get('status')!='succeeded' or result.get('final_redacted') is not False:
        raise BridgeError('session result not settled or output redacted')
    parts=result.get('final_parts')
    if not isinstance(parts,list) or len(parts)!=1 or not isinstance(parts[0],dict) or parts[0].get('type')!='text' or not isinstance(parts[0].get('text'),str):
        raise BridgeError('expected exactly one final text part')
    # No tools in the whole turn: this slice permits no model actions, only text.
    if not isinstance(result.get('parts'),list) or any(not isinstance(p,dict) or p.get('type')!='text' for p in result['parts']):
        raise BridgeError('tools or invalid session output')
    if result['parts'][-1:] != parts: raise BridgeError('final response mismatch')
    return parse_edits(parts[0]['text'], allowed)

def parse_edits(text, allowed):
    """Validate untrusted edit text only; this does not assert session origin."""
    if not isinstance(text,str) or len(text.encode('utf-8'))>coding.MAX_PATCH: raise BridgeError('proposal too large or invalid')
    edits=strict_json(text)
    if not isinstance(edits,list) or not 1<=len(edits)<=100: raise BridgeError('expected a non-empty JSON edit array')
    for edit in edits:
        if not isinstance(edit,dict) or set(edit) not in ({'path','sha256','old','new'},{'path','sha256','new'}): raise BridgeError('invalid edit shape')
        path=edit['path']; coding._parts(path)
        if path not in allowed: raise BridgeError('path outside explicit approval scope')
        if not isinstance(edit['new'],str) or '\x00' in edit['new']: raise BridgeError('invalid replacement')
        if 'old' in edit:
            if not isinstance(edit['old'],str) or not edit['old'] or '\x00' in edit['old'] or not isinstance(edit['sha256'],str) or not re.fullmatch(r'[a-f0-9]{64}',edit['sha256']): raise BridgeError('invalid hunk or hash')
        elif edit['sha256'] is not None: raise BridgeError('create must have null hash')
    return edits

def _run_pinned(task, allowed, approve, *, engine_factory=None, _root_fd):
    """approve(stage, payload) must return exactly True. Mock factory only for tests.

    Permanent one-shot marker is written before the mock session; neither prompt nor
    candidate can replay after cancellation, error or interruption. No source sent.
    """
    if not isinstance(allowed,list) or not allowed or len(allowed)>100 or any(not isinstance(p,str) for p in allowed) or len(set(allowed))!=len(allowed): raise BridgeError('provide unique allowed paths')
    for p in allowed: coding._parts(p)
    allowed=list(allowed)  # caller-owned mutable list is not the authorization snapshot
    # Rules reject glob/path characters unsupported by the OpenCode adapter.
    rules=rules_for(allowed); config=config_for(rules)
    before=coding.inspect(task)
    coding._require_revision_room(before['revision'])
    start={'allowed_paths':list(allowed),'revision':before['revision'],'mode':'offline mock; no project contents are sent'}
    start_bytes=coding._json_bytes(start)
    if approve('start',start) is not True:
        return {'status':'cancelled-before-start'}
    try: unchanged=coding._json_bytes(start)==start_bytes
    except (TypeError,ValueError,UnicodeError,RecursionError):unchanged=False
    if not unchanged:raise BridgeError('mock start approval changed')
    root=coding._open_abs(task)
    try:
        coding._same_root(root,_root_fd)
        st=os.fstat(root)
        if st.st_uid!=os.getuid() or st.st_mode & 0o077: raise BridgeError('task must be private')
        coding._write_new(root,'mock-coding-once',b'Mock run reserved; never replay automatically.\n');os.fsync(root)
    finally:os.close(root)
    # Tests or CLI may not plug in the real engine. This is an in-process fixture.
    from test.mock_inprocess import InProcessMock
    engine=engine_factory(config) if engine_factory else InProcessMock(config)
    store=None; clean=False
    try:
        store=Store(Path(task)/'mock-session');store.acquire()
        session=Session(engine.client,store,'/mock-work',rules,config,{},['offline-test-key',engine.pw])
        result=session.prompt('MOCK_CODE_FIXTURE',deadline_seconds=2,poll_interval=.01)
        journal=store.read('task.json')
        if not isinstance(journal,dict) or journal.get('status')!='succeeded' or journal.get('id')!=result.get('task_id'): raise BridgeError('session journal not settled')
        edits=parse_proposal(result,set(allowed))
        payload={'edits':edits,'revision':before['revision']}
        approved_bytes=coding._json_bytes(payload);preview=json.loads(approved_bytes)
        if approve('proposal',preview) is not True:
            clean=True; return {'status':'cancelled-after-response'}
        try: unchanged=coding._json_bytes(preview)==approved_bytes
        except (TypeError,ValueError,UnicodeError,RecursionError):unchanged=False
        if not unchanged:raise BridgeError('mock proposal approval changed; do not replay')
        root=coding._open_abs(task)
        try:coding._same_root(root,_root_fd)
        finally:os.close(root)
        current=coding.inspect(task)
        if current['revision']!=before['revision'] or current['manifest']!=before['manifest']: raise BridgeError('candidate changed since start')
        outcome=coding.propose(task,edits,expected_revision=before['revision'],expected_manifest=before['manifest'],_expected_root_fd=_root_fd)
        clean=True
        return {'status':'candidate-only','result':outcome}
    finally:
        stopped=engine.close()
        if clean and stopped and store: store.release()


def run(task,allowed,approve,*,engine_factory=None):
    task=coding._checked_abs(task);root=coding._open_abs(task)
    try:return _run_pinned(task,allowed,approve,engine_factory=engine_factory,_root_fd=root)
    finally:os.close(root)
