"""Bounded static Python compilation of a staged candidate, never executes code.

The compiler itself runs in this process, not a resource sandbox. Results are
revision-linked consistency observations, not test success or authentication.
"""
import os
import sys
import warnings
from . import coding

MAX_FILES = 20
MAX_FILE_BYTES = 65_536
MAX_SELECTED_BYTES = 524_288


def _validate_paths(paths):
    if not isinstance(paths, list) or not 1 <= len(paths) <= MAX_FILES:
        raise coding.CodingError('select 1 to 20 Python files')
    if len(set(paths)) != len(paths):
        raise coding.CodingError('duplicate file')
    for path in paths:
        coding._parts(path)
        if not path.endswith('.py'): raise coding.CodingError('Python files only')


def _check_locked(state, tree, manifest, paths):
    """Internal helper; caller verifies the revision and owns the task lock."""
    files = manifest['files']
    if any(p not in files for p in paths): raise coding.CodingError('file not staged')
    if any(files[p]['bytes'] > MAX_FILE_BYTES for p in paths):
        raise coding.CodingError('file exceeds syntax check limit')
    if sum(files[p]['bytes'] for p in paths) > MAX_SELECTED_BYTES:
        raise coding.CodingError('selected files exceed syntax check limit')
    results = []
    for path in paths:
        raw = coding._relative_read(tree, path)
        digest = coding._digest(raw)
        if digest != files[path]['sha256'] or len(raw) != files[path]['bytes']:
            raise coding.CodingError('file changed during syntax check')
        try:
            # Produces a code object only; does not import or execute project code.
            # Do not emit untrusted source-dependent compiler warnings to the terminal.
            # This checker does not report warnings; a clean status is not linting.
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                compile(raw, path, 'exec', dont_inherit=True)
            result = {'path':path, 'sha256':digest, 'status':'compile_passed', 'error':None}
        except (SyntaxError, ValueError, OverflowError) as exc:
            result = {'path':path, 'sha256':digest, 'status':'compile_failed',
                      'error':{'type':type(exc).__name__, 'message':str(exc.msg if isinstance(exc,SyntaxError) else exc)[:1000],
                               'line':getattr(exc,'lineno',None), 'offset':getattr(exc,'offset',None),
                               'end_line':getattr(exc,'end_lineno',None), 'end_offset':getattr(exc,'end_offset',None)}}
        results.append(result)
    out = {'revision':state['revision'], 'manifest_sha256':coding._digest(coding._json_bytes(manifest)),
           'python_version':sys.version.split()[0], 'files':results,
           'status':'compile_failed' if any(r['status']=='compile_failed' for r in results) else 'compile_passed',
           'limitations':'Static compilation only; no code executed, no imports, no runtime or behavior tests; compiler warnings are suppressed. Results become stale on revision change; manifest hash is not authentication.'}
    return out


def check(task, paths):
    _validate_paths(paths)
    root = coding._open_abs(task)
    revs = rev = tree = None
    try:
        st = os.fstat(root)
        if st.st_uid != os.getuid() or st.st_mode & 0o077:
            raise coding.CodingError('task must be private')
        coding._lock(root)
        state = coding._load(root, 'state.json')
        if not isinstance(state,dict) or state.get('version') != 1 or state.get('status') != 'ready':
            raise coding.CodingError('task is not ready')
        revs = coding._open_dir(root, 'revisions')
        rev, tree, manifest = coding._open_revision(revs, state.get('revision'))
        diff = coding._verified_review_diff(revs, state['revision'], tree, manifest)
        fd = os.open('diff.txt', coding.READ, dir_fd=rev)
        try: saved, _ = coding._read(fd, coding.MAX_DIFF)
        finally: os.close(fd)
        if saved != diff: raise coding.CodingError('stored diff does not match revisions')
        out = _check_locked(state, tree, manifest, paths)
        coding._unlock(root)
        return out
    finally:
        # Like coding.inspect, unexpected errors after lock retain it for investigation.
        for fd in (tree, rev, revs, root):
            if fd is not None: os.close(fd)
