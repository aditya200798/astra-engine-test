"""Node syntax checks on explicit staged bytes, not behavioral tests or a sandbox."""
import os
import selectors
import subprocess
import time
from . import coding

MAX_FILES = 12
MAX_FILE_BYTES = 65_536
MAX_SELECTED_BYTES = 393_216
MAX_DIAGNOSTIC = 8192
TIMEOUT_PER_FILE = 5.0
TIMEOUT_TOTAL = 30.0


def _check_one(node, raw, mode, deadline):
    """Drive only the supplied Node binary with fixed check args and bounded pipes.

    Timeout/output overflow attempts to kill and reap the direct process only;
    it cannot contain or prove cleanup of descendants or a compromised binary.
    """
    proc = subprocess.Popen([node, '--check', '--input-type='+mode], stdin=subprocess.PIPE,
                            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE,
                            cwd='/', env={'LANG':'C', 'PATH':''}, close_fds=True)
    limit = min(deadline, time.monotonic()+TIMEOUT_PER_FILE)
    chunks = bytearray(); sent = 0; reaped = False
    try:
        with selectors.DefaultSelector() as sel:
            for stream in (proc.stdin, proc.stderr): os.set_blocking(stream.fileno(), False)
            sel.register(proc.stderr, selectors.EVENT_READ)
            if raw: sel.register(proc.stdin, selectors.EVENT_WRITE)
            else: proc.stdin.close()
            while sel.get_map():
                remaining = limit - time.monotonic()
                if remaining <= 0: raise coding.CodingError('Node syntax check timed out')
                for key, _ in sel.select(remaining):
                    if key.fileobj is proc.stdin:
                        try: n = os.write(proc.stdin.fileno(), raw[sent:sent+65536])
                        except BrokenPipeError: n = 0
                        if n == 0:
                            sel.unregister(proc.stdin); proc.stdin.close()
                        else:
                            sent += n
                            if sent == len(raw): sel.unregister(proc.stdin); proc.stdin.close()
                    else:
                        data = os.read(proc.stderr.fileno(), min(4096, MAX_DIAGNOSTIC+1-len(chunks)))
                        if not data:
                            sel.unregister(proc.stderr); proc.stderr.close()
                        else:
                            chunks.extend(data)
                            if len(chunks)>MAX_DIAGNOSTIC:
                                raise coding.CodingError('Node diagnostic exceeds limit')
        remaining = limit-time.monotonic()
        if remaining <= 0: raise coding.CodingError('Node syntax check timed out')
        try: rc=proc.wait(timeout=remaining)
        except subprocess.TimeoutExpired: raise coding.CodingError('Node syntax check timed out') from None
        reaped = True
        if rc < 0: raise coding.CodingError('Node syntax checker terminated by signal')
        if sent != len(raw): raise coding.CodingError('Node syntax input could not be written to pipe')
        return rc, chunks.decode('utf-8', errors='replace')
    finally:
        if not reaped:
            try:
                if proc.poll() is None: proc.kill()
            except ProcessLookupError:
                pass
            try: proc.wait(timeout=2)
            except subprocess.TimeoutExpired: pass
        for stream in (proc.stdin, proc.stderr):
            if stream and not stream.closed: stream.close()


def _validate(paths, node, mode):
    """Validate inputs before acquiring the task lock."""
    if not isinstance(node, str) or not os.path.isabs(node) or '\x00' in node:
        raise coding.CodingError('an absolute trusted Node executable path is required')
    if mode not in ('module', 'commonjs'): raise coding.CodingError('explicit module or commonjs mode required')
    if not isinstance(paths,list) or not 1 <= len(paths) <= MAX_FILES:
        raise coding.CodingError('select 1 to 12 JavaScript files')
    for path in paths:
        coding._parts(path)
        if not path.endswith(('.js','.mjs','.cjs')): raise coding.CodingError('JavaScript files only')
    if len(set(paths)) != len(paths): raise coding.CodingError('duplicate file')


def _check_locked(state, tree, manifest, paths, node, mode):
    """Caller holds task lock and has verified revision and path parameters."""
    files=manifest['files']
    if any(p not in files for p in paths): raise coding.CodingError('file not staged')
    if any(files[p]['bytes']>MAX_FILE_BYTES for p in paths): raise coding.CodingError('file exceeds syntax check limit')
    if sum(files[p]['bytes'] for p in paths)>MAX_SELECTED_BYTES: raise coding.CodingError('selected files exceed syntax check limit')
    deadline=time.monotonic()+TIMEOUT_TOTAL; results=[]
    for path in paths:
        if time.monotonic() >= deadline: raise coding.CodingError('Node syntax check timed out')
        raw=coding._relative_read(tree,path); digest=coding._digest(raw)
        if digest!=files[path]['sha256'] or len(raw)!=files[path]['bytes']:
            raise coding.CodingError('file changed during syntax check')
        rc,diagnostic=_check_one(node,raw,mode,deadline)
        results.append({'path':path,'sha256':digest,'status':'check_passed' if rc==0 else 'check_failed_or_node_error',
                        'node_exit_code':rc,'diagnostic':diagnostic})
    result={'revision':state['revision'],'manifest_sha256':coding._digest(coding._json_bytes(manifest)),
            'mode':mode,'node_executable':node,'files':results,
            'status':'check_passed' if all(x['status']=='check_passed' for x in results) else 'check_failed_or_node_error',
            'limitations':'Syntax check only: no runtime, imports or behavior tests; nonzero may be a Node error. User-selected executable is not authenticated. Manifest hash is not authentication.'}
    return result


def check(task, paths, node, mode):
    """Check explicitly selected JS paths in a verified current staged revision."""
    _validate(paths,node,mode)
    root=coding._open_abs(task); revs=rev=tree=None
    try:
        st=os.fstat(root)
        if st.st_uid!=os.getuid() or st.st_mode & 0o077: raise coding.CodingError('task must be private')
        coding._lock(root)
        state=coding._load(root,'state.json')
        if not isinstance(state,dict) or state.get('version')!=1 or state.get('status')!='ready':
            raise coding.CodingError('task is not ready')
        revs=coding._open_dir(root,'revisions')
        rev,tree,manifest=coding._open_revision(revs,state.get('revision'))
        diff=coding._verified_review_diff(revs,state['revision'],tree,manifest)
        fd=os.open('diff.txt',coding.READ,dir_fd=rev)
        try: saved,_=coding._read(fd,coding.MAX_DIFF)
        finally: os.close(fd)
        if saved!=diff: raise coding.CodingError('stored diff does not match revisions')
        result=_check_locked(state,tree,manifest,paths,node,mode)
        coding._unlock(root)
        return result
    finally:
        for fd in (tree,rev,revs,root):
            if fd is not None: os.close(fd)
