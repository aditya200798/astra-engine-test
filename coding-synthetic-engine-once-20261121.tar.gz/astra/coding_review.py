"""One-lock, offline history and selected Python syntax review; no execution."""
import os
from . import coding, coding_syntax, coding_js_syntax


def review(task, paths, *, _expected_root_fd=None):
    """Review verified bounded history and selected current Python files together.

    Cooperative writer lock is held throughout; not an authenticity root or a
    defense against hostile same-UID changes. Errors after locking retain the lock.
    """
    coding_syntax._validate_paths(paths)
    root = coding._open_abs(task); revs = rev = tree = None
    try:
        st = os.fstat(root)
        if st.st_uid != os.getuid() or st.st_mode & 0o077:
            raise coding.CodingError('task must be private')
        if _expected_root_fd is not None: coding._same_root(root,_expected_root_fd)
        coding._lock(root)
        state = coding._load(root, 'state.json')
        if not isinstance(state, dict) or state.get('version') != 1 or state.get('status') != 'ready':
            raise coding.CodingError('task is not ready')
        revs = coding._open_dir(root, 'revisions')
        history = coding._review_history_locked(state, revs)
        rev, tree, manifest = coding._open_revision(revs, state['revision'])
        syntax = coding_syntax._check_locked(state, tree, manifest, paths)
        if (history['revision'] != syntax['revision'] or
            history['revisions'][-1]['manifest_sha256'] != syntax['manifest_sha256']):
            raise coding.CodingError('history and syntax snapshot mismatch')
        out = {'revision': state['revision'], 'history': history, 'python_syntax': syntax,
               'limitations': 'Local consistency and static Python compilation only; no code executed, authentication, sandbox, behavior testing, or source application. Results become stale after a revision change; cooperative locking does not exclude hostile same-UID writes.'}
        coding._unlock(root)
        return out
    finally:
        for fd in (tree, rev, revs, root):
            if fd is not None: os.close(fd)


def review_mixed(task, python_paths, js_paths, node=None, mode=None):
    """One locked history + explicit selected Python/JS static checks, no apply."""
    if type(python_paths) is not list or type(js_paths) is not list or not (python_paths or js_paths):
        raise coding.CodingError('select Python or JavaScript files')
    if python_paths: coding_syntax._validate_paths(python_paths)
    if js_paths: coding_js_syntax._validate(js_paths,node,mode)
    elif node is not None or mode is not None: raise coding.CodingError('Node options require JS files')
    root=coding._open_abs(task);revs=rev=tree=None
    try:
        st=os.fstat(root)
        if st.st_uid!=os.getuid() or st.st_mode & 0o077: raise coding.CodingError('task must be private')
        coding._lock(root)
        state=coding._load(root,'state.json')
        if not isinstance(state,dict) or state.get('version')!=1 or state.get('status')!='ready':
            raise coding.CodingError('task is not ready')
        revs=coding._open_dir(root,'revisions')
        history=coding._review_history_locked(state,revs)
        rev,tree,manifest=coding._open_revision(revs,state['revision'])
        py=coding_syntax._check_locked(state,tree,manifest,python_paths) if python_paths else None
        js=coding_js_syntax._check_locked(state,tree,manifest,js_paths,node,mode) if js_paths else None
        expected=history['revisions'][-1]['manifest_sha256']
        for result in (py,js):
            if result is not None and (result['revision']!=history['revision'] or result['manifest_sha256']!=expected):
                raise coding.CodingError('history and syntax snapshot mismatch')
        passed=(py is None or py['status']=='compile_passed') and (js is None or js['status']=='check_passed')
        result={'revision':state['revision'],'manifest_sha256':expected,'history':history,
                'python_syntax':py,'javascript_syntax':js,'status':'selected_syntax_passed' if passed else 'selected_syntax_failed_or_checker_error',
                'limitations':'Only selected file syntax and bounded history checked; no project code executed, behavior, sandbox, provenance, model integration or source application. Checks do not cover unselected files. Results stale on revision change; cooperative lock is not hostile-writer protection.'}
        coding._unlock(root)
        return result
    finally:
        for fd in (tree,rev,revs,root):
            if fd is not None:os.close(fd)
