"""Offline-only candidate snapshots and exact edits. Never invokes a model or shell.

Uses directory-relative, no-follow opens for all tree traversal. This is not a
sandbox or a defense against hostile same-UID concurrent mutation. A crashed
writer leaves a persistent lock and must be investigated, never replayed.
"""
import difflib
import hashlib
import json
import os
import re
import secrets
import stat
from pathlib import Path

MAX_FILE = 8_000_000
MAX_TOTAL = 40_000_000
MAX_FILES = 1000
MAX_PATCH = 1_000_000
MAX_DIFF = 2_000_000
MAX_MANIFEST = 4_000_000
DIR = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
READ = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK
WRITE = os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW

class CodingError(ValueError):
    pass

class ProposalInvalid(CodingError):
    """Deterministic invalid edits/limits; no candidate write attempted."""
    pass

def _name(name):
    if (not isinstance(name, str) or not name or name in ('.', '..') or '/' in name
            or '\\' in name or len(name.encode('utf-8')) > 255
            or any(ord(c) < 32 or 127 <= ord(c) <= 159 for c in name)):
        raise CodingError('invalid path component')
    return name

def _parts(path):
    if not isinstance(path, str) or path.startswith('/') or not path:
        raise CodingError('path must be relative')
    parts = path.split('/')
    for p in parts: _name(p)
    return parts

def _checked_abs(path):
    raw = os.fspath(path)
    if not isinstance(raw, str) or any(p in ('.', '..') for p in raw.split('/')):
        raise CodingError('dot path components rejected')
    return os.path.abspath(raw)

def _open_abs(path):
    # Check before normalization; then refuse symlinks in every component.
    path = _checked_abs(path)
    # O_PATH requires only directory search permission for ancestors. Reopen the
    # final directory readably to enumerate it. Fail closed on platforms lacking it.
    if not hasattr(os, 'O_PATH'): raise CodingError('O_PATH unavailable')
    traverse = os.O_PATH | os.O_DIRECTORY | os.O_NOFOLLOW
    fd = os.open('/', traverse)
    try:
        for p in path.split('/')[1:]:
            _name(p)
            new = os.open(p, traverse, dir_fd=fd)
            os.close(fd); fd = new
        result = os.open('.', DIR, dir_fd=fd)
        os.close(fd)
        return result
    except BaseException:
        os.close(fd); raise

def _same_root(fd, expected_fd):
    # Inode comparison is only a live descriptor identity check. The caller
    # keeps expected_fd open so the original inode cannot be reused here.
    if type(expected_fd) is not int or expected_fd < 0: raise CodingError('invalid task identity')
    actual=os.fstat(fd); expected=os.fstat(expected_fd)
    if not stat.S_ISDIR(expected.st_mode) or (actual.st_dev,actual.st_ino)!=(expected.st_dev,expected.st_ino):
        raise CodingError('task directory changed; do not replay')


def _open_dir(fd, name):
    return os.open(_name(name), DIR, dir_fd=fd)

def _regular(fd):
    st = os.fstat(fd)
    if not stat.S_ISREG(st.st_mode) or st.st_nlink != 1:
        raise CodingError('link or non-regular file rejected')
    if st.st_size > MAX_FILE: raise CodingError('file too large')
    return st

def _read(fd, max_bytes=MAX_FILE):
    st = _regular(fd)
    chunks = []; n = 0
    while True:
        chunk = os.read(fd, min(65536, max_bytes + 1 - n))
        if not chunk: break
        chunks.append(chunk); n += len(chunk)
        if n > max_bytes: raise CodingError('file exceeds limit')
    end = os.fstat(fd)
    if (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns) != (end.st_dev, end.st_ino, end.st_size, end.st_mtime_ns, end.st_ctime_ns) or n != st.st_size:
        raise CodingError('file changed during read')
    return b''.join(chunks), st

def _write_new(fd, name, data, mode=0o600):
    out = os.open(_name(name), WRITE, mode, dir_fd=fd)
    try:
        pos = 0
        while pos < len(data):
            n = os.write(out, data[pos:])
            if n <= 0: raise OSError('short write')
            pos += n
        os.fchmod(out, mode); os.fsync(out)
    finally: os.close(out)

def _json_bytes(obj):
    return (json.dumps(obj, ensure_ascii=False, sort_keys=True, indent=2) + '\n').encode('utf-8')

def _load(fd, name):
    f = os.open(_name(name), READ, dir_fd=fd)
    try: raw, _ = _read(f, MAX_MANIFEST)
    finally: os.close(f)
    def unique(pairs):
        d = {}
        for k, v in pairs:
            if k in d: raise CodingError('duplicate JSON key')
            d[k] = v
        return d
    return json.loads(raw, object_pairs_hook=unique, parse_constant=lambda _: (_ for _ in ()).throw(CodingError('invalid JSON')))

def _replace_state(fd, obj):
    temp = '.state-' + secrets.token_hex(12)
    _write_new(fd, temp, _json_bytes(obj))
    os.rename(temp, 'state.json', src_dir_fd=fd, dst_dir_fd=fd)
    os.fsync(fd)

def _digest(data): return hashlib.sha256(data).hexdigest()

def _walk(fd, dst=None, prefix='', accum=None):
    """Read a tree, optionally copy it, rejecting every link and special file."""
    if accum is None: accum = {'files': {}, 'dirs': [], 'total': 0}
    for name in sorted(os.listdir(fd)):
        _name(name)
        if name in ('AGENTS.md', 'CLAUDE.md'):
            raise CodingError('instruction file rejected')
        rel = prefix + name
        if len(rel.encode('utf-8')) > 4096 or rel.count('/') > 64: raise CodingError('tree path limit')
        st = os.stat(name, dir_fd=fd, follow_symlinks=False)
        if stat.S_ISDIR(st.st_mode):
            source_child = _open_dir(fd, name)
            target_child = None
            try:
                if (os.fstat(source_child).st_dev, os.fstat(source_child).st_ino) != (st.st_dev, st.st_ino): raise CodingError('directory changed')
                if len(accum['dirs']) >= MAX_FILES: raise CodingError('too many directories')
                accum['dirs'].append(rel)
                if dst is not None:
                    os.mkdir(name, 0o700, dir_fd=dst); target_child = _open_dir(dst, name)
                _walk(source_child, target_child, rel+'/', accum)
                if target_child is not None: os.fsync(target_child)
            finally:
                os.close(source_child)
                if target_child is not None: os.close(target_child)
        elif stat.S_ISREG(st.st_mode):
            f = os.open(name, READ, dir_fd=fd)
            try:
                raw, opened = _read(f)
                if (opened.st_dev, opened.st_ino) != (st.st_dev, st.st_ino): raise CodingError('file changed')
            finally: os.close(f)
            accum['total'] += len(raw)
            if len(accum['files']) >= MAX_FILES or accum['total'] > MAX_TOTAL: raise CodingError('tree exceeds limits')
            executable = bool(opened.st_mode & 0o111)
            accum['files'][rel] = {'sha256': _digest(raw), 'bytes': len(raw), 'executable': executable}
            if dst is not None: _write_new(dst, name, raw, 0o700 if executable else 0o600)
        else:
            raise CodingError('link or special file rejected')
    return accum

def _relative_read(root, path):
    parts = _parts(path); d = os.dup(root)
    try:
        for p in parts[:-1]:
            nxt = _open_dir(d, p); os.close(d); d = nxt
        f = os.open(parts[-1], READ, dir_fd=d)
        try: return _read(f)[0]
        finally: os.close(f)
    finally: os.close(d)

def _relative_new(root, path, raw, executable=False):
    parts = _parts(path); d = os.dup(root)
    try:
        for p in parts[:-1]:
            nxt = _open_dir(d, p); os.close(d); d = nxt
        _write_new(d, parts[-1], raw, 0o700 if executable else 0o600)
        os.fsync(d)
    finally: os.close(d)

def _relative_replace(root, path, raw, executable=False):
    # Only edits a newly created, not-yet-published revision tree.
    parts = _parts(path); d = os.dup(root)
    try:
        for p in parts[:-1]:
            nxt = _open_dir(d, p); os.close(d); d = nxt
        old = os.open(parts[-1], READ, dir_fd=d)
        try: _regular(old)
        finally: os.close(old)
        temp = '.edit-' + secrets.token_hex(12)
        _write_new(d, temp, raw, 0o700 if executable else 0o600)
        os.rename(temp, parts[-1], src_dir_fd=d, dst_dir_fd=d); os.fsync(d)
    finally: os.close(d)

def _manifest(tree):
    return {'version': 1, 'files': tree['files'], 'dirs': tree['dirs'], 'total': tree['total']}

def _same_manifest(tree, manifest):
    return _manifest(tree) == manifest

def _lock(fd):
    try: _write_new(fd, 'writer.lock', b'Unresolved operation: manual investigation required.\n')
    except FileExistsError: raise CodingError('writer lock exists; do not replay') from None
    os.fsync(fd)

def _unlock(fd):
    os.unlink('writer.lock', dir_fd=fd); os.fsync(fd)

def create(source, task):
    """Create a separate task. Never overwrite an existing path or source files."""
    src_path = _checked_abs(source); task_path = _checked_abs(task)
    if os.path.commonpath((src_path, task_path)) in (src_path, task_path):
        raise CodingError('source and task directories overlap')
    parent, name = os.path.split(task_path); _name(name)
    src = _open_abs(src_path); par = _open_abs(parent); root = revs = rev = tree = None
    try:
        os.mkdir(name, 0o700, dir_fd=par); os.fsync(par); root = _open_dir(par, name); _lock(root)
        os.mkdir('revisions', 0o700, dir_fd=root); revs = _open_dir(root, 'revisions')
        os.mkdir('000000', 0o700, dir_fd=revs); rev = _open_dir(revs, '000000')
        os.mkdir('tree', 0o700, dir_fd=rev); tree = _open_dir(rev, 'tree')
        copied = _walk(src, tree)
        if _walk(src) != copied or _walk(tree) != copied: raise CodingError('source changed during copy')
        manifest = _manifest(copied)
        manifest_bytes = _json_bytes(manifest)
        if len(manifest_bytes) > MAX_MANIFEST: raise CodingError('manifest exceeds limit')
        _write_new(rev, 'manifest.json', manifest_bytes); _write_new(rev, 'diff.txt', b'Initial snapshot; no edits.\n')
        for d in (tree, rev, revs): os.fsync(d)
        _write_new(root, 'state.json', _json_bytes({'version':1, 'status':'ready', 'revision':0, 'source':src_path})); os.fsync(root)
        _unlock(root)
        return manifest
    finally:
        for d in (tree, rev, revs, root, par, src):
            if d is not None: os.close(d)

def _open_revision(revs, n):
    if type(n) is not int or n < 0 or n > 999998: raise CodingError('invalid revision')
    r = _open_dir(revs, f'{n:06d}')
    try:
        m = _load(r, 'manifest.json'); t = _open_dir(r, 'tree')
        try:
            if not _same_manifest(_walk(t), m): raise CodingError('revision differs from manifest')
        except BaseException:
            os.close(t); raise
        return r, t, m
    except BaseException:
        os.close(r); raise

def _render_diff(originals, changes):
    """Bounded unified diff of the exact before/after file bytes, in path order."""
    result = bytearray()
    def append(text):
        raw = text.encode('utf-8')
        if len(result) + len(raw) > MAX_DIFF: raise CodingError('diff exceeds limit')
        result.extend(raw)
    def lf_lines(raw):
        text = raw.decode('utf-8'); chunks = text.split('\n')
        return [chunk+'\n' for chunk in chunks[:-1]] + ([chunks[-1]] if chunks[-1] else [])
    for path in sorted(changes):
        old, new = originals[path], changes[path]
        try:
            a = [] if old is None else lf_lines(old)
            b = lf_lines(new)
        except UnicodeDecodeError:
            raise CodingError('edited files must be UTF-8') from None
        if old is None and not new:
            append('Created empty file: '+path+'\n')
        for line in difflib.unified_diff(a,b,fromfile='/dev/null' if old is None else 'a/'+path,tofile='b/'+path):
            append(line if line.endswith('\n') else line+'\n\\ No newline at end of file\n')
    return bytes(result)


def _render_historical_diff(originals, changes):
    """Recreate the 86c070b5 WIP renderer, for explicit historical review only.

    This old representation can omit an empty-file creation and its CR-only
    display is misleading. It is never the diff returned for review.
    """
    result = bytearray()
    for path in sorted(changes):
        old, new = originals[path], changes[path]
        try:
            a = [] if old is None else old.decode('utf-8').splitlines(keepends=True)
            b = new.decode('utf-8').splitlines(keepends=True)
        except UnicodeDecodeError:
            raise CodingError('edited files must be UTF-8') from None
        for line in difflib.unified_diff(a, b, fromfile='/dev/null' if old is None else 'a/'+path, tofile='b/'+path):
            raw = (line if line.endswith('\n') else line+'\n\\ No newline at end of file\n').encode('utf-8')
            if len(result) + len(raw) > MAX_DIFF: raise CodingError('diff exceeds limit')
            result.extend(raw)
    return bytes(result)


def _compare_revision_trees(old_tree, old, tree, manifest, renderer=_render_diff):
    """Recompute a diff between two verified manifests/trees, without trusting saved diffs."""
    previous, current = old['files'], manifest['files']
    if old['dirs'] != manifest['dirs'] or not previous.keys() <= current.keys():
        raise CodingError('unexpected deletion or directory change')
    originals = {}; changes = {}
    for path in sorted(current):
        before, after = previous.get(path), current[path]
        if before is not None and before['executable'] != after['executable']:
            raise CodingError('unexpected executable mode change')
        if before == after: continue
        old_raw = None if before is None else _relative_read(old_tree, path)
        new_raw = _relative_read(tree, path)
        if ((old_raw is not None and _digest(old_raw) != before['sha256'])
                or _digest(new_raw) != after['sha256']):
            raise CodingError('revision changed while reviewing')
        originals[path] = old_raw; changes[path] = new_raw
    return renderer(originals, changes)


def _verified_review_diff(revs, n, tree, manifest, renderer=_render_diff):
    """Recompute last revision against verified previous tree, not stored diff.

    Manifests and trees are locally writable and are not an authenticity root.
    Concurrent hostile mutation and power-failure consistency are not solved.
    """
    if n == 0: return b'Initial snapshot; no edits.\n'
    prior = old_tree = None
    try:
        prior, old_tree, old = _open_revision(revs, n - 1)
        return _compare_revision_trees(old_tree, old, tree, manifest, renderer)
    finally:
        for fd in (old_tree, prior):
            if fd is not None: os.close(fd)


def _preflight_next_revision(revs, tree, manifest, changes, originals, modes):
    """Validate deterministic bounds for the prospective complete history.

    Called under the cooperative writer lock after the existing history was
    verified. This is a sampled local check, not an atomic filesystem snapshot.
    """
    files=dict(manifest['files']);total=manifest['total']
    for path,raw in changes.items():
        previous=files.get(path)
        if previous is not None:total-=previous['bytes']
        total+=len(raw)
        files[path]={'sha256':_digest(raw),'bytes':len(raw),'executable':modes[path]}
    if len(files)>MAX_FILES or total>MAX_TOTAL:raise ProposalInvalid('next tree exceeds limits')
    predicted={'version':1,'files':files,'dirs':manifest['dirs'],'total':total}
    if len(_json_bytes(predicted))>MAX_MANIFEST:raise ProposalInvalid('next manifest exceeds limit')
    # History review requires a bounded diff from revision zero to the latest
    # revision, not just each adjacent diff. Validate it before marking building.
    first=first_tree=None
    try:
        first,first_tree,baseline=_open_revision(revs,0)
        if baseline['dirs']!=manifest['dirs'] or not baseline['files'].keys()<=files.keys():
            raise CodingError('unexpected deletion or directory change')
        old={};new={}
        for path in sorted(files):
            before=baseline['files'].get(path);after=files[path]
            if before is not None and before['executable']!=after['executable']:
                raise CodingError('unexpected executable mode change')
            if before==after:continue
            old_raw=None if before is None else _relative_read(first_tree,path)
            new_raw=changes[path] if path in changes else _relative_read(tree,path)
            if ((old_raw is not None and _digest(old_raw)!=before['sha256']) or _digest(new_raw)!=after['sha256']):
                raise CodingError('revision changed while preflighting')
            old[path]=old_raw;new[path]=new_raw
        try:_render_diff(old,new)
        except CodingError as e:
            if str(e)=='diff exceeds limit':raise ProposalInvalid(str(e)) from None
            raise
        return predicted
    finally:
        for fd in (first_tree,first):
            if fd is not None:os.close(fd)


def _prepare_edits_locked(revs,tree,manifest,edits):
    """Calculate exact edits/diffs with no writes; caller holds task lock."""
    if not isinstance(edits,list) or not edits or len(edits)>100:
        raise ProposalInvalid('invalid edits')
    if len(_json_bytes(edits))>MAX_PATCH:raise ProposalInvalid('edits exceed limit')
    changes = {}; originals = {}; modes = {}
    for e in edits:
        if not isinstance(e, dict) or set(e) not in ({'path','sha256','old','new'}, {'path','sha256','new'}): raise ProposalInvalid('invalid edit shape')
        path=e['path']; parts=_parts(path)
        if parts[-1] in ('AGENTS.md','CLAUDE.md'): raise ProposalInvalid('instruction file rejected')
        if not isinstance(e['new'], str) or '\x00' in e['new']: raise ProposalInvalid('invalid replacement')
        create_file = set(e)=={'path','sha256','new'}
        if path not in changes:
            if create_file:
                if e['sha256'] is not None or path in manifest['files']: raise ProposalInvalid('create conflict')
                # Existing parent must be in manifest; no implicit directories.
                parent='/'.join(parts[:-1])
                if parent and parent not in manifest['dirs']: raise ProposalInvalid('new file parent missing')
                originals[path]=None; modes[path]=False; changes[path]=b''
            else:
                if path not in manifest['files']: raise ProposalInvalid('file not staged')
                originals[path]=_relative_read(tree, path); changes[path]=originals[path]
                modes[path]=manifest['files'][path]['executable']
        elif create_file:
            raise ProposalInvalid('duplicate create')
        raw=changes[path]
        if not create_file:
            if not isinstance(e['sha256'],str) or not re.fullmatch(r'[0-9a-f]{64}',e['sha256']) or _digest(raw)!=e['sha256']: raise ProposalInvalid('content hash conflict')
            if not isinstance(e['old'],str) or not e['old'] or '\x00' in e['old']: raise ProposalInvalid('invalid old hunk')
            old=e['old'].encode('utf-8'); new=e['new'].encode('utf-8')
            # count() misses overlapping matches, so search a second time from +1.
            at=raw.find(old)
            if at < 0 or raw.find(old, at+1) >= 0: raise ProposalInvalid('hunk must match exactly once')
            raw=raw[:at]+new+raw[at+len(old):]
        else: raw=e['new'].encode('utf-8')
        try: raw.decode('utf-8')
        except UnicodeDecodeError: raise ProposalInvalid('edited files must be UTF-8') from None
        if len(raw)>MAX_FILE: raise ProposalInvalid('edited file exceeds limit')
        changes[path]=raw
    try:rendered=_render_diff(originals, changes)
    except CodingError as e:
        if str(e) in ('diff exceeds limit','edited files must be UTF-8'):raise ProposalInvalid(str(e)) from None
        raise
    predicted=_preflight_next_revision(revs,tree,manifest,changes,originals,modes)
    return changes,originals,modes,rendered,predicted


def propose(task, edits, *, expected_revision=None, expected_manifest=None, _expected_root_fd=None):
    """Build a new revision. Edits list: path, sha256, old, new; or create with sha256 null and new.

    Every hunk targets the exact UTF-8 text occurring once at that operation.
    For multiple hunks on a file each sha256 describes the text before that hunk.
    This only creates a new task revision. It does not touch the original.
    """
    if not isinstance(edits, list) or not edits or len(edits) > 100: raise CodingError('invalid edits')
    if len(_json_bytes(edits)) > MAX_PATCH: raise CodingError('edits exceed limit')
    root = _open_abs(task); revs = rev = tree = newrev = newtree = None; locked = False
    try:
        rootst = os.fstat(root)
        if rootst.st_uid != os.getuid() or rootst.st_mode & 0o077: raise CodingError('task must be private')
        if _expected_root_fd is not None: _same_root(root,_expected_root_fd)
        _lock(root); locked = True
        state = _load(root, 'state.json')
        if not isinstance(state, dict) or state.get('version') != 1 or state.get('status') != 'ready': raise CodingError('task is not ready')
        revs = _open_dir(root, 'revisions'); n = state.get('revision')
        _require_revision_room(n)
        _review_history_locked(state,revs)
        rev, tree, manifest = _open_revision(revs, n)
        if expected_revision is not None and (type(expected_revision) is not int or n != expected_revision): raise CodingError('approved revision changed')
        if expected_manifest is not None and manifest != expected_manifest: raise CodingError('approved manifest changed')
        changes,originals,modes,rendered,predicted=_prepare_edits_locked(revs,tree,manifest,edits)
        nextname=f'{n+1:06d}'
        # Once marked, any failure stays locked/uncertain. Never retry on restart.
        _replace_state(root, {**state,'status':'building','pending_revision':n+1})
        os.mkdir(nextname, 0o700, dir_fd=revs); newrev=_open_dir(revs,nextname)
        os.mkdir('tree',0o700,dir_fd=newrev); newtree=_open_dir(newrev,'tree')
        if not _same_manifest(_walk(tree,newtree),manifest): raise CodingError('source revision changed while copying')
        for path,raw in changes.items():
            if originals[path] is None: _relative_new(newtree,path,raw,modes[path])
            else: _relative_replace(newtree,path,raw,modes[path])
        new_manifest=_manifest(_walk(newtree))
        if new_manifest!=predicted:raise CodingError('new revision differs from preflight')
        new_manifest_bytes=_json_bytes(new_manifest)
        if len(new_manifest_bytes)>MAX_MANIFEST: raise CodingError('manifest exceeds limit')
        _write_new(newrev,'manifest.json',new_manifest_bytes); _write_new(newrev,'diff.txt',rendered)
        for d in (newtree,newrev,revs): os.fsync(d)
        _replace_state(root, {'version':1,'status':'ready','revision':n+1,'source':state['source']})
        _unlock(root); locked=False
        return {'revision':n+1,'manifest':new_manifest,'diff':rendered.decode('utf-8')}
    finally:
        # A rejection before state=building also retains lock, deliberately conservative.
        for d in (newtree,newrev,tree,rev,revs,root):
            if d is not None: os.close(d)

def inspect(task, path=None, offset=0, length=16384, *, historical_wip=False):
    """Verify latest revision and return a canonical diff and optional byte range.

    Explicit historical_wip accepts only the known 86c070b5 WIP diff renderer,
    after both trees verify; it reports that representation and never returns it
    as the review diff. It does not migrate the task or authenticate its origin.
    Content is untrusted data, not loaded into any agent/model.
    """
    import base64
    if type(historical_wip) is not bool: raise CodingError('invalid historical option')
    if type(offset) is not int or type(length) is not int or offset < 0 or not 1 <= length <= 32768:
        raise CodingError('invalid byte range')
    root=_open_abs(task); revs=rev=tree=None; locked=False
    try:
        st=os.fstat(root)
        if st.st_uid!=os.getuid() or st.st_mode & 0o077: raise CodingError('task must be private')
        _lock(root); locked=True
        state=_load(root,'state.json')
        if not isinstance(state,dict) or state.get('version')!=1 or state.get('status')!='ready': raise CodingError('task is not ready')
        revs=_open_dir(root,'revisions');rev,tree,manifest=_open_revision(revs,state.get('revision'))
        # Check the stored artifact as well as returning the freshly recomputed diff.
        # Missing or inconsistent artifacts fail closed and retain the writer lock.
        diff=_verified_review_diff(revs,state['revision'],tree,manifest)
        diff_fd=os.open('diff.txt',READ,dir_fd=rev)
        try: saved_diff,_=_read(diff_fd,MAX_DIFF)
        finally: os.close(diff_fd)
        diff_format = 'canonical'
        if saved_diff != diff:
            if not historical_wip: raise CodingError('stored diff does not match revisions')
            historical = _verified_review_diff(revs,state['revision'],tree,manifest,renderer=_render_historical_diff)
            if saved_diff != historical: raise CodingError('stored diff does not match revisions')
            diff_format = 'historical-wip-86c070b5'
        result={'revision':state['revision'],'manifest':manifest,'diff':diff.decode('utf-8'),'trust':'untrusted project data'}
        if historical_wip:
            result['stored_diff_format'] = diff_format
            result['historical_review_only'] = True
        if path is not None:
            _parts(path)
            if path not in manifest['files']: raise CodingError('file not staged')
            raw=_relative_read(tree,path)
            if _digest(raw)!=manifest['files'][path]['sha256']: raise CodingError('file changed')
            result['file']={'path':path,'sha256':_digest(raw),'bytes':len(raw),'offset':offset,
                            'contentBase64':base64.b64encode(raw[offset:offset+length]).decode('ascii'),
                            'nextOffset':min(len(raw),offset+length) if offset<len(raw) else len(raw)}
        _unlock(root);locked=False
        return result
    finally:
        for fd in (tree,rev,revs,root):
            if fd is not None: os.close(fd)


MAX_HISTORY_REVISIONS = 50

def _require_revision_room(revision):
    # A new revision must remain reviewable by the existing bounded history
    # machinery. Rejections retain the caller's existing post-lock semantics.
    if type(revision) is not int or not 0 <= revision < MAX_HISTORY_REVISIONS - 1:
        raise CodingError('candidate revision limit reached; no new revision')

def _review_history_locked(state, revs):
    """Internal helper; caller owns task lock and revision-directory FD."""
    n = state.get('revision')
    if type(n) is not int or not 0 <= n < MAX_HISTORY_REVISIONS:
        raise CodingError('history exceeds review limit')
    expected = {f'{i:06d}' for i in range(n+1)}
    if set(os.listdir(revs)) != expected:
        raise CodingError('unexpected or missing revision')
    steps = []
    for i in range(n+1):
        rev = tree = None
        try:
            rev, tree, manifest = _open_revision(revs, i)
            diff = _verified_review_diff(revs, i, tree, manifest)
            fd = os.open('diff.txt', READ, dir_fd=rev)
            try: saved, _ = _read(fd, MAX_DIFF)
            finally: os.close(fd)
            if saved != diff: raise CodingError('stored history diff does not match revisions')
            steps.append({'revision':i, 'manifest_sha256':_digest(_json_bytes(manifest)),
                          'diff_sha256':_digest(diff)})
        finally:
            for fd in (tree, rev):
                if fd is not None: os.close(fd)
    first = first_tree = last = last_tree = None
    try:
        first, first_tree, first_manifest = _open_revision(revs, 0)
        last, last_tree, last_manifest = _open_revision(revs, n)
        cumulative = _compare_revision_trees(first_tree, first_manifest, last_tree, last_manifest)
    finally:
        for fd in (last_tree,last,first_tree,first):
            if fd is not None: os.close(fd)
    out = {'revision':n, 'revisions':steps, 'cumulative_diff':cumulative.decode('utf-8'),
           'trust':'Local consistency only; history and project content are untrusted, not authenticated. No code executed or changes applied.'}
    return out


def review_history(task):
    """Offline local-consistency review, not authentication or execution."""
    root = _open_abs(task); revs = None
    try:
        st = os.fstat(root)
        if st.st_uid != os.getuid() or st.st_mode & 0o077:
            raise CodingError('task must be private')
        _lock(root)
        state = _load(root, 'state.json')
        if not isinstance(state,dict) or state.get('version') != 1 or state.get('status') != 'ready':
            raise CodingError('task is not ready')
        revs = _open_dir(root, 'revisions')
        out = _review_history_locked(state, revs)
        _unlock(root)
        return out
    finally:
        for fd in (revs,root):
            if fd is not None: os.close(fd)
