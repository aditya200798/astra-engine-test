"""Bounded diagnostic vocabulary, not authentication, success or safety proof."""
FIELDS={
    'capture':('not_observed','body_examined','body_unavailable'),
    'model':('not_observed','missing','matches_fixture','different_or_invalid'),
    'input':('not_observed','missing','not_array','array'),
    'user_prompt':('not_observed','not_checked','missing_user','multiple_users','exact_string','exact_input_text_array','different_or_invalid'),
    'rejection':('not_observed','none','method','path','authorization','transfer_encoding','length','size','content_type','body_truncated','json_or_schema','duplicate','expect'),
}
def unknown():return {k:'not_observed' for k in FIELDS}
def validate(value):
    if type(value) is not dict or set(value)!=set(FIELDS):raise ValueError('diagnostic fields')
    if any(type(value[k]) is not str or value[k] not in v for k,v in FIELDS.items()):raise ValueError('diagnostic category')
    if value['capture']!='body_examined' and any(value[k]!='not_observed' for k in ('model','input','user_prompt')):raise ValueError('diagnostic reachability')
    if value['capture']=='body_examined' and (value['model']=='not_observed' or value['input']=='not_observed') :raise ValueError('diagnostic reachability')
    if value['capture']=='body_examined':
        if value['input']=='array' and value['user_prompt'] not in ('missing_user','multiple_users','exact_string','exact_input_text_array','different_or_invalid'):raise ValueError('diagnostic reachability')
        if value['input']!='array' and value['user_prompt']!='not_checked':raise ValueError('diagnostic reachability')
    return dict(value)


def validate_context(value, *, control, flow_stage, owner_stage, owner_reason,
                     start_phase, start_error, record, stop):
    """Finite labels only after the existing owner sampled a failed record.

    These are reachability checks, not provenance, authenticated labels or
    launch permission. No claim about a later cleanup is made here.
    """
    value=validate(value)
    if value!=unknown():
        expected=('unknown','owner_returned_cleanup_unverified','finished',
                  'inner_exit_mismatch','complete','not_observed','received',
                  'job_done_inactive_snapshot')
        actual=(control,flow_stage,owner_stage,owner_reason,start_phase,start_error,record,stop)
        if actual!=expected or any(type(x) is not str for x in actual):
            raise ValueError('failure evidence lifecycle')
    return value
