"""Genuine blocked-driver supervisor composition; NOT launch authorization.

Uses the separately forked staging and service watchdog machinery, but always
reports un-reconciled manager jobs and unverified cleanup. A disposable VM with
an independently controlled outer deadline/teardown is mandatory. Never invoke
on a shared host, user device, or with real provider credentials.
"""
from . import genuine_control_flow as flow
from . import synthetic_no_engine_supervisor as common

_BLOCKED=True
class SupervisorError(RuntimeError):pass

def _supervise(controller,timeout=120,*,staging_guard):
    if type(controller) is not flow._ControlFlow:
        raise SupervisorError('genuine control required')
    # Unlike legacy no-engine tests, a separate guard is mandatory.
    try:
        return common._supervise_common(controller,timeout,staging_guard=staging_guard,genuine=True)
    except common.SupervisorError as exc:
        raise SupervisorError('genuine supervision unavailable; external recovery required') from exc

def run():
    if _BLOCKED:raise SupervisorError('genuine supervisor blocked; outside recovery unverified')
    raise SupervisorError('no approved orchestration')
