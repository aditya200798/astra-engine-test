"""Finite projection of local coding-assembly observations; not a supervisor.

Not wired to the existing target's output channel; never upgrades unknown,
claims isolation, authentication, cleanup, or permission for engine launch.
"""
from astra.policy import json_equal

_EXPECTED={'session_status':'succeeded','candidate':'revision_1_static_python_passed',
 'source_apply':'not_done','candidate_execution':'not_done','fixture_valid_attempts':1,
 'fixture_user_prompt_matches':True,'fixture_response_delivery':'write_completed_not_client_receipt',
 'genuine_engine':'not_attested','isolation':'not_verified',
 'descendant_cleanup':'not_verified','all_network_traffic':'not_observed'}

def project(evidence):
    try:
        if (type(evidence) is not dict or evidence.get('stage')!='assembled_observation_complete'
            or evidence.get('fixture_final_check')!='passed' or evidence.get('fixture_thread_stopped') is not True
            or evidence.get('session_worker_call')!='call_completed'
            or not json_equal(evidence.get('session_report'),_EXPECTED)):
            raise ValueError('incomplete observation')
        result='candidate_observed'
    except Exception:
        result='not_observed_or_uncertain'
    return {'schema':'astra-coding-observation-v1','result':result,'synthetic_only':True,
            'engine_launch_authorized':False,'genuine_engine':'not_attested',
            'isolation':'not_verified','descendant_cleanup':'not_verified',
            'external_supervisor_cleanup':'not_observed','production_approved':False}
