"""Private fixed archive download and binary staging; NOT a launch gate.

Only in a fresh, disposable synthetic VM. Parent must guard this entire
function in a separate enrolled process, and own exclusive directory ancestors.
No retries. Source digest is historical byte identity, not provenance.
"""
import hashlib
import os
import stat
import time
import urllib.parse
import urllib.request
from . import pinned_engine_stage as pin

_BLOCKED=True
_URL='https://github.com/anomalyco/opencode/releases/download/v2.3.2/opencode-linux-x64.tar.gz'
_ALLOWED={'github.com','release-assets.githubusercontent.com'}

class AcquireError(RuntimeError):pass
class _Redirect(urllib.request.HTTPRedirectHandler):
    def __init__(self): self.count=0
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        self.count+=1
        p=urllib.parse.urlsplit(newurl)
        if (self.count>3 or p.scheme!='https' or p.hostname not in _ALLOWED or
            p.username is not None or p.password is not None or p.port not in (None,443) or p.fragment):
            raise AcquireError('redirect refused')
        return super().redirect_request(req,fp,code,msg,headers,newurl)

def _private(fd):
    st=os.fstat(fd)
    if (not stat.S_ISDIR(st.st_mode) or st.st_uid!=os.geteuid() or
        stat.S_IMODE(st.st_mode)!=0o700 or os.listdir(fd)):
        raise AcquireError('fresh private directory required')
    return (st.st_dev,st.st_ino)

def _copy(response,fd,size,digest,deadline):
    if response.status!=200:raise AcquireError('status')
    if response.headers.get('Content-Encoding','identity').lower()!='identity':raise AcquireError('encoding')
    length=response.headers.get('Content-Length')
    if length is not None and (not length.isdigit() or int(length)!=size):raise AcquireError('length')
    sha=hashlib.sha256();total=0
    while True:
        if time.monotonic()>=deadline:raise AcquireError('deadline')
        data=response.read(min(1024*1024,size+1-total))
        if not data:break
        total+=len(data)
        if total>size:raise AcquireError('oversize')
        sha.update(data);view=memoryview(data)
        while view:
            n=os.write(fd,view)
            if n<=0:raise AcquireError('write')
            view=view[n:]
    if total!=size or sha.hexdigest()!=digest or time.monotonic()>=deadline:raise AcquireError('digest, length or deadline')

def _acquire(archive_fd,engine_fd,timeout=95):
    """Download once, stage exactly pinned archive; only callable under guard.

    Held directory descriptors and no-follow leaf opens avoid pathname
    re-resolution; no protection from other writers with root/same UID or
    malicious mounts. Timeout in this
    process is advisory; parent guard/outer VM deadline handle slow syscalls.
    Partial output is never reused. Input FDs are caller-owned.
    """
    if (type(timeout) not in (int,float) or not 1<=timeout<=100 or
        type(archive_fd) is not int or type(engine_fd) is not int or archive_fd==engine_fd):
        raise AcquireError('inputs')
    if _private(archive_fd)==_private(engine_fd):raise AcquireError('alias')
    deadline=time.monotonic()+timeout
    fd=None
    try:
        fd=os.open('release.tar.gz',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o400,dir_fd=archive_fd)
        os.fchmod(fd,0o400)
        opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),_Redirect())
        req=urllib.request.Request(_URL,headers={'Accept-Encoding':'identity','User-Agent':'astra-synthetic-pin/1'})
        with opener.open(req,timeout=12) as response:
            _copy(response,fd,pin.ARCHIVE_SIZE,pin.ARCHIVE_SHA256,deadline)
        os.fsync(fd);os.close(fd);fd=None;os.fsync(archive_fd)
        if time.monotonic()>=deadline:raise AcquireError('deadline')
        result=pin.stage_pinned_held_directories(archive_fd,engine_fd)
        if time.monotonic()>=deadline or result['executed'] is not False or result['engine_launch_authorized'] is not False:
            raise AcquireError('stage deadline or contract')
        return {'archive':'fixed_download_and_binary_rehashed','execution':False,'engine_launch_authorized':False}
    except Exception:
        raise AcquireError('acquisition or stage failed; dispose VM tree, no retry') from None
    finally:
        if fd is not None:os.close(fd)

def run():
    if _BLOCKED:raise AcquireError('genuine archive acquisition blocked')
    raise AcquireError('no approved orchestration')
