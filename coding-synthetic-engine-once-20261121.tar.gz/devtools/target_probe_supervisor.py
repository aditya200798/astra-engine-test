"""Private diagnostic-only probe supervisor, never launch authority.

Requires an exclusive disposable synthetic VM and an independently enforced
whole-VM deadline/disposal. Canary and worker are separate processes; monitored
heartbeats and pidfds are sampled, not continuous or atomic isolation proof.
Public entry remains blocked. No real engine or provider is invoked here.
"""
import os,select,socket,struct,time
from . import cgroup_watchdog as cg,synthetic_no_engine_supervisor as common
from . import target_probe_canaries as canaries,target_probe_flow as flow
_BLOCKED=True
class SupervisorError(RuntimeError):pass

def _challenge(channel,pidfd,deadline,*,expected_identity=None):
    # One outstanding request, never accept unsolicited, stale or truncated
    # packets. Time is measured from before issuance, never from dequeue alone.
    start=time.monotonic();end=min(deadline,start+3)
    if end<=start:raise SupervisorError('challenge deadline')
    r,_,_=select.select([channel,pidfd],[],[],0)
    if r:raise SupervisorError('unexpected canary packet or death')
    nonce=os.urandom(32);packet=b'H'+nonce
    r,w,_=select.select([pidfd],[channel],[],max(0,end-time.monotonic()))
    if r or not w or time.monotonic()>=end:raise SupervisorError('challenge send deadline')
    if channel.send(packet)!=len(packet):raise SupervisorError('challenge send')
    r,_,_=select.select([channel,pidfd],[],[],max(0,end-time.monotonic()))
    if pidfd in r or channel not in r or time.monotonic()>=end:raise SupervisorError('challenge response deadline')
    data,anc,flags,_=channel.recvmsg(50,0)
    if (anc or flags&(socket.MSG_TRUNC|socket.MSG_CTRUNC) or len(data)!=49 or
        data[:33]!=packet or time.monotonic()>=end):
        raise SupervisorError('invalid canary response')
    identity=struct.unpack('!QQ',data[33:])
    if identity[1]==0 or (expected_identity is not None and
        (type(expected_identity) is not tuple or len(expected_identity)!=2 or
         any(type(x) is not int for x in expected_identity) or identity!=expected_identity)):
        raise SupervisorError('canary path identity changed')
    cg._require_watchdog_alive(pidfd)
    if time.monotonic()>=end:raise SupervisorError('challenge deadline')
    return start,identity

def _canary_child(channel,deadline):
    c=canaries._Canaries();last_identity=None
    try:
        c.start_once()
        if channel.send(b'R')!=1:raise ValueError('readiness')
        while True:
            left=deadline-time.monotonic()
            if left<=0:raise TimeoutError()
            ready,_,_=select.select([channel],[],[],left)
            if not ready:raise TimeoutError()
            data,anc,flags,_=channel.recvmsg(34,0)
            if anc or flags&(socket.MSG_TRUNC|socket.MSG_CTRUNC):raise ValueError('control')
            if data in (b'',b'Q'):
                if data==b'':
                    c.close_once()
                    return 0
                # One final live sample before capturing markers and closing.
                # A probe/foreign connection can have queued since the prior H;
                # omitting this check could report a stale marker mask. The
                # sample is still racy, not an atomic queue/close guarantee.
                identity=c.sample_live()
                if (last_identity is None or identity!=last_identity or
                    time.monotonic()>=deadline):raise ValueError('final liveness')
                # Public diagnostic evidence, not peer authentication.
                seen=c.probe_seen
                if type(seen) is not list or len(seen)!=3 or any(type(v) is not bool for v in seen):raise ValueError('canary evidence')
                mask=sum((1<<i) for i,v in enumerate(seen) if v)
                c.close_once()
                if data==b'Q' and channel.send(b'C'+bytes([mask]))!=2:raise ValueError('close')
                return 0
            if len(data)!=33 or data[:1]!=b'H':raise ValueError('control')
            identity=c.sample_live()
            if (type(identity) is not tuple or len(identity)!=2 or
                any(type(x) is not int or not 0<=x<2**64 for x in identity) or identity[1]==0):
                raise ValueError('canary identity')
            if last_identity is not None and identity!=last_identity:raise ValueError('identity changed')
            last_identity=identity
            reply=data+struct.pack('!QQ',*identity)
            if time.monotonic()>=deadline or channel.send(reply)!=len(reply):raise ValueError('sample deadline')
    except BaseException:
        try:
            if c.state=='live_sampled':c.close_once()
        except BaseException:pass
        return 1

def _matched_controls(sample,mask):
    """Fail closed on missing exposed-socket positive or contradictory markers.

    The public marker is not authentication; this only correlates bounded
    synthetic samples on an exclusive VM. It does not prove confinement.
    """
    from .target_probe_entry import _validate
    _validate(sample)
    if type(mask) is not int or not 0<=mask<=7:raise SupervisorError('canary evidence')
    keys=('pathname_socket','abstract_socket','network_canary')
    if sample['pathname_socket']!='connected':raise SupervisorError('exposed path positive control missing')
    for i,key in enumerate(keys):
        val=sample[key]
        if val not in ('connected','not_connected') or bool(mask & (1<<i))!=(val=='connected'):
            raise SupervisorError('contradictory or uncertain canary sample')

def _supervise(controller,timeout=120,*,staging_guard):
    if type(controller) is not flow._Flow:raise SupervisorError('exact probe flow required')
    # A consumed controller or unavailable guard cannot start any canary.
    if controller._used or type(staging_guard) is not cg.Guard or staging_guard.finished:
        raise SupervisorError('controller or guard unavailable')
    if type(timeout) not in (int,float) or not .1<=timeout<=120:
        controller._used=True;raise SupervisorError('deadline')
    start=time.monotonic();deadline=start+timeout;parent=child=None;pidfd=None;pid=None;result=None
    clean=False;mask=None
    try:
        parent,child=socket.socketpair(socket.AF_UNIX,socket.SOCK_SEQPACKET|socket.SOCK_CLOEXEC)
        pid=os.fork()
        if pid==0:
            parent.close()
            for item in os.listdir('/proc/self/fd'):
                fd=int(item)
                if fd!=child.fileno():
                    try:os.close(fd)
                    except OSError:pass
            os._exit(_canary_child(child,deadline))
        child.close();child=None;pidfd=os.pidfd_open(pid,0)
        ready,_,_=select.select([parent,pidfd],[],[],max(0,min(5,deadline-time.monotonic())))
        if pidfd in ready or parent not in ready or parent.recv(2)!=b'R':raise SupervisorError('canary readiness unavailable')
        cg._require_watchdog_alive(pidfd)
        parent.setblocking(False)
        _,identity=_challenge(parent,pidfd,deadline)
        left=deadline-time.monotonic()
        if left<.1:raise SupervisorError('deadline')
        result=common._supervise_common(controller,left,staging_guard=staging_guard,probe=True,canary_pidfd=pidfd,canary_channel=parent,canary_identity=identity)
        # The monitor itself must close its owned paths and exit successfully;
        # neither this nor an empty cgroup proves VM cleanup.
        if parent.send(b'Q')!=1:raise SupervisorError('canary close request uncertain')
        end=min(deadline,time.monotonic()+3)
        while time.monotonic()<end:
            r,_,_=select.select([parent,pidfd],[],[],end-time.monotonic())
            if parent in r:
                msg,anc,flags,_=parent.recvmsg(3,0)
                if not anc and not flags&(socket.MSG_TRUNC|socket.MSG_CTRUNC) and len(msg)==2 and msg[:1]==b'C' and msg[1]<=7:
                    clean=True;mask=msg[1];break
                break
            if pidfd in r and parent not in r:break
        status=common._wait_reap(pidfd,max(0,min(1,deadline-time.monotonic())))
        if not clean or status!=(os.CLD_EXITED,0):raise SupervisorError('canary cleanup uncertain')
        # After child exit, require a true peer EOF, not just a valid close
        # acknowledgement. Enabling SO_PASSCRED here also distinguishes an
        # already-queued zero-length datagram from EOF; credentials frame only,
        # never authenticate a peer. The common receiver rejects ancillary FDs.
        parent.setsockopt(socket.SOL_SOCKET,socket.SO_PASSCRED,1)
        if common._recv_worker_packet(parent) is not None:raise SupervisorError('trailing canary control packet')
        os.close(pidfd);pidfd=None
        if controller.nobind:
            if result.get('control')=='nobind_pending':
                pending=result.pop('_nobind_pending',None)
                from .target_probe_nobind_packet_lab import Supervisor as NoBindState
                if type(pending) is not NoBindState:raise SupervisorError('missing case state')
                final=pending.finish(mask)
                result['control']=final['control'];result['sample']=final['sample']
            elif result.get('control')!='unknown':raise SupervisorError('cross-case result')
        else:
            if result.get('control')=='probe_record_and_exit_sampled':_matched_controls(result.get('sample'),mask)
            elif result.get('control')!='unknown':raise SupervisorError('cross-case result')
        result['canary_lifecycle']='live_checks_and_close_sampled'
        return result
    except BaseException:
        controller._used=True
        # Supervisor setup can fail before consuming the guard. Explicitly
        # trigger its watchdog; an independently owned VM must still be torn down.
        if not staging_guard.finished:
            try:staging_guard.finish()
            except BaseException:pass
        return {'control':'unknown','canary_lifecycle':'uncertain','cleanup':'not_verified',
                'isolation':'not_verified','engine_launch_authorized':False,'production_approved':False,
                'external_recovery':'required','late_start':'not_reconciled'}
    finally:
        if child is not None:child.close()
        if parent is not None:parent.close()
        if pidfd is not None:
            cg._stop_setup_child(pidfd);os.close(pidfd)

def run():
    if _BLOCKED:raise SupervisorError('target supervisor blocked')
    raise SupervisorError('no approved orchestration')
