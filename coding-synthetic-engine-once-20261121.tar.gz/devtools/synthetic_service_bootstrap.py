"""Fixed inner bootstrap, *not* a supervisor, root builder or authorization.

Intended service invocation: /usr/bin/python3 -I -S
/app/devtools/synthetic_service_bootstrap.py baseline|integration. The root,
interpreter, stdlib, /app and /work must already be provisioned and inspected
by a separately reviewed outside supervisor. Both drivers remain hard-blocked.
"""
import os
import sys

_ENV = {'PATH':'/usr/bin:/bin', 'HOME':'/work/home', 'TMPDIR':'/work/tmp',
        'LANG':'C', 'LC_ALL':'C'}


def main():
    # Isolated mode suppresses PYTHONPATH, user site and script/current paths;
    # -S avoids site customizations. Refuse before importing project code.
    if sys.flags.isolated != 1 or sys.flags.no_site != 1 or len(sys.argv) != 2:
        return 2
    mode = sys.argv[1]
    if mode not in ('baseline','integration'):
        return 2
    # System managers add e.g. INVOCATION_ID/USER. Replace, never merge.
    # This does not protect the interpreter and dynamic loader before Python
    # starts, or attest that project files are immutable or trustworthy.
    os.environ.clear()
    os.environ.update(_ENV)
    if dict(os.environ) != _ENV:
        return 2
    # Resolve only the bootstrap's own staged package to import the admission
    # barrier. No entry or driver is imported until the barrier has succeeded.
    app = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    sys.path.insert(0,app)
    from devtools.synthetic_service_barrier import receive_on_stdin
    # Fixed readiness marker on the privately owned stderr pipe; only for the
    # no-engine control. It means imports have completed, not authorization.
    # Parent consumes exactly this marker before process observation.
    marker=b'ASTRA-NO-ENGINE-READY-1\n'
    if os.write(2,marker)!=len(marker):return 2
    receive_on_stdin()
    # Derive our enclosing app directory. The *future fixed unit* must pin
    # /app and establish protected mounts and expected source hash; this
    # calculation alone does not enforce any trust or file provenance.
    # Entry main() itself takes no arguments. Only two fixed modules exist.
    sys.argv[:] = [sys.argv[0]]
    if mode == 'baseline':
        from devtools.baseline_entry import main as entry
        from devtools import fixed_baseline_driver as driver
    else:
        from devtools.synthetic_entry import main as entry
        from devtools import fixed_integration_driver as driver
    # Preserve the current blocked-entry behavior. If a separately reviewed
    # future change unblocks a driver, fixed /work preparation must complete
    # once before that entry starts; no reinitialization or retry is permitted.
    if driver._LAUNCH_BLOCKED is not True:
        from devtools.genuine_run_layout import prepare_fixed_service_work
        prepare_fixed_service_work()
    return entry()


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (Exception,KeyboardInterrupt):
        # Do not leak raw exception, path, environment or traceback.
        raise SystemExit(2) from None
