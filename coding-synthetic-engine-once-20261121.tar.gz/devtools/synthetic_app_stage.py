"""Stage pinned synthetic Python sources, not a launcher, root or sandbox.

Caller owns source/destination descriptors, excludes concurrent writers and
must dispose the synthetic tree after all processes stop. This snapshots local
reviewed bytes, not upstream provenance or a runtime admission decision.
"""
import hashlib
import os
import stat

MANIFEST = {
    'astra/__init__.py': 'c2a5d744820c3c777a6431749c9f4e05fa039b75bcf9efe31eda0d96324d927e',
    'astra/policy.py': 'ad56393d7a1c7d7ea35ed22a014adb76d3e812ab93cab1efaf2e1acdd08aebe5',
    'astra/session.py': 'b0db6fdc86d41a77a6a9215b10dd88a693f6756642dd4f538420fda1a460329a',
    'astra/storage.py': '06815d63cff5a11b4dc2e2cb7acee6b98003ec474062a265f5624e96749e8df0',
    'astra/transport.py': 'd7a09599d564c5866f3a4416d45e04be9db61ee78a774dd1bc5551a5ae382e84',
    'devtools/baseline_config_observer.py': '2a82557e15de4e7e31e2c6a3b04acbcb3879f7583305953ab725cebd91378fcb',
    'devtools/baseline_controller.py': '076312d081942cd43fa88f4fcdfc686c005ed7ae274360a9ed0cf98d17758c7f',
    'devtools/baseline_entry.py': 'a07276b6beac6a037bb1776d51b8d427b580dc81969703840be7c3f9c750176f',
    'devtools/baseline_only.py': 'b3cf1d862583ea02de5229bc80a3cb62c78bd9041ef027c3f06a022f855cdc56',
    'devtools/engine_controller.py': '25cf11a4fef1113b62991697c59aeef1dccdd03813184f6ecd721ec0592f4b86',
    'devtools/fake_responses.py': 'aee9693881a04781ce6fc4e47a10dc8549c94bd22df00bacdc36889fb1d98371',
    'devtools/fixed_baseline_driver.py': '2f0afe8303be8e8975d1c358b5a5adb09686a70308fc9951e2017f2306d0cdf5',
    'devtools/fixed_integration_driver.py': '22bcc34638716d24cd2b249091993c99b47e3d8031a92258826d9524f415f0e0',
    'devtools/genuine_service_bootstrap.py': 'e737ccb80edef11acd881569c6b4043ea923f0027dec97607b7318139136a98a',
    'devtools/genuine_run_layout.py': '9ff8bfb2f342a8c08059f7b290e592bf6a44802dc5f57a0715497b13a116defb',
    'devtools/integration_evidence.py': 'b389974534fccd71d0d3bca370b35229d305d0cf4f75adac3d8e6bf98cb36838',
    'devtools/listener_observer.py': 'e7f995542b6fe28894ef095d59e1c9295092b9bd79c3243747b6b6f18512095a',
    'devtools/synthetic_baseline_gate.py': '2813481a66f7b9a7f1cef3936b5b138db2d3fb378c487f57a2b3cb2c08788a4c',
    'devtools/synthetic_entry.py': '6db75077d98c1f7c4f38ca8ece2e9ca177b189d981b7b5c2dcb1bf214f9a5f12',
    'devtools/synthetic_integration.py': '8433b6de9afbd59db78e3af10f9c01fbffd60ae1d041eb3001aabf5864fae063',
    'devtools/synthetic_service_barrier.py': '27ae6bd26060363076b5ef0bebd66550787ea27df04b70eedd3baf9159e17ec4',
    'devtools/target_probe_bootstrap.py': '344cc31f8e7ffd7e0ecb9d81c4c0f14819baead344f09f443985f724430ae124',
    'devtools/target_probe_entry.py': '8c3dacc0b6465466e4b65d17a64c27df7ed639e2d765c3c3c8589915c62a409b',
    'devtools/target_boundary_probe.py': '9377c03e2a79a35ff76220e077faeb94c622cfeaf3ac89a2eb08e37e409664ff',
    'devtools/synthetic_service_bootstrap.py': '87bbfbe89e1eb274fdab1ee7f3bc25eb5634dede47d46120b5a6370d5c0ffc81',
    'devtools/synthetic_failure_evidence.py': '7a812a46c3f282e315831466eea75941102ebd32a368fcc9313f4e8c11456429',
    'devtools/synthetic_request_diagnostics.py': '3dff412661a30b4c24c7beb728f31ff16e32a243ce67b3ff7e4f51539fde4c1b',
    'devtools/synthetic_session_probe.py': 'a5616067d74bd9efc49c2f226efb4ea06c79f55584b4ac6dfd6b672cfc760196',
}
MAX_SOURCE=1_000_000
MAX_TOTAL=4_000_000
class StageError(RuntimeError): pass

def _identity(st):
    return (st.st_dev,st.st_ino,st.st_mode,st.st_uid,st.st_nlink,st.st_size,st.st_mtime_ns,st.st_ctime_ns)

def stage_into_empty_private_directory(source_fd, destination_fd):
    """FD-only fixed copy; rollback is best effort, never a containment proof.

    No symlink leaves, hardlinked source files or nonempty/nonprivate output.
    Only destination leaves are created. No guarantees about parent paths,
    ACLs, concurrent root/same-UID writers, mounts or writable aliases.
    """
    if type(source_fd) is not int or type(destination_fd) is not int or min(source_fd,destination_fd)<0:
        raise StageError('directory descriptors required')
    sources={}; dirs={}; made=[]; payloads={}; success=False; uncertain=False
    try:
        if not all(hasattr(os,x) for x in ('O_NOFOLLOW','O_DIRECTORY','O_CLOEXEC')): raise ValueError('unsupported')
        src=os.fstat(source_fd); dst=os.fstat(destination_fd)
        if (not stat.S_ISDIR(src.st_mode) or not stat.S_ISDIR(dst.st_mode) or dst.st_uid!=os.geteuid()
            or stat.S_IMODE(dst.st_mode)!=0o700 or os.listdir(destination_fd)):
            raise ValueError('invalid destination')
        flags=os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC
        for package in ('astra','devtools'): sources[package]=os.open(package,flags,dir_fd=source_fd)
        total=0
        for path,want in sorted(MANIFEST.items()):
            package,name=path.split('/')
            fd=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK,dir_fd=sources[package])
            try:
                before=os.fstat(fd)
                if not stat.S_ISREG(before.st_mode) or before.st_nlink!=1 or not 0<=before.st_size<=MAX_SOURCE:
                    raise ValueError('invalid source')
                data=bytearray()
                while len(data)<=MAX_SOURCE:
                    part=os.read(fd,min(65536,MAX_SOURCE+1-len(data)))
                    if not part: break
                    data.extend(part)
                total+=len(data); named=os.stat(name,dir_fd=sources[package],follow_symlinks=False)
                if (len(data)!=before.st_size or total>MAX_TOTAL or _identity(os.fstat(fd))!=_identity(before)
                    or (named.st_dev,named.st_ino)!=(before.st_dev,before.st_ino)
                    or hashlib.sha256(data).hexdigest()!=want): raise ValueError('source changed')
                payloads[path]=bytes(data)
            finally: os.close(fd)
        for package in ('astra','devtools'):
            os.mkdir(package,0o700,dir_fd=destination_fd); made.append((None,package))
            dirs[package]=os.open(package,flags,dir_fd=destination_fd); os.fchmod(dirs[package],0o700)
        for path,data in sorted(payloads.items()):
            package,name=path.split('/')
            fd=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=dirs[package])
            made.append((package,name))
            try:
                view=memoryview(data)
                while view:
                    written=os.write(fd,view)
                    if written<=0: raise OSError('write failed')
                    view=view[written:]
                os.fchmod(fd,0o400); os.fsync(fd); st=os.fstat(fd)
                if not stat.S_ISREG(st.st_mode) or st.st_nlink!=1 or st.st_size!=len(data) or stat.S_IMODE(st.st_mode)!=0o400:
                    raise ValueError('invalid staged file')
            finally: os.close(fd)
        for fd in dirs.values(): os.fsync(fd)
        os.fsync(destination_fd); success=True
        return {'files':len(payloads),'bytes':sum(map(len,payloads.values())),
                'manifest':'fixed_local_digests_matched','executable_started':False,
                'engine_launch_authorized':False,'isolation':'not_verified',
                'provenance':'not_verified','runtime_dependencies':'not_staged',
                'cleanup':'caller_required'}
    except (OSError,ValueError,TypeError,KeyError):
        raise StageError('app stage failed; inspect destination and do not launch') from None
    finally:
        if not success:
            for package,name in reversed(made):
                try:
                    if package is None: os.rmdir(name,dir_fd=destination_fd)
                    else: os.unlink(name,dir_fd=dirs[package])
                except OSError: uncertain=True
        for fd in dirs.values(): os.close(fd)
        for fd in sources.values(): os.close(fd)
        if uncertain: raise StageError('app stage failed; rollback uncertain; dispose destination') from None
