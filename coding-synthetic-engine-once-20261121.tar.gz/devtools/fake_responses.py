"""Developer-only, one-shot synthetic Responses provider component; no launcher.

Not isolation or an engine harness. Run only on a separately isolated, disposable
machine with synthetic requests. Request contents are kept in process memory.
"""
import hashlib
import json
import math
import socket
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer

MAX_REQUEST_BYTES = 262_144
SOCKET_TIMEOUT = 3.0
REQUEST_WALL_TIMEOUT = 5.0
MAX_HANDLED_CONNECTIONS = 4
MAX_RESPONSE_EVENTS_BYTES = 8192
SYNTHETIC_KEY = 'astra-synthetic-fixture-key'
MODEL = 'astra-fixture-model'
ANSWER = 'ASTRA_SYNTHETIC_RESPONSE_OK'


def _strict_json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError('duplicate key')
            result[key] = value
        return result
    def invalid_constant(_):
        raise ValueError('non-finite number')
    def finite_float(value):
        result = float(value)
        if not math.isfinite(result):
            raise ValueError('non-finite number')
        return result
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=invalid_constant,
                      parse_float=finite_float)


def response_events():
    """Fixed SSE text scenario; upstream-source-inspired, compatibility unproved."""
    item = {'type': 'message', 'id': 'msg_astra_fixture', 'status': 'completed',
            'role': 'assistant', 'content': [{'type': 'output_text', 'text': ANSWER,
                                             'annotations': [], 'logprobs': []}]}
    events = [
        {'type': 'response.created', 'response': {'id': 'resp_astra_fixture'}},
        {'type': 'response.output_item.added', 'output_index': 0,
         'item': {'type': 'message', 'id': 'msg_astra_fixture'}},
        {'type': 'response.output_text.delta', 'item_id': 'msg_astra_fixture', 'delta': ANSWER},
        {'type': 'response.output_text.done', 'item_id': 'msg_astra_fixture', 'text': ANSWER},
        {'type': 'response.output_item.done', 'output_index': 0, 'item': item},
        {'type': 'response.completed', 'response': {'id': 'resp_astra_fixture',
             'output': [item], 'usage': {'input_tokens': 1, 'output_tokens': 1}}},
    ]
    return b''.join(b'data: ' + json.dumps(e, separators=(',', ':'), ensure_ascii=True).encode('ascii') + b'\n\n' for e in events)


class Ledger:
    """At-most-once admission, independent of response transport success."""
    def __init__(self):
        self._lock = threading.Lock()
        self._record = None
        self._attempts = 0
        self._http_attempts = 0
        self._http_rejections = 0
        self._last_rejection = None
        self._handled_connections = 0
        self._connection_slots = 0
        self._refused_connections = 0
        self._wall_timeouts = 0
        self._first_shape = None

    def reserve_connection(self):
        # One fixed total budget for sockets accepted by this server. A socket
        # not yet accepted, kernel backlog, or external traffic is not counted.
        with self._lock:
            if self._connection_slots >= MAX_HANDLED_CONNECTIONS:
                self._refused_connections = min(1_000_000, self._refused_connections + 1)
                return False
            self._connection_slots += 1
            return True

    def wall_timeout(self):
        with self._lock:
            self._wall_timeouts = min(1_000_000, self._wall_timeouts + 1)

    def connection_seen(self):
        # Accepted and dispatched connections, including empty, malformed and
        # unsupported requests. Does not count a socket still queued at shutdown.
        with self._lock:
            self._handled_connections = min(1_000_000, self._handled_connections + 1)

    def request_seen(self):
        # Counts only requests which reach GET/POST handlers, not parse errors,
        # unsupported methods, sockets or other traffic. Saturation is explicit.
        with self._lock:
            self._http_attempts = min(1_000_000, self._http_attempts + 1)

    def rejected(self, reason):
        allowed = {'method', 'path', 'authorization', 'transfer_encoding',
                   'length', 'size', 'content_type', 'body_truncated',
                   'json_or_schema', 'duplicate', 'expect'}
        if reason not in allowed: raise ValueError('invalid diagnostic reason')
        with self._lock:
            self._http_rejections = min(1_000_000, self._http_rejections + 1)
            self._last_rejection = reason

    def note_body(self, raw):
        # Fixed categories only; keep the first body, never append raw values.
        from . import synthetic_request_diagnostics as shape
        from . import synthetic_failure_evidence as vocabulary
        try:
            value=shape.diagnose(raw)
            if value['status']=='examined':
                record={'capture':'body_examined', 'model':value['model'], 'input':value['input'],
                        'user_prompt':value['user_prompt'], 'rejection':'not_observed'}
            else:
                record={**vocabulary.unknown(),'capture':'body_unavailable'}
            vocabulary.validate(record)
        except Exception:
            record={**vocabulary.unknown(),'capture':'body_unavailable'}
        with self._lock:
            if self._first_shape is None:self._first_shape=record

    def failure_shape(self):
        # Snapshot is non-atomic with other lifecycle evidence and peer identity.
        from . import synthetic_failure_evidence as vocabulary
        with self._lock:
            out=dict(self._first_shape) if self._first_shape else vocabulary.unknown()
            out['rejection']=self._last_rejection if self._last_rejection else 'none'
        return vocabulary.validate(out)

    def diagnostics(self):
        # Never includes request headers, URL, body, or exception details.
        with self._lock:
            return {'handled_connections': self._handled_connections,
                    'handled_http_requests': self._http_attempts,
                    'handled_rejections': self._http_rejections,
                    'refused_connections': self._refused_connections,
                    'wall_timeouts': self._wall_timeouts,
                    'last_rejection': self._last_rejection,
                    'scope': 'accepted_handler_connections_only'}

    def admit(self, raw):
        with self._lock:
            self._attempts += 1
            if self._record is not None:
                return False
            self._record = {'raw': bytes(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                            'bytes': len(raw), 'response_delivery': 'unknown'}
            return True

    def delivered(self):
        with self._lock:
            self._record['response_delivery'] = 'write_completed_not_client_receipt'

    def snapshot(self):
        with self._lock:
            return None if self._record is None else {**self._record, 'valid_attempts': self._attempts}


class FixtureHTTPServer(HTTPServer):
    """One-at-a-time request handler; caller supplies explicit loopback address.

    Binding loopback does not prevent outbound connections from other processes.
    Caller must separately enforce network isolation and ensure no secrets exist.
    """
    allow_reuse_address = False
    def __init__(self, address):
        if (not isinstance(address, tuple) or len(address) != 2 or address[0] != '127.0.0.1'
                or type(address[1]) is not int or not 0 <= address[1] <= 65535):
            raise ValueError('literal IPv4 loopback and port required')
        self.ledger = Ledger()
        super().__init__(address, FixtureHandler)

    def verify_request(self, request, client_address):
        # Refuse excess accepted sockets, without parsing or sending a reply.
        # socketserver closes refused sockets. This is not a kernel rate limit.
        return self.ledger.reserve_connection()


class FixtureHandler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    server_version = 'AstraSyntheticFixture'
    sys_version = ''

    def setup(self):
        self.server.ledger.connection_seen()
        super().setup()
        self.connection.settimeout(SOCKET_TIMEOUT)
        # Unlike per-read socket timeout, this one wall timer spans headers,
        # body, parse and response. shutdown wakes blocked socket I/O. Thread
        # scheduling and kernel stalls mean an external watchdog is still
        # required; the marker is not proof a peer received a response.
        self._finished = threading.Event()
        self._expired = threading.Event()
        self._timer_lock = threading.Lock()
        self._deadline = time.monotonic() + REQUEST_WALL_TIMEOUT
        self._timer = threading.Timer(REQUEST_WALL_TIMEOUT, self._expire)
        self._timer.daemon = True
        self._timer.start()

    def _expire(self):
        with self._timer_lock:
            if self._finished.is_set() or self._expired.is_set(): return
            self._expired.set()
            self.server.ledger.wall_timeout()
            try: self.connection.shutdown(socket.SHUT_RDWR)
            except OSError: pass

    def _past_deadline(self):
        # Even if the timer thread is delayed, never admit/claim delivery
        # after the sampled monotonic deadline. These are not atomic with a
        # peer or with wall-clock time, and a hung process still needs a guard.
        if time.monotonic() >= self._deadline: self._expire()
        return self._expired.is_set()

    def finish(self):
        try:
            with self._timer_lock:
                self._finished.set()
                self._timer.cancel()
            super().finish()
        finally:
            self._timer.cancel()

    def log_message(self, *args):
        pass  # Never log bodies, header values or terminal control characters.

    def _error(self, status, reason):
        self.server.ledger.rejected(reason)
        self.close_connection = True
        self.send_response(status)
        self.send_header('Content-Length', '0')
        self.send_header('Connection', 'close')
        self.end_headers()

    def handle_expect_100(self):
        self.server.ledger.request_seen()
        self._error(417, 'expect')
        return False

    def do_GET(self):
        self.server.ledger.request_seen()
        self._error(405, 'method')

    def do_POST(self):
        self.server.ledger.request_seen()
        self.close_connection = True
        try:
            if self.path != '/v1/responses':
                self._error(404, 'path'); return
            if self.headers.get_all('Authorization') != ['Bearer ' + SYNTHETIC_KEY]:
                self._error(401, 'authorization'); return
            if self.headers.get_all('Transfer-Encoding') is not None:
                self._error(400, 'transfer_encoding'); return
            lengths = self.headers.get_all('Content-Length')
            if (not lengths or len(lengths) != 1 or not lengths[0].isascii()
                    or not lengths[0].isdigit() or len(lengths[0]) > 7):
                self._error(400, 'length'); return
            size = int(lengths[0])
            if not 1 <= size <= MAX_REQUEST_BYTES:
                self._error(413, 'size'); return
            content_types = self.headers.get_all('Content-Type')
            if not content_types or len(content_types) != 1 or content_types[0].split(';', 1)[0].strip().lower() != 'application/json':
                self._error(415, 'content_type'); return
            raw = self.rfile.read(size)
            if len(raw) != size:
                self._error(400, 'body_truncated'); return
            self.server.ledger.note_body(raw)
            try:
                body = _strict_json(raw)
                if (not isinstance(body, dict) or body.get('model') != MODEL
                        or body.get('stream') is not True or not isinstance(body.get('input'), list)):
                    raise ValueError('invalid fixture request shape')
            except (ValueError, UnicodeError, RecursionError):
                self._error(400, 'json_or_schema'); return
            if self._past_deadline(): return
            if not self.server.ledger.admit(raw):
                self._error(409, 'duplicate'); return
            data = response_events()
            if len(data) > MAX_RESPONSE_EVENTS_BYTES:
                return
            self.send_response(200)
            self.send_header('Content-Type', 'text/event-stream')
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Connection', 'close')
            self.end_headers()
            self.wfile.write(data)
            self.wfile.flush()
            if not self._past_deadline():
                self.server.ledger.delivered()
        except (OSError, TimeoutError):
            # Once admitted, an interrupted write remains unknown and never replays.
            return
