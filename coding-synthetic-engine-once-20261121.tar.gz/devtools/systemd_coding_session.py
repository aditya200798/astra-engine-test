"""Private genuine fixed-root single-connection candidate; public blocked.

No end-to-end runner. Caller must provide a protected synthetic VM, exclusive
unit lifecycle and independent stop/watchdog. All results are observations and
ambiguous effects require outer recovery; never retry an uncertain start.
"""
import ctypes as c
import os
import select
import time
import math
from . import systemd_coding_direct_start as direct
from . import systemd_job_tracker as jobs
from . import systemd_manager_identity as manager
from . import systemd_coding_pidfd_lookup as look
from . import systemd_pipe_transport as pipe
from . import synthetic_root_verify as roots
from . import systemd_manager_environment as env
from . import systemd_exact_stop as stop
from . import systemd_no_engine_release as release
from . import systemd_slice_anchor as anchor_mod
from . import coding_stream_pair as streams
from . import coding_vm_root as genuine_root
from . import pinned_engine_stage as pinned

_BLOCKED=True
class SessionError(RuntimeError):pass


class _Session:
    """Single-owner, single-threaded state; a close does NOT stop the unit."""
    def __init__(self,lib,bus,owner,unit,custody,in_write,out_read,err_read,*,slice_name=None,anchor=None):
        if (type(custody) is not genuine_root._Custody or custody.state != "assembled" or
            custody.work_uid != 65534 or custody.work_gid != 65534 or
            custody.binary_size != pinned.BINARY_SIZE or custody.binary_sha256 != pinned.BINARY_SHA256):
            raise SessionError("fixed pinned custody required")
        self.custody=custody
        root,root_fd,kind=custody.root_path,custody._fds[2],"integration"
        if (type(unit) is not str or pipe._UNIT.fullmatch(unit) is None or
            type(kind) is not str or kind not in ('baseline','integration') or
            not pipe._valid_root(root)):
            raise SessionError('invalid session')
        if slice_name is not None and slice_name!=direct._slice_for(unit):raise SessionError('invalid fixed slice')
        if anchor is not None and (type(anchor) is not anchor_mod._Anchor or slice_name is None or
                anchor.name!=slice_name or anchor.lib is not lib or anchor.bus is not bus or anchor.owner!=owner or
                anchor.state!='anchored'):
            raise SessionError('anchor not bound to this session')
        self.slice_name=slice_name;self.anchor=anchor
        # Most recently entered fixed start phase; observation only. Never
        # infer a manager side effect merely from this diagnostic.
        self.start_phase='not_started';self.start_error='not_observed'
        self.lib=lib;self.bus=bus;self.owner=owner;self.unit=unit;self.kind=kind
        self.root=root;self.root_fd=root_fd;self.in_write=in_write;self.out_read=out_read;self.err_read=err_read
        # This separate profile does not alter the no-engine control.
        self.engine_contract='genuine_pinned_candidate'
        self.tracker=jobs._Tracker(lib,bus,owner,unit);self.state='fresh';self._job=None;self._bound=None;self._stop_attempted=False;self._input_consumed=False;self._streams=None
    def start_once(self,inf,outf,errf):
        """Observe manager, subscribe, send one job and await result.

        Internal marker becomes uncertain immediately before native send. Even
        an exception or negative reply may have side effects. There is no stop
        here: external independently watched owner is mandatory. Never retry.
        """
        if self.state!='fresh':raise SessionError('attempt consumed')
        self.state='preparing';msg=None
        try:
            # Caller-supplied lib must have every native signature configured
            # before using pointer-valued APIs (default ctypes int truncates).
            self.start_phase='proto'
            direct._proto(self.lib);jobs._proto(self.lib);manager._proto(self.lib)
            self.start_phase='manager_before';manager.inspect(self.lib,self.bus,self.owner)
            self.start_phase='subscribe'
            # The anchor's tracker already subscribed on this exact private
            # bus; subscribe() again can return AlreadySubscribed on systemd.
            if self.anchor is None:self.tracker.subscribe()
            else:self.tracker.subscribe(existing=self.anchor.tracker)
            # Revalidate held source, path, populated engine and entire root before start.
            self.start_phase='root_first';self.custody.recheck()
            self.start_phase='root_inspect'
            self.start_phase='environment'
            try:env.inspect(self.lib,self.bus,self.owner,fixed_path_override=True)
            except env.EnvironmentError as exc:
                self.start_error=exc.category if exc.category in env._CATEGORIES else 'env_internal'
                raise
            # Hashing/environment queries may take time; recheck root pathname
            # and populated engine at the latest possible point before message build.
            self.start_phase='root_recheck';self.custody.recheck()
            self.start_phase='anchor_recheck'
            if self.anchor is not None:self.anchor.observe_anchor()
            self.start_phase='message_build';msg=direct._build(self.lib,self.bus,self.owner,self.unit,self.kind,self.root,inf,outf,errf,**({'slice_name':self.slice_name} if self.slice_name else {}),profile='coding_genuine')
            self.state='start_uncertain'
            self.start_phase='send_uncertain'
            try:sent=direct._send(self.lib,self.bus,msg)
            except direct.StartCallError as exc:
                self.start_error=exc.category;raise
            self._job=sent['job_path']
            self.start_phase='await_job';result=self.tracker.await_job(self._job,10)
            if result['job_result']!='done':
                # Fixed categories only; failure is not proof of no side effects.
                value=result['job_result']
                allowed=('canceled','timeout','failed','dependency','skipped','invalid','assert','unsupported','collected','once')
                self.start_error='job_'+value if type(value) is str and value in allowed else 'job_other'
                self.start_phase='job_not_done'
                raise ValueError('start failed')
            self.start_phase='manager_after';manager.inspect(self.lib,self.bus,self.owner)
            self.state='job_done';self.start_phase='complete'
            return {'start':'job_done_on_same_bus','engine_contract':self.engine_contract,'unit_ownership':'not_proven',
                    'isolation':'not_verified','admission':'not_authorized','cleanup':'not_observed',
                    'engine_launch_authorized':False}
        except BaseException:
            if self.state!='start_uncertain':self.state='failed_no_retry'
            raise SessionError('session start failed or uncertain; external recovery required') from None
        finally:
            if msg is not None and msg.value:self.lib.sd_bus_message_unref(msg)
    _READY=b'ASTRA-CODING-GENUINE-READY-1\n'
    def _quiet_snapshot(self):
        # Readable includes pending bytes and EOF. Never drain untrusted data:
        # final collector retains it. This check is only an instantaneous sample.
        ready,_,_=select.select([self.out_read,self.err_read],[],[],0)
        if ready:raise ValueError('unexpected output or eof')

    def read_ready_once(self,timeout=3):
        """Consume exactly one marker, and reject sampled pre-frame output.

        No polling can exclude output written after the final sample. Safety
        relies on the pinned bootstrap obeying its no-preframe-output contract;
        identity/root/manager checks remain independently mandatory.
        """
        if self.state!='job_done':raise SessionError('readiness unavailable or consumed')
        self.state='readiness_uncertain'
        try:
            if type(timeout) not in (int,float) or not math.isfinite(timeout) or not 0<timeout<=3:raise ValueError('timeout')
            os.set_blocking(self.err_read,False)
            end=time.monotonic()+timeout;buf=bytearray()
            while len(buf)<len(self._READY):
                left=end-time.monotonic()
                if left<=0:raise ValueError('timeout')
                readable,_,_=select.select([self.out_read,self.err_read],[],[],left)
                if self.out_read in readable or self.err_read not in readable:raise ValueError('output or timeout')
                try:part=os.read(self.err_read,len(self._READY)-len(buf))
                except BlockingIOError:continue
                if not part:raise ValueError('eof')
                buf.extend(part)
                if not self._READY.startswith(buf):raise ValueError('marker')
            self._quiet_snapshot();self.state='ready'
            return {'readiness':'marker_and_quiet_sample','authentication':'not_verified','engine_launch_authorized':False}
        except BaseException:
            self.state='readiness_failed'
            raise SessionError('readiness failed; no retry') from None

    def observe(self):
        if self.state!='ready':raise SessionError('readiness not complete')
        try:
            result=look._compare_on_bus(self.lib,self.bus,self.owner,self.unit,self.root_fd,
                                         self.in_write,self.out_read,self.err_read,self.root,self.kind,
                                         **({'expected_slice':self.slice_name} if self.slice_name else {}),profile='coding_genuine')
            inv=result.get('invocation');cg=result.get('cgroup');pid=result.get('main_pid')
            stop._valid(self.unit,inv)
            if type(cg) is not str or not cg.startswith('/') or type(pid) is not int or pid<=0:
                raise ValueError('sampled identity missing')
            self._bound=(inv,cg,pid)
            # Preserve bound invocation before placement observation: if the
            # latter fails, the outer owner may attempt exact-invocation stop.
            if self.anchor is not None:self.anchor.observe_service_membership(cg)
            self.state='observed'
            return result
        except Exception:
            self.state='observation_failed';raise SessionError('process observation unavailable; recovery required') from None
    def admit_genuine_once(self):
        """Recheck the bound process then write/close the fixed admission frame.

        Private genuine blocked-driver candidate only; caller owns the exclusive pipe ends,
        a protected root and an independent manager watchdog. Process/root
        snapshots do not establish ownership, admission integrity or isolation.
        This object consumes the writer on both success and recheck failure.
        Neither this action nor a test unblocks the real engine or production.
        """
        if self.state!='observed' or self._bound is None or self._input_consumed:
            raise SessionError('admission unavailable or consumed')
        self._input_consumed=True
        sender=None
        try:
            sender=release._Release(self.in_write)
            self._streams=streams.StreamPair(self.out_read,self.err_read,'coding')
            self.custody.recheck()
            result=look._compare_on_bus(self.lib,self.bus,self.owner,self.unit,self.root_fd,
                                         self.in_write,self.out_read,self.err_read,self.root,self.kind,
                                         **({'expected_slice':self.slice_name} if self.slice_name else {}),profile='coding_genuine')
            if (result.get('invocation'),result.get('cgroup'),result.get('main_pid'))!=self._bound:
                raise ValueError('process identity changed')
            if self.anchor is not None:self.anchor.observe_service_membership(result['cgroup'])
            self.state='admission_uncertain'
            # Binding is sampled under the protected-root/exclusive-writer prerequisite.
            # It is not a transfer of the outer file descriptor or a mount proof.
            installed=os.fstat(self.custody._fds[4])
            if (installed.st_dev,installed.st_ino)!=self.custody._installed_identity[:2]:
                raise ValueError('held image identity changed')
            self._quiet_snapshot() # sampled immediately before send, not atomic with write
            sender.send_genuine_once((installed.st_dev,installed.st_ino))
            self.state='released'
            return {'release':'frame_write_and_close_returned','unit':self.unit,
                    'admission':'not_attested','isolation':'not_verified',
                    'cleanup':'not_observed','engine_launch_authorized':False}
        except BaseException:
            self.state='admission_uncertain'
            if sender is not None and sender.state=='ready':
                try:sender.abort()
                except Exception:pass
            elif sender is None:
                # Exclusively owned writer: closing it prevents an accidental
                # later frame; the outer owner handles any unknown close.
                try:os.close(self.in_write)
                except OSError:pass
            raise SessionError('admission unavailable or uncertain; external recovery required') from None
    def read_provisional(self,timeout):
        """Read one candidate line before stop; no EOF/exit/cleanup claim."""
        if self.state!='released' or self._streams is None:
            raise SessionError('stream not available')
        self.state='stream_uncertain'
        result=self._streams.before_stop(timeout)
        if result.get('record')!='provisional':
            raise SessionError('provisional record unavailable; external recovery required')
        self.state='provisional'
        return result
    def read_final(self,timeout):
        """Drain both EOFs after a stop attempt, never attest cleanup."""
        if self.state not in ('stop_observed','stop_uncertain') or self._streams is None or not self._stop_attempted:
            raise SessionError('final drain unavailable')
        result=self._streams.after_stop(timeout)
        if result.get('record')!='received':raise SessionError('final record unavailable; external recovery required')
        return result
    def observe_exit(self):
        """Read sampled manager main-exit only; can never prove cleanup."""
        if self.state not in ('released','provisional','exit_observed') or self._bound is None:
            raise SessionError('binding unavailable; external recovery required')
        inv,cgroup,pid=self._bound
        try:
            result=stop._exit_observation(self.lib,self.bus,self.owner,self.unit,inv,pid,cgroup)
            self.state='exit_observed';return result
        except Exception:
            # No retry of the workload; caller may observe while still under
            # its independent deadline, or trigger outside recovery.
            raise SessionError('exit not yet observed or unavailable') from None
    def stop_once(self):
        """One invocation-addressed stop; only if pre-release bound.

        Independent exclusive owner and watchdog remain prerequisites. A start
        or identity uncertainty cannot justify name-based or guessed cleanup.
        This method cannot independently bound native calls or verify cgroup.
        """
        if self.state not in ('observed','observation_failed','released','provisional','stream_uncertain','admission_uncertain','exit_observed') or self._bound is None or self._stop_attempted:
            raise SessionError('stop not bound or already consumed; external recovery required')
        self._stop_attempted=True
        inv,cgroup,pid=self._bound
        try:
            identity=stop._observation(self.lib,self.bus,self.owner,self.unit,inv)
            if identity.get('cgroup') not in ('',cgroup):raise ValueError('cgroup changed')
            # The call can take effect even if its reply or job event is lost.
            self.state='stop_uncertain'
            result=stop._send_invocation_once(self.lib,self.bus,self.owner,self.unit,inv)
            job=self.tracker.await_job(result['job_path'],5)
            if job.get('job_result')!='done':raise ValueError('stop job not done')
            identity=stop._observation(self.lib,self.bus,self.owner,self.unit,inv)
            if identity.get('state') not in ('inactive','failed') or identity.get('cgroup') not in ('',cgroup):
                raise ValueError('stop not observed')
            self.state='stop_observed'
            return {'stop':'job_done_inactive_snapshot','unit':self.unit,'invocation':inv,
                    'cgroup_cleanup':'not_observed','ownership':'not_proven',
                    'vm_decommission':'not_observed','engine_launch_authorized':False}
        except BaseException:
            self.state='stop_uncertain'
            raise SessionError('stop unavailable or uncertain; no retry, external recovery required') from None
    def close(self):
        self.tracker.close();self.state='closed'
        # Bus, root and stream FDs remain caller-owned; no stop/cleanup implied.


def run():
    if _BLOCKED:raise SessionError('same-bus session blocked; stop and independent watchdog missing')
    raise SessionError('no approved orchestration')
