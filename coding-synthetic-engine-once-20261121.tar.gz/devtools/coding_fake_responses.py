"""Exact fixed coding fixture; no launcher, containment or peer attestation."""
from http.server import HTTPServer
import hashlib
from .fake_responses import (FixtureHandler, FixtureHTTPServer, Ledger, SYNTHETIC_KEY, MODEL,
    MAX_REQUEST_BYTES, MAX_RESPONSE_EVENTS_BYTES, _strict_json)
from . import coding_integration_scenario as scenario

class CodingLedger(Ledger):
    """First bounded coding request shape only; never return request contents."""
    def note_body(self, raw):
        from . import synthetic_request_diagnostics as shape
        from . import synthetic_failure_evidence as vocabulary
        try:
            value=shape.diagnose(raw)
            if value['status'] != 'examined':
                record={**vocabulary.unknown(),'capture':'body_unavailable'}
            else:
                prompt=value['user_prompt']
                if value['input']=='array':
                    body=_strict_json(raw)
                    users=[x for x in body['input'] if type(x) is dict and x.get('role')=='user']
                    if len(users)==1:
                        content=users[0].get('content')
                        form='exact_string'
                        if type(content) is list:
                            form='exact_input_text_array'
                            if (len(content)!=1 or type(content[0]) is not dict or
                                set(content[0])!={'type','text'} or content[0]['type']!='input_text'):
                                content=None
                            else: content=content[0]['text']
                        if (type(content) is str and
                            hashlib.sha256(content.encode('utf-8')).hexdigest()==scenario.PROMPT_SHA256):
                            prompt=form
                        else: prompt='different_or_invalid'
                record={'capture':'body_examined','model':value['model'],'input':value['input'],
                        'user_prompt':prompt,'rejection':'not_observed'}
            vocabulary.validate(record)
        except Exception:
            record={**vocabulary.unknown(),'capture':'body_unavailable'}
        with self._lock:
            if self._first_shape is None:self._first_shape=record


class CodingHandler(FixtureHandler):
    def do_POST(self):
        self.server.ledger.request_seen()
        self.close_connection = True
        try:
            if self.path != '/v1/responses':
                self._error(404, 'path'); return
            if self.headers.get_all('Authorization') != ['Bearer ' + SYNTHETIC_KEY]:
                self._error(401, 'authorization'); return
            if self.headers.get_all('Transfer-Encoding') is not None:
                self._error(400, 'transfer_encoding'); return
            lengths = self.headers.get_all('Content-Length')
            if (not lengths or len(lengths) != 1 or not lengths[0].isascii()
                    or not lengths[0].isdigit() or len(lengths[0]) > 7):
                self._error(400, 'length'); return
            size = int(lengths[0])
            if not 1 <= size <= MAX_REQUEST_BYTES:
                self._error(413, 'size'); return
            content_types = self.headers.get_all('Content-Type')
            if not content_types or len(content_types) != 1 or content_types[0].split(';', 1)[0].strip().lower() != 'application/json':
                self._error(415, 'content_type'); return
            raw = self.rfile.read(size)
            if len(raw) != size:
                self._error(400, 'body_truncated'); return
            self.server.ledger.note_body(raw)
            try:
                body = _strict_json(raw)
                if (not isinstance(body, dict) or body.get('model') != MODEL
                        or body.get('stream') is not True or not isinstance(body.get('input'), list)
                        or not scenario.matches_request(raw)):
                    raise ValueError('invalid fixture request shape')
            except (ValueError, UnicodeError, RecursionError):
                self._error(400, 'json_or_schema'); return
            if self._past_deadline(): return
            if not self.server.ledger.admit(raw):
                self._error(409, 'duplicate'); return
            data = scenario.response_events()
            if len(data) > MAX_RESPONSE_EVENTS_BYTES:
                return
            self.send_response(200)
            self.send_header('Content-Type', 'text/event-stream')
            self.send_header('Content-Length', str(len(data)))
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Connection', 'close')
            self.end_headers()
            self.wfile.write(data)
            self.wfile.flush()
            if not self._past_deadline():
                self.server.ledger.delivered()
        except (OSError, TimeoutError):
            # Once admitted, an interrupted write remains unknown and never replays.
            return


class CodingHTTPServer(FixtureHTTPServer):
    def __init__(self,address):
        if (not isinstance(address,tuple) or len(address)!=2 or address[0]!='127.0.0.1'
            or type(address[1]) is not int or not 0<=address[1]<=65535):
            raise ValueError('literal IPv4 loopback and port required')
        self.ledger=CodingLedger()
        HTTPServer.__init__(self,address,CodingHandler)
