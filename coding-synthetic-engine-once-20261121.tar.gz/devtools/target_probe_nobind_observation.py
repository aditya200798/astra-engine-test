"""Unwired local no-bind observation primitive; never a launch authority.

Sampling is racy. This module does not start a service, prove isolation,
validate manager properties, authenticate the host canary, or authorize CI.
An independent live host challenge and a case-specific complete lifecycle are
required; there is deliberately no public execution entrypoint.
"""
import os,stat
from . import service_namespace_observer as ns, target_probe_entry as entry

class NoBindObservationError(RuntimeError): pass

def _sample_run_dir(root_fd, host_path, mount_raw):
    """Bounded sample: host socket identity, strict mounts, child leaf ENOENT.

    root_fd must be a separately bound, live service root descriptor. A hidden
    alias in a non-mount location is not ruled out. ENOENT is not proof that
    the socket stayed absent, or that the host endpoint was listening.
    """
    if type(root_fd) is not int or root_fd < 0 or type(host_path) is not str or not host_path.startswith('/'):
        raise NoBindObservationError('input')
    try:
        before=os.stat(host_path,follow_symlinks=False)
        if not stat.S_ISSOCK(before.st_mode):raise ValueError('host not socket')
        # Do not use permissive no-engine-compat: it tolerates arbitrary mounts.
        # These stringent expectations may reject a legitimate target. This is
        # deliberately sampled, not a proof of absence of all aliases.
        ns._mounts(mount_raw,allow_propagation=True,no_engine_compat=False)
        runfd=os.open('run',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=root_fd)
        try:
            try:os.stat(os.path.basename(host_path),dir_fd=runfd,follow_symlinks=False)
            except FileNotFoundError:pass
            else:raise ValueError('child path present')
        finally:os.close(runfd)
        after=os.stat(host_path,follow_symlinks=False)
        if not stat.S_ISSOCK(after.st_mode) or (before.st_dev,before.st_ino)!=(after.st_dev,after.st_ino):raise ValueError('host changed')
        return (before.st_dev,before.st_ino)
    except Exception as exc:raise NoBindObservationError('no-bind observation unknown') from exc

def _sample(pid, mount_raw):
    """Fixed target only, intended for use within existing pidfd observer."""
    if type(pid) is not int or pid<=0:raise NoBindObservationError('input')
    fd=os.open('/proc/'+str(pid)+'/root',os.O_RDONLY|os.O_DIRECTORY|os.O_CLOEXEC)
    try:return _sample_run_dir(fd,entry._PATH,mount_raw)
    finally:os.close(fd)

def _manager_empty_bind_arrays(lib,bus,owner,path):
    """Same-bus diagnostic primitive only; caller must bind unit/invocation.

    Empty per-unit properties do not prove manager defaults, path absence or
    an unchanged namespace. Both arrays must be queried, on the same selected
    service; the complete before/after identity lifecycle is not implemented.
    """
    from . import systemd_pidfd_lookup as look
    interface=b'org.freedesktop.systemd1.Service';signature=b'a(ssbt)'
    try:
        for name in (b'BindReadOnlyPaths',b'BindPaths'):
            if not look._property_empty_array(lib,bus,owner,path,interface,name,signature):raise ValueError('non-empty bind')
    except Exception as exc:raise NoBindObservationError('manager observation unknown') from exc
    return None
