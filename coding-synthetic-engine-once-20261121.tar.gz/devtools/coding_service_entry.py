"""Blocked fixed coding entry; emits at most one categorical local record."""
import asyncio,json,sys
from .fixed_coding_driver import DriverError,FixedCodingDriver
from .synthetic_entry import _ALLOWED
from . import synthetic_failure_evidence as failure
from astra.policy import json_equal

_SUMMARY={'coding':'fixed_synthetic_candidate_observed','baseline':'matched',
 'direct_stream_exit':'matched','fixture_final':'passed','worker':'call_completed',
 'source_apply':'not_done','candidate_execution':'not_done','endpoint':'not_authenticated',
 'engine':'not_attested','isolation':'not_verified','descendants':'not_verified',
 'all_network_traffic':'not_observed'}
_REQUIRED={'stage':'integration_observation_complete','spawn':'child_handle_obtained',
 'direct_child_cleanup':'direct_exit_observed','config_observer_close':'closed',
 'lease_close':'close_requested','fixture_exit':'returned','session_worker_call':'call_completed'}
_OUTCOMES=('returned','driver_error','cancelled','internal_error','invalid_return')

def _report(evidence,outcome):
    if type(evidence) is not dict:evidence={}
    if type(outcome) is not str or outcome not in _OUTCOMES:outcome='internal_error'
    fields={}
    for k,allowed in _ALLOWED.items():
        v=evidence.get(k);fields[k]=v if type(v) is str and v in allowed else 'unknown'
    summary=None
    if outcome=='returned':
        if json_equal(evidence.get('integration'),_SUMMARY) and all(fields.get(k)==v for k,v in _REQUIRED.items()):summary=dict(_SUMMARY)
        else:outcome='invalid_return'
    shape=failure.unknown()
    if outcome!='returned':
        try:shape=failure.validate(evidence.get('failure_shape',shape))
        except ValueError:shape=failure.unknown()
    return {'schema':'astra-synthetic-coding-inner-v1','outcome':outcome,'fixture_failure':shape,'observations':fields,
            'coding_evidence':summary,'synthetic_only':True,'engine_launch_authorized':False,
            'unit_cleanup':'not_observed','vm_decommission':'not_observed','production_approved':False}

async def _once(expected_identity=None):
    driver=FixedCodingDriver(expected_identity)
    try:await driver.run();outcome='returned'
    except asyncio.CancelledError:outcome='cancelled'
    except DriverError:outcome='driver_error'
    except Exception:outcome='internal_error'
    return _report(driver.evidence,outcome)

def main(expected_identity=None):
    if len(sys.argv)!=1:return 2
    try:
        result=asyncio.run(_once(expected_identity));line=json.dumps(result,sort_keys=True,separators=(',',':'),ensure_ascii=True)
        if len(line)>2048:return 2
        sys.stdout.write(line+'\n');sys.stdout.flush()
        return 0 if result['outcome']=='returned' else 1
    except (Exception,KeyboardInterrupt):return 2
if __name__=='__main__':raise SystemExit(main())
