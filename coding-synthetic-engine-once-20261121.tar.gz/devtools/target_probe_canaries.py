"""Bounded owned synthetic canaries. No manager/VM orchestration or gate.

Private construction only for an exclusive credential-free disposable VM;
callers must independently ensure no conflicting processes and supervise this
process. Fixed host-local endpoints. No internet or arbitrary address input.
Live samples do not prove they remain alive or identify absence of other routes.
"""
import os,select,socket,stat,time
from . import target_probe_entry as e, target_boundary_probe as boundary
_BLOCKED=True
class CanaryError(RuntimeError):pass
def _receive_exact(sock,n,deadline):
    data=b''
    while len(data)<n:
        remaining=deadline-time.monotonic()
        if remaining<=0:raise CanaryError('connection deadline')
        sock.settimeout(remaining)
        part=sock.recv(n-len(data))
        if not part:raise CanaryError('connection closed')
        data+=part
    if time.monotonic()>=deadline:raise CanaryError('connection deadline')
    return data

def _check_connection(server,address,allow_probe=False):
    """Match own nonce; permit at most one complete fixed probe plus EOF.

    Marker is public, not peer authentication. Exclusive synthetic VM and
    independent owner remain mandatory. Foreign, partial, repeated or stalled
    traffic invalidates the experiment; no unbounded draining.
    """
    if type(allow_probe) is not bool:raise CanaryError('inputs')
    deadline=time.monotonic()+.6
    client=socket.socket(server.family,socket.SOCK_STREAM|socket.SOCK_CLOEXEC)
    consumed=False
    try:
        client.settimeout(max(.001,deadline-time.monotonic()));client.connect(address)
        nonce=os.urandom(32);client.sendall(b'P'+nonce)
        for _ in range(2):
            remaining=deadline-time.monotonic()
            if remaining<=0 or not select.select([server],[],[],remaining)[0]:raise CanaryError('accept deadline')
            conn,_=server.accept()
            try:
                first=_receive_exact(conn,1,deadline)
                if first==boundary._PROBE_FRAME[:1] and allow_probe and not consumed:
                    tail=_receive_exact(conn,len(boundary._PROBE_FRAME)-1,deadline)
                    if first+tail!=boundary._PROBE_FRAME:raise CanaryError('foreign probe')
                    conn.settimeout(max(.001,deadline-time.monotonic()))
                    if conn.recv(1)!=b'':raise CanaryError('extra probe bytes')
                    consumed=True
                    continue
                if first!=b'P' or _receive_exact(conn,32,deadline)!=nonce:raise CanaryError('foreign challenge')
                response=os.urandom(32);conn.settimeout(max(.001,deadline-time.monotonic()));conn.sendall(b'A'+response)
                if _receive_exact(client,33,deadline)!=b'A'+response:raise CanaryError('wrong client response')
                if time.monotonic()>=deadline:raise CanaryError('connection deadline')
                return consumed
            finally:conn.close()
        raise CanaryError('too many queued peers')
    finally:client.close()

class _Canaries:
    def __init__(self):self.state='fresh';self.sockets=[];self.path_identity=None;self.path_unidentified=False;self.probe_seen=[False,False,False]
    def _close_owned(self):
        failed=False
        for s in self.sockets:
            try:s.close()
            except OSError:failed=True
        self.sockets=[]
        # Bind may have succeeded even when the following lstat failed.
        # Without a captured identity, do not unlink a potentially replaced path.
        if self.path_unidentified:failed=True
        if self.path_identity is not None:
            try:
                st=os.lstat(e._PATH)
                if not stat.S_ISSOCK(st.st_mode) or (st.st_dev,st.st_ino)!=self.path_identity:raise ValueError('replaced')
                os.unlink(e._PATH)
            except Exception:failed=True
            self.path_identity=None
        return not failed
    def start_once(self):
        if self.state!='fresh':raise CanaryError('consumed')
        self.state='starting_uncertain'
        try:
            # Bind fixed names only. No reuse and no unlink of a pre-existing
            # pathname: collision invalidates the whole attempt.
            if os.path.lexists(e._PATH):raise ValueError('path exists')
            path=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM|socket.SOCK_CLOEXEC);self.sockets.append(path)
            # Treat even a bind error as an ambiguous side effect.
            self.path_unidentified=True;path.bind(e._PATH)
            st=os.lstat(e._PATH)
            if not stat.S_ISSOCK(st.st_mode):raise ValueError('not socket')
            self.path_identity=(st.st_dev,st.st_ino);self.path_unidentified=False
            os.chmod(e._PATH,0o777);path.listen(4)
            abstract=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM|socket.SOCK_CLOEXEC);self.sockets.append(abstract)
            abstract.bind(e._ABSTRACT);abstract.listen(4)
            network=socket.socket(socket.AF_INET,socket.SOCK_STREAM|socket.SOCK_CLOEXEC);self.sockets.append(network)
            network.bind((e._IP,e._PORT));network.listen(4)
            self._check_live(allow_probe=False)
            self.state='live_sampled'
            return {'canaries':'three_connect_and_accept_sampled','external_egress':'not_tested',
                    'isolation':'not_verified','engine_launch_authorized':False}
        except BaseException:
            cleaned=self._close_owned();self.state='failed' if cleaned else 'cleanup_uncertain'
            raise CanaryError('setup or liveness failed; no retry') from None
    def _check_live(self,*,allow_probe=True):
        if len(self.sockets)!=3 or self.path_identity is None:raise CanaryError('canary set unavailable')
        st=os.lstat(e._PATH)
        if not stat.S_ISSOCK(st.st_mode) or (st.st_dev,st.st_ino)!=self.path_identity:raise CanaryError('path replaced')
        for i,(server,address) in enumerate(zip(self.sockets,(e._PATH,e._ABSTRACT,(e._IP,e._PORT)))):
            if _check_connection(server,address,allow_probe=allow_probe and not self.probe_seen[i]):self.probe_seen[i]=True
        st=os.lstat(e._PATH)
        if not stat.S_ISSOCK(st.st_mode) or (st.st_dev,st.st_ino)!=self.path_identity:raise CanaryError('path replaced')
    def sample_live(self):
        if self.state!='live_sampled':raise CanaryError('not live')
        try:self._check_live()
        except BaseException:raise CanaryError('canary liveness uncertain') from None
        # The value is sampled on both sides of the nonce connections by
        # _check_live, and is meaningful only while this owner is alive.
        return self.path_identity
    def close_once(self):
        if self.state!='live_sampled':raise CanaryError('not live or already consumed')
        self.state='closing_uncertain';cleaned=self._close_owned()
        self.state='closed' if cleaned else 'cleanup_uncertain'
        if not cleaned:raise CanaryError('cleanup uncertain')
        return {'canaries':'closed_path_removed_sampled','cleanup':'not_verified','engine_launch_authorized':False}
def run():
    if _BLOCKED:raise CanaryError('target canaries blocked')
    raise CanaryError('no approved orchestration')
