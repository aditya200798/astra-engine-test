"""Private one-shot engine-free probe flow via actual root/bus/anchor/session.

The controller is never called by the public run() or a workflow. A separately
owned synthetic VM, guarded staging process, outside-cgroup watchdog and outer
whole-VM timeout/recovery are mandatory. Even a complete record cannot prove
isolation or authorize a genuine engine. Returned categories are untrusted.
"""
import os,socket
from . import synthetic_control_root as root,systemd_private_bus as bus
from . import systemd_slice_anchor as anchors,systemd_pipe_transport as transport
from . import systemd_direct_start as direct,target_probe_owner as owner
_BLOCKED=True
class FlowError(RuntimeError):pass
class _Flow:
 def __init__(self,source_fd,package_fd,root_fd,root_path,unit,cgroup_root_fd,*,nobind=False):
  if type(nobind) is not bool:raise FlowError('case')
  self.nobind=nobind;self._nobind_protocol=None
  fds=(source_fd,package_fd,root_fd,cgroup_root_fd)
  if (any(type(fd) is not int or fd<0 for fd in fds) or len(set(fds))!=4 or
      not transport._valid_root(root_path) or type(unit) is not str or transport._UNIT.fullmatch(unit) is None):raise FlowError('inputs')
  self.source_fd,self.package_fd,self.root_fd,self.cgroup_root_fd=fds
  self.root_path=root_path;self.unit=unit;self.slice_name=direct._slice_for(unit);self._used=False
 def _run_once(self,*,_anchor_channel=None):
  if self._used:raise FlowError('consumed')
  self._used=True;lib=conn=anchor=None
  result={'stage':'root_unknown','control':'unknown','root':'not_observed','manager':'not_observed',
          'sample':'not_observed','owner_stage':'not_observed','stop':'not_observed',
          'start_phase':'not_observed','start_error':'not_observed','service_diag':'not_observed','service_result':'not_observed','exec_status':'not_observed','observe_phase':'not_observed','observe_error':'not_observed',
          'cleanup':'not_verified','canary_liveness':'not_verified','isolation':'not_verified',
          'engine_launch_authorized':False,'production_approved':False}
  try:
   if os.geteuid()!=0 or _anchor_channel is None:raise ValueError('supervision missing')
   st=os.fstat(self.root_fd);identity=(st.st_dev,st.st_ino)
   staged=root._assemble(self.source_fd,self.package_fd,self.root_fd,65534,65534)
   if staged.get('root')!='fixed_no_engine_tree_sampled' or staged.get('engine')!='empty_snapshot':raise ValueError('root')
   profile=root._create_systemd_no_engine_profile(self.root_fd,self.root_path,65534,65534);profile.verify(self.root_fd,self.root_path)
   st=os.fstat(self.root_fd)
   if (st.st_dev,st.st_ino)!=identity:raise ValueError('identity')
   result['root']='fixed_no_engine_tree_sampled';result['stage']='manager_unknown'
   lib,conn,manager=bus._open();result['manager']='same_connection_sampled';result['stage']='anchor_uncertain'
   anchor=anchors._Anchor(lib,conn,manager,self.unit,self.cgroup_root_fd);anchor.start_once()
   # Reuse the actual anchor FD handoff; supervisor must acknowledge only
   # after its independently spawned outside-slice watchdog is alive.
   from . import synthetic_no_engine_supervisor as supervisor
   supervisor._send_anchor(_anchor_channel,anchor.group_fd)
   result['stage']='owner_uncertain'
   def announce(attempt):
    from . import target_probe_nobind_packet_lab as protocol
    if self._nobind_protocol is not None:raise ValueError('duplicate announcement')
    state=protocol.Worker(attempt);self._nobind_protocol=state
    frame=state.announce()
    if _anchor_channel.send(frame)!=len(frame):raise ValueError('announcement uncertain')
    _anchor_channel.settimeout(5)
    try:
     data,anc,flags,_=_anchor_channel.recvmsg(protocol.MAX_PACKET+1,0)
     if anc or flags&(socket.MSG_TRUNC|socket.MSG_CTRUNC) or not data:raise ValueError('ack')
     state.accept_ack(data)
    finally:_anchor_channel.settimeout(None)
   kwargs={'nobind':True,'nobind_announce':announce} if self.nobind else {}
   obs=owner._drive_once(lib,conn,manager,self.unit,self.root_path,self.root_fd,
                         slice_name=self.slice_name,anchor=anchor,root_profile=profile,**kwargs)
   if (type(obs) is not dict or obs.get('control') not in (('unknown','nobind_unverified') if self.nobind else ('unknown','probe_record_and_exit_sampled')) or
       obs.get('engine_launch_authorized') is not False or obs.get('production_approved') is not False):raise ValueError('owner record')
   if obs['control']=='probe_record_and_exit_sampled':
    from .target_probe_entry import _validate
    _validate(obs.get('sample'));result['sample']=obs['sample']
   if obs['control']=='nobind_unverified':
    from .target_probe_entry import _validate_nobind
    from .target_probe_nobind_packet_lab import _identity
    attempt=bytes.fromhex(obs['attempt']);_validate_nobind(obs['sample'],attempt)
    if self._nobind_protocol is None or self._nobind_protocol._attempt!=attempt:raise ValueError('attempt')
    _identity(obs['nobind_host_identity'])
    result['sample']=obs['sample']['sample'];result['nobind_host_identity']=obs['nobind_host_identity']
   stage=obs.get('stage');stop=obs.get('stop')
   if stage not in ('pipes','start_uncertain','readiness','observe','announce_uncertain','release_uncertain','record','exit','stop','finished') or (stage=='announce_uncertain' and not self.nobind) or stop not in ('not_observed','bound_inactive_snapshot'):raise ValueError('owner categories')
   if obs['control']=='nobind_unverified' and (stage!='finished' or stop!='bound_inactive_snapshot'):raise ValueError('lifecycle')
   from . import systemd_pidfd_lookup as lookup
   from .target_probe_packet import _valid_start_diagnostic, _valid_start_service
   start_phase=obs.get('start_phase','not_observed');start_error=obs.get('start_error','not_observed')
   if not _valid_start_diagnostic(obs['control'],stage,start_phase,start_error):raise ValueError('start categories')
   diag=obs.get('service_diag','not_observed');service=obs.get('service_result','not_observed');status=obs.get('exec_status','not_observed')
   if not _valid_start_service(obs['control'],stage,start_phase,start_error,diag,service,status):raise ValueError('service categories')
   phase=obs.get('observe_phase','not_observed');error=obs.get('observe_error','not_observed')
   if not lookup._valid_probe_diagnostic(stage,phase,error,nobind=self.nobind):raise ValueError('observe categories')
   if obs['control']!='unknown' and (phase!='not_observed' or error!='not_observed'):raise ValueError('success diagnostics')
   if (phase!='not_observed' or error!='not_observed') and stage not in ('observe','release_uncertain'):raise ValueError('diagnostic stage')
   result['start_phase']=start_phase;result['start_error']=start_error
   result['service_diag']=diag;result['service_result']=service;result['exec_status']=status
   result['observe_phase']=phase;result['observe_error']=error
   result['owner_stage']=stage;result['stop']=stop;result['control']=obs['control'];result['stage']='owner_returned_cleanup_unverified'
  except BaseException:result['control']='unknown'
  finally:
   if anchor is not None:
    try:anchor.close()
    except BaseException:result['control']='unknown';result['stage']='anchor_close_uncertain'
   if conn is not None:
    try:bus._close(lib,conn)
    except BaseException:result['control']='unknown';result['manager']='close_uncertain'
  return result

def run():
 if _BLOCKED:raise FlowError('probe flow blocked')
 raise FlowError('no approved orchestration')
