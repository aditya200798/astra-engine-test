"""UNWIRED private no-bind packet experiment. Never authorization or proof.

Callers MUST perform actual ordered I/O, deadline/pidfd and challenge checks;
this module is only a one-use state machine and strict data validator. Device
and inode tuples are sampled observations, not authentication or isolation.
"""
import json
from .target_probe_entry import _validate, ProbeEntryError
from .target_probe_packet import _unique, _reject_constant

CASE='no-bind-path-v1'
MAX_PACKET=4096
class ProtocolError(ValueError):pass

def _token(t):
    if type(t) is not bytes or len(t)!=32 or not any(t):raise ProtocolError('token')
    return t

def _identity(i):
    if (type(i) is not tuple or len(i)!=2 or any(type(x) is not int or not 0<=x<2**64 for x in i) or i[1]==0):
        raise ProtocolError('identity')
    return i

def _parse(data,prefix,fields):
    if type(data) is not bytes or len(data)>MAX_PACKET or not data.startswith(prefix):raise ProtocolError('frame')
    try:
        obj=json.loads(data[len(prefix):].decode('ascii'),object_pairs_hook=_unique,parse_constant=_reject_constant)
        if type(obj) is not dict or set(obj)!=fields:raise ValueError('fields')
        return obj
    except (ValueError,TypeError,UnicodeError,RecursionError):raise ProtocolError('payload') from None

def _frame(prefix,obj):
    data=prefix+json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('ascii')
    if len(data)>MAX_PACKET:raise ProtocolError('frame too large')
    return data

def _attempt_string(value):
    if type(value) is not str or len(value)!=64:raise ProtocolError('attempt')
    try:t=bytes.fromhex(value)
    except ValueError:raise ProtocolError('attempt') from None
    _token(t)
    if t.hex()!=value:raise ProtocolError('attempt canonical')
    return t

class Worker:
    def __init__(self,attempt):
        self._attempt=_token(attempt);self._state='new'
    def announce(self):
        if self._state!='new':self._state='failed';raise ProtocolError('order')
        self._state='announced'
        return _frame(b'A',{'case':CASE,'attempt':self._attempt.hex()})
    def accept_ack(self,data):
        try:
            if self._state!='announced':raise ProtocolError('order')
            o=_parse(data,b'K',{'case','attempt'})
            if o['case']!=CASE or _attempt_string(o['attempt'])!=self._attempt:raise ProtocolError('binding')
            self._state='acked'
        except BaseException:self._state='failed';raise
    def result(self,sample,observed_identity):
        try:
            if self._state!='acked':raise ProtocolError('order')
            _identity(observed_identity);_validate(sample)
            if sample['pathname_socket']!='path_missing':raise ProtocolError('unsupported pathname')
            out=_frame(b'R',{'case':CASE,'attempt':self._attempt.hex(),'sample':sample,
                            'observer_identity':list(observed_identity)})
            self._state='done';return out
        except BaseException:self._state='failed';raise

class Supervisor:
    def __init__(self,pre_challenge_identity):
        self._pre=_identity(pre_challenge_identity);self._state='new';self._attempt=None
    def accept_announcement(self,data):
        try:
            if self._state!='new':raise ProtocolError('order')
            o=_parse(data,b'A',{'case','attempt'})
            if o['case']!=CASE:raise ProtocolError('case')
            self._attempt=_attempt_string(o['attempt']);self._state='announced'
            return _frame(b'K',{'case':CASE,'attempt':self._attempt.hex()})
        except BaseException:self._state='failed';raise
    def accept_result(self,data,post_challenge_identity,marker_mask):
        self.accept_pending(data,post_challenge_identity)
        return self.finish(marker_mask)

    def accept_pending(self,data,post_challenge_identity):
        try:
            if self._state!='announced':raise ProtocolError('order')
            post=_identity(post_challenge_identity)
            o=_parse(data,b'R',{'case','attempt','sample','observer_identity'})
            if o['case']!=CASE or _attempt_string(o['attempt'])!=self._attempt:raise ProtocolError('binding')
            raw=o['observer_identity']
            if type(raw) is not list or len(raw)!=2:raise ProtocolError('identity')
            seen=_identity(tuple(raw))
            if self._pre!=seen or seen!=post:raise ProtocolError('identity mismatch')
            sample=o['sample'];_validate(sample)
            if sample['pathname_socket']!='path_missing':raise ProtocolError('unsupported pathname')
            self._sample=sample;self._state='pending'
            return None
        except BaseException:self._state='failed';raise
    def finish(self,marker_mask):
        try:
            if self._state!='pending':raise ProtocolError('order')
            sample=self._sample
            if type(marker_mask) is not int or not 0<=marker_mask<=7 or marker_mask&1:raise ProtocolError('contradictory pathname marker')
            for bit,key in ((2,'abstract_socket'),(4,'network_canary')):
                if sample[key] not in ('connected','not_connected') or bool(marker_mask&bit)!=(sample[key]=='connected'):
                    raise ProtocolError('contradictory or uncertain marker')
            self._state='done'
            return {'control':'nobind_nonatomic_sample_only','case':CASE,'sample':sample,
                    'cleanup':'not_verified','isolation':'not_verified',
                    'engine_launch_authorized':False,'production_approved':False}
        except BaseException:self._state='failed';raise
