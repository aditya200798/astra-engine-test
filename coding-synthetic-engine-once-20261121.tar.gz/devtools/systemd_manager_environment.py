"""Read-only sampled systemd-manager effective environment, never launch gate.

Requires a caller-owned bus and independently trusted owner/VM. Check does not
change manager defaults or expose values, and is not atomic with a later start.
"""
import ctypes as c
import re
from . import systemd_pidfd_lookup as look

P=c.c_void_p
_CATEGORIES=('env_input','env_owner_before','env_property','env_array','env_read',
             'env_assignment','env_allowlist','env_path_rejected','env_lang_rejected',
             'env_other_name','env_duplicate','env_size',
             'env_changed','env_owner_after','env_internal')
class EnvironmentError(RuntimeError):
    def __init__(self,category):
        self.category=category if type(category) is str and category in _CATEGORIES else 'env_internal'
        super().__init__('manager environment unavailable')
class _Fault(ValueError):
    def __init__(self,category):self.category=category

_LIMIT=65536
_COUNT=128


def _decode_assignment(raw, *, fixed_path_override=False):
    if type(raw) is not bytes or len(raw)>4096:raise _Fault('env_assignment')
    key,sep,value=raw.partition(b'=')
    if not sep:raise _Fault('env_assignment')
    try:name=key.decode('ascii');val=value.decode('ascii')
    except UnicodeError:raise _Fault('env_assignment') from None
    if re.fullmatch('[A-Z_][A-Z0-9_]*',name) is None or any(ord(x)<32 or ord(x)>126 for x in val):raise _Fault('env_assignment')
    # Global manager inputs are deliberately narrower than eventual service
    # variables which systemd itself synthesizes; no arbitrary values needed.
    if name=='PATH':
        parts=val.split(':')
        if fixed_path_override is not True and (not parts or any(x not in ('/usr/local/sbin','/usr/local/bin','/usr/sbin','/usr/bin','/sbin','/bin') for x in parts)):raise _Fault('env_path_rejected')
    elif name=='LANG':
        if val not in ('C','C.UTF-8','C.utf8','en_US.UTF-8'):raise _Fault('env_lang_rejected')
    else:raise _Fault('env_other_name')
    return name


def _property(lib,bus,owner, *, fixed_path_override=False):
    """Read manager Environment (`as`) from actual sd-bus property message."""
    msg=P()
    try:
        if lib.sd_bus_get_property(bus,owner,look._PATH,look._INTERFACE,b'Environment',None,c.byref(msg),b'as')<0 or not msg.value:
            raise _Fault('env_property')
        if lib.sd_bus_message_enter_container(msg,b'a',b's')<=0:raise _Fault('env_array')
        names=set();assignments=set();total=0
        while True:
            value=c.c_char_p();r=lib.sd_bus_message_read(msg,b's',c.byref(value))
            if r<0:raise _Fault('env_read')
            if r==0:break
            if value.value is None:raise _Fault('env_read')
            raw=value.value;total+=len(raw)+1
            if total>_LIMIT or len(names)>=_COUNT:raise _Fault('env_size')
            name=_decode_assignment(raw, fixed_path_override=fixed_path_override)
            if name in names:raise _Fault('env_duplicate')
            names.add(name);assignments.add(raw)
        if lib.sd_bus_message_exit_container(msg)<0:raise _Fault('env_array')
        return frozenset(assignments)
    finally:
        if msg.value:lib.sd_bus_message_unref(msg)


def inspect(lib,bus,owner, *, fixed_path_override=False):
    """Read twice without returning values; this is sampled, NOT atomic.

    fixed_path_override=True is ONLY for the fixed unit builder that submits
    Environment=PATH=/usr/bin:/bin. All other fields remain allowlisted.
    A matching pair does not detect changes between/after reads or prove a
    service's environment. Exclude concurrent writers; independently verify
    the manager and enforce a deadline. Diagnostics are finite categories.
    """
    if type(fixed_path_override) is not bool:raise EnvironmentError('env_input')
    if type(owner) is not str or re.fullmatch(r':[0-9]+\.[0-9]+',owner) is None or not bus:
        raise EnvironmentError('env_input')
    phase='env_owner_before'
    try:
        if look._owner(lib,bus)!=owner:raise _Fault(phase)
        phase='env_internal'
        kw={'fixed_path_override':True} if fixed_path_override else {}
        first=_property(lib,bus,owner.encode(),**kw)
        second=_property(lib,bus,owner.encode(),**kw)
        if first!=second:raise _Fault('env_changed')
        phase='env_owner_after'
        if look._owner(lib,bus)!=owner:raise _Fault(phase)
        return {'manager_global_environment':('allowlisted_except_overridden_path_two_snapshots' if fixed_path_override else 'allowlisted_two_snapshots'),
                'unit_environment':'not_verified','pre_exec_atomicity':'not_proven',
                'engine_launch_authorized':False}
    except _Fault as exc:raise EnvironmentError(exc.category) from None
    except Exception:raise EnvironmentError(phase) from None


def _removal_snapshot(lib,bus,owner):
    """Read bounded globals privately; return exact assignments and names, never log."""
    msg=P()
    try:
        if lib.sd_bus_get_property(bus,owner,look._PATH,look._INTERFACE,b'Environment',None,c.byref(msg),b'as')<0 or not msg.value:raise _Fault('env_property')
        if lib.sd_bus_message_enter_container(msg,b'a',b's')<=0:raise _Fault('env_array')
        assignments=set(); names=set(); total=0
        while True:
            value=c.c_char_p();r=lib.sd_bus_message_read(msg,b's',c.byref(value))
            if r<0:raise _Fault('env_read')
            if r==0:break
            if value.value is None:raise _Fault('env_read')
            raw=value.value;total+=len(raw)+1
            if total>_LIMIT or len(names)>=_COUNT:raise _Fault('env_size')
            key,sep,val=raw.partition(b'=')
            if len(raw)>4096 or not sep:raise _Fault('env_assignment')
            try:name=key.decode('ascii');val.decode('utf-8')
            except UnicodeError:raise _Fault('env_assignment') from None
            if re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*',name) is None:raise _Fault('env_assignment')
            if name in names:raise _Fault('env_duplicate')
            # Do not suppress systemd's own identity needed by admission.
            if name in ('INVOCATION_ID','SYSTEMD_EXEC_PID'):raise _Fault('env_allowlist')
            names.add(name);assignments.add(raw)
        if lib.sd_bus_message_exit_container(msg)<0:raise _Fault('env_array')
        return frozenset(assignments),tuple(sorted(names-{'PATH'}))
    finally:
        if msg.value:lib.sd_bus_message_unref(msg)


def removal_names_for_no_engine(lib,bus,owner):
    """Private no-engine-only removal set; assumes no concurrent manager writers.

    Full double snapshot detects differing samples, not intervening or later
    mutation. Unknown global names are passed only to fixed UnsetEnvironment;
    PATH is overridden separately. Never use for genuine/production launch.
    """
    if type(owner) is not str or re.fullmatch(r':[0-9]+\.[0-9]+',owner) is None or not bus:raise EnvironmentError('env_input')
    phase='env_owner_before'
    try:
        if look._owner(lib,bus)!=owner:raise _Fault(phase)
        phase='env_internal'
        first=_removal_snapshot(lib,bus,owner.encode());second=_removal_snapshot(lib,bus,owner.encode())
        if first!=second:raise _Fault('env_changed')
        phase='env_owner_after'
        if look._owner(lib,bus)!=owner:raise _Fault(phase)
        return first[1]
    except _Fault as exc:raise EnvironmentError(exc.category) from None
    except Exception:raise EnvironmentError(phase) from None
