"""Bounded exclusive pipe reader only: no identity, exit, stop, or cleanup."""
import fcntl
import json
import math
import os
import select
import stat
import time
from astra.policy import json_equal
from . import baseline_entry, synthetic_entry

MAX_LINE = 2048
_OUTCOMES = ('returned','driver_error','cancelled','internal_error','invalid_return')
class RecordError(ValueError): pass


def _object(pairs):
    out = {}
    for key,val in pairs:
        if key in out: raise RecordError('duplicate')
        out[key] = val
    return out


def _constant(value): raise RecordError('constant')


def parse(raw, kind):
    if (type(raw) is not bytes or not 1 <= len(raw) <= MAX_LINE+1 or not raw.endswith(b'\n')
        or raw.count(b'\n') != 1 or type(kind) is not str or kind not in ('baseline','integration')):
        raise RecordError('framing')
    try:
        obj = json.loads(raw[:-1].decode('ascii'), object_pairs_hook=_object, parse_constant=_constant)
        if type(obj) is not dict or type(obj.get('outcome')) is not str or obj['outcome'] not in _OUTCOMES:
            raise RecordError('outcome')
        obs = obj.get('observations'); outcome = obj['outcome']
        if type(obs) is not dict: raise RecordError('observations')
        e = dict(obs)
        if kind == 'integration':
            e['failure_shape'] = obj.get('fixture_failure')
            if outcome == 'returned': e['integration'] = obj.get('synthetic_evidence')
            canonical = synthetic_entry._report(e,outcome)
        else:
            if outcome == 'returned':
                s = obj.get('synthetic_evidence')
                if type(s) is not dict: raise RecordError('summary')
                e['baseline'] = {'stage':'baseline_observation_complete','astra_client_info_matches_baseline':True,
                  'astra_client_config_matches_baseline':True,'stderr_bytes':s.get('stderr_bytes'),
                  'info_check':{'version_statement_matches':True,'pid_statement_matches':True,'url_statement_matches':True,
                    'tmp_statement_matches':True,'endpoint_identity':'not_authenticated','binary_provenance':'not_verified'},
                  'config_check':{'effective_config':'matched_expected_sources_and_document','startup_safety':'not_verified'}}
            canonical = baseline_entry._report(e,outcome)
        if not json_equal(obj,canonical): raise RecordError('mismatch')
        return canonical
    except (ValueError,UnicodeError,TypeError,RecursionError,KeyError):
        raise RecordError('invalid record') from None


def collect(fd,kind,timeout):
    """Read to EOF; caller supplies exclusive pipe and owns all lifecycle.

    Changes O_NONBLOCK on the shared open-file description; never closes it.
    Timeouts do not bound kernel stalls and do not stop an associated unit.
    """
    def unknown(reason): return {'record':'unknown','reason':reason,'unit_cleanup':'not_observed','engine_launch_authorized':False}
    if (type(fd) is not int or fd < 0 or type(kind) is not str or kind not in ('baseline','integration')
        or type(timeout) not in (int,float) or not math.isfinite(timeout) or not 0 < timeout <= 120):
        return unknown('invalid_arguments')
    try:
        if not stat.S_ISFIFO(os.fstat(fd).st_mode): return unknown('not_pipe')
        if fcntl.fcntl(fd,fcntl.F_GETFL) & os.O_ACCMODE == os.O_WRONLY: return unknown('not_readable')
        os.set_blocking(fd,False); end=time.monotonic()+timeout; buf=bytearray()
        while True:
            remaining=end-time.monotonic()
            if remaining <= 0: return unknown('deadline')
            ready,_,_=select.select([fd],[],[],remaining)
            if not ready: continue
            try: data=os.read(fd, min(4096,MAX_LINE+2-len(buf)))
            except BlockingIOError: continue
            if not data:
                try: result=parse(bytes(buf),kind)
                except RecordError: return unknown('invalid_record')
                return {'record':'received','reason':None,'inner':result,'unit_cleanup':'not_observed','engine_launch_authorized':False}
            buf.extend(data)
            if len(buf) > MAX_LINE+1: return unknown('output_limit')
    except (OSError,ValueError,OverflowError): return unknown('read_error')
