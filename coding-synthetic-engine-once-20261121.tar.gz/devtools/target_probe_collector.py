"""Bounded final diagnostic record for the engine-free probe only.

No process start, verification, authentication, promotion or cleanup. An
external owner must independently supervise, stop, and dispose the VM. Missing
EOF, duplicates, malformed/oversize bytes, timeout and errors all fail closed.
"""
import json,os,select,time
from . import target_probe_entry as entry
class CollectorError(RuntimeError):pass

def _collect(stdout_fd,stderr_fd,timeout,*,expected_nobind_attempt=None):
    if (type(stdout_fd) is not int or type(stderr_fd) is not int or
        min(stdout_fd,stderr_fd)<0 or stdout_fd==stderr_fd or
        type(timeout) not in (int,float) or not 0<timeout<=10):raise CollectorError('inputs')
    end=time.monotonic()+timeout;buf={stdout_fd:bytearray(),stderr_fd:bytearray()};pending=set(buf)
    try:
        # Exact bound matters: a full buffer without EOF must not become an
        # artificial EOF from os.read(fd, 0). Validate real pipe direction.
        import fcntl,stat
        identities=[]
        for fd in pending:
            st=os.fstat(fd)
            if not stat.S_ISFIFO(st.st_mode) or fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE!=os.O_RDONLY:raise ValueError('pipe')
            identities.append((st.st_dev,st.st_ino));os.set_blocking(fd,False)
        if len(set(identities))!=2:raise ValueError('pipe alias')
        while pending:
            left=end-time.monotonic()
            if left<=0:raise TimeoutError
            ready,_,_=select.select(list(pending),[],[],left)
            if not ready:raise TimeoutError
            for fd in ready:
                # Always read at least one byte, including at exact limit.
                try:b=os.read(fd,max(1,entry._MAX+1-len(buf[fd])))
                except BlockingIOError:continue
                if not b:pending.remove(fd);continue
                buf[fd].extend(b)
                if len(buf[fd])>entry._MAX or (fd==stderr_fd and buf[fd]):raise ValueError('stream')
        data=bytes(buf[stdout_fd])
        if not data.endswith(b'\n') or data.count(b'\n')!=1:raise ValueError('frame')
        def pairs(items):
            d={}
            for k,v in items:
                if k in d:raise ValueError('duplicate')
                d[k]=v
            return d
        result=json.loads(data.decode('ascii'),object_pairs_hook=pairs)
        if expected_nobind_attempt is None:entry._validate(result)
        else:entry._validate_nobind(result,expected_nobind_attempt)
        return result
    except Exception:raise CollectorError('record unavailable or malformed') from None
