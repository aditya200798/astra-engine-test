"""Private one-shot genuine composition, blocked for public invocation.

This is NOT a sandbox, a provider teardown proof or launch authorization. All
FDs/paths and deadline must be held by an exclusively controlled disposable
VM wrapper; no credentials or personal data. Fixed driver remains blocked.
"""
import os
import secrets
import stat
import time
import re
from . import cgroup_watchdog as cg
from . import synthetic_no_engine_entry as base
from . import genuine_archive_guard as archive
from . import coding_control_flow as flow
from . import coding_supervisor as supervisor
from . import systemd_direct_start as direct
from . import synthetic_no_engine_supervisor as diagnostic
from . import synthetic_failure_evidence as failure

_BLOCKED=True
class EntryError(RuntimeError):pass
class _Entry:
    def __init__(self,source,evidence,packages,root,archive_dir,engine_dir,root_path,cgroup_root,delegated,deadline):
        self.fds=(source,evidence,packages,root,archive_dir,engine_dir,cgroup_root,delegated)
        if (any(type(x) is not int or x<0 for x in self.fds) or len(set(self.fds))!=8 or
            not flow.transport._valid_root(root_path) or type(deadline) not in (int,float) or
            not time.monotonic()<deadline<=time.monotonic()+480):raise EntryError('inputs')
        self.root_path=root_path;self.deadline=deadline;self.used=False
    def _remaining(self,cap,minimum):
        n=min(cap,self.deadline-time.monotonic())
        if n<minimum:raise EntryError('deadline')
        return n
    def _run_once(self):
        if self.used:raise EntryError('one shot')
        self.used=True
        source,evidence,packages,root,archive_dir,engine_dir,cgroup_root,delegated=self.fds
        result={'packages':'unknown','archive':'unknown','control':'unknown','staging':'not_started',
                'watchdog':'not_started','cleanup':'not_verified','isolation':'not_verified',
                'late_start':'not_reconciled','vm_decommission':'not_observed',
                'engine_launch_authorized':False,'production_approved':False,'fixture_request_sha256':None,
                'fixture_failure':failure.unknown(),
                'flow_stage':'not_observed','owner_stage':'not_observed','owner_reason':'not_observed',
                'start_phase':'not_observed','start_error':'not_observed','record':'not_observed','stop':'not_observed'}
        guard=None;engine_fd=None
        try:
            ids=[]
            for fd in self.fds:
                s=os.fstat(fd)
                if not stat.S_ISDIR(s.st_mode):raise EntryError('directory')
                ids.append((s.st_dev,s.st_ino))
            if len(set(ids))!=len(ids) or not cg._is_cgroup2(delegated):raise EntryError('identity')
            for fd in (packages,root,archive_dir,engine_dir):
                s=os.fstat(fd)
                if s.st_uid!=os.geteuid() or stat.S_IMODE(s.st_mode)!=0o700 or os.listdir(fd):raise EntryError('fresh directory')
            named=os.stat(self.root_path,follow_symlinks=False);held=os.fstat(root)
            if not stat.S_ISDIR(named.st_mode) or (named.st_dev,named.st_ino)!=(held.st_dev,held.st_ino):raise EntryError('root binding')
            self._remaining(110,110)
            guard=cg.create_guard(delegated,timeout=110)
            r=base._fetch_guarded(evidence,packages,guard,self._remaining(100,1));guard=None
            result['packages']=r['fetch']
            if r['fetch']!='fixed_17_downloads_rehashed':return result
            self._remaining(110,110)
            guard=cg.create_guard(delegated,timeout=110)
            r=archive._archive_guarded(archive_dir,engine_dir,guard,self._remaining(100,1));guard=None
            result['archive']=r['fetch']
            if r['fetch']!='fixed_download_and_binary_rehashed':return result
            self._remaining(115,115)
            engine_fd=os.open('opencode',os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK,dir_fd=engine_dir)
            unit='astra-synthetic-'+secrets.token_hex(16)+'.service'
            controller=flow._ControlFlow(source,packages,root,engine_fd,self.root_path,unit,
                         slice_name=direct._slice_for(unit),cgroup_root_fd=cgroup_root)
            guard=cg.create_guard(delegated,timeout=120)
            r=supervisor._supervise(controller,self._remaining(110,1),staging_guard=guard);guard=None
            if time.monotonic()>=self.deadline:raise EntryError('late supervisor result')
            if (type(r) is not dict or r.get('control') not in
                ('unknown','blocked_genuine_entry_record_and_exit_sampled','coding_inner_returned_cleanup_unverified') or
                r.get('engine_launch_authorized') is not False or r.get('production_approved') is not False):
                raise EntryError('supervisor result')
            digest=r.get('fixture_request_sha256')
            if digest is not None:
                raise EntryError('supervisor digest')
            shape=failure.validate_context(r.get('fixture_failure',failure.unknown()),control=r['control'],
                flow_stage=r.get('flow_stage'),owner_stage=r.get('owner_stage'),
                owner_reason=r.get('owner_reason'),start_phase=r.get('start_phase'),
                start_error=r.get('start_error'),record=r.get('record'),stop=r.get('stop'))
            if shape!=failure.unknown() and (r.get('watchdog')!='kill_returned_empty_sampled' or r.get('staging')!='kill_returned_empty_removed_sampled'):raise EntryError('failure evidence cleanup')
            # Revalidate all forwarded values; never forward arbitrary text.
            checked=diagnostic._worker_diagnostics({
                'stage':r.get('flow_stage','not_observed'),
                **{k:r.get(k,'not_observed') for k in
                   ('owner_stage','owner_reason','start_phase','start_error','record','stop')}})
            if r.get('staging') not in ('not_started','not_guarded','enrolled_sampled','kill_returned_empty_removed_sampled','cleanup_uncertain'):
                raise EntryError('staging category')
            if r.get('watchdog') not in ('not_started','ready_sampled','kill_returned_empty_sampled','outcome_uncertain'):
                raise EntryError('watchdog category')
            if r['control']!='unknown' and (r['staging']!='kill_returned_empty_removed_sampled' or r['watchdog']!='kill_returned_empty_sampled' or checked['stage']!='owner_returned_cleanup_unverified' or checked['owner_stage']!='finished' or checked['owner_reason']!='cleanup_unverified' or checked['start_phase']!='complete' or checked['start_error']!='not_observed' or checked['record']!='received' or checked['stop']!='job_done_inactive_snapshot'):
                raise EntryError('inconsistent lifecycle')
            result.update({'control':r['control'],'staging':r['staging'],
                           'watchdog':r['watchdog'],'fixture_request_sha256':digest,'fixture_failure':shape,
                           'flow_stage':checked['stage'],
                           **{k:checked[k] for k in ('owner_stage','owner_reason','start_phase','start_error','record','stop')}})
        except BaseException:
            result['control']='unknown';result['fixture_request_sha256']=None;result['fixture_failure']=failure.unknown()
        finally:
            if engine_fd is not None:os.close(engine_fd)
            if type(guard) is cg.Guard and not guard.finished:
                try:guard.finish()
                except BaseException:pass
                result['control']='unknown';result['fixture_request_sha256']=None;result['fixture_failure']=failure.unknown()
        return result

def run():
    if _BLOCKED:raise EntryError('genuine delegated entry blocked')
    raise EntryError('no approved orchestration')
