"""One-shot CI-only no-engine wiring; private, blocked, not a sandbox.

Caller must supply verified, exclusively owned FDs and protected ancestors in
an expendable synthetic VM and an externally delegated empty cgroup parent.
This module does not create the VM, grant permission or implement a workflow.
No real engine, model, secret or user data may be supplied. Public run blocked.
"""
import os
import secrets
import select
import signal
import stat
import time
from . import cgroup_watchdog as cg
from . import synthetic_no_engine_supervisor as supervisor
from . import synthetic_control_flow as flow
from . import systemd_direct_start as direct
from . import systemd_slice_anchor as anchor
from . import ubuntu_candidate_acquire as acquire

_BLOCKED=True
class EntryError(RuntimeError):pass


def _close_except(keep):
    # Single-threaded caller, exclusive child reaping, Linux procfs required.
    for item in os.listdir('/proc/self/fd'):
        fd=int(item)
        if fd not in keep:
            try:os.close(fd)
            except OSError:pass


def _fetch_guarded(evidence_fd,package_fd,guard,timeout=100):
    """Single actual acquisition, child gated before network, fixed byte reply.

    Guard must be a fresh ready delegated cgroup and is consumed, even on
    failure. No retries or tree removal. Assumes no other thread/child reaper.
    Parent/monitor death, pidfd acquisition failure and kernel stalls remain
    outer VM-recovery responsibilities. A result isn't a VM cleanup receipt.
    """
    deadline=time.monotonic()+timeout
    pidfd=None;pid=None;rd=wr=admit_r=admit_w=None;child_status=None;packet=b''
    result={'fetch':'unknown','guard':'cleanup_uncertain','fallback':'not_attempted'}
    checked=False;normal_completion=False;eof=False
    try:
        if (type(guard) is not cg.Guard or guard.finished or
            type(timeout) not in (int,float) or not 1<=timeout<=110):
            raise EntryError('guard or deadline')
        anchor._check_group(guard.parent_fd,guard.group_fd,guard.name)
        if cg._populated(cg._read(guard.group_fd,'cgroup.events')):raise EntryError('nonempty')
        cg._require_watchdog_alive(guard.pidfd);checked=True
        rd,wr=os.pipe2(os.O_CLOEXEC);admit_r,admit_w=os.pipe2(os.O_CLOEXEC)
        pid=os.fork()
        if pid==0:
            try:
                _close_except({wr,admit_r,evidence_fd,package_fd})
                # Parent death/failed enrollment must not start a download.
                ready,_,_=select.select([admit_r],[],[],5)
                if not ready or os.read(admit_r,2)!=b'G':os._exit(2)
                fetched=acquire._acquire(evidence_fd,package_fd)
                if (fetched.get('packages')!='fixed_17_downloads_rehashed' or
                    fetched.get('execution') is not False or
                    fetched.get('engine_launch_authorized') is not False):os._exit(3)
                os.write(wr,b'Y');os._exit(0)
            except BaseException:os._exit(4)
        os.close(wr);wr=None;os.close(admit_r);admit_r=None
        pidfd=os.pidfd_open(pid,0)
        cg._require_watchdog_alive(pidfd);cg._require_watchdog_alive(guard.pidfd)
        anchor._check_group(guard.parent_fd,guard.group_fd,guard.name)
        cg._write(guard.group_fd,'cgroup.procs',str(pid))
        if str(pid) not in cg._read(guard.group_fd,'cgroup.procs').split():raise EntryError('enrollment')
        cg._require_watchdog_alive(pidfd);cg._require_watchdog_alive(guard.pidfd)
        if time.monotonic()>=deadline:raise EntryError('deadline before fetch release')
        if os.write(admit_w,b'G')!=1:raise EntryError('release')
        os.close(admit_w);admit_w=None
        while time.monotonic()<deadline:
            readers=[pidfd,guard.pidfd]+([] if eof else [rd])
            ready,_,_=select.select(readers,[],[],max(0,deadline-time.monotonic()))
            if guard.pidfd in ready:break
            if rd in ready:
                chunk=os.read(rd,2-len(packet))
                if chunk:packet+=chunk
                else:eof=True
                if len(packet)>1:break
            if pidfd in ready and eof:
                normal_completion=True;break
    except BaseException:
        pass
    finally:
        for fd in (wr,admit_r,admit_w):
            if fd is not None:
                try:os.close(fd)
                except OSError:pass
        if pidfd is not None:
            try:
                st=os.waitid(os.P_PIDFD,pidfd,os.WEXITED|os.WNOHANG|os.WNOWAIT)
                if st is None:signal.pidfd_send_signal(pidfd,signal.SIGKILL)
            except (OSError,ChildProcessError):pass
        duplicate=None
        if type(guard) is cg.Guard and not guard.finished:
            try:duplicate=os.dup(guard.group_fd)
            except OSError:pass
            try:os.close(guard.pipe_w);guard.pipe_w=None
            except OSError:pass
        if pidfd is not None:
            child_status=supervisor._wait_reap(pidfd,3)
            os.close(pidfd)
        if type(guard) is cg.Guard and not guard.finished:
            try:
                guard.finish();result['guard']='kill_returned_empty_removed_sampled'
            except BaseException:
                if checked and duplicate is not None and child_status is not None:
                    result['fallback']=supervisor._fallback_once(guard.parent_fd,duplicate,guard.name)
            finally:
                if duplicate is not None:os.close(duplicate)
        if rd is not None:os.close(rd)
    if (normal_completion and packet==b'Y' and child_status==(os.CLD_EXITED,0) and
        time.monotonic()<deadline and result['guard']=='kill_returned_empty_removed_sampled'):
        result['fetch']='fixed_17_downloads_rehashed'
    return result


class _Entry:
    """Private composition; external owner supplies all independently trusted FDs.

    A single fetch into an empty fresh private destination is followed by one
    fixed baseline control flow in a separate guarded group. No deletion on
    failure. Source/evidence/package/root/parent identity, no competing writers,
    VM isolation and enclosing deadline are required from the caller, not proved.
    The caller must keep all FDs open; no PRoot, engine or provider is involved.
    """
    def __init__(self,source_fd,evidence_fd,package_fd,root_fd,root_path,cgroup_root_fd,delegated_fd):
        fds=(source_fd,evidence_fd,package_fd,root_fd,cgroup_root_fd,delegated_fd)
        if (any(type(fd) is not int or fd<0 for fd in fds) or len(set(fds))!=len(fds) or
            not flow.transport._valid_root(root_path)):
            raise EntryError('invalid input')
        self.fds=fds;self.root_path=root_path;self.used=False
    def _run_once(self):
        if self.used:raise EntryError('attempt consumed')
        self.used=True
        source,evidence,package,root,cgroup_root,delegated=self.fds
        # Overall admission budget: cleanup may exceed it, but a late stage
        # must never begin the next one. Kernel calls still need an outer bound.
        deadline=time.monotonic()+230
        staging_guard=None
        result={'fetch':'unknown','fetch_guard':'not_started','control':'unknown',
                'staging':'not_started','service_watchdog':'not_started',
                'cleanup':'not_verified','isolation':'not_verified',
                'vm_decommission':'not_observed','engine_launch_authorized':False,
                'production_approved':False,
                'supervisor_stage':'not_observed','worker':'not_observed','anchor':'not_observed',
                'flow_stage':'not_observed','owner_stage':'not_observed','owner_reason':'not_observed','start_phase':'not_observed','start_error':'not_observed','service_diag':'not_observed','service_result':'not_observed','exec_status':'not_observed','observe_phase':'not_observed','observe_error':'not_observed','timing':'not_observed',
                'record':'not_observed','stop':'not_observed'}
        try:
            identities=[]
            for fd in self.fds:
                st=os.fstat(fd)
                if not stat.S_ISDIR(st.st_mode):raise EntryError('not directory')
                identities.append((st.st_dev,st.st_ino))
            if len(set(identities))!=len(identities):raise EntryError('directory alias')
            for fd in (package,root):
                st=os.fstat(fd)
                if (st.st_uid!=os.geteuid() or stat.S_IMODE(st.st_mode)!=0o700 or
                    not cg._is_cgroup2(delegated) or os.listdir(fd)):
                    raise EntryError('fresh private directory required')
            # Exact pathname binding is sampled again by transport before owner.
            st=os.stat(self.root_path,follow_symlinks=False);held=os.fstat(root)
            if not stat.S_ISDIR(st.st_mode) or (st.st_dev,st.st_ino)!=(held.st_dev,held.st_ino):
                raise EntryError('root path mismatch')
            if deadline-time.monotonic()<2:raise EntryError('entry deadline')
            guard=cg.create_guard(delegated,timeout=110)
            remaining=min(100,deadline-time.monotonic())
            if remaining<1:
                # Consume a created guard even if setup exceeded the budget.
                guard.finish();raise EntryError('entry deadline')
            fetched=_fetch_guarded(evidence,package,guard,remaining)
            result['fetch']=fetched['fetch'];result['fetch_guard']=fetched['guard']
            if fetched['fetch']!='fixed_17_downloads_rehashed' or deadline-time.monotonic()<5:return result
            # Preserve entry-time directory identities across the guarded fetch.
            # Descriptor numbers alone can be closed and reused by caller bugs.
            for fd,expected in zip(self.fds,identities):
                current=os.fstat(fd)
                if not stat.S_ISDIR(current.st_mode) or (current.st_dev,current.st_ino)!=expected:
                    raise EntryError('directory identity changed')
            unit='astra-synthetic-'+secrets.token_hex(16)+'.service'
            controller=flow._ControlFlow(source,package,root,self.root_path,unit,'baseline',
                                          slice_name=direct._slice_for(unit),cgroup_root_fd=cgroup_root)
            remaining=deadline-time.monotonic()
            if remaining<5:raise EntryError('entry deadline')
            staging_guard=cg.create_guard(delegated,timeout=min(120,remaining))
            remaining=deadline-time.monotonic()
            if remaining<0.1:raise EntryError('entry deadline')
            observed=supervisor._supervise(controller,min(110,remaining),staging_guard=staging_guard)
            result['control']=observed['control'];result['staging']=observed['staging']
            result['service_watchdog']=observed['watchdog']
            # Values originate in the supervisor's fixed allowlists, not raw
            # user input, exception messages, paths, subprocess output or logs.
            for key in ('worker','anchor','flow_stage','owner_stage','owner_reason','start_phase','start_error','service_diag','service_result','exec_status','observe_phase','observe_error','timing','record','stop'):
                result[key]=observed.get(key,'not_observed')
            result['supervisor_stage']=observed['stage']
        except BaseException:
            # Any possibly accepted manager job and incomplete root remain for
            # outside recovery/provider teardown. Never guess a unit to stop.
            result['control']='unknown'
        finally:
            # _supervise can reject before entering its own finally. A valid
            # still-live guard is ours; finish once, never claim success here.
            if type(staging_guard) is cg.Guard and not staging_guard.finished:
                try:staging_guard.finish()
                except BaseException:pass
                result['control']='unknown';result['staging']='cleanup_uncertain'
        return result


def run():
    if _BLOCKED:raise EntryError('private entry blocked: CI boundary and review incomplete')
    raise EntryError('no approved orchestration')
