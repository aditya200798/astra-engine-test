"""Dedicated fixed synthetic target probe bootstrap, not a launch gate.

Must be started only as /usr/bin/python3 -I -S -B inside the verified empty-
engine control root and an independently supervised credential-free VM. It
uses the existing no-engine barrier, then emits only categorical probe data.
The fixed public orchestration and all engine/production gates remain blocked.
"""
import os,sys
_ENV={'PATH':'/usr/bin:/bin','HOME':'/work/home','TMPDIR':'/work/tmp','LANG':'C','LC_ALL':'C'}
def main():
 if sys.flags.isolated!=1 or sys.flags.no_site!=1 or sys.flags.dont_write_bytecode!=1 or sys.argv[1:] not in (['probe'],['probe_nobind']):return 2
 nobind=sys.argv[1:]==['probe_nobind']
 os.environ.clear();os.environ.update(_ENV)
 app=os.path.dirname(os.path.dirname(os.path.realpath(__file__)));sys.path.insert(0,app)
 from devtools.synthetic_service_barrier import receive_on_stdin
 marker=b'ASTRA-TARGET-PROBE-READY-1\n'
 if os.write(2,marker)!=len(marker):return 2
 attempt=receive_on_stdin(nobind=nobind)
 from devtools.target_probe_entry import main as entry
 return entry(nobind_attempt=attempt)
if __name__=='__main__':
 try:raise SystemExit(main())
 except (Exception,KeyboardInterrupt):raise SystemExit(2) from None
