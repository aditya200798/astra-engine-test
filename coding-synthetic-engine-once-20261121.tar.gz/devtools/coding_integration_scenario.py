"""Fixed synthetic coding scenario, offline specification; no engine launcher.

Nothing imports this from the existing genuine entry. SSE shape follows the
old fixture; runtime OpenCode compatibility and any isolation remain untested.
Only fixed, invented source/prompt/response values are accepted here.
"""
import hashlib
import json
from . import fake_responses as fake
from astra.transport import strict_json

SOURCE=b'answer = 1\n'
SOURCE_SHA256='31055738067e8e385812d6332aa83e4a4bba83a4cd24e7c4a32f350c82a68a82'
PROMPT_SHA256='9d532a1af3cd121b9a0aeea7fb487f03b1b859922b76e3326214f6a21503cb24'
INSTRUCTION='Change answer to two'
RESPONSE=json.dumps([{'path':'main.py','sha256':SOURCE_SHA256,'old':'1','new':'2'}],separators=(',',':'),ensure_ascii=True)


def response_events():
    """Produce one fixed code-edit response, not selectable by caller input."""
    events=[]
    for frame in fake.response_events().strip().split(b'\n\n'):
        if not frame.startswith(b'data: '):raise ValueError('fixture frame')
        event=strict_json(frame[6:])
        if event['type']=='response.output_text.delta':event['delta']=RESPONSE
        if event['type']=='response.output_text.done':event['text']=RESPONSE
        if event['type'] in ('response.output_item.done','response.completed'):
            item=event['item'] if event['type']=='response.output_item.done' else event['response']['output'][0]
            item['content'][0]['text']=RESPONSE
        events.append(b'data: '+json.dumps(event,separators=(',',':'),ensure_ascii=True).encode('ascii')+b'\n\n')
    result=b''.join(events)
    if len(result)>fake.MAX_RESPONSE_EVENTS_BYTES:raise ValueError('fixture response too large')
    return result


def matches_request(raw):
    """Exact fixed user-prompt hash, not a check of all model/provider traffic."""
    try:
        if not isinstance(raw,bytes) or len(raw)>fake.MAX_REQUEST_BYTES:return False
        body=strict_json(raw)
        if type(body) is not dict or body.get('model')!=fake.MODEL or body.get('stream') is not True:return False
        items=body.get('input')
        if type(items) is not list:return False
        users=[x for x in items if type(x) is dict and x.get('role')=='user']
        if len(users)!=1:return False
        content=users[0].get('content')
        if type(content) is list:
            if len(content)!=1 or type(content[0]) is not dict or set(content[0])!={'type','text'} or content[0]['type']!='input_text':return False
            content=content[0]['text']
        if type(content) is not str:return False
        return hashlib.sha256(content.encode('utf-8')).hexdigest()==PROMPT_SHA256
    except (ValueError,TypeError,UnicodeError,RecursionError):return False


def run():
    raise RuntimeError('unwired coding scenario; genuine execution not authorized')
