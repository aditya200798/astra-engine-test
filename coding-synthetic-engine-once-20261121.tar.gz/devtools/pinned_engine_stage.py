"""Developer-only artifact staging for the previously observed v2.3.2 archive.

No download, execution, runtime setup, provenance verification, or promotion.
Only use inside a fresh isolated developer CI VM with synthetic material. A
hash match is byte identity to recorded observations, not new attestation.
"""
import hashlib
import os
import stat
import tarfile

ARCHIVE_SIZE = 122_641_607
ARCHIVE_SHA256 = '563b5d663637226b6e3bb4bb6803281bc39b0d2cd88db06d674b6420aab009b0'
BINARY_SIZE = 252_848_304
BINARY_SHA256 = 'e6543f6e5c39c40971ba38afd1819ac852c29ac735b5a89065d3d148d47f27ad'
CHUNK = 1024 * 1024


class StageError(RuntimeError):
    pass


def _identity(st):
    return (st.st_dev, st.st_ino, st.st_mode, st.st_size,
            st.st_mtime_ns, st.st_ctime_ns)


def _digest_fd(fd, expected_size):
    os.lseek(fd, 0, os.SEEK_SET)
    digest = hashlib.sha256()
    total = 0
    while True:
        data = os.read(fd, CHUNK)
        if not data:
            break
        total += len(data)
        if total > expected_size:
            raise StageError('archive length exceeded')
        digest.update(data)
    if total != expected_size:
        raise StageError('archive length mismatch')
    return digest.hexdigest()


def _stage(archive_path, directory, *, archive_size, archive_digest,
           binary_size, binary_digest):
    """Path convenience API; intermediate components are not authenticated.

    The actual guarded acquisition uses held directory FDs instead. A caller
    using paths must independently protect their ancestors and mount topology.
    """
    if not all(hasattr(os, flag) for flag in ('O_NOFOLLOW', 'O_DIRECTORY', 'O_CLOEXEC')):
        raise StageError('required OS flags unavailable')
    if not all(isinstance(p, str) and os.path.isabs(p) and '\0' not in p
               for p in (archive_path, directory)):
        raise StageError('absolute paths required')
    afd = dfd = None
    try:
        afd = os.open(archive_path, os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW | os.O_CLOEXEC)
        dfd = os.open(directory, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
        return _stage_open(afd, dfd, archive_size=archive_size, archive_digest=archive_digest,
                           binary_size=binary_size, binary_digest=binary_digest)
    except StageError:
        raise
    except Exception as exc:
        raise StageError('staging failed') from exc
    finally:
        if afd is not None: os.close(afd)
        if dfd is not None: os.close(dfd)


def stage_pinned_held_directories(archive_dir_fd, engine_dir_fd):
    """Stage from the held archive directory into held engine directory.

    No proc-fd pathname is resolved. Both supplied FDs remain caller-owned.
    A no-follow leaf open binds release.tar.gz to the archive directory FD.
    This does not prevent concurrent writers or prove mount/VM integrity.
    """
    if any(type(fd) is not int or fd < 0 for fd in (archive_dir_fd, engine_dir_fd)):
        raise StageError('invalid directory descriptor')
    afd = None
    try:
        ars = os.fstat(archive_dir_fd)
        ens = os.fstat(engine_dir_fd)
        if (not stat.S_ISDIR(ars.st_mode) or not stat.S_ISDIR(ens.st_mode) or
                (ars.st_dev, ars.st_ino) == (ens.st_dev, ens.st_ino)):
            raise StageError('invalid or aliased directories')
        afd = os.open('release.tar.gz', os.O_RDONLY | os.O_NONBLOCK | os.O_NOFOLLOW | os.O_CLOEXEC,
                      dir_fd=archive_dir_fd)
        return _stage_open(afd, engine_dir_fd, archive_size=ARCHIVE_SIZE, archive_digest=ARCHIVE_SHA256,
                           binary_size=BINARY_SIZE, binary_digest=BINARY_SHA256)
    except StageError:
        raise
    except Exception as exc:
        raise StageError('staging failed') from exc
    finally:
        if afd is not None: os.close(afd)


def _stage_open(afd, dfd, *, archive_size, archive_digest, binary_size, binary_digest):
    """Internal staging core; input descriptors borrowed, never closed here."""
    outfd = None
    created = False
    try:
        before = os.fstat(afd)
        if not stat.S_ISREG(before.st_mode) or before.st_size != archive_size:
            raise StageError('archive not expected regular file')
        dstat = os.fstat(dfd)
        if dstat.st_uid != os.geteuid() or stat.S_IMODE(dstat.st_mode) != 0o700:
            raise StageError('stage directory must be owner-private')
        if os.listdir(dfd):
            raise StageError('stage directory not empty')
        if _digest_fd(afd, archive_size) != archive_digest or _identity(os.fstat(afd)) != _identity(before):
            raise StageError('archive digest or identity mismatch')
        os.lseek(afd, 0, os.SEEK_SET)
        # Duplicate so closing the stream doesn't close the original verification FD.
        with os.fdopen(os.dup(afd), 'rb') as source, tarfile.open(fileobj=source, mode='r:gz') as tar:
            members = tar.getmembers()
            if (len(members) != 1 or members[0].name != 'opencode' or
                    members[0].type not in (tarfile.REGTYPE, tarfile.AREGTYPE) or
                    members[0].size != binary_size or
                    stat.S_IMODE(members[0].mode) != 0o755):
                raise StageError('archive layout mismatch')
            stream = tar.extractfile(members[0])
            if stream is None:
                raise StageError('archive member unavailable')
            outfd = os.open('opencode', os.O_WRONLY | os.O_CREAT | os.O_EXCL |
                            os.O_NOFOLLOW | os.O_CLOEXEC, 0o600, dir_fd=dfd)
            created = True
            digest = hashlib.sha256()
            total = 0
            with stream:
                while True:
                    data = stream.read(CHUNK)
                    if not data:
                        break
                    total += len(data)
                    if total > binary_size:
                        raise StageError('binary length exceeded')
                    digest.update(data)
                    view = memoryview(data)
                    while view:
                        n = os.write(outfd, view)
                        if n <= 0:
                            raise StageError('binary write failed')
                        view = view[n:]
            if total != binary_size or digest.hexdigest() != binary_digest:
                raise StageError('binary digest or length mismatch')
        # Recheck full compressed bytes and stat to detect normal concurrent changes.
        if _identity(os.fstat(afd)) != _identity(before) or _digest_fd(afd, archive_size) != archive_digest or _identity(os.fstat(afd)) != _identity(before):
            raise StageError('archive changed during staging')
        os.fchmod(outfd, 0o400)  # no execute permission; staging never runs the file
        os.fsync(outfd)
        os.close(outfd)
        outfd = None
        os.fsync(dfd)
        return {'archive_bytes': archive_size, 'archive_sha256': archive_digest,
                'binary_bytes': binary_size, 'binary_sha256': binary_digest,
                'file_mode': '0400', 'executed': False,
                'provenance': 'not_verified_by_this_function',
                'engine_launch_authorized': False}
    except Exception as exc:
        if outfd is not None:
            try:
                os.close(outfd)
            except OSError:
                pass
            outfd = None
        if created and dfd is not None:
            try:
                os.unlink('opencode', dir_fd=dfd)
            except OSError:
                raise StageError('staging failed; cleanup uncertain') from None
        raise StageError('staging failed') from exc
    finally:
        if outfd is not None:
            os.close(outfd)
        # Input FDs belong to the caller; only the output FD is owned here.


def stage_pinned_archive(archive_path, fresh_private_directory):
    """Stage fixed observed bytes only. Never execute the staged executable.

    Call only inside a disposable isolated developer VM. Caller owns removal of
    the entire fresh directory on all paths. A matching hash is not provenance,
    isolation, an independent audit, a gate, or permission to launch.
    """
    return _stage(archive_path, fresh_private_directory, archive_size=ARCHIVE_SIZE,
                  archive_digest=ARCHIVE_SHA256, binary_size=BINARY_SIZE,
                  binary_digest=BINARY_SHA256)
