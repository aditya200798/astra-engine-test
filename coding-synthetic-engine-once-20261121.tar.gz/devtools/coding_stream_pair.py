"""Bounded two-phase pipe reader; never a supervisor or launch authority.

Real FD I/O only. The caller owns exclusive read ends and must independently
bind the unit, start/admit it, supervise, stop it and verify cleanup. A complete
line before EOF is provisional; later output or absent EOF invalidates it.
"""
import fcntl
import math
import os
import select
import stat
import time
from .coding_inner_collector import MAX_LINE, RecordError, parse

STDERR_LIMIT=4096
class StreamError(RuntimeError): pass


def _unknown(reason):
    return {'record':'unknown','reason':reason,'stderr':'not_reported',
            'exit':'not_observed','unit_cleanup':'not_observed',
            'engine_launch_authorized':False}


def _timeout(value):
    return type(value) in (int,float) and math.isfinite(value) and 0 < value <= 120


class StreamPair:
    """One owner, one provisional read, one final drain; no FD is closed here.

    Private anonymous/FIFO pipe read ends must come from the trusted caller.
    `O_NONBLOCK` changes the shared open-file description. All bounds exclude
    kernel hangs/scheduling delays. A record is never evidence until EOF on BOTH
    streams, zero stderr, strict parse, and an independent lifecycle observation.
    """
    def __init__(self,stdout_fd,stderr_fd,kind):
        if (type(stdout_fd) is not int or type(stderr_fd) is not int or
            stdout_fd<0 or stderr_fd<0 or stdout_fd==stderr_fd or
            type(kind) is not str or kind != 'coding'):
            raise StreamError('invalid_arguments')
        try:
            a,b=os.fstat(stdout_fd),os.fstat(stderr_fd)
            if not stat.S_ISFIFO(a.st_mode) or not stat.S_ISFIFO(b.st_mode): raise StreamError('not_pipe')
            if (a.st_dev,a.st_ino)==(b.st_dev,b.st_ino): raise StreamError('same_pipe')
            for fd in (stdout_fd,stderr_fd):
                if fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE==os.O_WRONLY:
                    raise StreamError('not_readable')
            for fd in (stdout_fd,stderr_fd): os.set_blocking(fd,False)
        except (OSError,ValueError,OverflowError): raise StreamError('read_error') from None
        self.outfd,self.errfd,self.kind=stdout_fd,stderr_fd,kind
        self.pending={stdout_fd,stderr_fd}; self.out=bytearray(); self.err_count=0
        self.error=None; self.stage='fresh'

    def _drain_ready(self,timeout):
        ready,_,_=select.select(list(self.pending),[],[],timeout)
        for fd in ready:
            limit=MAX_LINE+2-len(self.out) if fd==self.outfd else STDERR_LIMIT+1-self.err_count
            try: data=os.read(fd,min(4096,limit))
            except BlockingIOError: continue
            if not data: self.pending.remove(fd); continue
            if fd==self.outfd:
                self.out.extend(data)
                if len(self.out)>MAX_LINE+1: self.error='stdout_limit'; return
            else:
                self.err_count+=len(data)
                if self.err_count>STDERR_LIMIT: self.error='stderr_limit'; return

    def _line(self):
        if b'\n' not in self.out: return False
        try: parse(bytes(self.out),self.kind)
        except RecordError: self.error='invalid_record'; return False
        return True

    def before_stop(self,timeout):
        """Drain until a valid line is *provisional*, or timeout/invalid input.

        One call only. Provisional never has `record=received` or `inner`; it is
        a signal for the owner to observe status and perform its cleanup path.
        No missing EOF, stderr, extra output or manager failure is papered over.
        """
        if self.stage!='fresh': return _unknown('invalid_state')
        self.stage='provisional_done'
        if not _timeout(timeout): self.error='invalid_arguments'; return _unknown(self.error)
        end=time.monotonic()+timeout
        try:
            while True:
                # Check stderr first, even when a line arrives in the same poll.
                if self.err_count: self.error='stderr_present'; break
                if self._line():
                    return {'record':'provisional','reason':'awaiting_eof_after_stop',
                            'stderr':'not_final','exit':'not_observed',
                            'unit_cleanup':'not_observed','engine_launch_authorized':False}
                if self.error: break
                if self.outfd not in self.pending: self.error='invalid_record'; break
                left=end-time.monotonic()
                if left<=0: self.error='deadline'; break
                self._drain_ready(left)
                if self.error: break
        except (OSError,ValueError,OverflowError): self.error='read_error'
        return _unknown(self.error)

    def after_stop(self,timeout):
        """Drain to both EOFs after the independently attempted stop, once.

        If before_stop failed, cleanup is still a caller obligation and no
        later bytes can retroactively convert that failure into a valid record.
        This call does not claim a stop occurred; the name documents ordering.
        """
        if self.stage!='provisional_done': return _unknown('invalid_state')
        self.stage='finalized'
        if self.error: return _unknown(self.error)
        if not _timeout(timeout): self.error='invalid_arguments'; return _unknown(self.error)
        end=time.monotonic()+timeout
        try:
            while self.pending:
                left=end-time.monotonic()
                if left<=0: self.error='deadline'; return _unknown(self.error)
                self._drain_ready(left)
                if self.error: return _unknown(self.error)
            if self.err_count: return _unknown('stderr_present')
            try: record=parse(bytes(self.out),self.kind)
            except RecordError: return _unknown('invalid_record')
            return {'record':'received','reason':None,'inner':record,'stderr':'empty',
                    'exit':'not_observed','unit_cleanup':'not_observed','engine_launch_authorized':False}
        except (OSError,ValueError,OverflowError): return _unknown('read_error')


def collect(stdout_fd,stderr_fd,kind,timeout):
    """Existing one-shot interface. Uses same deadline for both phases.

    No stop is performed here; if writers remain open this still times out.
    """
    if not _timeout(timeout): return _unknown('invalid_arguments')
    try: stream=StreamPair(stdout_fd,stderr_fd,kind)
    except StreamError as e: return _unknown(str(e))
    end=time.monotonic()+timeout
    provisional=stream.before_stop(timeout)
    if provisional['record']!='provisional': return provisional
    left=end-time.monotonic()
    if left<=0: return _unknown('deadline')
    return stream.after_stop(left)
