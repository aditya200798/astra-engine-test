"""Fixed pre-entry admission rendezvous; not a supervisor or authorization.

Only the existing fixed synthetic bootstrap may call `receive_on_stdin`.
The parent must supply an exclusive private pipe as stdin, bind its other end
and the service invocation, check its real settings, and kill/clean the unit
on any uncertainty. The frame is public protocol data, not authentication.
"""
import fcntl
import os
import select
import stat
import struct
import sys
import time

# Complete fixed frame followed by EOF. Single action, no command or data.
_FRAME=b'ASTRA-SYNTHETIC-ADMIT-1\n'
# Genuine service adds device/inode of the outer held installed inode.
_GENUINE_PREFIX=b'ASTRA-GENUINE-ADMIT-2\n'
_GENUINE_SIZE=len(_GENUINE_PREFIX)+16
# Fixed no-bind diagnostic case, not an authorization or an authentication token.
_NOBIND_PREFIX=b'ASTRA-TARGET-NOBIND-ADMIT-1\nno-bind-path-v1\n'
_NOBIND_SIZE=len(_NOBIND_PREFIX)+32

def _nobind_attempt(attempt):
    if type(attempt) is not bytes or len(attempt)!=32 or not any(attempt):raise ValueError('attempt')
    return attempt
_TIMEOUT=15.0
class BarrierError(RuntimeError): pass

def receive_on_stdin(*, genuine=False, nobind=False):
    """Require complete frame AND EOF before replacing stdin with /dev/null.

    EOF without the frame, wrong/extra bytes, lost writer, invalid FD and
    deadline all fail before project driver imports. Direct syscalls can hang;
    this timeout is not a hard external watchdog. Success does not validate
    manager properties, caller identity, network, root, or lifecycle.
    """
    fd=0
    try:
        if type(genuine) is not bool or type(nobind) is not bool or genuine and nobind: raise ValueError('invalid barrier')
        prefix=_NOBIND_PREFIX if nobind else _GENUINE_PREFIX if genuine else _FRAME
        length=_NOBIND_SIZE if nobind else _GENUINE_SIZE if genuine else len(_FRAME)
        s=os.fstat(fd)
        if not stat.S_ISFIFO(s.st_mode): raise ValueError('not pipe')
        if fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE==os.O_WRONLY: raise ValueError('not readable')
        # The caller must own this open-file description; the flag is shared.
        os.set_blocking(fd,False)
        deadline=time.monotonic()+_TIMEOUT; buf=bytearray()
        while True:
            remaining=deadline-time.monotonic()
            if remaining<=0: raise ValueError('deadline')
            ready,_,_=select.select([fd],[],[],remaining)
            if not ready: raise ValueError('deadline')
            try: data=os.read(fd,length+1-len(buf))
            except BlockingIOError: continue
            if not data:
                if len(buf)!=length or not bytes(buf).startswith(prefix): raise ValueError('incomplete')
                break
            buf.extend(data)
            if len(buf)>length or (len(buf)<=len(prefix) and not prefix.startswith(buf)) or (len(buf)>len(prefix) and not bytes(buf).startswith(prefix)): raise ValueError('unexpected frame')
        # Never let the release descriptor escape into engine/children. The
        # pipe's write end must be closed by the parent to deliver EOF.
        os.close(fd)
        null=os.open('/dev/null',os.O_RDONLY|os.O_CLOEXEC)
        # The inherited fd is now harmless /dev/null, not the admission pipe.
        # Keep standard input available to programs that inherit it across exec.
        if null!=fd:
            try: os.dup2(null,fd,inheritable=True)
            finally: os.close(null)
        else: os.set_inheritable(fd,True)
        sys.stdin=os.fdopen(fd,'r',encoding='ascii',closefd=False)
        if nobind:return _nobind_attempt(bytes(buf[len(prefix):]))
        return struct.unpack('!QQ',bytes(buf[len(prefix):])) if genuine else None
    except (OSError,ValueError,TypeError,OverflowError):
        raise BarrierError('prestart admission unavailable') from None
