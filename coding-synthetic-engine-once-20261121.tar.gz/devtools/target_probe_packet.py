"""Fixed schema for untrusted target-probe worker packets; no authority.

A parser is not a supervisor. Public orchestration remains blocked. This
module validates diagnostics only, including nested duplicate JSON keys.
"""
import json
from . import target_probe_entry as entry, systemd_pidfd_lookup as lookup, systemd_manager_environment as env, systemd_bound_session as bound

class PacketError(ValueError):
    pass

_FIELDS={'stage','control','root','manager','sample','owner_stage','stop','start_phase','start_error','service_diag','service_result','exec_status','observe_phase','observe_error',
         'cleanup','canary_liveness','isolation','engine_launch_authorized',
         'production_approved'}
_CATEGORIES={
 'stage':{'root_unknown','manager_unknown','anchor_uncertain','owner_uncertain',
          'owner_returned_cleanup_unverified','anchor_close_uncertain'},
 'control':{'unknown','probe_record_and_exit_sampled'},
 'root':{'not_observed','fixed_no_engine_tree_sampled'},
 'manager':{'not_observed','same_connection_sampled','close_uncertain'},
 'owner_stage':{'not_observed','pipes','start_uncertain','readiness','observe',
                'announce_uncertain','release_uncertain','record','exit','stop','finished'},
 'stop':{'not_observed','bound_inactive_snapshot'},
 'cleanup':{'not_verified'},'canary_liveness':{'not_verified'},
 'isolation':{'not_verified'}}

_START_PHASES={'not_observed','not_started','proto','manager_before','subscribe','root_first','root_inspect','environment','root_recheck','anchor_recheck','message_build','send_uncertain','await_job','job_not_done','manager_after','complete'}
_NATIVE_ERRORS={'invalid_argument','permission','timeout','connection','fork_mismatch','resource','exists','io','not_found','not_supported','busy','other','no_reply'}
def _valid_start_diagnostic(control, stage, phase, error):
    # These are last-entered phases, not proof that a call occurred or failed.
    if any(type(x) is not str for x in (control,stage,phase,error)):return False
    if phase not in _START_PHASES:return False
    if phase=='not_observed':return error=='not_observed'
    if control!='unknown' or stage!='start_uncertain':return False
    if phase=='job_not_done':return error in bound._JOB_ERRORS
    if error=='not_observed':return True
    # An interruption after storing the job error but before phase advances
    # may leave await_job as the last entered phase. Diagnostic only.
    if phase=='await_job':return error in bound._JOB_ERRORS
    if phase=='environment':return error in env._CATEGORIES
    if phase=='send_uncertain':return error in _NATIVE_ERRORS
    return False

def _valid_start_service(control, stage, phase, error, diag, result, status):
    if any(type(x) is not str for x in (diag,result,status)):return False
    if diag=='not_observed':return result==status=='not_observed'
    if (control,stage,phase,error)!=('unknown','start_uncertain','job_not_done','job_failed'):return False
    if diag not in bound._SERVICE_DIAG or result not in bound._SERVICE_RESULTS or status not in bound._EXEC_STATUS:return False
    if diag=='sampled':return result!='not_observed' and status!='not_observed'
    return result==status=='unknown'

def _valid_transition(stage, owner_stage, stop, *, nobind, announced=None):
    """Check reachable diagnostics; announcement is supervisor-observed only.

    A close failure can replace any prior stage. A received ACK does not prove
    its callback returned. Untrusted categories remain non-authorizing.
    """
    if type(nobind) is not bool or announced not in (None, True, False):return False
    if owner_stage != 'not_observed' and stage not in ('owner_returned_cleanup_unverified','anchor_close_uncertain'):return False
    if stage == 'owner_returned_cleanup_unverified' and owner_stage == 'not_observed':return False
    if stop != 'not_observed' and owner_stage in ('not_observed','pipes','start_uncertain','readiness'):return False
    if owner_stage=='finished' and stop!='bound_inactive_snapshot':return False
    if nobind and announced is not None:
        if announced and (stage in ('root_unknown','manager_unknown','anchor_uncertain') or
                          owner_stage in ('pipes','start_uncertain','readiness','observe')):return False
        if not announced and owner_stage in ('release_uncertain','record','exit','stop','finished'):return False
    return True

def _valid_observe_stop(owner_stage, phase, stop):
    # _bound is first set after lookup returned and identity checks. It may
    # already exist if later no-bind identity or anchor membership fails.
    return not (owner_stage=='observe' and stop=='bound_inactive_snapshot' and
                phase not in ('not_observed','bound_identity','anchor_membership','complete'))

def _unique(items):
    result={}
    for key,value in items:
        if key in result:raise PacketError('duplicate key')
        result[key]=value
    return result

def _reject_constant(_):
    raise PacketError('invalid constant')

def _parse(packet,*,nobind=False):
    """Parse exactly one bounded R+ASCII JSON datagram; no trailing data."""
    try:
        if type(packet) is not bytes or not 2<=len(packet)<=4096 or packet[:1]!=b'R':
            raise PacketError('frame')
        obj=json.loads(packet[1:].decode('ascii'),object_pairs_hook=_unique,
                       parse_constant=_reject_constant)
        if type(obj) is not dict or set(obj)!=_FIELDS:raise PacketError('fields')
        for key,values in _CATEGORIES.items():
            if type(obj[key]) is not str or obj[key] not in values:raise PacketError('category')
        if not _valid_transition(obj['stage'],obj['owner_stage'],obj['stop'],nobind=nobind):raise PacketError('transition')
        # Owner runs only after fixed root, manager connection and anchor ACK.
        # Bus close may replace same_connection with close_uncertain afterwards.
        if obj['owner_stage']!='not_observed' and (obj['root']!='fixed_no_engine_tree_sampled' or obj['manager'] not in ('same_connection_sampled','close_uncertain')):raise PacketError('owner prerequisites')
        if not _valid_start_diagnostic(obj['control'],obj['owner_stage'],obj['start_phase'],obj['start_error']):raise PacketError('start diagnostic')
        if not _valid_start_service(obj['control'],obj['owner_stage'],obj['start_phase'],obj['start_error'],obj['service_diag'],obj['service_result'],obj['exec_status']):raise PacketError('service diagnostic')
        phase=obj['observe_phase'];error=obj['observe_error']
        if not _valid_observe_stop(obj['owner_stage'],phase,obj['stop']):raise PacketError('stop order')
        if not lookup._valid_probe_diagnostic(obj['owner_stage'],phase,error,nobind=nobind):raise PacketError('observation category')
        if (phase!='not_observed' or error!='not_observed') and (obj['control']!='unknown' or obj['owner_stage'] not in ('observe','release_uncertain')):raise PacketError('observation stage')
        if obj['engine_launch_authorized'] is not False or obj['production_approved'] is not False:
            raise PacketError('authority')
        sample=obj['sample']
        if sample!='not_observed':entry._validate(sample)
        if obj['control']=='probe_record_and_exit_sampled':
            if (type(sample) is not dict or obj['stage']!='owner_returned_cleanup_unverified' or
                obj['root']!='fixed_no_engine_tree_sampled' or obj['manager']!='same_connection_sampled' or
                obj['owner_stage']!='finished' or obj['stop']!='bound_inactive_snapshot'):
                raise PacketError('inconsistent success')
        return obj
    except (ValueError,TypeError,UnicodeError,RecursionError,entry.ProbeEntryError):
        raise PacketError('invalid target-probe packet') from None


def _project_nobind_unknown(info):
    """Project a failed no-bind flow to a bounded, non-authorizing packet.

    A previously sampled success may have become unknown during anchor or
    bus closure; discard its sample and private inode before serialization.
    Never coerce malformed categories or permit additional fields.
    """
    if (type(info) is not dict or info.get('control') != 'unknown' or
        set(info) not in (_FIELDS, _FIELDS | {'nobind_host_identity'})):
        raise PacketError('invalid no-bind failure')
    projected={k:info[k] for k in _FIELDS}
    projected['sample']='not_observed'
    try:
        packet=b'R'+json.dumps(projected,sort_keys=True,separators=(',',':'),
                              ensure_ascii=True,allow_nan=False).encode('ascii')
        _parse_nobind_unknown(packet)
        return packet
    except (ValueError,TypeError,UnicodeError,RecursionError):
        raise PacketError('invalid no-bind failure') from None

def _parse_nobind_unknown(packet):
    info=_parse(packet,nobind=True)
    if info['control']!='unknown' or info['sample']!='not_observed':
        raise PacketError('not a no-bind failure')
    return info
