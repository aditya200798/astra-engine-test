"""Read-only exact staged no-engine root verification, not isolation or approval.

For a trusted disposable CI VM with a caller-owned protected root only. No tree
is mounted, repaired, deleted, executed, or authorized by this module. The
checks are sampled and cannot defeat concurrent privileged filesystem changes.
"""
import hashlib
import os
import stat
from . import coding_supervised_app_stage as app
from . import coding_root_skeleton as sk
from . import ubuntu_runtime_stage as rt
from . import pinned_engine_stage as pinned

class RootVerifyError(RuntimeError):pass
_FLAGS=os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC
_MAX_DEPTH=32


def _identity(st):
    return (st.st_dev,st.st_ino,st.st_mode,st.st_uid,st.st_gid,st.st_nlink,
            st.st_size,st.st_mtime_ns,st.st_ctime_ns)


def _specs():
    manifest=rt._manifest();files={};links=dict(rt._EXTRAS);dirs={'usr','app','app/astra','app/devtools'}
    for path,digest in app.MANIFEST.items():
        files['app/'+path]=(None,'0444',digest)
    for entry in manifest['entries']:
        path=entry['path']
        if (type(path) is not str or not path.startswith('usr/') or
            any(part in ('','.','..') for part in path.split('/')) or path in files or path in links):
            raise ValueError('manifest path')
        if entry['kind']=='file':files[path]=(entry['size'],entry['mode'],entry['sha256'])
        elif entry['kind']=='symlink':links[path]=entry['target']
        else:raise ValueError('manifest kind')
    for path in (*files,*links):
        parts=path.split('/')
        if len(parts)>_MAX_DEPTH:raise ValueError('manifest depth')
        for i in range(1,len(parts)):dirs.add('/'.join(parts[:i]))
    if set(files)&set(links) or (set(files)|set(links))&dirs:raise ValueError('manifest collision')
    return files,links,dirs


def _verify_tree(root_fd,owner,group):
    files,links,dirs=_specs();opened={};seen=set();file_count=0;link_count=0
    try:
        for top in ('app','usr'):
            opened[top]=os.open(top,_FLAGS,dir_fd=root_fd)
        for path in sorted(dirs,key=lambda x:(x.count('/'),x)):
            if path not in opened:
                parent,_,name=path.rpartition('/');opened[path]=os.open(name,_FLAGS,dir_fd=opened[parent])
            fd=opened[path];st=sk._dir(fd,owner,group,0o555)
            if path in ('app','usr'):
                named=os.stat(path,dir_fd=root_fd,follow_symlinks=False)
            else:
                parent,_,name=path.rpartition('/');named=os.stat(name,dir_fd=opened[parent],follow_symlinks=False)
            if sk._identity(st)!=sk._identity(named):raise ValueError('directory changed')
            children=set()
            for p in dirs|set(files)|set(links):
                parent,_,leaf=p.rpartition('/')
                if parent==path:children.add(leaf)
            if set(os.listdir(fd))!=children:raise ValueError('unexpected directory entries')
        for path,(size,mode,digest) in sorted(files.items()):
            parent,_,name=path.rpartition('/');fd=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC,dir_fd=opened[parent])
            try:
                st=os.fstat(fd);named=os.stat(name,dir_fd=opened[parent],follow_symlinks=False)
                if (not stat.S_ISREG(st.st_mode) or st.st_uid!=owner or st.st_gid!=group or st.st_nlink!=1 or
                    stat.S_IMODE(st.st_mode)!=int(mode,8) or not sk._no_acl(fd) or
                    sk._identity(st)!=sk._identity(named) or st.st_size<0 or
                    st.st_size>(rt._MAX_FILE if path.startswith('usr/') else app.MAX_SOURCE) or
                    (size is not None and st.st_size!=size)):
                    raise ValueError('file metadata')
                h=hashlib.sha256();total=0
                while total<st.st_size:
                    block=os.read(fd,min(65536,st.st_size-total))
                    if not block:raise ValueError('short')
                    h.update(block);total+=len(block)
                if os.read(fd,1) or h.hexdigest()!=digest or _identity(os.fstat(fd))!=_identity(st):raise ValueError('file changed')
                file_count+=1
            finally:os.close(fd)
        for path,target in sorted(links.items()):
            parent,_,name=path.rpartition('/');st=os.stat(name,dir_fd=opened[parent],follow_symlinks=False)
            if (not stat.S_ISLNK(st.st_mode) or st.st_uid!=owner or st.st_gid!=group or
                os.readlink(name,dir_fd=opened[parent])!=target):raise ValueError('link changed')
            link_count+=1
        # Check names and metadata again; calls are not an atomic snapshot.
        for path,fd in opened.items():
            sk._dir(fd,owner,group,0o555)
            if path in ('app','usr'):named=os.stat(path,dir_fd=root_fd,follow_symlinks=False)
            else:
                parent,_,name=path.rpartition('/');named=os.stat(name,dir_fd=opened[parent],follow_symlinks=False)
            if sk._identity(os.fstat(fd))!=sk._identity(named):raise ValueError('directory replaced')
        return file_count,link_count
    finally:
        for fd in opened.values():os.close(fd)


def _verify_engine(fd,owner,group,size,digest):
    """Rehash exactly one owned executable without running it."""
    if type(size) is not int or size<=0 or type(digest) is not str or len(digest)!=64 or any(x not in '0123456789abcdef' for x in digest):raise ValueError('artifact contract')
    if os.listdir(fd)!=['opencode']:raise ValueError('engine contents')
    exe=os.open('opencode',os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK|os.O_CLOEXEC,dir_fd=fd)
    try:
        st=os.fstat(exe);named=os.stat('opencode',dir_fd=fd,follow_symlinks=False)
        if (not stat.S_ISREG(st.st_mode) or st.st_uid!=owner or st.st_gid!=group or st.st_nlink!=1 or
            stat.S_IMODE(st.st_mode)!=0o555 or st.st_size!=size or not sk._no_acl(exe) or
            sk._identity(st)!=sk._identity(named)):
            raise ValueError('engine metadata')
        h=hashlib.sha256();left=size
        while left:
            block=os.read(exe,min(1048576,left))
            if not block:raise ValueError('engine short')
            left-=len(block);h.update(block)
        if os.read(exe,1) or h.hexdigest()!=digest or _identity(os.fstat(exe))!=_identity(st):raise ValueError('engine changed')
        if _identity(os.stat('opencode',dir_fd=fd,follow_symlinks=False))!=_identity(st):raise ValueError('engine renamed')
    finally:os.close(exe)


def _inspect(root_fd,work_uid,work_gid,engine_spec=None):
    """Private configurable test core; real output never proves execution safe."""
    if any(type(x) is not int or x<0 for x in (root_fd,work_uid,work_gid)):raise RootVerifyError('invalid descriptor')
    owner,group=os.geteuid(),os.getegid();opened=[]
    try:
        before=sk._dir(root_fd,owner,group,0o555);sk._check_root_entries(root_fd)
        for name in ('engine','etc','proc','sys','dev','run','work'):
            fd=os.open(name,_FLAGS,dir_fd=root_fd);opened.append(fd)
            uid,gid,mode=(work_uid,work_gid,0o700) if name=='work' else (owner,group,0o555)
            st=sk._dir(fd,uid,gid,mode)
            if sk._identity(st)!=sk._identity(os.stat(name,dir_fd=root_fd,follow_symlinks=False)):
                raise ValueError('placeholder changed')
            if name=='engine' and engine_spec is not None:
                _verify_engine(fd,owner,group,*engine_spec)
            elif os.listdir(fd):raise ValueError('placeholder not empty')
        nfiles,nlinks=_verify_tree(root_fd,owner,group)
        sk._check_root_entries(root_fd)
        if _identity(sk._dir(root_fd,owner,group,0o555))!=_identity(before):raise ValueError('root changed')
        return {'app_and_runtime':'fixed_tree_hashes_matched_snapshot','files':nfiles,'links':nlinks,
                'engine':'empty_snapshot' if engine_spec is None else 'fixed_digest_snapshot',
                'work':'empty_identity_snapshot',
                'protected_ancestors':'not_verified','read_only_mounts':'not_verified',
                'actual_runtime':'not_executed','admission':'not_authorized','engine_launch_authorized':False}
    except Exception:raise RootVerifyError('staged root verification unavailable') from None
    finally:
        for fd in opened:os.close(fd)


def inspect_fixed(root_fd):
    """Fixed public candidate UID/GID; no privileged action or launch."""
    return _inspect(root_fd,65534,65534)


def inspect_pinned(root_fd):
    """Read-only exact pinned artifact root observation; never launch approval.

    The candidate must be in an independently reviewed synthetic-only VM;
    the hard-blocked no-engine session does not invoke this function.
    """
    return _inspect(root_fd,65534,65534,(pinned.BINARY_SIZE,pinned.BINARY_SHA256))
