"""One-shot no-engine root + same-bus owner composition; NOT a supervisor.

Private plumbing for an independently supervised, credential-free disposable
VM. The caller must establish exclusive unit lifecycle, protect all descriptors
and paths, bound native calls, handle uncertain starts, and verify cgroup cleanup
independently. This code must not be used to start a real engine. run() is blocked.
"""
import os
from . import synthetic_control_root as root
from . import systemd_private_bus as bus
from . import systemd_no_engine_owner as owner
from . import systemd_pipe_transport as transport
from . import systemd_slice_anchor as anchor_mod
from . import systemd_manager_environment as env
from . import systemd_pidfd_lookup as lookup
from . import systemd_bound_session as bound

_BLOCKED=True
_ROOT_EUID=os.geteuid
class ControlFlowError(RuntimeError):pass


class _ControlFlow:
    """One attempt even on partial root, lost manager, or exception; no retry.

    Caller owns all descriptors and the root, and must dispose the *entire* tree
    only after independent cleanup. Closing a bus connection does not stop a
    systemd service. Never treat returned categories as isolation/launch proof.
    """
    def __init__(self,source_fd,package_fd,root_fd,root_path,unit,kind,*,slice_name=None,cgroup_root_fd=None):
        if (any(type(x) is not int or x<0 for x in (source_fd,package_fd,root_fd)) or
            len({source_fd,package_fd,root_fd})!=3 or not transport._valid_root(root_path) or
            type(unit) is not str or transport._UNIT.fullmatch(unit) is None or
            type(kind) is not str or kind not in ('baseline','integration')):
            raise ControlFlowError('invalid fixed control inputs')
        if slice_name is not None and slice_name!=owner.bound.direct._slice_for(unit):
            raise ControlFlowError('invalid fixed slice')
        if cgroup_root_fd is not None and (slice_name is None or type(cgroup_root_fd) is not int or
                cgroup_root_fd<0 or cgroup_root_fd in (source_fd,package_fd,root_fd)):
            raise ControlFlowError('invalid cgroup root')
        self.slice_name=slice_name;self.cgroup_root_fd=cgroup_root_fd
        self.source_fd=source_fd;self.package_fd=package_fd;self.root_fd=root_fd
        self.root_path=root_path;self.unit=unit;self.kind=kind;self._used=False
    def _run_once(self,*,_anchor_channel=None):
        if self._used:raise ControlFlowError('attempt consumed; do not retry')
        self._used=True
        result={'stage':'root_unknown','root':'not_observed','manager':'not_observed',
                'control':'unknown','record':'not_observed','stop':'not_observed',
                'owner_stage':'not_observed','owner_reason':'not_observed','start_phase':'not_observed','start_error':'not_observed','observe_phase':'not_observed','observe_error':'not_observed','timing':'not_observed','service_diag':'not_observed','service_result':'not_observed','exec_status':'not_observed',
                'cgroup_cleanup':'not_observed','vm_decommission':'not_observed',
                'isolation':'not_verified','engine_launch_authorized':False,
                'production_approved':False}
        lib=connection=anchor=None
        try:
            if _ROOT_EUID()!=0:raise ValueError('root required')
            initial_identity=root.sk._identity(os.fstat(self.root_fd))
            staged=root._assemble(self.source_fd,self.package_fd,self.root_fd,65534,65534)
            if staged.get('root')!='fixed_no_engine_tree_sampled' or staged.get('engine')!='empty_snapshot':
                raise ValueError('root')
            # Name/path match and no engine are checked before connecting; the
            # owner also rechecks before start and admission. These are samples.
            if root.sk._identity(os.fstat(self.root_fd))!=initial_identity:raise ValueError('staged root identity changed')
            profile=root._create_systemd_no_engine_profile(self.root_fd,self.root_path,65534,65534)
            if root.sk._identity(os.fstat(self.root_fd))!=initial_identity:raise ValueError('profile root identity changed')
            profile.verify(self.root_fd,self.root_path)
            result['root']='fixed_no_engine_tree_sampled';result['stage']='manager_unknown'
            lib,connection,manager=bus._open()
            result['manager']='same_connection_sampled';result['stage']='anchor_uncertain'
            if self.cgroup_root_fd is not None:
                anchor=anchor_mod._Anchor(lib,connection,manager,self.unit,self.cgroup_root_fd)
                anchor.start_once()
                if _anchor_channel is not None:
                    # A fixed local helper sends the actual held FD and waits
                    # for the separately running watchdog before service start.
                    from . import synthetic_no_engine_supervisor as supervisor
                    supervisor._send_anchor(_anchor_channel,anchor.group_fd)
            elif _anchor_channel is not None:
                raise ValueError('supervision requires an anchor')
            result['stage']='owner_uncertain'
            observation=owner._drive_once(lib,connection,manager,self.unit,self.kind,self.root_path,self.root_fd,
                                          root_profile=profile,
                                          **({'slice_name':self.slice_name} if self.slice_name is not None else {}),
                                          **({'anchor':anchor} if anchor is not None else {}))
            if type(observation) is not dict:raise ValueError('owner response')
            # Owner progress is diagnostic only, never a release or success gate.
            for key,allowed in (
                ('stage',('pipe_creation','start_uncertain','readiness','observe','admission_uncertain','provisional','exit','stop','final','finished')),
                ('reason',('not_completed','descriptor_close_uncertain','operation_failed_or_uncertain','session_close_uncertain','inner_exit_mismatch','cleanup_unverified'))):
                value=observation.get(key,'not_observed')
                if value not in allowed and value!='not_observed':raise ValueError('invalid owner diagnostic')
                result['owner_'+key]=value
            phase=observation.get('start_phase','not_observed')
            if type(phase) is not str or phase not in ('not_observed','not_started','proto','manager_before','subscribe','root_first','root_inspect','environment','root_recheck','anchor_recheck','message_build','send_uncertain','await_job','job_not_done','manager_after','complete'):
                raise ValueError('invalid start phase')
            result['start_phase']=phase
            error=observation.get('start_error','not_observed')
            if type(error) is not str or error not in ('not_observed','invalid_argument','permission','timeout','connection','fork_mismatch','resource','exists','io','not_found','not_supported','busy','other','no_reply')+env._CATEGORIES+bound._JOB_ERRORS:
                raise ValueError('invalid start error')
            result['start_error']=error
            for key,allowed in (('service_diag',bound._SERVICE_DIAG),('service_result',bound._SERVICE_RESULTS),('exec_status',bound._EXEC_STATUS),('observe_phase',lookup._OBSERVE_PHASES),('observe_error',lookup._OBSERVE_ERRORS)):
                value=observation.get(key,'not_observed')
                if type(value) is not str or (value not in allowed and not (key=='observe_phase' and lookup._valid_inventory(value))):raise ValueError('invalid observation diagnostic')
                result[key]=value
            timing=observation.get('timing','not_observed')
            if not bound._valid_timing(timing):raise ValueError('invalid timing')
            result['timing']=timing
            # Allowlist only fixed categorical values; never pass arbitrary raw
            # details, paths or exceptions from the privileged process into logs.
            for key,allowed in (
                ('control',('unknown','blocked_entry_record_and_exit_sampled')),
                ('record',('not_observed','received','received_diagnostic_only')),
                ('stop',('not_observed','job_done_inactive_snapshot'))):
                if observation.get(key) not in allowed:raise ValueError('owner result')
                result[key]=observation[key]
            if (observation.get('engine_launch_authorized') is not False or
                observation.get('production_approved') is not False):raise ValueError('invalid authority')
            result['stage']='owner_returned_cleanup_unverified'
        except BaseException:
            # An interrupted manager action may still have taken effect. Do not
            # guess a name-based stop or retry. Outside recovery is mandatory.
            result['control']='unknown'
        finally:
            if anchor is not None:
                try:anchor.close()
                except BaseException:result['control']='unknown';result['stage']='anchor_close_uncertain'
            if connection is not None:
                try:bus._close(lib,connection)
                except BaseException:
                    result['manager']='close_uncertain';result['control']='unknown'
        return result


def run():
    if _BLOCKED:raise ControlFlowError('control flow blocked: external supervisor and recovery not established')
    raise ControlFlowError('no approved orchestration')
