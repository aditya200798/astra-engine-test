"""One-shot synthetic-only probe composition; not production authorization.

Caller supplies a reviewed, disposable VM, exclusive root/cgroups and
independent whole-job watchdog. Public path remains blocked. This code never
obtains or executes an engine, or contacts a model/provider; package downloads
are fixed public runtime assets under a guarded child.
"""
import os,secrets,stat,time
from . import cgroup_watchdog as cg,synthetic_no_engine_entry as base
from . import target_probe_flow as flow,target_probe_supervisor as supervisor
from . import target_probe_entry as sample_contract,systemd_pidfd_lookup as lookup,target_probe_packet as packet
_BLOCKED=True
class EntryError(RuntimeError):pass

def validate(obj,*,nobind=False):
 if type(nobind) is not bool:raise EntryError('case')
 fields={'fetch':{'unknown','fixed_17_downloads_rehashed'},
  'fetch_guard':{'not_started','cleanup_uncertain','kill_returned_empty_removed_sampled'},
  'control':({'unknown','nobind_nonatomic_sample_only'} if nobind else {'unknown','probe_record_and_exit_sampled'}),
  'staging':{'not_started','not_guarded','enrolled_sampled','kill_returned_empty_removed_sampled','cleanup_uncertain'},
  'service_watchdog':{'not_started','ready_sampled','kill_returned_empty_sampled','outcome_uncertain'},
  'worker':{'not_observed','exited_sampled','reap_uncertain','reaped','pidfd_unavailable'},
  'anchor':{'not_observed','held_group_sampled'},
  'flow_stage':{'not_observed','root_unknown','manager_unknown','anchor_uncertain','owner_uncertain','owner_returned_cleanup_unverified','anchor_close_uncertain'},
  'owner_stage':{'not_observed','pipes','start_uncertain','readiness','observe','announce_uncertain','release_uncertain','record','exit','stop','finished'},
  'stop':{'not_observed','bound_inactive_snapshot'},
  'canary_lifecycle':{'not_observed','uncertain','live_checks_and_close_sampled'},
  'cleanup':{'not_verified'},'isolation':{'not_verified'},'vm_decommission':{'not_observed'},
  'late_start':{'not_reconciled'},'external_recovery':{'required'},
  'delegated_work':{'not_observed','uncertain','empty_removed_sampled'}}
 if type(obj) is not dict or set(obj)!=set(fields)|{'sample','engine_launch_authorized','production_approved','start_phase','start_error','service_diag','service_result','exec_status','observe_phase','observe_error'}:raise EntryError('schema')
 for k,values in fields.items():
  if type(obj[k]) is not str or obj[k] not in values:raise EntryError('category')
 if not packet._valid_transition(obj['flow_stage'],obj['owner_stage'],obj['stop'],nobind=nobind):raise EntryError('transition')
 # Owner diagnostics only survive a clean post-handoff exchange and monitor.
 if obj['owner_stage']!='not_observed' and (obj['fetch']!='fixed_17_downloads_rehashed' or obj['fetch_guard']!='kill_returned_empty_removed_sampled' or obj['anchor']!='held_group_sampled' or obj['worker']!='reaped' or obj['staging']!='kill_returned_empty_removed_sampled' or obj['service_watchdog']!='kill_returned_empty_sampled' or obj['canary_lifecycle']!='live_checks_and_close_sampled'):raise EntryError('owner without completed supervision')
 if obj['anchor']=='held_group_sampled' and obj['flow_stage'] in ('root_unknown','manager_unknown'):raise EntryError('post-anchor early stage')
 if not packet._valid_start_diagnostic(obj['control'],obj['owner_stage'],obj['start_phase'],obj['start_error']):raise EntryError('start diagnostic')
 if not packet._valid_start_service(obj['control'],obj['owner_stage'],obj['start_phase'],obj['start_error'],obj['service_diag'],obj['service_result'],obj['exec_status']):raise EntryError('service diagnostic')
 phase=obj['observe_phase'];error=obj['observe_error']
 if not packet._valid_observe_stop(obj['owner_stage'],phase,obj['stop']):raise EntryError('stop order')
 if not lookup._valid_probe_diagnostic(obj['owner_stage'],phase,error,nobind=nobind):raise EntryError('observation category')
 if (phase!='not_observed' or error!='not_observed') and (obj['control']!='unknown' or obj['owner_stage'] not in ('observe','release_uncertain')):raise EntryError('observation stage')
 if obj['engine_launch_authorized'] is not False or obj['production_approved'] is not False:raise EntryError('authority')
 if obj['control']==('nobind_nonatomic_sample_only' if nobind else 'probe_record_and_exit_sampled'):
  if (obj['fetch']!='fixed_17_downloads_rehashed' or obj['fetch_guard']!='kill_returned_empty_removed_sampled' or
      obj['staging']!='kill_returned_empty_removed_sampled' or obj['service_watchdog']!='kill_returned_empty_sampled' or
      obj['worker']!='reaped' or obj['anchor']!='held_group_sampled' or obj['flow_stage']!='owner_returned_cleanup_unverified' or
      obj['owner_stage']!='finished' or obj['stop']!='bound_inactive_snapshot' or obj['canary_lifecycle']!='live_checks_and_close_sampled' or
      obj['delegated_work']=='uncertain'):raise EntryError('inconsistent')
  sample_contract._validate(obj['sample'])
  if obj['sample']['pathname_socket']!=('path_missing' if nobind else 'connected'):raise EntryError('pathname case mismatch')
 elif obj['sample']!='not_observed':raise EntryError('unknown sample')
 return obj

def validate_outer(obj,*,nobind=False):
 # At the inner Entry layer work has not yet been removed; the outer wrapper
 # must replace its placeholder before a success can cross the whole-step.
 validate(obj,nobind=nobind)
 if obj['control']!='unknown' and obj['delegated_work']!='empty_removed_sampled':
  raise EntryError('outer delegated work not sampled')
 return obj

class _Entry:
 _nobind=False
 def __init__(self,source,evidence,packages,root,root_path,cgroup_root,delegated,deadline):
  self.fds=(source,evidence,packages,root,cgroup_root,delegated)
  if (any(type(fd) is not int or fd<0 for fd in self.fds) or len(set(self.fds))!=6 or
      not flow.transport._valid_root(root_path) or type(deadline) not in (int,float) or
      not time.monotonic()<deadline<=time.monotonic()+480):raise EntryError('inputs')
  self.root_path=root_path;self.deadline=deadline;self.used=False
 def _remaining(self,cap,minimum):
  n=min(cap,self.deadline-time.monotonic())
  if n<minimum:raise EntryError('deadline')
  return n
 def _run_once(self):
  if self.used:raise EntryError('consumed')
  self.used=True;source,evidence,packages,root,cgroup_root,delegated=self.fds;guard=None
  result={'fetch':'unknown','fetch_guard':'not_started','control':'unknown','staging':'not_started','service_watchdog':'not_started',
   'worker':'not_observed','anchor':'not_observed','flow_stage':'not_observed','owner_stage':'not_observed','stop':'not_observed',
   'start_phase':'not_observed','start_error':'not_observed','service_diag':'not_observed','service_result':'not_observed','exec_status':'not_observed','observe_phase':'not_observed','observe_error':'not_observed',
   'canary_lifecycle':'not_observed','sample':'not_observed','cleanup':'not_verified','isolation':'not_verified',
   'vm_decommission':'not_observed','late_start':'not_reconciled','external_recovery':'required','delegated_work':'not_observed',
   'engine_launch_authorized':False,'production_approved':False}
  try:
   ids=[]
   for fd in self.fds:
    st=os.fstat(fd)
    if not stat.S_ISDIR(st.st_mode):raise EntryError('directory')
    ids.append((st.st_dev,st.st_ino))
   if len(set(ids))!=6 or not cg._is_cgroup2(delegated):raise EntryError('directory alias')
   for fd in (packages,root):
    st=os.fstat(fd)
    if st.st_uid!=os.geteuid() or stat.S_IMODE(st.st_mode)!=0o700 or os.listdir(fd):raise EntryError('fresh directory')
   named=os.stat(self.root_path,follow_symlinks=False);held=os.fstat(root)
   if not stat.S_ISDIR(named.st_mode) or (named.st_dev,named.st_ino)!=(held.st_dev,held.st_ino):raise EntryError('root binding')
   self._remaining(110,110);guard=cg.create_guard(delegated,timeout=110)
   fetched=base._fetch_guarded(evidence,packages,guard,self._remaining(100,1));guard=None
   result['fetch']=fetched['fetch'];result['fetch_guard']=fetched['guard']
   if result['fetch']!='fixed_17_downloads_rehashed' or result['fetch_guard']!='kill_returned_empty_removed_sampled':return validate(result,nobind=self._nobind)
   for fd,identity in zip(self.fds,ids):
    st=os.fstat(fd)
    if not stat.S_ISDIR(st.st_mode) or (st.st_dev,st.st_ino)!=identity:raise EntryError('fd changed')
   self._remaining(115,115)
   unit='astra-synthetic-'+secrets.token_hex(16)+'.service'
   controller=flow._Flow(source,packages,root,self.root_path,unit,cgroup_root,**({'nobind':True} if self._nobind else {}))
   guard=cg.create_guard(delegated,timeout=120)
   observed=supervisor._supervise(controller,self._remaining(110,.1),staging_guard=guard);guard=None
   if time.monotonic()>=self.deadline or type(observed) is not dict:raise EntryError('late result')
   for out,key in (('control','control'),('staging','staging'),('service_watchdog','watchdog'),('worker','worker'),('anchor','anchor'),('flow_stage','flow_stage'),('owner_stage','owner_stage'),('stop','stop'),('start_phase','start_phase'),('start_error','start_error'),('service_diag','service_diag'),('service_result','service_result'),('exec_status','exec_status'),('observe_phase','observe_phase'),('observe_error','observe_error'),('canary_lifecycle','canary_lifecycle'),('sample','sample')):
    result[out]=observed.get(key,result[out])
   if observed.get('engine_launch_authorized') is not False or observed.get('production_approved') is not False:raise EntryError('authority')
   validate(result,nobind=self._nobind)
  except BaseException:
   result['control']='unknown';result['sample']='not_observed'
   # Unrecognized/untrusted categories must not leak into the outer record.
   try:validate(result,nobind=self._nobind)
   except BaseException:
    result.update(fetch='unknown',fetch_guard='cleanup_uncertain',staging='cleanup_uncertain',service_watchdog='outcome_uncertain',worker='not_observed',anchor='not_observed',flow_stage='not_observed',owner_stage='not_observed',stop='not_observed',start_phase='not_observed',start_error='not_observed',service_diag='not_observed',service_result='not_observed',exec_status='not_observed',observe_phase='not_observed',observe_error='not_observed',canary_lifecycle='uncertain')
  finally:
   if type(guard) is cg.Guard and not guard.finished:
    try:guard.finish()
    except BaseException:pass
    result['control']='unknown';result['sample']='not_observed'
  return validate(result,nobind=self._nobind)

class _NoBindEntry(_Entry):
 _nobind=True

def validate_nobind_outer(obj):return validate_outer(obj,nobind=True)

def run():
 if _BLOCKED:raise EntryError('target probe entry blocked')
 raise EntryError('no approved orchestration')
