"""Offline redacted shape diagnostics for *synthetic-only* Responses requests.

Not a provider, request recorder, provenance check, schema validator or launch
admission gate. Input is untrusted: no input-derived strings are returned.
"""
import json
import sys
from . import fake_responses as fake

MAX_INPUT = fake.MAX_REQUEST_BYTES
_FIELDS = frozenset(('model','input','instructions','tools','tool_choice','store',
    'metadata','safety_identifier','stream_options','top_logprobs','truncation',
    'service_tier','prompt_cache_key','include','reasoning','text','max_output_tokens',
    'max_tool_calls','parallel_tool_calls','temperature','top_p','presence_penalty',
    'frequency_penalty','stream'))
_ROLES = ('system','developer','user','assistant','other','not_object')
_CONTENT = ('string','array','other','missing')
_ITEMS = ('input_text','input_image','input_file','input_video','output_text','other','not_object')


def _empty():
    return {'status':'unavailable', 'parse':'not_checked', 'top_level':'not_checked',
            'model':'not_checked', 'stream':'not_checked', 'input':'not_checked',
            'user_prompt':'not_checked', 'role_counts':{k:0 for k in _ROLES},
            'user_content_counts':{k:0 for k in _CONTENT},
            'user_content_item_counts':{k:0 for k in _ITEMS},
            'known_body_fields_present':[], 'unknown_body_field_count':0,
            'input_items_examined':0,
            'limitations':'Synthetic-only offline shape observations; values are untrusted. No real OpenCode, endpoint, isolation, full schema, secrecy, receipt, behavior, or provenance attested.'}


def diagnose(raw):
    """Read a bounded JSON body and emit only finite labels/counts.

    On malformed input no exception details or bytes are returned. This is not
    identical to the pinned OpenCode parser and never accepts a run on its own.
    """
    from .synthetic_session_probe import PROMPT
    out = _empty()
    if not isinstance(raw, bytes): out['parse']='invalid_input_type'; return out
    if len(raw)>MAX_INPUT: out['parse']='too_large'; return out
    try: body=fake._strict_json(raw)
    except (ValueError, UnicodeError, RecursionError):
        out['parse']='invalid_json'; return out
    out['parse']='json_object' if type(body) is dict else 'json_non_object'
    if type(body) is not dict:
        out['top_level']='not_object'; return out
    out['status']='examined'; out['top_level']='object'
    out['known_body_fields_present']=sorted(_FIELDS.intersection(body))
    out['unknown_body_field_count']=sum(k not in _FIELDS for k in body)
    out['model']='missing' if 'model' not in body else 'matches_fixture' if body['model']==fake.MODEL else 'different_or_invalid'
    out['stream']='missing' if 'stream' not in body else 'true' if body['stream'] is True else 'different_or_invalid'
    items=body.get('input')
    if type(items) is not list:
        out['input']='missing' if 'input' not in body else 'not_array'; return out
    out['input']='array'; out['input_items_examined']=len(items); users=[]
    for item in items:
        if type(item) is not dict: out['role_counts']['not_object']+=1; continue
        role=item.get('role'); role=role if type(role) is str and role in _ROLES[:4] else 'other'
        out['role_counts'][role]+=1
        if role!='user': continue
        users.append(item)
        if 'content' not in item: out['user_content_counts']['missing']+=1; continue
        content=item['content']
        if type(content) is str: out['user_content_counts']['string']+=1
        elif type(content) is list:
            out['user_content_counts']['array']+=1
            for value in content:
                if type(value) is not dict: kind='not_object'
                else:
                    kind=value.get('type'); kind=kind if type(kind) is str and kind in _ITEMS[:5] else 'other'
                out['user_content_item_counts'][kind]+=1
        else: out['user_content_counts']['other']+=1
    if not users: out['user_prompt']='missing_user'
    elif len(users)!=1: out['user_prompt']='multiple_users'
    else:
        content=users[0].get('content')
        if content==PROMPT: out['user_prompt']='exact_string'
        elif type(content) is list and len(content)==1 and type(content[0]) is dict and content[0]=={'type':'input_text','text':PROMPT}:
            out['user_prompt']='exact_input_text_array'
        else: out['user_prompt']='different_or_invalid'
    return out


def main():
    # Do not read a local file or network; explicit synthetic stdin only.
    raw=sys.stdin.buffer.read(MAX_INPUT+1)
    result=diagnose(raw)
    print(json.dumps(result,ensure_ascii=True,separators=(',',':')))
    return 0 if result['status']=='examined' else 2

if __name__=='__main__': sys.exit(main())
