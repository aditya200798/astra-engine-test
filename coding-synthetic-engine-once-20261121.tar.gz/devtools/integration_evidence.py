"""Synthetic observation projection; neither attestation nor a launch gate."""
import re


class EvidenceError(ValueError):
    pass


def _mapping(value):
    if type(value) is not dict:
        raise EvidenceError('missing integration observation')
    return value


def _require(mapping, expected):
    _mapping(mapping)
    for key, value in expected.items():
        if key not in mapping or type(mapping[key]) is not type(value) or mapping[key] != value:
            raise EvidenceError('integration observation mismatch')


def summarize(evidence):
    """Validate same-process claims; synthetic request digest is not binary ID."""
    e = _mapping(evidence)
    _require(e, {'stage':'assembled_observation_complete', 'fixture_final_check':'passed',
                 'fixture_thread_stopped':True, 'session_worker_call':'call_completed'})
    _require(e.get('baseline_info_check'), {'version_statement_matches':True,
        'pid_statement_matches':True, 'url_statement_matches':True, 'tmp_statement_matches':True})
    _require(e.get('baseline_config_check'), {'effective_config':'matched_expected_sources_and_document'})
    baseline = _mapping(e.get('baseline_observation'))
    _require(baseline, {'unauth_info_status':401, 'wrong_info_status':401, 'auth_info_status':200,
        'unauth_config_status':401, 'wrong_config_status':401, 'auth_config_status':200,
        'streams_complete':True, 'direct_exit_code':0})
    session = _mapping(e.get('session_report'))
    _require(session, {'session_status':'succeeded', 'fixture_valid_attempts':1,
        'fixture_handled_http_requests':1, 'fixture_response_delivery':'write_completed_not_client_receipt',
        'fixture_user_prompt_matches':True})
    _require(e.get('fixture_diagnostics'), {'handled_connections':1, 'handled_http_requests':1, 'handled_rejections':0,
        'refused_connections':0, 'wall_timeouts':0,
        'last_rejection':None, 'scope':'accepted_handler_connections_only'})
    digest = session.get('fixture_request_sha256')
    if type(digest) is not str or not re.fullmatch('[0-9a-f]{64}', digest):
        raise EvidenceError('synthetic request digest mismatch')
    count = baseline.get('stderr_bytes')
    if type(count) is not int or not 0 <= count <= 65536:
        raise EvidenceError('stderr count mismatch')
    return {'baseline_auth_and_config_checks':'matched', 'baseline_streams_and_direct_exit':'matched',
        'stderr_bytes':count, 'session_status':'succeeded', 'fixture_handled_requests':1,
        'fixture_valid_attempts':1, 'fixture_user_prompt_matches':True,
        'fixture_response_delivery':'write_completed_not_client_receipt', 'fixture_request_sha256':digest,
        'fixture_final_check':'passed', 'session_worker_call':'call_completed',
        'endpoint_identity':'not_authenticated', 'binary_provenance':'not_verified',
        'isolation':'not_verified', 'descendant_cleanup':'not_verified',
        'all_network_traffic':'not_observed', 'tool_read':'not_run'}
