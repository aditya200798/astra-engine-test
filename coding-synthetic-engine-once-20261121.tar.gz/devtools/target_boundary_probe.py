"""Engine-free in-service boundary observation primitives; not an admission gate.

Never execute against a real user's system, data, or credentials. The only
supported future caller is a separately guarded disposable synthetic Linux VM.
No systemd/unit/owner wiring is supplied here. Results are sampled diagnostics,
not identity, complete confinement, or authorization. Private parameterized
helpers enable local negative controls. Network canaries must be demonstrably
controlled, local to the disposable VM and independently observed live.
"""
import errno
import os
import socket
import stat

_BLOCKED = True
_PROBE_FRAME = b'ASTRA-BOUNDARY-PROBE-1\n'
_EXPECTED_DENIAL = frozenset((errno.EACCES, errno.EPERM, errno.EROFS))

class ProbeError(RuntimeError):
    pass


def _open_fds(*, after_barrier=False):
    """Snapshot FDs before/after actual barrier; transient closed proc dirfd ignored.

    After barrier the actual bootstrap replaces stdin with /dev/null; match it.
    Single-threaded target bootstrap only. Other threads or concurrent close/
    reuse invalidate this sample. Reject all extras, including sockets. The
    parent must separately bind 0/1/2 to the exact intended pipe inodes.
    """
    try:
        names=os.listdir('/proc/self/fd')
        if len(names)>256 or any(not x.isascii() or not x.isdigit() for x in names):
            raise ValueError('invalid fd listing')
        found={}
        for name in names:
            n=int(name)
            try: found[n]=os.fstat(n).st_mode
            except OSError as e:
                if e.errno!=errno.EBADF:raise
        if type(after_barrier) is not bool or set(found)!={0,1,2}:
            return 'unexpected_or_nonpipe_fd'
        if not stat.S_ISFIFO(found[1]) or not stat.S_ISFIFO(found[2]):
            return 'unexpected_or_nonpipe_fd'
        if after_barrier:
            current=os.fstat(0); null=os.stat('/dev/null',follow_symlinks=False)
            if (not stat.S_ISCHR(current.st_mode) or not stat.S_ISCHR(null.st_mode) or
                (current.st_dev,current.st_ino,current.st_rdev)!=(null.st_dev,null.st_ino,null.st_rdev)):
                return 'unexpected_or_nonpipe_fd'
            return 'null_input_two_pipes_sampled'
        if not stat.S_ISFIFO(found[0]):return 'unexpected_or_nonpipe_fd'
        return 'three_pipes_sampled'
    except Exception:
        return 'unknown'


def _protected_open(path):
    """Try write-open existing synthetic regular file, never truncate/write it."""
    fd=None
    try:
        fd=os.open(path,os.O_WRONLY|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK)
        return 'write_open_succeeded' if stat.S_ISREG(os.fstat(fd).st_mode) else 'unknown'
    except OSError as e:
        return 'write_open_denied' if e.errno in _EXPECTED_DENIAL else 'unknown'
    finally:
        if fd is not None:os.close(fd)


def _work_create(directory):
    """Create/unlink a fixed zero-byte file in a fresh synthetic work directory.

    Existing names or any unexpected error remain unknown, not success.
    Caller disposes the whole VM/tree; no arbitrary recursive cleanup.
    """
    d=fd=None; made=False;out='unknown'
    name='.astra-boundary-canary-v1'
    try:
        d=os.open(directory,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
        fd=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=d)
        made=True
        s=os.fstat(fd);named=os.stat(name,dir_fd=d,follow_symlinks=False)
        if (stat.S_ISREG(s.st_mode) and s.st_size==0 and s.st_nlink==1 and
            (s.st_dev,s.st_ino)==(named.st_dev,named.st_ino)):
            os.unlink(name,dir_fd=d);made=False;out='created_removed_sampled'
    except OSError:
        out='unknown'
    finally:
        if fd is not None:os.close(fd)
        if made and d is not None:
            # Failure may have changed the name; do not unlink an unverified
            # replacement. Full isolated-tree cleanup belongs to the owner.
            out='cleanup_unknown'
        if d is not None:os.close(d)
    return out


def _connect(family,address,*,pathname_detail=False):
    """Fixed diagnostic marker; pathname errors are categories, not confinement.

    The detail mode is only for the pathname canary. A missing pathname must
    never be collapsed with access denied or refused for a future negative
    control. Connected evidence still needs an independent live canary.
    """
    if type(pathname_detail) is not bool or (pathname_detail and
       (family!=socket.AF_UNIX or type(address) is not str or not address.startswith('/'))):
        return 'unknown'
    s=None
    try:
        s=socket.socket(family,socket.SOCK_STREAM|socket.SOCK_CLOEXEC)
        s.settimeout(.2)
        s.connect(address)
        # The canary owner recognizes at most one completed fixed probe frame
        # per endpoint; send errors never erase a successful connect.
        try:s.sendall(_PROBE_FRAME)
        except OSError:pass
        return 'connected'
    except socket.timeout:
        return 'timeout_unknown'
    except OSError as e:
        if pathname_detail:
            return {errno.ENOENT:'path_missing',errno.EACCES:'path_access_denied',
                    errno.EPERM:'path_operation_denied',errno.ECONNREFUSED:'path_connection_refused'}.get(e.errno,'unknown')
        if e.errno in (errno.ENOENT,errno.ECONNREFUSED,errno.EACCES,errno.EPERM,
                       errno.ENETUNREACH,errno.EHOSTUNREACH):
            return 'not_connected'
        return 'unknown'
    except Exception:
        return 'unknown'
    finally:
        if s is not None:s.close()


def _sample(protected,work,pathname,abstract,ip,port,*,after_barrier=False):
    """Private test primitive. Fixed synthetic inputs only in a reviewed caller.

    This does not establish that canaries exist or are reachable in a positive
    control, does not check all mounts/endpoints/addresses, and cannot authorize
    launch. Caller must independently supervise any blocking operation.
    """
    return {'fd_snapshot':_open_fds(after_barrier=after_barrier), 'protected_write_open':_protected_open(protected),
            'work_probe':_work_create(work),
            'pathname_socket':_connect(socket.AF_UNIX,pathname,pathname_detail=True),
            'abstract_socket':_connect(socket.AF_UNIX,abstract),
            'network_canary':_connect(socket.AF_INET,(ip,port)),
            'external_canary_liveness':'not_verified',
            'mount_backing':'not_verified','egress':'not_verified','isolation':'not_verified',
            'engine_launch_authorized':False,'production_approved':False}


def run():
    if _BLOCKED:raise ProbeError('target boundary probe not wired or approved')
    raise ProbeError('no approved target orchestration')
