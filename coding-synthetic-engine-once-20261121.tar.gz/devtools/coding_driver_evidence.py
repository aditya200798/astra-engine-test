"""Strict local coding observation; never an engine or containment attestation."""
from astra.policy import json_equal
from .coding_integration_evidence import project

def summarize(e):
    if type(e) is not dict or project(e)['result']!='candidate_observed':raise ValueError('coding observation incomplete')
    def require(item,expected):
        if type(item) is not dict or any(k not in item or not json_equal(item[k],v) for k,v in expected.items()):
            raise ValueError('coding baseline or fixture evidence mismatch')
    require(e.get('baseline_info_check'),{'version_statement_matches':True,'pid_statement_matches':True,'url_statement_matches':True,'tmp_statement_matches':True})
    require(e.get('baseline_config_check'),{'effective_config':'matched_expected_sources_and_document'})
    baseline=e.get('baseline_observation')
    require(baseline,{'unauth_info_status':401,'wrong_info_status':401,'auth_info_status':200,
        'unauth_config_status':401,'wrong_config_status':401,'auth_config_status':200,
        'streams_complete':True,'direct_exit_code':0})
    count=baseline.get('stderr_bytes')
    if type(count) is not int or not 0<=count<=65536:raise ValueError('stderr bound')
    require(e.get('fixture_diagnostics'),{'handled_connections':1,'handled_http_requests':1,
        'handled_rejections':0,'refused_connections':0,'wall_timeouts':0,
        'last_rejection':None,'scope':'accepted_handler_connections_only'})
    return {'coding':'fixed_synthetic_candidate_observed','baseline':'matched',
            'direct_stream_exit':'matched','fixture_final':'passed','worker':'call_completed',
            'source_apply':'not_done','candidate_execution':'not_done','endpoint':'not_authenticated',
            'engine':'not_attested','isolation':'not_verified','descendants':'not_verified',
            'all_network_traffic':'not_observed'}
