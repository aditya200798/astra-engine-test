"""Developer-only assembly of existing components; no engine launcher or boundary.

Only use in an independently isolated disposable CI VM with synthetic data and
an independent hard process/cgroup supervisor. This module cannot establish
isolation, binary authenticity, startup safety, CI serialization or cleanup.
"""
import asyncio
import threading

from . import fake_responses as fake
from .baseline_controller import observe_baseline
from .listener_observer import DirectListenerObserver
from .synthetic_session_probe import (exercise_astra_session, synthetic_server_environment,
                                     synthetic_config, SessionWorkerEvidence)
from .synthetic_baseline_gate import check_baseline_info, check_baseline_config


class SyntheticIntegrationError(RuntimeError):
    pass


class OneShotIntegration:
    """One fixture, one spawned-process observation, no retry or process launch.

    Caller opens fixture before launching a fresh server and supplies environment()
    verbatim to its own independently supervised launcher. Scope exit destroys
    fixture; repeated calls are forbidden even on failure. Do not use outside an
    independently contained VM; public synthetic key is not authentication.
    """
    def __init__(self):
        self._server = None
        self._thread = None
        self._thread_error = False
        self._entered = False
        self._used = False
        self._closed = False
        self.worker = SessionWorkerEvidence()
        self.evidence = {'stage': 'not_started', 'engine_launch_authorized': False,
                         'genuine_engine': 'not_attested', 'isolation': 'not_verified',
                         'descendant_cleanup': 'not_verified'}

    def __enter__(self):
        if self._entered or self._closed:
            raise SyntheticIntegrationError('fixture already used')
        self._entered = True
        try:
            self._server = fake.FixtureHTTPServer(('127.0.0.1', 0))
            def serve():
                try:
                    self._server.serve_forever(poll_interval=.05)
                except Exception:
                    self._thread_error = True
            self._thread = threading.Thread(target=serve, name='astra-fake-provider', daemon=False)
            self._thread.start()
        except Exception:
            if self._server is not None:
                self._server.server_close()
            self._closed = True
            raise SyntheticIntegrationError('fixture startup failed') from None
        self.evidence['stage'] = 'fixture_started'
        return self

    def environment(self):
        if not self._entered or self._closed or self._used:
            raise SyntheticIntegrationError('fixture unavailable')
        port = self._server.server_address[1]
        return synthetic_server_environment(port)

    async def run(self, process, verify_config_directory):
        if not self._entered or self._closed or self._used:
            raise SyntheticIntegrationError('fixture unavailable or run already attempted')
        self._used = True
        self.evidence['stage'] = 'baseline_entered'
        try:
            if not callable(verify_config_directory):
                raise ValueError('config verifier required')
            observer = DirectListenerObserver(process.pid)
            async def exercise(port, info, config):
                # Fail before any Session or prompt when the baseline does not
                # match the fixed synthetic contract. These are assertions by
                # the endpoint, not proof of peer, isolation or provenance.
                self.evidence['stage'] = 'baseline_gate_entered'
                info_report = check_baseline_info(port, process.pid, info)
                config_report = check_baseline_config(config, synthetic_config(self._server.server_address[1]),
                                                      verify_config_directory)
                self.evidence['baseline_info_check'] = info_report
                self.evidence['baseline_config_check'] = config_report
                self.evidence['stage'] = 'session_entered'
                return await exercise_astra_session(port, info, config,
                    provider_port=self._server.server_address[1], ledger=self._server.ledger,
                    verify_config_directory=verify_config_directory, verify_listener=observer, worker=self.worker)
            baseline = await observe_baseline(process, timeout=60, verify_listener=observer,
                                              exercise=exercise)
            # Defense in depth: a completion result must include the actual
            # observer's direct-exit and stream evidence. These claims still
            # do not prove descendant cleanup, isolation, or binary identity.
            if (not isinstance(baseline, dict) or
                baseline.get('streams_complete') is not True or
                type(baseline.get('direct_exit_code')) is not int or
                baseline['direct_exit_code'] != 0):
                raise ValueError('baseline completion evidence missing')
            # Preserve only fixed observer facts, never raw info/config or stderr.
            keys = ('unauth_info_status', 'wrong_info_status', 'auth_info_status',
                    'unauth_config_status', 'wrong_config_status', 'auth_config_status',
                    'streams_complete', 'direct_exit_code', 'stderr_bytes')
            self.evidence['baseline_observation'] = {key: baseline.get(key) for key in keys}
            self.evidence['stage'] = 'baseline_complete'
            report = baseline.get('exercise_result')
            if (self.worker.snapshot() != 'call_completed' or not isinstance(report, dict) or
                    report.get('session_status') != 'succeeded'):
                raise ValueError('session report missing')
            # No returned info/config/raw fixture input or stderr in public evidence.
            self.evidence['session_report'] = report
        except asyncio.CancelledError:
            self.evidence['stage'] = 'cancelled_outcome_uncertain'
            raise
        except Exception:
            self.evidence['stage'] = 'failed_outcome_uncertain'
            raise SyntheticIntegrationError('baseline or session failed; no retry') from None
        finally:
            # An unknown snapshot may become stale if the worker later exits.
            self.evidence['session_worker_call'] = self.worker.snapshot()

    def __exit__(self, exc_type, exc, tb):
        self._closed = True
        if self._server is None:
            return False
        # An interrupted executor call may still touch the fixture. Do not
        # tear down shared resources until call completion is observed; leave
        # this whole unit to its mandatory external hard supervisor instead.
        # A stale unknown is deliberately conservative and may leak resources
        # until process termination. This does not establish worker quiescence.
        if self.worker.snapshot() == 'unknown':
            self.evidence['fixture_final_check'] = 'not_checked_worker_unknown'
            self.evidence['fixture_cleanup'] = 'deferred_to_external_supervisor'
            self.evidence['stage'] = 'worker_unknown_cleanup_deferred'
            if exc_type is None:
                raise SyntheticIntegrationError('worker completion unknown; external cleanup required')
            return False
        self.evidence['fixture_cleanup'] = 'attempted_in_process'
        # Blocking in shutdown/join is possible: external hard supervisor needed.
        try:
            if self._thread is not None and self._thread.is_alive():
                self._server.shutdown()
                self._thread.join(timeout=4)
            stopped = self._thread is not None and not self._thread.is_alive() and not self._thread_error
            self._server.server_close()
            diag = self._server.ledger.diagnostics()
            self.evidence['fixture_diagnostics'] = diag
            self.evidence['fixture_thread_stopped'] = stopped
            if stopped:
                # Categorical, bounded only; all request bytes remain in process.
                self.evidence['failure_shape'] = self._server.ledger.failure_shape()
            # A dispatched malformed/unsupported/empty connection still counts.
            # Sockets queued but not accepted at shutdown remain unobserved.
            valid = (stopped and diag.get('handled_connections') == 1 and
                     diag.get('handled_http_requests') == 1 and
                     diag.get('handled_rejections') == 0 and
                     diag.get('refused_connections') == 0 and
                     diag.get('wall_timeouts') == 0)
            self.evidence['fixture_final_check'] = 'passed' if valid else 'failed_or_unknown'
            if not valid and exc_type is None:
                self.evidence['stage'] = 'failed_outcome_uncertain'
                raise SyntheticIntegrationError('final fixture observation failed; no retry')
            if valid and exc_type is None and self.evidence['stage'] == 'baseline_complete':
                self.evidence['stage'] = 'assembled_observation_complete'
        except SyntheticIntegrationError:
            raise
        except Exception:
            self.evidence['fixture_final_check'] = 'failed_or_unknown'
            self.evidence['stage'] = 'failed_outcome_uncertain'
            if exc_type is None:
                raise SyntheticIntegrationError('fixture cleanup uncertain; no retry') from None
        return False
