"""Private fixed populated-engine backing-root profile, never authorizes launch.

Not authorization, a security boundary, or a runtime replacement. Requires
protected ancestors, an exclusive writer and independently supervised lifecycle.
Creation failure poisons the full tree: no repair/retry. Snapshots can race.
"""
import os
import stat
from devtools import coding_root_skeleton as sk
from devtools import coding_root_verify as tree
from devtools import systemd_pipe_transport as pipe

FLAGS = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
DIRS = ('root', 'var')
LINKS = {'bin': 'usr/bin', 'lib': 'usr/lib', 'lib64': 'usr/lib64'}
NAMES = set(sk._DIRS) | set(DIRS) | set(LINKS)
PLACEHOLDERS = ('engine', 'etc', 'proc', 'sys', 'dev', 'run', 'work', 'root', 'var')

class ProfileError(RuntimeError):
    pass

def path(fd, name):
    if not pipe._valid_root(name): raise ValueError('root path')
    current = os.open('/', FLAGS)
    try:
        for component in name[1:].split('/'):
            child = os.open(component, FLAGS, dir_fd=current)
            os.close(current)
            current = child
        if sk._identity(os.fstat(current)) != sk._identity(os.fstat(fd)):
            raise ValueError('root identity')
    finally:
        os.close(current)

def links(fd, owner, group):
    if set(os.listdir(fd)) != NAMES: raise ValueError('root entries')
    for name, target in LINKS.items():
        st = os.stat(name, dir_fd=fd, follow_symlinks=False)
        if (not stat.S_ISLNK(st.st_mode) or (st.st_uid, st.st_gid) != (owner, group)
                or os.readlink(name, dir_fd=fd) != target): raise ValueError('root link')

def verify(fd, root_path, uid, gid, engine_spec):
    """Full pinned tree plus exact populated engine; never authorizes launch."""
    if any(type(x) is not int or x < 0 for x in (fd, uid, gid)):
        raise ProfileError('invalid inputs')
    opened = {}
    owner, group = os.geteuid(), os.getegid()
    try:
        before = sk._dir(fd, owner, group, 0o555)
        path(fd, root_path); links(fd, owner, group)
        for name in PLACEHOLDERS:
            child = os.open(name, FLAGS, dir_fd=fd); opened[name] = child
            u, g, mode = (uid, gid, 0o700) if name == 'work' else (owner, group, 0o555)
            st = sk._dir(child, u, g, mode)
            if sk._identity(st) != sk._identity(os.stat(name, dir_fd=fd, follow_symlinks=False)):
                raise ValueError('placeholder replaced')
            if name == 'engine': tree._verify_engine(child, owner, group, *engine_spec)
            elif os.listdir(child): raise ValueError('nonempty placeholder')
        count, link_count = tree._verify_tree(fd, owner, group)
        for name, child in opened.items():
            u, g, mode = (uid, gid, 0o700) if name == 'work' else (owner, group, 0o555)
            st = sk._dir(child, u, g, mode)
            if sk._identity(st) != sk._identity(os.stat(name, dir_fd=fd, follow_symlinks=False)):
                raise ValueError('placeholder replaced')
            if name == 'engine': tree._verify_engine(child, owner, group, *engine_spec)
            elif os.listdir(child): raise ValueError('placeholder changed')
        links(fd, owner, group); path(fd, root_path)
        if tree._identity(sk._dir(fd, owner, group, 0o555)) != tree._identity(before):
            raise ValueError('root changed')
        return {'profile':'genuine_fixed_snapshot', 'engine':'fixed_digest_snapshot',
                'app_and_runtime':'fixed_tree_hashes_matched_snapshot', 'work':'empty_identity_snapshot',
                'files':count, 'links':link_count, 'engine_launch_authorized':False,
                'isolation':'not_verified'}
    except Exception:
        raise ProfileError('verification failed; no retry') from None
    finally:
        for child in opened.values(): os.close(child)

def create(fd, root_path, uid, gid, engine_spec):
    """Fresh exact strict genuine tree only; partial failure requires disposal."""
    opened = []
    try:
        path(fd, root_path)
        observed = tree._inspect(fd, uid, gid, engine_spec)
        if observed['engine'] != 'fixed_digest_snapshot': raise ValueError('engine')
        before = sk._dir(fd, os.geteuid(), os.getegid(), 0o555)
        os.fchmod(fd, 0o700)
        for name in DIRS:
            os.mkdir(name, 0o700, dir_fd=fd)
            child = os.open(name, FLAGS, dir_fd=fd); opened.append(child)
            os.fchmod(child, 0o555)
            st = sk._dir(child, os.geteuid(), os.getegid(), 0o555)
            if sk._identity(st) != sk._identity(os.stat(name, dir_fd=fd, follow_symlinks=False)) or os.listdir(child):
                raise ValueError('created child')
        for name in ('bin', 'lib'): os.symlink(LINKS[name], name, dir_fd=fd)
        os.fchmod(fd, 0o555)
        if sk._identity(before) != sk._identity(os.fstat(fd)): raise ValueError('root replaced')
        return verify(fd, root_path, uid, gid, engine_spec)
    except Exception:
        raise ProfileError('creation failed; dispose tree') from None
    finally:
        for child in opened: os.close(child)
