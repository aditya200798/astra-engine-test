"""Exact-unit lifecycle model; live backend and admission are NOT implemented.

This module cannot start an engine, systemd service or process. Injected private
collaborators are for local lifecycle tests only, not authorization or isolation.
"""
import re
import uuid

_LAUNCH_BLOCKED=True
_UNIT=re.compile(r'astra-synthetic-[0-9a-f]{32}\.service\Z')
_INVOCATION=re.compile(r'[0-9a-f]{32}\Z')
class SupervisorError(RuntimeError): pass

def new_unit():
    """Candidate only, never an atomic reservation."""
    return 'astra-synthetic-'+uuid.uuid4().hex+'.service'
def _valid_unit(unit): return type(unit) is str and _UNIT.fullmatch(unit) is not None
def _same_identity(snapshot,unit,invocation):
    return (type(snapshot) is dict and snapshot.get('unit')==unit and
            type(snapshot.get('invocation')) is str and
            _INVOCATION.fullmatch(snapshot['invocation']) is not None and
            snapshot['invocation']==invocation)


def _supervise(backend,collector,unit,kind):
    """Private lifecycle model: pre-stop provisional, stop, final drain.

    Collaborators need independently bounded I/O, actual reservation, invocation
    binding, independent watchdog and cgroup observation. This model establishes
    none. Uncertain start triggers one exact stop only under a real caller's
    exclusive, collision-free reservation. A fake backend is not a safety gate.
    """
    if not _valid_unit(unit) or type(kind) is not str or kind not in ('baseline','integration'):
        raise SupervisorError('invalid fixed unit or kind')
    report={'outcome':'unknown','reason':'not_started','unit':unit,
            'invocation':'not_observed','unit_stop':'not_observed',
            'cgroup_cleanup':'unknown','engine_launch_authorized':False,
            'isolation':'not_verified','genuine_engine':'not_attested',
            'production_approved':False}
    invocation=None; status=None; provisional=False; stopped=False; record=None
    try:
        report['reason']='start_uncertain'
        started=backend.start(unit,kind)
        if (type(started) is not dict or started.get('unit')!=unit or
            type(started.get('invocation')) is not str or
            _INVOCATION.fullmatch(started['invocation']) is None or started.get('start')!='accepted'):
            report['reason']='start_unbound'
        else:
            invocation=started['invocation']; report['invocation']=invocation
            report['reason']='report_uncertain'
            pre=collector.before_stop(kind)
            if type(pre) is dict and pre.get('record')=='provisional':
                provisional=True; report['reason']='manager_status_uncertain'
                status=backend.observe(unit)
                if not _same_identity(status,unit,invocation): report['reason']='manager_identity_mismatch'
                elif (type(status.get('exit_code')) is not int or status.get('exit_kind')!='exited' or
                      status.get('state') not in ('inactive','failed')): report['reason']='exit_not_observed'
                else: report['reason']='awaiting_final_record'
    except Exception:
        report['reason']='operation_failed'
    finally:
        # Stop attempted even when start's reply is lost. Real exclusive
        # reservation/ownership is a prerequisite, not furnished by this model.
        try:
            stop=backend.stop(unit)
            if type(stop) is dict and stop.get('unit')==unit and stop.get('stop')=='accepted':
                stopped=True; report['unit_stop']='accepted_not_proof'
        except Exception: pass
        # Only a provisional record merits final parsing, always after the stop
        # attempt, even if stop failed: its bytes are never proof of cleanup.
        if provisional:
            try: record=collector.after_stop(kind)
            except Exception: record=None
        if stopped:
            try:
                post=backend.observe(unit); empty=backend.empty(unit)
                if (invocation is not None and _same_identity(post,unit,invocation) and
                    post.get('state') in ('inactive','failed') and type(empty) is dict and
                    empty.get('unit')==unit and empty.get('invocation')==invocation and empty.get('empty') is True):
                    report['unit_stop']='stopped_observed'
                    report['cgroup_cleanup']='empty_observed_not_escape_proof'
            except Exception: pass
        if report['cgroup_cleanup']!='empty_observed_not_escape_proof':
            report['outcome']='unknown'; report['reason']='cleanup_uncertain'
        elif report['reason']=='awaiting_final_record':
            if (type(record) is not dict or record.get('record')!='received' or type(record.get('inner')) is not dict):
                report['reason']='record_missing'
            else:
                outcome=record['inner'].get('outcome'); code=status['exit_code']
                if outcome=='returned' and code==0:
                    report['outcome']='inner_return_observed'; report['reason']=None
                elif outcome in ('driver_error','cancelled','internal_error','invalid_return') and code==1:
                    report['outcome']='inner_failure_observed'; report['reason']='inner_failed'
                else: report['reason']='record_exit_mismatch'
    return report


def run():
    """No arguments or bypass; never creates a backend."""
    if _LAUNCH_BLOCKED: raise SupervisorError('external service supervisor not authorized or implemented')
    raise SupervisorError('no live manager backend exists')
