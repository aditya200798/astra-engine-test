"""Separate guarded fixed archive acquisition; synthetic VM only."""
import os, select, signal, time
from . import cgroup_watchdog as cg
from . import synthetic_no_engine_supervisor as supervisor
from . import systemd_slice_anchor as anchor
from . import genuine_archive_acquire as archive
from .synthetic_no_engine_entry import _close_except
class EntryError(RuntimeError):pass

def _archive_guarded(evidence_fd,package_fd,guard,timeout=100):
    """Single actual acquisition, child gated before network, fixed byte reply.

    Guard must be a fresh ready delegated cgroup and is consumed, even on
    failure. No retries or tree removal. Assumes no other thread/child reaper.
    Parent/monitor death, pidfd acquisition failure and kernel stalls remain
    outer VM-recovery responsibilities. A result isn't a VM cleanup receipt.
    """
    deadline=time.monotonic()+timeout
    pidfd=None;pid=None;rd=wr=admit_r=admit_w=None;child_status=None;packet=b''
    result={'fetch':'unknown','guard':'cleanup_uncertain','fallback':'not_attempted'}
    checked=False;normal_completion=False;eof=False
    try:
        if (type(guard) is not cg.Guard or guard.finished or
            type(timeout) not in (int,float) or not 1<=timeout<=110):
            raise EntryError('guard or deadline')
        anchor._check_group(guard.parent_fd,guard.group_fd,guard.name)
        if cg._populated(cg._read(guard.group_fd,'cgroup.events')):raise EntryError('nonempty')
        cg._require_watchdog_alive(guard.pidfd);checked=True
        rd,wr=os.pipe2(os.O_CLOEXEC);admit_r,admit_w=os.pipe2(os.O_CLOEXEC)
        pid=os.fork()
        if pid==0:
            try:
                _close_except({wr,admit_r,evidence_fd,package_fd})
                # Parent death/failed enrollment must not start a download.
                ready,_,_=select.select([admit_r],[],[],5)
                if not ready or os.read(admit_r,2)!=b'G':os._exit(2)
                fetched=archive._acquire(evidence_fd,package_fd,timeout=min(95,timeout))
                if (fetched.get('archive')!='fixed_download_and_binary_rehashed' or
                    fetched.get('execution') is not False or
                    fetched.get('engine_launch_authorized') is not False):os._exit(3)
                os.write(wr,b'Y');os._exit(0)
            except BaseException:os._exit(4)
        os.close(wr);wr=None;os.close(admit_r);admit_r=None
        pidfd=os.pidfd_open(pid,0)
        cg._require_watchdog_alive(pidfd);cg._require_watchdog_alive(guard.pidfd)
        anchor._check_group(guard.parent_fd,guard.group_fd,guard.name)
        cg._write(guard.group_fd,'cgroup.procs',str(pid))
        if str(pid) not in cg._read(guard.group_fd,'cgroup.procs').split():raise EntryError('enrollment')
        cg._require_watchdog_alive(pidfd);cg._require_watchdog_alive(guard.pidfd)
        if time.monotonic()>=deadline:raise EntryError('deadline before fetch release')
        if os.write(admit_w,b'G')!=1:raise EntryError('release')
        os.close(admit_w);admit_w=None
        while time.monotonic()<deadline:
            readers=[pidfd,guard.pidfd]+([] if eof else [rd])
            ready,_,_=select.select(readers,[],[],max(0,deadline-time.monotonic()))
            if guard.pidfd in ready:break
            if rd in ready:
                chunk=os.read(rd,2-len(packet))
                if chunk:packet+=chunk
                else:eof=True
                if len(packet)>1:break
            if pidfd in ready and eof:
                normal_completion=True;break
    except BaseException:
        pass
    finally:
        for fd in (wr,admit_r,admit_w):
            if fd is not None:
                try:os.close(fd)
                except OSError:pass
        if pidfd is not None:
            try:
                st=os.waitid(os.P_PIDFD,pidfd,os.WEXITED|os.WNOHANG|os.WNOWAIT)
                if st is None:signal.pidfd_send_signal(pidfd,signal.SIGKILL)
            except (OSError,ChildProcessError):pass
        duplicate=None
        if type(guard) is cg.Guard and not guard.finished:
            try:duplicate=os.dup(guard.group_fd)
            except OSError:pass
            try:os.close(guard.pipe_w);guard.pipe_w=None
            except OSError:pass
        if pidfd is not None:
            child_status=supervisor._wait_reap(pidfd,3)
            os.close(pidfd)
        if type(guard) is cg.Guard and not guard.finished:
            try:
                guard.finish();result['guard']='kill_returned_empty_removed_sampled'
            except BaseException:
                if checked and duplicate is not None and child_status is not None:
                    result['fallback']=supervisor._fallback_once(guard.parent_fd,duplicate,guard.name)
            finally:
                if duplicate is not None:os.close(duplicate)
        if rd is not None:os.close(rd)
    if (normal_completion and packet==b'Y' and child_status==(os.CLD_EXITED,0) and
        time.monotonic()<deadline and result['guard']=='kill_returned_empty_removed_sampled'):
        result['fetch']='fixed_download_and_binary_rehashed'
    return result

