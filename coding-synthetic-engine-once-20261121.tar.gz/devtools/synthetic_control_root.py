"""Assemble fixed empty-engine control root; not a runner or safety gate.

All descriptors are caller-owned. The caller must ensure exclusive trusted
source/package/root directories, protected ancestors and mounts, fresh VM,
independent deadline/resource watchdog, and full disposal on any failure.
No engine artifact, service, mount or workload is created or launched here.
"""
from . import synthetic_root_skeleton as skeleton
from . import ubuntu_runtime_stage as runtime
from . import synthetic_root_verify as verify

_BLOCKED=True
class ControlRootError(RuntimeError):pass


def _assemble(source_fd,package_fd,root_fd,work_uid,work_gid):
    """Private composition for a fresh empty root; never retry a failed tree."""
    if (any(type(x) is not int or x<0 for x in (source_fd,package_fd,root_fd,work_uid,work_gid))
        or len({source_fd,package_fd,root_fd})!=3):
        raise ControlRootError('invalid descriptors')
    try:
        skeleton._assemble(source_fd,root_fd,work_uid,work_gid)
        runtime._install(package_fd,root_fd,runtime._decompress_deb)
        observed=verify._inspect(root_fd,work_uid,work_gid)
        if (observed.get('app_and_runtime')!='fixed_tree_hashes_matched_snapshot' or
            observed.get('engine')!='empty_snapshot' or
            observed.get('work')!='empty_identity_snapshot'):
            raise ValueError('incomplete observation')
        return {'root':'fixed_no_engine_tree_sampled','engine':'empty_snapshot',
                'work':'empty_identity_snapshot','files':observed['files'],'links':observed['links'],
                'executed':False,'mounts':'not_created','isolation':'not_verified',
                'protected_ancestors':'not_verified','provenance':'not_verified_here',
                'cleanup':'caller_required','engine_launch_authorized':False}
    except Exception:
        raise ControlRootError('control root failed; dispose whole tree; do not reuse') from None


def run():
    if _BLOCKED:raise ControlRootError('root assembly blocked: independent VM supervisor not established')
    raise ControlRootError('no approved orchestration')


# Separate no-engine-only, fixed systemd-compatible backing-tree profile.
# All validation is sampled; protected ancestors and sole caller-owned fd remain required.
import os,stat
from . import synthetic_root_skeleton as sk, synthetic_root_verify as tree, systemd_pipe_transport as pipe
DIRS=('root','var')
LINKS={'bin':'usr/bin','lib':'usr/lib','lib64':'usr/lib64'}
NAMES=set(sk._DIRS)|set(DIRS)|set(LINKS)
FLAGS=os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC
class ProfileError(RuntimeError):pass

def _check_links(fd,owner,group):
    if set(os.listdir(fd))!=NAMES:raise ValueError('unexpected root names')
    for n,target in LINKS.items():
        s=os.stat(n,dir_fd=fd,follow_symlinks=False)
        if not stat.S_ISLNK(s.st_mode) or (s.st_uid,s.st_gid)!=(owner,group) or os.readlink(n,dir_fd=fd)!=target:
            raise ValueError('link')

def _path(fd,path):
    # A leaf-only lstat follows symlinked ancestors. Open every component
    # without following links and compare the final inode to the held fd.
    # This is not a stable-path guarantee: trusted, protected ancestors and
    # exclusion of other writers remain mandatory throughout manager use.
    if not pipe._valid_root(path):raise ValueError('path grammar')
    current=os.open('/',FLAGS)
    try:
        for part in path[1:].split('/'):
            child=os.open(part,FLAGS,dir_fd=current)
            os.close(current);current=child
        named=os.fstat(current);held=os.fstat(fd)
        if not stat.S_ISDIR(named.st_mode) or sk._identity(named)!=sk._identity(held):raise ValueError('path mismatch')
    finally:os.close(current)

def _profile_verify(fd,path,work_uid,work_gid):
    if any(type(n) is not int or n<0 for n in (fd,work_uid,work_gid)):raise ProfileError('input')
    owner,group=os.geteuid(),os.getegid();fds={}
    try:
        before=sk._dir(fd,owner,group,0o555);_path(fd,path);_check_links(fd,owner,group)
        for name in ('engine','etc','proc','sys','dev','run','work','root','var'):
            child=os.open(name,FLAGS,dir_fd=fd);fds[name]=child
            uid,gid,mode=(work_uid,work_gid,0o700) if name=='work' else (owner,group,0o555)
            st=sk._dir(child,uid,gid,mode)
            if sk._identity(st)!=sk._identity(os.stat(name,dir_fd=fd,follow_symlinks=False)):raise ValueError('child replaced')
            if os.listdir(child):raise ValueError('nonempty placeholder')
        files,links=tree._verify_tree(fd,owner,group)
        # Revisit all placeholder names, metadata and contents; still not an atomic snapshot.
        for name,child in fds.items():
            uid,gid,mode=(work_uid,work_gid,0o700) if name=='work' else (owner,group,0o555)
            if sk._identity(sk._dir(child,uid,gid,mode))!=sk._identity(os.stat(name,dir_fd=fd,follow_symlinks=False)) or os.listdir(child):raise ValueError('changed')
        _check_links(fd,owner,group);_path(fd,path)
        if tree._identity(sk._dir(fd,owner,group,0o555))!=tree._identity(before):raise ValueError('root changed')
        return {'no_engine_profile':'fixed_snapshot','files':files,'links':links,'engine':'empty_snapshot','isolation':'not_verified','engine_launch_authorized':False}
    except Exception:raise ProfileError('profile verification failed') from None
    finally:
        for x in fds.values():os.close(x)

def _profile_extend(fd,path,work_uid,work_gid):
    """Transform ONLY a freshly staged strict no-engine root; never repair/reuse.
    Production must never call this experiment; partial failure requires disposal.
    """
    opened=[]
    try:
        _path(fd,path)
        # Existing verifier, before mutation, requires exact original layout and empty engine.
        tree._inspect(fd,work_uid,work_gid)
        before=sk._dir(fd,os.geteuid(),os.getegid(),0o555)
        os.fchmod(fd,0o700)
        for name in DIRS:
            os.mkdir(name,0o700,dir_fd=fd)
            c=os.open(name,FLAGS,dir_fd=fd);opened.append(c);os.fchmod(c,0o555)
            st=sk._dir(c,os.geteuid(),os.getegid(),0o555)
            if sk._identity(st)!=sk._identity(os.stat(name,dir_fd=fd,follow_symlinks=False)) or os.listdir(c):raise ValueError('child')
        for name in ('bin','lib'):os.symlink(LINKS[name],name,dir_fd=fd)
        os.fchmod(fd,0o555)
        if sk._identity(before)!=sk._identity(os.fstat(fd)):raise ValueError('root inode')
        return _profile_verify(fd,path,work_uid,work_gid)
    except Exception:raise ProfileError('profile assembly failed; dispose tree') from None
    finally:
        for c in opened:os.close(c)


_PROFILE_TOKEN=object()
class _SystemdNoEngineProfile:
    def __init__(self,token,fd,path,work_uid,work_gid):
        if token is not _PROFILE_TOKEN:raise ProfileError('private construction only')
        self._fd=fd;self._path=path;self._uid=work_uid;self._gid=work_gid
        self._identity=sk._identity(os.fstat(fd))
    def verify(self,fd,path):
        if fd!=self._fd or path!=self._path:raise ProfileError('profile binding changed')
        try:
            if sk._identity(os.fstat(fd))!=self._identity:raise ValueError('descriptor identity')
            result=_profile_verify(fd,path,self._uid,self._gid)
            if sk._identity(os.fstat(fd))!=self._identity:raise ValueError('descriptor changed')
            return result
        except Exception:raise ProfileError('profile binding unavailable') from None

def _create_systemd_no_engine_profile(fd,path,work_uid,work_gid):
    # Call only immediately after fresh strict assembly. Any failure consumes
    # the entire tree; do not repair or retry, dispose after safe cleanup.
    _profile_extend(fd,path,work_uid,work_gid)
    p=_SystemdNoEngineProfile(_PROFILE_TOKEN,fd,path,work_uid,work_gid)
    p.verify(fd,path)
    return p
