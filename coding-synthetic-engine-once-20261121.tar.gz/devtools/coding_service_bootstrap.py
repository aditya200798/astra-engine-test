"""Fixed genuine candidate bootstrap. Driver remains hard-blocked. No authorization."""
import os
import sys
_ENV={'PATH':'/usr/bin:/bin','HOME':'/work/home','TMPDIR':'/work/tmp','LANG':'C','LC_ALL':'C'}
def main():
    if sys.flags.isolated!=1 or sys.flags.no_site!=1 or sys.argv[1:]!=['integration']:
        return 2
    os.environ.clear();os.environ.update(_ENV)
    if dict(os.environ)!=_ENV:return 2
    app=os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    sys.path.insert(0,app)
    from devtools.synthetic_service_barrier import receive_on_stdin
    # Trusted, fixed bootstrap promises no more output until the frame arrives.
    # The marker is synchronization, not authentication or a security proof.
    marker=b'ASTRA-CODING-GENUINE-READY-1\n'
    if os.write(2,marker)!=len(marker):return 2
    identity=receive_on_stdin(genuine=True)
    sys.argv[:]=[sys.argv[0]]
    from devtools.coding_service_entry import main as entry
    from devtools import fixed_coding_driver as driver
    if driver._LAUNCH_BLOCKED is not True:
        from devtools.genuine_run_layout import prepare_fixed_service_work
        prepare_fixed_service_work()
    return entry(identity)
if __name__=='__main__':
    try:raise SystemExit(main())
    except (Exception,KeyboardInterrupt):raise SystemExit(2) from None
