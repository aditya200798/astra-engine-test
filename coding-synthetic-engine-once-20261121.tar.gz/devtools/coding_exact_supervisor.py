"""Adapter to the existing private exact-unit lifecycle model; public blocked.

The reused supervisor expects kind=integration; the adapter maps it to the
separate coding-only strict stream without global patches. Collaborators must
own pipes and enforce stopping before EOF. This is a lifecycle model, not
systemd or cgroup authorization, independent cleanup or attestation.
"""
from . import exact_service_supervisor as base
_BLOCKED=True
class SupervisorError(RuntimeError):pass
class _CodingCollector:
    def __init__(self,stream):self.stream=stream
    def before_stop(self,kind):
        if kind!='integration':raise SupervisorError('unexpected mode')
        return self.stream.before_stop(3)
    def after_stop(self,kind):
        if kind!='integration':raise SupervisorError('unexpected mode')
        return self.stream.after_stop(3)

def _supervise(backend,stream,unit):
    from .coding_stream_pair import StreamPair
    if type(stream) is not StreamPair or stream.kind!='coding':raise SupervisorError('coding stream required')
    return base._supervise(backend,_CodingCollector(stream),unit,'integration')
def run():
    if _BLOCKED:raise SupervisorError('coding supervisor blocked')
    raise SupervisorError('no approved orchestration')
