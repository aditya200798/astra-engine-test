"""Unapproved developer-only integration driver, launch permanently hard-blocked.

No entry point or switch enables the block. In-memory dependency patching in
unit tests does not authorize execution. This is wiring, not a supervisor,
sandbox, provenance check, CI lock, or production gate. Independent boundary
review and real disposable runtime controls remain prerequisites to any launch.
"""
import asyncio
import os
import hashlib
import stat

from .baseline_config_observer import ConfigDirectoryObservation
from .synthetic_integration import OneShotIntegration
from .integration_evidence import summarize

_LAUNCH_BLOCKED = True
_BINARY = '/engine/opencode'
_ARGV = (_BINARY, 'serve', '--stdio', '--hostname', '127.0.0.1', '--port', '0')
_DRIVER_ENV = {'PATH': '/usr/bin:/bin', 'HOME': '/work/home', 'TMPDIR': '/work/tmp',
               'LANG': 'C', 'LC_ALL': 'C'}


# These duplicate the reviewed artifact pin deliberately: this file is staged
# in the minimal service app; tests compare them to the outer pin.
_IMAGE_SIZE = 252_848_304
_IMAGE_SHA256 = 'e6543f6e5c39c40971ba38afd1819ac852c29ac735b5a89065d3d148d47f27ad'

def _metadata(st):
    return (st.st_dev,st.st_ino,st.st_mode,st.st_uid,st.st_gid,st.st_nlink,
            st.st_size,st.st_mtime_ns,st.st_ctime_ns)

def _open_image(directory, size, digest, uid, gid):
    """Parameterized private core for inert tests. Caller owns returned fd."""
    flags=os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC
    d=os.open(directory,flags)
    try:
        ds=os.fstat(d)
        if (not stat.S_ISDIR(ds.st_mode) or ds.st_uid!=uid or ds.st_gid!=gid or
            stat.S_IMODE(ds.st_mode)!=0o555 or
            any(a in ('system.posix_acl_access','system.posix_acl_default') for a in os.listxattr(d))):
            raise ValueError('engine directory')
        fd=os.open('opencode',os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK,dir_fd=d)
        try:
            _check_image(fd,directory,size,digest,uid,gid)
            return fd
        except BaseException:
            os.close(fd);raise
    finally:os.close(d)

def _check_image(fd,directory,size,digest,uid,gid):
    """Compare path and held inode and digest; all observations are racy."""
    before=os.fstat(fd)
    if (not stat.S_ISREG(before.st_mode) or before.st_uid!=uid or before.st_gid!=gid or
        before.st_nlink!=1 or stat.S_IMODE(before.st_mode)!=0o555 or before.st_size!=size or
        any(a in ('system.posix_acl_access','system.posix_acl_default') for a in os.listxattr(fd))):
        raise ValueError('engine file metadata')
    flags=os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC
    d=os.open(directory,flags)
    try:
        ds=os.fstat(d)
        if (not stat.S_ISDIR(ds.st_mode) or ds.st_uid!=uid or ds.st_gid!=gid or
            stat.S_IMODE(ds.st_mode)!=0o555 or
            any(a in ('system.posix_acl_access','system.posix_acl_default') for a in os.listxattr(d))):
            raise ValueError('engine directory')
        named=os.open('opencode',os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK,dir_fd=d)
        try:
            if _metadata(os.fstat(named))!=_metadata(before):raise ValueError('engine inode')
        finally:os.close(named)
    finally:os.close(d)
    h=hashlib.sha256();at=0
    while at<size:
        b=os.pread(fd,min(1048576,size-at),at)
        if not b:raise ValueError('short image')
        h.update(b);at+=len(b)
    if (os.pread(fd,1,at) or h.hexdigest()!=digest or _metadata(os.fstat(fd))!=_metadata(before)):
        raise ValueError('engine digest or mutation')
    d=os.open(directory,flags)
    try:
        if (_metadata(os.fstat(d))!=_metadata(ds) or
            any(a in ('system.posix_acl_access','system.posix_acl_default') for a in os.listxattr(d))):
            raise ValueError('engine directory changed')
        named=os.open('opencode',os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK,dir_fd=d)
        try:
            if _metadata(os.fstat(named))!=_metadata(before):raise ValueError('engine inode changed')
        finally:os.close(named)
    finally:os.close(d)

def _require_outer_identity(fd,identity):
    """Compare held service FD with sampled outer dev/inode; not an FD transfer."""
    image=os.fstat(fd)
    if (type(identity) is not tuple or len(identity)!=2 or
        any(type(v) is not int or not 0<=v<2**64 for v in identity) or
        (image.st_dev,image.st_ino)!=identity):
        raise DriverError('outer and service executable identities differ')

def _open_fixed_executable():
    return _open_image('/engine',_IMAGE_SIZE,_IMAGE_SHA256,0,0)

def _check_fixed_executable(fd):
    _check_image(fd,'/engine',_IMAGE_SIZE,_IMAGE_SHA256,0,0)


class DriverError(RuntimeError):
    pass


class FixedIntegrationDriver:
    """At most one attempt; no command, path or environment supplied by caller.

    Successful wiring observation is not proof of engine, isolation, provenance,
    descendant cleanup, or fixture peer identity. This driver must not run a real
    child without independently reviewed external lifecycle and runtime controls.
    """
    def __init__(self, expected_identity=None):
        self._used = False
        self._expected_identity = expected_identity
        self.evidence = {'stage': 'not_started', 'engine_launch_authorized': False,
                         'genuine_engine': 'not_attested', 'isolation': 'not_verified',
                         'provenance': 'not_verified', 'descendant_cleanup': 'not_verified',
                         'direct_child_cleanup': 'not_verified', 'spawn': 'not_attempted',
                         'config_observer_close': 'not_opened', 'lease_close': 'not_attempted',
                         'fixture_exit': 'not_entered', 'session_worker_call': 'not_submitted'}

    async def run(self):
        if self._used:
            raise DriverError('driver already attempted; do not replay')
        self._used = True
        if _LAUNCH_BLOCKED:
            self.evidence['stage'] = 'blocked_before_start'
            raise DriverError('integration launch hard-blocked; external controls not verified')
        observation = None
        integration = None
        engine_fd = None
        try:
            self.evidence['stage'] = 'preflight'
            if (os.getuid() != 65534 or os.geteuid() != 65534 or
                os.getgid() != 65534 or os.getegid() != 65534 or
                os.getgroups() != [] or dict(os.environ) != _DRIVER_ENV):
                raise DriverError('driver identity, groups or environment differs')
            observation = ConfigDirectoryObservation('/work')
            self.evidence['config_observer_close'] = 'not_attempted'
            if observation.verify() is not True:
                raise DriverError('config observation failed')
            # A separate service-local held FD; this is not a transfer of the
            # supervisor custody FD. Digest identity needs the protected root.
            engine_fd = _open_fixed_executable()
            # The service's FD is distinct, but must name the same inode as
            # outer custody's retained installed FD. Neither this nor a digest
            # freezes mutable bytes; a protected mount/exclusive writers remain
            # mandatory. Equality may fail closed across differing device views.
            identity=self._expected_identity
            _require_outer_identity(engine_fd,identity)
            integration = OneShotIntegration()
            with integration:
                self.evidence['fixture_exit'] = 'pending'
                proc = None
                try:
                    env = integration.environment()
                    _check_fixed_executable(engine_fd)
                    _require_outer_identity(engine_fd,identity)
                    self.evidence['stage'] = 'spawning_outcome_uncertain'
                    self.evidence['spawn'] = 'outcome_unknown'
                    proc = await asyncio.create_subprocess_exec(
                        *_ARGV, stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE, cwd='/work/project', env=env,
                        close_fds=True, executable='/proc/self/fd/%d' % engine_fd,
                        pass_fds=(engine_fd,))
                    self.evidence['spawn'] = 'child_handle_obtained'
                    self.evidence['stage'] = 'child_spawned'
                    await integration.run(proc, observation.verify)
                finally:
                    if proc is not None:
                        try:
                            if proc.stdin is None:
                                self.evidence['lease_close'] = 'uncertain'
                            else:
                                try:
                                    proc.stdin.close()
                                    self.evidence['lease_close'] = 'close_requested'
                                except Exception:
                                    self.evidence['lease_close'] = 'uncertain'
                            if proc.returncode is None:
                                try:
                                    proc.kill()
                                except ProcessLookupError:
                                    pass
                                try:
                                    await asyncio.wait_for(proc.wait(), timeout=2)
                                except TimeoutError:
                                    # Direct exit may be recorded while descendants still hold pipes.
                                    # Snapshot below only; external unit cleanup is still mandatory.
                                    pass
                            self.evidence['direct_child_cleanup'] = (
                                'direct_exit_observed' if proc.returncode is not None else 'uncertain')
                        except asyncio.CancelledError:
                            self.evidence['direct_child_cleanup'] = 'uncertain'
                            raise
                        except Exception:
                            self.evidence['direct_child_cleanup'] = 'uncertain'
            self.evidence['fixture_exit'] = 'returned'
            if (not isinstance(integration.evidence, dict) or
                integration.evidence.get('stage') != 'assembled_observation_complete' or
                integration.evidence.get('fixture_final_check') != 'passed' or
                integration.evidence.get('fixture_thread_stopped') is not True or
                integration.evidence.get('session_worker_call') != 'call_completed'):
                raise DriverError('integration evidence incomplete')
            # Same-process claims only: not identity, isolation or cleanup proof.
            self.evidence['integration'] = summarize(integration.evidence)
            self.evidence['stage'] = 'integration_observed_cleanup_pending'
        except asyncio.CancelledError:
            self.evidence['stage'] = 'cancelled_outcome_uncertain'
            raise
        except Exception:
            self.evidence['stage'] = 'failed_outcome_uncertain'
            raise DriverError('integration failed or uncertain; no retry') from None
        finally:
            # The subprocess receives an inheritable descriptor (proc-fd
            # execution, not CLOEXEC execveat). It may retain it after exec.
            if engine_fd is not None:
                try:
                    os.close(engine_fd)
                    self.evidence['engine_fd_close']='closed'
                except OSError:
                    self.evidence['engine_fd_close']='uncertain'
            # Unknown cannot imply that the worker or unit has stopped.
            if integration is not None:
                try:
                    from . import synthetic_failure_evidence as categories
                    shape=integration.evidence.get('failure_shape')
                    if shape is not None:self.evidence['failure_shape']=categories.validate(shape)
                except Exception:
                    self.evidence.pop('failure_shape',None)
                try:
                    self.evidence['session_worker_call'] = integration.worker.snapshot()
                except Exception:
                    self.evidence['session_worker_call'] = 'unknown'
            if observation is not None:
                if self.evidence['session_worker_call'] == 'unknown':
                    # The worker may still be in verify(); do not close/reuse
                    # its fds here. External unit termination owns this case.
                    self.evidence['config_observer_close'] = 'deferred_to_external_supervisor'
                else:
                    try:
                        observation.close()
                        self.evidence['config_observer_close'] = 'closed'
                    except Exception:
                        self.evidence['config_observer_close'] = 'uncertain'
        if (self.evidence.get('engine_fd_close') != 'closed' or
            self.evidence['config_observer_close'] != 'closed' or
            self.evidence['lease_close'] != 'close_requested' or
            self.evidence['direct_child_cleanup'] != 'direct_exit_observed'):
            self.evidence['stage'] = 'failed_cleanup_uncertain'
            raise DriverError('integration cleanup uncertain; no retry')
        self.evidence['stage'] = 'integration_observation_complete'
        return dict(self.evidence)
