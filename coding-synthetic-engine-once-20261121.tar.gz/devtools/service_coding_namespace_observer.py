"""Read-only sampled namespace/mount information, NOT admission or sandbox.

Only a trusted externally supervised disposable VM caller may use this module.
A passing snapshot neither proves no egress nor authorizes process execution.
"""
import os
import re
import select
import stat
from .service_proc_observer import _pidfd,_fdinfo,_read,_stat_start

_MAX=1_048_576
_PHASES=('namespace_input','namespace_pidfd','namespace_stat','namespace_identity',
         'namespace_interfaces','namespace_mounts','namespace_mount_format',
         'namespace_mount_propagation','namespace_mount_duplicate','namespace_mount_unknown',
         'namespace_missing_root','namespace_missing_work','namespace_missing_dev','namespace_missing_proc',
         'namespace_extra_dev_mqueue','namespace_extra_dev_hugepages','namespace_extra_dev_other',
         'namespace_extra_proc','namespace_extra_sys','namespace_extra_run','namespace_extra_etc','namespace_extra_var','namespace_extra_tmp',
         'namespace_mount_protected','namespace_mount_work','namespace_mount_fstype','namespace_probe_bind','namespace_stability')
# Fixed, public diagnostic bits only: no paths, source/options, IDs or values.
# These are observations, not permissions. Multiple bits may be set.
_INVENTORY_BITS=(
 'malformed','duplicate','propagation','missing_root','missing_work','missing_dev','missing_proc',
 'protected_rw','work_not_rw','base_fstype','mqueue_shape','hugepages_shape',
 'extra_dev_other','extra_proc_other','extra_sys','extra_run','extra_etc','extra_var','extra_tmp','extra_other',
 'extra_rw','extra_nonprocfs','extra_nonroot',
 'proc_acpi','proc_apm','proc_asound','proc_bus','proc_fs','proc_irq','proc_kallsyms','proc_kcore',
 'proc_latency_stats','proc_mtrr','proc_scsi','proc_timer_stats','proc_kmsg',
 'sys_bpf','sys_selinux','sys_debug','sys_tracing')
_INV_PREFIX='namespace_inventory_'
def _valid_inventory(value):
    return (type(value) is str and re.fullmatch(_INV_PREFIX+r'[0-9a-f]{16}',value) is not None
            and 0<int(value[len(_INV_PREFIX):],16)<(1<<len(_INVENTORY_BITS)))

def _mount_inventory(raw):
    """One bounded, value-free best-effort inventory; never authorizes admission.

    A malformed bit means results may be incomplete. Each set bit is a category,
    not an occurrence count, backing identity, origin, or isolation evidence.
    """
    flags=set();rows={};ids=set()
    def mark(name):flags.add(name)
    if type(raw) is not bytes or len(raw)>_MAX:return _INV_PREFIX+format(1,'016x')
    try:lines=raw.decode('ascii').splitlines()
    except UnicodeDecodeError:return _INV_PREFIX+format(1,'016x')
    for line in lines:
        f=line.split()
        if f.count('-')!=1:mark('malformed');continue
        i=f.index('-')
        if i<6 or len(f)!=i+4 or not f[0].isdigit() or not f[1].isdigit() or not re.fullmatch(r'[0-9]+:[0-9]+',f[2]):mark('malformed');continue
        root,path=f[3],f[4];opts=f[5].split(',')
        if '\\' in root or '\\' in path or not root.startswith('/') or not path.startswith('/') or len(set(opts))!=len(opts) or ('ro' in opts)==('rw' in opts):mark('malformed');continue
        if f[0] in ids or path in rows:mark('duplicate')
        ids.add(f[0]);rows.setdefault(path,(set(opts),f[i+1],root))
        if any(x.startswith(('shared:','master:','propagate_from:')) for x in f[6:i]):mark('propagation')
    allowed={'/','/app','/usr','/work','/dev','/dev/pts','/dev/shm','/proc','/proc/sys','/proc/sysrq-trigger','/sys','/sys/fs/cgroup','/run','/run/host/os-release'}
    for path,bit,fs in (('/dev/mqueue','mqueue_shape','mqueue'),('/dev/hugepages','hugepages_shape','hugetlbfs')):
        if path in rows:
            if rows[path][1:]!=(fs,'/'):mark(bit)
            else:allowed.add(path)
    for path,bit in (('/','missing_root'),('/work','missing_work'),('/dev','missing_dev'),('/proc','missing_proc')):
        if path not in rows:mark(bit)
    for path in ('/','/app','/usr','/sys','/sys/fs/cgroup','/proc/sys','/proc/sysrq-trigger','/run/host/os-release'):
        if path in rows and 'ro' not in rows[path][0]:mark('protected_rw')
    if '/work' in rows and 'rw' not in rows['/work'][0]:mark('work_not_rw')
    for path,fs in (('/dev','tmpfs'),('/proc','proc'),('/run','tmpfs')):
        if path in rows and rows[path][1]!=fs:mark('base_fstype')
    known={ '/proc/'+n:'proc_'+n for n in ('acpi','apm','asound','bus','fs','irq','kallsyms','kcore','latency_stats','mtrr','scsi','timer_stats','kmsg') }
    known.update({'/sys/fs/bpf':'sys_bpf','/sys/fs/selinux':'sys_selinux','/sys/kernel/debug':'sys_debug','/sys/kernel/tracing':'sys_tracing'})
    for path in set(rows)-allowed:
        opts,fs,root=rows[path]
        if path in ('/dev/mqueue','/dev/hugepages'):continue
        if path in known:mark(known[path])
        else:
            for prefix,bit in (('/dev/','extra_dev_other'),('/proc/','extra_proc_other'),('/sys/','extra_sys'),('/run/','extra_run'),('/etc/','extra_etc'),('/var/','extra_var'),('/tmp/','extra_tmp')):
                if path.startswith(prefix):mark(bit);break
            else:mark('extra_other')
        if 'rw' in opts:mark('extra_rw')
        if fs!='proc':mark('extra_nonprocfs')
        if root!='/':mark('extra_nonroot')
    mask=sum(1<<_INVENTORY_BITS.index(x) for x in flags)
    # A snapshot not reproducing the original failure is explicitly incomplete.
    return _INV_PREFIX+format(mask or 1,'016x')

class NamespaceError(RuntimeError):
    def __init__(self,phase='namespace_input',category='other'):
        self.phase=phase if phase in _PHASES or _valid_inventory(phase) else 'namespace_input'
        self.category=category if category in ('permission','not_found','other') else 'other'
        super().__init__('namespace observation unavailable')

class _MountError(ValueError):
    def __init__(self,phase):
        self.phase=phase if phase in _PHASES or _valid_inventory(phase) else 'namespace_mounts'
        super().__init__('mount observation unavailable')


def _interfaces(raw):
    lines=raw.decode('ascii').splitlines()
    if len(lines)<3 or 'Inter-' not in lines[0] or 'face' not in lines[1]:raise ValueError('header')
    names=[]
    for line in lines[2:]:
        left,sep,right=line.partition(':')
        if not sep or not left.strip() or len(right.split())!=16 or any(not v.isdigit() for v in right.split()):
            raise ValueError('interface')
        names.append(left.strip())
    if names!=['lo']:raise ValueError('extra interfaces')


def _mounts(raw,*,allow_propagation=False,no_engine_compat=False):
    """Restrictive candidate shape; may reject a legitimate target manager."""
    if (type(raw) is not bytes or len(raw)>_MAX or type(allow_propagation) is not bool or type(no_engine_compat) is not bool or (no_engine_compat and not allow_propagation)):raise _MountError('namespace_mount_format')
    rows={};roots={};ids=set()
    for line in raw.decode('ascii').splitlines():
        fields=line.split();
        if fields.count('-')!=1:raise _MountError('namespace_mount_format')
        i=fields.index('-')
        if i<6 or len(fields)!=i+4 or not fields[0].isdigit() or not fields[1].isdigit():raise _MountError('namespace_mount_format')
        if fields[0] in ids or not re.fullmatch(r'[0-9]+:[0-9]+',fields[2]):raise _MountError('namespace_mount_format')
        ids.add(fields[0]);root,mount=fields[3],fields[4]
        if '\\' in root or '\\' in mount or not root.startswith('/') or not mount.startswith('/'):
            raise _MountError('namespace_mount_format')
        options=fields[5].split(',')
        if len(set(options))!=len(options) or ('ro' in options)==('rw' in options):raise _MountError('namespace_mount_format')
        tags=fields[6:i]
        propagation=[x for x in tags if x.startswith(('shared:','master:','propagate_from:'))]
        # Tolerance is solely for the blocked no-engine bootstrap in a disposable
        # synthetic VM. No isolation, origin or future-propagation claim follows.
        if propagation and (not allow_propagation or len(set(propagation))!=len(propagation) or
            len({x.split(':',1)[0] for x in propagation})!=len(propagation) or
            any(re.fullmatch(r'(shared|master|propagate_from):[1-9][0-9]*',x) is None for x in propagation)):
            raise _MountError('namespace_mount_propagation')
        if mount in rows:raise _MountError('namespace_mount_duplicate')
        rows[mount]=(set(options),fields[i+1]);roots[mount]=root
    if no_engine_compat:
        # Diagnostic only for the blocked empty-engine CI control. Do not infer
        # isolation: extra mounts, writable protected mounts, their origins and
        # propagation are deliberately not admitted as safe. A disposable VM,
        # no credentials and fixed inert bootstrap are external prerequisites.
        for path,phase in (('/','namespace_missing_root'),('/work','namespace_missing_work'),
                           ('/dev','namespace_missing_dev'),('/proc','namespace_missing_proc')):
            if path not in rows:raise _MountError(phase)
        if 'rw' not in rows['/work'][0]:raise _MountError('namespace_mount_work')
        if rows['/proc'][1]!='proc' or rows['/dev'][1]!='tmpfs':raise _MountError('namespace_mount_fstype')
        if '/run' in rows and rows['/run'][1]!='tmpfs':raise _MountError('namespace_mount_fstype')
        return len(rows)
    # Unknown mounts, including overmounts or writable aliases, are rejected.
    # This is a candidate, not a claim systemd mounts exactly this topology.
    allowed={'/','/app','/usr','/work','/dev','/dev/pts','/dev/shm','/proc',
             '/proc/sys','/proc/sysrq-trigger','/sys','/sys/fs/cgroup','/run','/run/host/os-release'}
    # The blocked synthetic bootstrap may see systemd PrivateDevices' bind of
    # /dev/mqueue. This is a shared IPC surface, not isolation evidence; do
    # not permit it for genuine execution. Only its exact mountpoint, fstype
    # and root are recognized. No submounts or unrelated paths are accepted.
    if allow_propagation and '/dev/mqueue' in rows:
        if rows['/dev/mqueue'][1]!='mqueue' or roots['/dev/mqueue']!='/':
            raise _MountError('namespace_extra_dev_mqueue')
        allowed.add('/dev/mqueue')
    # Same test-only concession for systemd PrivateDevices' optional host
    # hugetlbfs bind. Files here can expose shared hugepage resources; this
    # condition is not backing identity, resource isolation or authorization.
    if allow_propagation and '/dev/hugepages' in rows:
        if rows['/dev/hugepages'][1]!='hugetlbfs' or roots['/dev/hugepages']!='/':
            raise _MountError('namespace_extra_dev_hugepages')
        allowed.add('/dev/hugepages')
    # A fixed, value-free category only; no arbitrary mount path, source,
    # options, filesystem or peer identifiers leave this observer. Failure is
    # unchanged: every missing mandatory mount or unexpected mount rejects.
    for path,phase in (('/','namespace_missing_root'),('/work','namespace_missing_work'),
                       ('/dev','namespace_missing_dev'),('/proc','namespace_missing_proc')):
        if path not in rows:raise _MountError(phase)
    extras=set(rows)-allowed
    if extras:
        # Fixed ordering prevents untrusted kernel text from becoming output.
        for path,phase in (('/dev/mqueue','namespace_extra_dev_mqueue'),('/dev/hugepages','namespace_extra_dev_hugepages')):
            if path in extras:raise _MountError(phase)
        for prefix,phase in (('/dev/','namespace_extra_dev_other'),('/proc/','namespace_extra_proc'),
                             ('/sys/','namespace_extra_sys'),('/run/','namespace_extra_run'),
                             ('/etc/','namespace_extra_etc'),('/var/','namespace_extra_var'),('/tmp/','namespace_extra_tmp')):
            if any(x.startswith(prefix) for x in extras):raise _MountError(phase)
        raise _MountError('namespace_mount_unknown')
    for path in ('/','/app','/usr','/sys','/sys/fs/cgroup','/proc/sys','/proc/sysrq-trigger','/run/host/os-release'):
        if path in rows and 'ro' not in rows[path][0]:raise _MountError('namespace_mount_protected')
    if 'rw' not in rows['/work'][0]:raise _MountError('namespace_mount_work')
    if rows['/proc'][1]!='proc' or rows['/dev'][1]!='tmpfs':raise _MountError('namespace_mount_fstype')
    # systemd MountAPIVFS may mount a fresh tmpfs at /run. No network or
    # backing-store assurance is implied by its reported filesystem type.
    if '/run' in rows and rows['/run'][1]!='tmpfs':raise _MountError('namespace_mount_fstype')
    return len(rows)


def _probe_bind_sample(pid,mount_raw):
    """Sample exact pathname socket mount and matching host inode, not isolation.

    Host file must be owned by the separately supervised synthetic canary;
    manager/owner exclude competing privileged writers. /proc access and
    inode checks are racy; no guarantee applies after this observation.
    """
    from .target_probe_entry import _PATH
    rows=[]
    if type(mount_raw) is not bytes or len(mount_raw)>_MAX:raise ValueError('mountinfo')
    for line in mount_raw.decode('ascii').splitlines():
        f=line.split()
        if f.count('-')!=1:raise ValueError('mountinfo')
        i=f.index('-')
        if i<6 or len(f)!=i+4:raise ValueError('mountinfo')
        if f[4]==_PATH:rows.append(f)
    if len(rows)!=1 or 'ro' not in rows[0][5].split(',') or 'rw' in rows[0][5].split(','):raise ValueError('probe bind mount')
    host=os.stat(_PATH,follow_symlinks=False)
    child=os.stat('/proc/'+str(pid)+'/root'+_PATH,follow_symlinks=False)
    if not stat.S_ISSOCK(host.st_mode) or not stat.S_ISSOCK(child.st_mode) or (host.st_dev,host.st_ino)!=(child.st_dev,child.st_ino):raise ValueError('probe bind identity')
    return None


def inspect(pid,pidfd,*,profile="genuine"):
    """Compare target/observer net + mount namespaces and sample target data.

    Uses no setns, no sockets and no mutation. Caller must bind this same live
    process to its manager and a trusted private root independently. Network
    interface list does NOT establish address/routes/loopback operation or all
    egress; mountinfo doesn't identify underlying host path aliases or future
    changes. Syscalls may hang: caller needs an external deadline/watchdog.
    """
    if profile not in ('genuine','coding_genuine','no_engine','target_probe','target_probe_nobind') or type(pid) is not int or pid<=0 or type(pidfd) is not int or pidfd<0:
        raise NamespaceError('invalid input')
    phase='namespace_pidfd'
    try:
        _pidfd(pidfd)
        _fdinfo(_read('/proc/self/fdinfo/'+str(pidfd)),pid)
        if select.select([pidfd],[],[],0)[0]:raise ValueError('exited')
        base='/proc/'+str(pid); phase='namespace_stat';start=_stat_start(_read(base+'/stat'),pid)
        def ns(path):
            st=os.stat(path);return st.st_dev,st.st_ino
        phase='namespace_identity';target_net=ns(base+'/ns/net');target_mnt=ns(base+'/ns/mnt')
        if target_net==ns('/proc/self/ns/net') or target_mnt==ns('/proc/self/ns/mnt'):
            raise ValueError('namespace not distinct')
        phase='namespace_interfaces';_interfaces(_read(base+'/net/dev',_MAX))
        phase='namespace_mounts';mount_raw=_read(base+'/mountinfo',_MAX)
        try:count=_mounts(mount_raw,allow_propagation=(profile in ('no_engine','target_probe','target_probe_nobind')),no_engine_compat=(profile in ('no_engine','target_probe')))
        except _MountError:
            if profile in ('no_engine','target_probe'):raise _MountError(_mount_inventory(mount_raw)) from None
            raise
        if profile=='target_probe':
            phase='namespace_probe_bind';_probe_bind_sample(pid,mount_raw)
        elif profile=='target_probe_nobind':
            # Strict per-run snapshot only, not a post-sample observation or proof.
            from .target_probe_nobind_observation import _sample
            phase='namespace_probe_bind';nobind_identity=_sample(pid,mount_raw)
        phase='namespace_stability'
        if (target_net!=ns(base+'/ns/net') or target_mnt!=ns(base+'/ns/mnt') or
            _stat_start(_read(base+'/stat'),pid)!=start or select.select([pidfd],[],[],0)[0]):
            raise ValueError('process changed')
        _fdinfo(_read('/proc/self/fdinfo/'+str(pidfd)),pid)
        result={'network_namespace':'distinct_snapshot','network_interfaces':'loopback_only_snapshot',
                'mount_namespace':'distinct_snapshot','mount_layout':'no_engine_compat_not_isolation' if profile in ('no_engine','target_probe') else 'candidate_shape_snapshot',
                'mount_count':count,'mount_propagation':'not_verified' if profile in ('no_engine','target_probe','target_probe_nobind') else 'no_recognized_propagation_tags_snapshot','routes_egress':'not_verified','mount_backing_aliases':'not_verified',
                'cleanup':'not_observed','admission':'not_authorized','engine_launch_authorized':False}
        if profile=='target_probe_nobind':result['nobind_host_identity']=nobind_identity
        return result
    except Exception as exc:
        if isinstance(exc,_MountError):phase=exc.phase
        category='permission' if isinstance(exc,PermissionError) else 'not_found' if isinstance(exc,FileNotFoundError) else 'other'
        raise NamespaceError(phase,category) from None
