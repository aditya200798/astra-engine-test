"""Strict bounded vocabulary for private genuine diagnostic projection."""
import re
from . import synthetic_no_engine_supervisor as common
from . import synthetic_failure_evidence as failure

_CATS={
 'packages':('unknown','fixed_17_downloads_rehashed'),
 'archive':('unknown','fixed_download_and_binary_rehashed'),
 'control':('unknown','blocked_genuine_entry_record_and_exit_sampled','synthetic_inner_returned_cleanup_unverified'),
 'staging':('not_started','not_guarded','enrolled_sampled','kill_returned_empty_removed_sampled','cleanup_uncertain'),
 'watchdog':('not_started','ready_sampled','kill_returned_empty_sampled','outcome_uncertain'),
 'cleanup':('not_verified',),'isolation':('not_verified',),'late_start':('not_reconciled',),
 'vm_decommission':('not_observed',),'delegated_work':('empty_removed_sampled','uncertain'),
 'flow_stage':common._FLOW_STAGES,'owner_stage':common._OWNER_STAGES,
 'owner_reason':common._OWNER_REASONS,'start_phase':common._START_PHASES,
 'start_error':common._START_ERRORS,'record':common._RECORDS,'stop':common._STOPS}

def validate(obj):
    if type(obj) is not dict or set(obj)!=set(_CATS)|{'engine_launch_authorized','production_approved','fixture_request_sha256','fixture_failure'}:raise ValueError('fields')
    for k,allowed in _CATS.items():
        if type(obj[k]) is not str or obj[k] not in allowed:raise ValueError('category')
    if obj['engine_launch_authorized'] is not False or obj['production_approved'] is not False:raise ValueError('flags')
    shape=failure.validate_context(obj['fixture_failure'],control=obj['control'],
        flow_stage=obj['flow_stage'],owner_stage=obj['owner_stage'],owner_reason=obj['owner_reason'],
        start_phase=obj['start_phase'],start_error=obj['start_error'],record=obj['record'],stop=obj['stop'])
    if shape!=failure.unknown() and (obj['packages']!='fixed_17_downloads_rehashed' or
        obj['archive']!='fixed_download_and_binary_rehashed' or
        obj['staging']!='kill_returned_empty_removed_sampled' or
        obj['watchdog']!='kill_returned_empty_sampled' or obj['delegated_work']!='empty_removed_sampled'):
        raise ValueError('failure evidence cleanup')
    d=obj['fixture_request_sha256']
    if obj['control']=='synthetic_inner_returned_cleanup_unverified':
        if type(d) is not str or re.fullmatch('[0-9a-f]{64}',d) is None:raise ValueError('digest')
    elif d is not None:raise ValueError('unexpected digest')
    return obj
