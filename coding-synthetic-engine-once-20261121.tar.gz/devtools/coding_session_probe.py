"""Fixed private coding probe for a separately supervised synthetic service.

No launch or containment, no arbitrary task, approval, provider, or source.
Not connected to any public entrypoint; synthetic data only.
"""
import asyncio
import hashlib
import os
from pathlib import Path
from astra import coding,coding_exchange,coding_session_exchange
from astra.policy import check_config,rules_for
from astra.session import Session
from astra.storage import Store
from astra.transport import Client
from . import coding_integration_scenario as scenario
from . import fake_responses as fake
from . import synthetic_session_probe as base
from .baseline_controller import SYNTHETIC_PASSWORD

# Only a disposable service whose layout has been created by its owner may use.
STATE_PARENT='/work/state'


def _fixed_probe(server_port, provider_port, ledger, verify_config_directory, verify_listener):
    if type(server_port) is not int or not 1<=server_port<=65535:raise ValueError('server port invalid')
    if not callable(verify_config_directory) or not callable(verify_listener):raise ValueError('observers required')
    root=Path(STATE_PARENT)/'astra-coding-synthetic'
    # O_EXCL mkdir is the one-shot namespace claim. Any error leaves it in place.
    root.mkdir(mode=0o700,parents=False,exist_ok=False)
    source=root/'source';source.mkdir(mode=0o700)
    fd=os.open(source/'main.py',os.O_CREAT|os.O_EXCL|os.O_WRONLY|os.O_NOFOLLOW,0o600)
    try:
        with os.fdopen(fd,'wb') as f:f.write(scenario.SOURCE);f.flush();os.fsync(f.fileno())
    except BaseException:
        raise
    task=root/'candidate';coding.create(source,task)
    prepared=coding_exchange.prepare(task,scenario.INSTRUCTION,['main.py'],acknowledged=True)
    if prepared['request_sha256']!=scenario.PROMPT_SHA256 or prepared['revision']!=0:raise ValueError('fixed prompt mismatch')
    store=Store(root/'session');store.acquire()
    try:
        client=base.ObservedClient(Client(server_port,SYNTHETIC_PASSWORD),server_port,verify_listener)
        rules=rules_for([]);config=base.synthetic_config(provider_port)
        session=Session(client,store,base.WORK,rules,config,
            {'PATH':'/usr/bin:/bin','HOME':'/work/home','TMPDIR':'/work/tmp','LANG':'C'},
            [SYNTHETIC_PASSWORD,fake.SYNTHETIC_KEY],
            {'trusted_directory':base.CONFIG_DIR,'verify_directory':verify_config_directory},model=dict(base.SYNTHETIC_MODEL))
        # These approvals apply only to this fixed, invented local scenario.
        out=coding_session_exchange._run_private(task,prepared['exchange_id'],session,lambda _:True,lambda _:True,
            deadline_seconds=20,poll_interval=.1,review_paths=['main.py'])
        rec=ledger.snapshot();diag=ledger.diagnostics()
        review=out.get('review',{});report=review.get('report',{})
        if (out.get('status')!='candidate_revision_created' or out.get('request_sha256')!=scenario.PROMPT_SHA256
            or out.get('source_applied') is not False or out.get('code_executed') is not False
            or out.get('candidate',{}).get('result',{}).get('revision')!=1
            or review.get('status')!='completed' or report.get('revision')!=1
            or report.get('python_syntax',{}).get('status')!='compile_passed'
            or (source/'main.py').read_bytes()!=scenario.SOURCE
            or (task/'revisions/000001/tree/main.py').read_bytes()!=b'answer = 2\n'
            or type(rec) is not dict or rec.get('valid_attempts')!=1
            or rec.get('response_delivery')!='write_completed_not_client_receipt'
            or not scenario.matches_request(rec.get('raw'))
            or diag.get('handled_connections')!=1 or diag.get('handled_http_requests')!=1
            or diag.get('handled_rejections')!=0 or diag.get('refused_connections')!=0 or diag.get('wall_timeouts')!=0):
            raise ValueError('coding result or fixture evidence mismatch')
        # Bounded categorical evidence; no source, request, response, IDs or paths.
        return {'session_status':'succeeded','candidate':'revision_1_static_python_passed',
            'source_apply':'not_done','candidate_execution':'not_done',
            'fixture_valid_attempts':1,'fixture_user_prompt_matches':True,
            'fixture_response_delivery':'write_completed_not_client_receipt',
            'genuine_engine':'not_attested','isolation':'not_verified',
            'descendant_cleanup':'not_verified','all_network_traffic':'not_observed'}
    finally:
        store.release()


async def exercise_coding_session(port, info, config, *, provider_port, ledger, verify_config_directory, verify_listener, worker):
    if not callable(verify_listener):raise ValueError('listener verifier required')
    check_config(config,base.synthetic_config(provider_port),trusted_directory=base.CONFIG_DIR,verify_directory=verify_config_directory)
    if not isinstance(worker,base.SessionWorkerEvidence):raise ValueError('session worker evidence required')
    worker.submit_once()
    return await asyncio.to_thread(worker.invoke,_fixed_probe,port,provider_port,ledger,verify_config_directory,verify_listener)
