"""Prepare fixed staged app for future non-root reading, never a launch gate.

Only call public entry for root-owned data in an exclusively controlled fresh
synthetic disposable VM. Caller manages mounts, review, lifecycle and disposal.
"""
import hashlib
import os
import stat
from .coding_supervised_app_stage import MANIFEST, MAX_SOURCE

class HandoffError(RuntimeError): pass


def _identity(st):
    return (st.st_dev,st.st_ino,st.st_mode,st.st_uid,st.st_gid,st.st_nlink,
            st.st_size,st.st_mtime_ns,st.st_ctime_ns)


def _no_posix_acl(fd):
    # Inability to inspect xattrs is a failure, not absence.
    return not any(a in ('system.posix_acl_access','system.posix_acl_default') for a in os.listxattr(fd))


def _handoff(root_fd, owner):
    """Check exact tree and transition mode; private owner override for tests.

    Requires no concurrent root/same-owner modifiers. Never confirms mount,
    alias, ancestors, LSM, upstream provenance or process root; failure leaves
    tree unusable even if best-effort mode rollback appears to succeed.
    """
    if type(root_fd) is not int or root_fd<0 or type(owner) is not int or owner!=os.geteuid():
        raise HandoffError('invalid owner or descriptor')
    dirs={}; leaves={}; changed=[]; success=False; uncertain=False
    def check_dir(fd, mode):
        st=os.fstat(fd)
        if not stat.S_ISDIR(st.st_mode) or st.st_uid!=owner or stat.S_IMODE(st.st_mode)!=mode or not _no_posix_acl(fd): raise ValueError('invalid directory')
        return st
    def check_leaf(fd, path, mode):
        before=os.fstat(fd)
        if (not stat.S_ISREG(before.st_mode) or before.st_uid!=owner or before.st_nlink!=1
            or stat.S_IMODE(before.st_mode)!=mode or not 0<=before.st_size<=MAX_SOURCE or not _no_posix_acl(fd)):
            raise ValueError('invalid leaf')
        os.lseek(fd,0,os.SEEK_SET); digest=hashlib.sha256(); total=0
        while True:
            part=os.read(fd,65536)
            if not part: break
            total+=len(part)
            if total>MAX_SOURCE: raise ValueError('oversize')
            digest.update(part)
        if total!=before.st_size or digest.hexdigest()!=MANIFEST[path] or _identity(os.fstat(fd))!=_identity(before):
            raise ValueError('changed source')
        return before
    def match_name(parent,name,opened):
        named=os.stat(name,dir_fd=parent,follow_symlinks=False)
        if (opened.st_dev,opened.st_ino)!=(named.st_dev,named.st_ino): raise ValueError('replaced')
    try:
        if not all(hasattr(os,a) for a in ('O_DIRECTORY','O_NOFOLLOW','O_CLOEXEC')): raise ValueError('unsupported')
        flags=os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC
        check_dir(root_fd,0o700)
        if set(os.listdir(root_fd))!={'astra','devtools'}: raise ValueError('root contents')
        for package in ('astra','devtools'):
            fd=os.open(package,flags|os.O_DIRECTORY,dir_fd=root_fd); dirs[package]=fd
            match_name(root_fd,package,check_dir(fd,0o700))
            if set(os.listdir(fd))!={p.split('/')[1] for p in MANIFEST if p.startswith(package+'/')}: raise ValueError('contents')
        for path in sorted(MANIFEST):
            package,name=path.split('/'); fd=os.open(name,flags|os.O_NONBLOCK,dir_fd=dirs[package]); leaves[path]=fd
            match_name(dirs[package],name,check_leaf(fd,path,0o400))
        # Record before fchmod because an interrupted syscall may have changed it.
        for fd in leaves.values():
            changed.append((fd,0o400)); os.fchmod(fd,0o444); os.fsync(fd)
        for fd in dirs.values():
            changed.append((fd,0o700)); os.fchmod(fd,0o555); os.fsync(fd)
        changed.append((root_fd,0o700)); os.fchmod(root_fd,0o555); os.fsync(root_fd)
        check_dir(root_fd,0o555)
        if set(os.listdir(root_fd))!={'astra','devtools'}: raise ValueError('root changed')
        for package,fd in dirs.items():
            match_name(root_fd,package,check_dir(fd,0o555))
            if set(os.listdir(fd))!={p.split('/')[1] for p in MANIFEST if p.startswith(package+'/')}: raise ValueError('contents changed')
        for path,fd in leaves.items():
            package,name=path.split('/'); match_name(dirs[package],name,check_leaf(fd,path,0o444))
        success=True
        return {'files':len(leaves),'root_and_directories':'0555','files_mode':'0444',
                'local_manifest':'matched','engine_launch_authorized':False,
                'read_only_mount':'not_created','provenance':'not_verified',
                'isolation':'not_verified','cleanup':'caller_required'}
    except Exception:
        raise HandoffError('handoff failed; do not launch or reuse tree') from None
    finally:
        if not success:
            for fd,mode in reversed(changed):
                try: os.fchmod(fd,mode); os.fsync(fd)
                except OSError: uncertain=True
        for fd in leaves.values(): os.close(fd)
        for fd in dirs.values(): os.close(fd)
        if uncertain: raise HandoffError('handoff failed; rollback uncertain; dispose tree') from None


def prepare_root_owned_staged_app(root_fd):
    """Require root-owned fixed staged tree; never builds, mounts or runs it."""
    if os.geteuid()!=0: raise HandoffError('root-owned disposable VM stage required')
    return _handoff(root_fd,0)
