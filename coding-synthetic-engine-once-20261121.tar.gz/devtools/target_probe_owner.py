"""One-shot no-engine target-probe owner using actual same-bus session.

Private helper only: external trusted owner supplies protected empty-engine
root, manager, exact unique unit/anchor, controlled VM and independent
watchdog. Public entry is blocked, no caller or workflow invokes this helper.
Never authorizes an engine or proves cleanup/isolation/known-live canaries.
"""
import os,time,select
from . import systemd_bound_session as bound, target_probe_collector as collector
_BLOCKED=True
_READY=b'ASTRA-TARGET-PROBE-READY-1\n'
class ProbeOwnerError(RuntimeError):pass

def _ready(fd,timeout=3):
    end=time.monotonic()+timeout;buf=bytearray();os.set_blocking(fd,False)
    while len(buf)<len(_READY):
        left=end-time.monotonic()
        if left<=0 or not select.select([fd],[],[],left)[0]:raise ProbeOwnerError('readiness unknown')
        try:part=os.read(fd,len(_READY)-len(buf))
        except BlockingIOError:continue
        if not part:raise ProbeOwnerError('readiness unknown')
        buf.extend(part)
        if not _READY.startswith(buf):raise ProbeOwnerError('readiness unknown')

def _drive_once(lib,bus,owner,unit,root,root_fd,*,slice_name,anchor,root_profile,nobind=False,nobind_announce=None):
    if type(nobind) is not bool:raise ProbeOwnerError('case')
    fds={};session=None;result={'control':'unknown','stage':'pipes','record':'not_observed',
        'stop':'not_observed','start_phase':'not_observed','start_error':'not_observed','service_diag':'not_observed','service_result':'not_observed','exec_status':'not_observed','observe_phase':'not_observed','observe_error':'not_observed','cleanup':'not_verified','canary_liveness':'not_verified',
        'isolation':'not_verified','engine_launch_authorized':False,'production_approved':False}
    def close(k):
        fd=fds.pop(k,None)
        if fd is not None:os.close(fd)
    try:
        attempt=os.urandom(32) if nobind else None
        if nobind and not any(attempt):raise ValueError('invalid random token')
        for a,b in (('ir','iw'),('or','ow'),('er','ew')):fds[a],fds[b]=os.pipe2(os.O_CLOEXEC)
        session=bound._Session(lib,bus,owner,unit,'probe_nobind' if nobind else 'probe',root,root_fd,fds['iw'],fds['or'],fds['er'],slice_name=slice_name,anchor=anchor,root_profile=root_profile)
        result['stage']='start_uncertain'
        try:session.start_once(fds['ir'],fds['ow'],fds['ew'])
        finally:
            for k in ('ir','ow','ew'):close(k)
        result['stage']='readiness';_ready(fds['er'])
        result['stage']='observe';session.observe()
        # Supervisor ACK of this owner-generated token precedes release.
        if nobind and nobind_announce is not None:
            result['stage']='announce_uncertain';nobind_announce(attempt)
        result['stage']='release_uncertain'
        try:session.admit_no_engine_once(**({'nobind_attempt':attempt} if nobind else {}))
        finally:
            if session._input_consumed:fds.pop('iw',None)
        result['stage']='record';sample=collector._collect(fds['or'],fds['er'],5,**({'expected_nobind_attempt':attempt} if nobind else {}))
        result['record']='fixed_categories_received';result['sample']=sample
        if nobind:
            result['case']='no-bind-path-v1';result['attempt']=attempt.hex();result['nobind_host_identity']=session._nobind_identity
        result['stage']='exit';end=time.monotonic()+5
        while True:
            try:status=session.observe_exit();break
            except bound.SessionError:
                if time.monotonic()>=end:raise
                time.sleep(.05)
        if type(status.get('exit_code')) is not int or status['exit_code']!=0:raise ProbeOwnerError('exit')
        result['stage']='stop';session.stop_once();result['stop']='bound_inactive_snapshot'
        result['control']='nobind_unverified' if nobind else 'probe_record_and_exit_sampled';result['stage']='finished'
    except BaseException:
        # Capture fixed internal categories before stop/close; never export raw exceptions.
        if session is not None and result['stage']=='start_uncertain':
            from .target_probe_packet import _valid_start_diagnostic, _valid_start_service
            phase=getattr(session,'start_phase','not_observed');error=getattr(session,'start_error','not_observed')
            if _valid_start_diagnostic('unknown',result['stage'],phase,error):
                result['start_phase']=phase;result['start_error']=error
                diag=getattr(session,'service_diag','not_observed');service=getattr(session,'service_result','not_observed');status=getattr(session,'exec_status','not_observed')
                if _valid_start_service('unknown',result['stage'],phase,error,diag,service,status):
                    result['service_diag']=diag;result['service_result']=service;result['exec_status']=status
        if session is not None and result['stage'] in ('observe','release_uncertain'):
            from . import systemd_pidfd_lookup as lookup
            phase=getattr(session,'observe_phase','not_observed');error=getattr(session,'observe_error','not_observed')
            if lookup._valid_probe_diagnostic(result['stage'],phase,error,nobind=nobind):
                result['observe_phase']=phase;result['observe_error']=error
        # Never retry an ambiguous start. Only the already-bound invocation may
        # be stopped, and even that observation is not a cleanup receipt.
        if session is not None and not session._stop_attempted and session._bound is not None:
            try:session.stop_once();result['stop']='bound_inactive_snapshot'
            except BaseException:pass
    finally:
        if session is not None:
            try:session.close()
            except BaseException:result['control']='unknown'
        for k in tuple(fds):
            try:close(k)
            except OSError:result['control']='unknown'
    return result

def run():
    if _BLOCKED:raise ProbeOwnerError('target probe owner blocked')
    raise ProbeOwnerError('no approved orchestration')
