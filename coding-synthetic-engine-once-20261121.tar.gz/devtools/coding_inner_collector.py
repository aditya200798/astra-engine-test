"""Strict bounded coding pipe parser; no lifecycle, identity, or cleanup proof."""
import json
from astra.policy import json_equal
from . import coding_service_entry as entry
from .strict_inner_collector import MAX_LINE,RecordError,_object,_constant

def parse(raw,kind):
    if (type(raw) is not bytes or not 1<=len(raw)<=MAX_LINE+1 or not raw.endswith(b'\n') or raw.count(b'\n')!=1 or kind!='coding'):
        raise RecordError('framing')
    try:
        obj=json.loads(raw[:-1].decode('ascii'),object_pairs_hook=_object,parse_constant=_constant)
        if type(obj) is not dict or type(obj.get('outcome')) is not str or obj['outcome'] not in entry._OUTCOMES:
            raise RecordError('outcome')
        obs=obj.get('observations')
        if type(obs) is not dict:raise RecordError('observations')
        evidence=dict(obs)
        evidence['failure_shape']=obj.get('fixture_failure')
        if obj['outcome']=='returned':evidence['integration']=obj.get('coding_evidence')
        canonical=entry._report(evidence,obj['outcome'])
        if not json_equal(obj,canonical):raise RecordError('mismatch')
        return canonical
    except (ValueError,UnicodeError,TypeError,RecursionError,KeyError):raise RecordError('invalid record') from None
