"""Fixed synthetic root *skeleton*, never a runnable root or launch approval.

Public function is exclusively for a fresh disposable VM with trusted caller;
no mounting, execution, recursive cleanup or system manager interaction occurs.
Caller excludes all other writers and disposes the entire tree on ANY failure.
"""
import os
import stat
from .coding_supervised_app_stage import stage_into_empty_private_directory
from .coding_app_handoff import _handoff

# Empty mountpoints are placeholders, not assembled dependencies or mounts.
_DIRS = ('app','engine','etc','usr','work','proc','sys','dev','run')
_LINKS = {'lib64':'usr/lib64'}
_NAMES = _DIRS + tuple(_LINKS)

def _check_root_entries(fd):
    if set(os.listdir(fd))!=set(_NAMES): raise ValueError('root contents')
    for name,target in _LINKS.items():
        st=os.stat(name,dir_fd=fd,follow_symlinks=False)
        if not stat.S_ISLNK(st.st_mode) or st.st_uid!=os.geteuid() or os.readlink(name,dir_fd=fd)!=target:
            raise ValueError('invalid root link')
class SkeletonError(RuntimeError): pass

def _identity(st): return (st.st_dev,st.st_ino)
def _no_acl(fd):
    return not any(x in ('system.posix_acl_access','system.posix_acl_default') for x in os.listxattr(fd))
def _dir(fd,uid,gid,mode):
    s=os.fstat(fd)
    if (not stat.S_ISDIR(s.st_mode) or s.st_uid!=uid or s.st_gid!=gid or
        stat.S_IMODE(s.st_mode)!=mode or not _no_acl(fd)):
        raise ValueError('directory metadata')
    return s

def _assemble(source_fd,root_fd,work_uid,work_gid):
    """Private parameterized test core: root is open, empty and owner-private.

    Caller owns all FDs, excludes concurrent modifications and tears down the
    fresh disposable tree after stopping all processes. No rollback/delete on
    partial failure; inode/ACL checks are snapshots, not mount confinement.
    """
    if any(type(x) is not int or x<0 for x in (source_fd,root_fd,work_uid,work_gid)):
        raise SkeletonError('invalid descriptors or identity')
    owner=os.geteuid(); group=os.getegid(); opened={}
    try:
        flags=os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC
        _dir(root_fd,owner,group,0o700)
        if os.listdir(root_fd): raise ValueError('root not empty')
        for name in _DIRS:
            os.mkdir(name,0o700,dir_fd=root_fd)
            fd=os.open(name,flags,dir_fd=root_fd); opened[name]=fd
            # Do not trust umask/default ACL or inherited setgid bits.
            os.fchmod(fd,0o700)
            st=_dir(fd,owner,group,0o700)
            linked=os.stat(name,dir_fd=root_fd,follow_symlinks=False)
            if _identity(st)!=_identity(linked) or os.listdir(fd): raise ValueError('created directory changed')
        # Fixed merged-/usr loader path only. Target remains empty until the
        # separately reviewed runtime builder installs usr/lib64.
        for name,target in _LINKS.items(): os.symlink(target,name,dir_fd=root_fd)
        _check_root_entries(root_fd)
        stage_into_empty_private_directory(source_fd,opened['app'])
        _handoff(opened['app'],owner)
        # Work can be writable only by its service UID. Do this last, before
        # exposing traversal, while no workload has yet been started.
        os.fchown(opened['work'],work_uid,work_gid)
        os.fchmod(opened['work'],0o700)
        for name in _DIRS:
            if name not in ('app','work'): os.fchmod(opened[name],0o555)
        for name,fd in opened.items():
            uid,gid,mode=(work_uid,work_gid,0o700) if name=='work' else (owner,group,0o555)
            s=_dir(fd,uid,gid,mode)
            linked=os.stat(name,dir_fd=root_fd,follow_symlinks=False)
            if _identity(s)!=_identity(linked): raise ValueError('replaced directory')
            if name!='app' and os.listdir(fd): raise ValueError('placeholder not empty')
        _check_root_entries(root_fd)
        os.fchmod(root_fd,0o555)
        _dir(root_fd,owner,group,0o555)
        _check_root_entries(root_fd)
        return {'app':'staged_local_manifest_and_mode_checked',
                'work':'empty_service_owned_0700','placeholders':'empty','loader_link':'fixed_dangling_until_runtime',
                'interpreter_stdlib_libraries':'not_staged',
                'engine':'not_staged','mounts':'not_created','executed':False,
                'isolation':'not_verified','cleanup':'caller_required',
                'engine_launch_authorized':False}
    except Exception:
        raise SkeletonError('skeleton failed; stop and dispose full tree, do not reuse') from None
    finally:
        for fd in opened.values(): os.close(fd)

def create_root_owned_skeleton(source_fd,root_fd):
    """No paths/commands: create fixed root skeleton, public root-only entry.

    Target work UID/GID are fixed 65534. Exclusively use in a fresh synthetic
    disposable VM. Does not verify parent paths, mounts, LSM or root provenance.
    Root caller must ensure root's effective group owns its empty destination.
    """
    if os.geteuid()!=0: raise SkeletonError('disposable VM root required')
    return _assemble(source_fd,root_fd,65534,65534)
