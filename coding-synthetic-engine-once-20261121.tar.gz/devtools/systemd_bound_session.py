"""Private no-release single-connection transient candidate; public blocked.

No end-to-end runner. Caller must provide a protected synthetic VM, exclusive
unit lifecycle and independent stop/watchdog. All results are observations and
ambiguous effects require outer recovery; never retry an uncertain start.
"""
import ctypes as c
import os
import time
import re
import stat
from . import systemd_direct_start as direct
from . import systemd_job_tracker as jobs
from . import systemd_manager_identity as manager
from . import systemd_pidfd_lookup as look
from . import systemd_pipe_transport as pipe
from . import synthetic_root_verify as roots
from . import synthetic_control_root as profile_root
from . import systemd_manager_environment as env
from . import systemd_exact_stop as stop
from . import systemd_no_engine_release as release
from . import systemd_slice_anchor as anchor_mod
from . import outer_stream_pair as streams

_BLOCKED=True
class SessionError(RuntimeError):pass

def _valid_timing(value):
    if value=='not_observed' and type(value) is str:return True
    if type(value) is not str or re.fullmatch(r't[0-9]{3}(?:_[0-9]{3}){5}',value) is None:return False
    values=[int(x) for x in value[1:].split('_')]
    if values[-1]==999:return False
    real=[x for x in values if x!=999]
    return all(a<=b for a,b in zip(real,real[1:]))

_JOB_ERRORS=('job_canceled','job_timeout','job_failed','job_dependency','job_skipped','job_invalid','job_assert','job_unsupported','job_collected','job_once','job_other')


# Only coarse, fixed categories escape the worker. Values are observations,
# never binding, ownership, isolation or release evidence.
_SERVICE_DIAG=('not_observed','sampled','not_found','unavailable','identity_unavailable','changed')
_SERVICE_RESULTS=('not_observed','unknown','success','resources','protocol','timeout','exit_code','signal','core_dump','watchdog','start_limit_hit','oom_kill','exec_condition')
_EXEC_STATUS=('not_observed','unknown','no_exit','exited_other','signaled','dumped')+tuple('exit_'+str(x) for x in range(200,245))

# Fixed positional categories, never path names, IDs or exception messages.
_ROOT_BITS=('invalid','fd_unavailable','root_type','root_owner','root_group','root_mode','root_acl','root_list_unavailable','missing_expected','extra_var','extra_tmp','extra_home','extra_root','extra_opt','extra_boot','extra_srv','extra_media','extra_mnt','extra_other','link_metadata','link_target','path_unavailable','path_type','path_identity','engine_unavailable','engine_type','engine_owner','engine_group','engine_mode','engine_acl','engine_nonempty','engine_list_unavailable','sample_exception')
_ROOT_PREFIX='root_inventory_'
def _valid_root_inventory(value):
    return (type(value) is str and re.fullmatch(_ROOT_PREFIX+r'[0-9a-f]{9}',value) is not None
            and int(value[len(_ROOT_PREFIX):],16)<(1<<len(_ROOT_BITS)))

def _diagnose_no_engine_root(root_fd,root_path,root_profile=None):
    """Independent bounded post-failure samples, not the original failure.

    Bit categories are cumulative and non-atomic. Zero means no sampled
    anomaly, not admission approval. No tree repair, execution or raw values.
    """
    bits=set(); mark=bits.add; held=None; engine=None
    try:
        if type(root_fd) is not int or root_fd<0 or not pipe._valid_root(root_path):
            mark('invalid')
        else:
            try:
                held=os.fstat(root_fd)
                if not stat.S_ISDIR(held.st_mode):mark('root_type')
                if held.st_uid!=os.geteuid():mark('root_owner')
                if held.st_gid!=os.getegid():mark('root_group')
                if stat.S_IMODE(held.st_mode)!=0o555:mark('root_mode')
            except Exception:mark('fd_unavailable')
            try:
                if not roots.sk._no_acl(root_fd):mark('root_acl')
            except Exception:mark('root_acl')
            try:
                names=set(os.listdir(root_fd));expected=(set(profile_root.NAMES) if type(root_profile) is profile_root._SystemdNoEngineProfile else set(roots.sk._NAMES))
                if expected-names:mark('missing_expected')
                known=('var','tmp','home','root','opt','boot','srv','media','mnt')
                for name in known:
                    if name in names-expected:mark('extra_'+name)
                if names-expected-set(known):mark('extra_other')
            except Exception:mark('root_list_unavailable')
            try:
                links=(profile_root.LINKS if type(root_profile) is profile_root._SystemdNoEngineProfile else {'lib64':'usr/lib64'})
                for name,target in links.items():
                    try:
                        link=os.stat(name,dir_fd=root_fd,follow_symlinks=False)
                        if not stat.S_ISLNK(link.st_mode) or link.st_uid!=os.geteuid() or (root_profile is not None and link.st_gid!=os.getegid()):mark('link_metadata')
                        try:
                            if os.readlink(name,dir_fd=root_fd)!=target:mark('link_target')
                        except Exception:mark('link_target')
                    except Exception:mark('link_metadata');mark('link_target')
            except Exception:mark('link_metadata');mark('link_target')
            try:
                named=os.stat(root_path,follow_symlinks=False)
                if not stat.S_ISDIR(named.st_mode):mark('path_type')
                if held is None or pipe._identity(named)!=pipe._identity(held):mark('path_identity')
            except Exception:mark('path_unavailable')
            try:
                engine=os.open('engine',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=root_fd)
            except Exception:mark('engine_unavailable')
            if engine is not None:
                try:
                    es=os.fstat(engine)
                    if not stat.S_ISDIR(es.st_mode):mark('engine_type')
                    if es.st_uid!=os.geteuid():mark('engine_owner')
                    if es.st_gid!=os.getegid():mark('engine_group')
                    if stat.S_IMODE(es.st_mode)!=0o555:mark('engine_mode')
                except Exception:mark('engine_unavailable')
                try:
                    if not roots.sk._no_acl(engine):mark('engine_acl')
                except Exception:mark('engine_acl')
                try:
                    if os.listdir(engine):mark('engine_nonempty')
                except Exception:mark('engine_list_unavailable')
    except BaseException:mark('sample_exception')
    finally:
        if engine is not None:
            try:os.close(engine)
            except OSError:mark('sample_exception')
    return _ROOT_PREFIX+format(sum(1<<_ROOT_BITS.index(bit) for bit in bits),'09x')


def _failed_service_snapshot(lib,bus,owner,unit):
    """Read twice after JobRemoved=failed. Non-atomic, diagnostic only.

    The manager address is the already captured unique owner; a unit name and
    matching nonzero invocation cannot prove job-to-invocation causality.
    Caller must use private no-engine worker and independent outer deadline.
    No string property or exception value is forwarded; no control operation.
    """
    result=('unavailable','unknown','unknown')
    try:
        if pipe._UNIT.fullmatch(unit) is None:raise ValueError('unit')
        path=look._expected_path(unit).encode('ascii');dest=owner.encode('ascii')
        U=b'org.freedesktop.systemd1.Unit';S=b'org.freedesktop.systemd1.Service'
        def sample():
            if look._owner(lib,bus)!=owner:raise ValueError('owner')
            ident=look._property_string(lib,bus,dest,path,U,b'Id')
            load=look._property_string(lib,bus,dest,path,U,b'LoadState')
            transient=look._property_number(lib,bus,dest,path,U,b'Transient','b')
            inv=look._property_invocation(lib,bus,dest,path,U)
            if (ident!=unit or load!='loaded' or transient!=1 or type(inv) is not str or
                len(inv)!=32 or any(ch not in '0123456789abcdef' for ch in inv) or inv=='0'*32):
                raise LookupError('identity')
            state=look._property_string(lib,bus,dest,path,U,b'ActiveState')
            service=look._property_string(lib,bus,dest,path,S,b'Result')
            code=look._property_number(lib,bus,dest,path,S,b'ExecMainCode','i')
            status=look._property_number(lib,bus,dest,path,S,b'ExecMainStatus','i')
            if look._owner(lib,bus)!=owner:raise ValueError('owner')
            return (ident,load,transient,inv,state,service,code,status)
        a=sample();b=sample()
        if a!=b:return ('changed','unknown','unknown')
        if a[4]!='failed':return ('identity_unavailable','unknown','unknown')
        service=a[5].replace('-','_') if type(a[5]) is str else ''
        if service not in _SERVICE_RESULTS or service in ('not_observed','unknown'):service='unknown'
        code,status=a[6:]
        if type(code) is not int or type(status) is not int or not 0<=status<=255:category='unknown'
        elif code==0 and status==0:category='no_exit'
        elif code==1:category='exit_'+str(status) if 200<=status<=244 else 'exited_other'
        elif code==2:category='signaled'
        elif code==3:category='dumped'
        else:category='unknown'
        return ('sampled',service,category)
    except look._NativeError as exc:
        return ('not_found' if exc.category=='not_found' else 'unavailable','unknown','unknown')
    except LookupError:
        return ('identity_unavailable','unknown','unknown')
    except BaseException:
        return result


class _Session:
    """Single-owner, single-threaded state; a close does NOT stop the unit."""
    def __init__(self,lib,bus,owner,unit,kind,root,root_fd,in_write,out_read,err_read,*,slice_name=None,anchor=None,root_profile=None):
        if (type(unit) is not str or pipe._UNIT.fullmatch(unit) is None or
            type(kind) is not str or kind not in ('baseline','integration','probe','probe_nobind') or
            not pipe._valid_root(root)):
            raise SessionError('invalid session')
        if slice_name is not None and slice_name!=direct._slice_for(unit):raise SessionError('invalid fixed slice')
        if anchor is not None and (type(anchor) is not anchor_mod._Anchor or slice_name is None or
                anchor.name!=slice_name or anchor.lib is not lib or anchor.bus is not bus or anchor.owner!=owner or
                anchor.state!='anchored'):
            raise SessionError('anchor not bound to this session')
        if root_profile is not None and type(root_profile) is not profile_root._SystemdNoEngineProfile:raise SessionError('invalid no-engine root profile')
        self.root_profile=root_profile
        self.slice_name=slice_name;self.anchor=anchor
        # Most recently entered fixed start phase; observation only. Never
        # infer a manager side effect merely from this diagnostic.
        self.service_diag='not_observed';self.service_result='not_observed';self.exec_status='not_observed'
        self.start_phase='not_started';self.start_error='not_observed';self.observe_phase='not_observed';self.observe_error='not_observed';self._unset_names=None
        self._diag_start=None;self._diag_times=[None]*5
        self.lib=lib;self.bus=bus;self.owner=owner;self.unit=unit;self.kind=kind
        self.root=root;self.root_fd=root_fd;self.in_write=in_write;self.out_read=out_read;self.err_read=err_read
        # This session is intentionally limited to the empty-engine control.
        # Never silently repurpose it to admit the genuine binary.
        self.engine_contract='target_probe_control' if kind in ('probe','probe_nobind') else 'no_engine_control'
        self._nobind_identity=None
        self.tracker=jobs._Tracker(lib,bus,owner,unit);self.state='fresh';self._job=None;self._bound=None;self._stop_attempted=False;self._input_consumed=False;self._streams=None
    def _diag_mark(self,index):
        if self._diag_start is not None and self._diag_times[index] is None:
            self._diag_times[index]=min(998,max(0,int(time.monotonic()-self._diag_start)))
    def diagnostic_timing(self):
        # Seconds since immediately before the start send; 999 = not observed.
        # send precedes exec/barrier: these are upper bounds, not service age.
        if self._diag_start is None:return 'not_observed'
        end=min(998,max(0,int(time.monotonic()-self._diag_start)))
        return 't'+'_'.join('%03d'% (999 if x is None else x) for x in self._diag_times+[end])
    def _verify_root(self):
        if self.root_profile is None:return pipe._verify_root(self.root_fd,self.root)
        return self.root_profile.verify(self.root_fd,self.root)
    def _inspect_root(self):
        if self.root_profile is None:return roots.inspect_fixed(self.root_fd)
        return self.root_profile.verify(self.root_fd,self.root)
    def start_once(self,inf,outf,errf):
        """Observe manager, subscribe, send one job and await result.

        Internal marker becomes uncertain immediately before native send. Even
        an exception or negative reply may have side effects. There is no stop
        here: external independently watched owner is mandatory. Never retry.
        """
        if self.state!='fresh':raise SessionError('attempt consumed')
        self.state='preparing';msg=None
        try:
            # Caller-supplied lib must have every native signature configured
            # before using pointer-valued APIs (default ctypes int truncates).
            self.start_phase='proto'
            direct._proto(self.lib);jobs._proto(self.lib);manager._proto(self.lib)
            self.start_phase='manager_before';manager.inspect(self.lib,self.bus,self.owner)
            self.start_phase='subscribe'
            # The anchor's tracker already subscribed on this exact private
            # bus; subscribe() again can return AlreadySubscribed on systemd.
            if self.anchor is None:self.tracker.subscribe()
            else:self.tracker.subscribe(existing=self.anchor.tracker)
            # Revalidate path and no-engine directory immediately before start.
            self.start_phase='root_first';self._verify_root()
            self.start_phase='root_inspect';self._inspect_root()
            self.start_phase='environment'
            try:self._unset_names=env.removal_names_for_no_engine(self.lib,self.bus,self.owner)
            except env.EnvironmentError as exc:
                self.start_error=exc.category if exc.category in env._CATEGORIES else 'env_internal'
                raise
            # Hashing/environment queries may take time; recheck root pathname
            # and empty engine at the latest possible point before message build.
            self.start_phase='root_recheck';self._verify_root()
            self.start_phase='anchor_recheck'
            if self.anchor is not None:self.anchor.observe_anchor()
            self.start_phase='message_build';msg=direct._build(self.lib,self.bus,self.owner,self.unit,self.kind,self.root,inf,outf,errf,**({'slice_name':self.slice_name} if self.slice_name else {}),**({'profile':'target_probe'} if self.kind=='probe' else {'profile':'target_probe_nobind'} if self.kind=='probe_nobind' else {}),unset_names=self._unset_names)
            self.state='start_uncertain'
            self.start_phase='send_uncertain';self._diag_start=time.monotonic()
            try:sent=direct._send(self.lib,self.bus,msg)
            except direct.StartCallError as exc:
                self.start_error=exc.category;raise
            self._job=sent['job_path']
            self.start_phase='await_job';result=self.tracker.await_job(self._job,10)
            if result['job_result']!='done':
                # Only fixed values; never forward arbitrary bus data. The job
                # result is not a root cause or proof that no side effect occurred.
                value=result['job_result']
                allowed=('canceled','timeout','failed','dependency','skipped','invalid','assert','unsupported','collected','once')
                self.start_error='job_'+value if type(value) is str and value in allowed else 'job_other'
                self.start_phase='job_not_done'
                if self.start_error=='job_failed':
                    self.service_diag,self.service_result,self.exec_status=_failed_service_snapshot(self.lib,self.bus,self.owner,self.unit)
                raise ValueError('start failed')
            self.start_phase='manager_after';manager.inspect(self.lib,self.bus,self.owner)
            self.state='job_done';self.start_phase='complete';self._diag_mark(0)
            return {'start':'job_done_on_same_bus','engine_contract':self.engine_contract,'unit_ownership':'not_proven',
                    'isolation':'not_verified','admission':'not_authorized','cleanup':'not_observed',
                    'engine_launch_authorized':False}
        except BaseException:
            if self.state!='start_uncertain':self.state='failed_no_retry'
            raise SessionError('session start failed or uncertain; external recovery required') from None
        finally:
            if msg is not None and msg.value:self.lib.sd_bus_message_unref(msg)
    def observe(self):
        if self.state!='job_done':raise SessionError('job not complete')
        try:
            # Recheck captured root identity immediately before the exact proc root observer.
            if self.root_profile is not None:
                try:self._verify_root()
                except Exception:
                    # Independent later bitmap, not the original exception or a gate.
                    self.observe_phase=_diagnose_no_engine_root(self.root_fd,self.root,self.root_profile)
                    raise
            result=look._compare_on_bus(self.lib,self.bus,self.owner,self.unit,self.root_fd,
                                         self.in_write,self.out_read,self.err_read,self.root,self.kind,
                                         **({'expected_slice':self.slice_name} if self.slice_name else {}),**({'profile':'target_probe'} if self.kind=='probe' else {'profile':'target_probe_nobind'} if self.kind=='probe_nobind' else {}),unset_names=self._unset_names)
            self.observe_phase='bound_identity'
            inv=result.get('invocation');cg=result.get('cgroup');pid=result.get('main_pid')
            stop._valid(self.unit,inv)
            if type(cg) is not str or not cg.startswith('/') or type(pid) is not int or pid<=0:
                raise ValueError('sampled identity missing')
            self._bound=(inv,cg,pid)
            if self.kind=='probe_nobind':
                ident=result.get('nobind_host_identity')
                if type(ident) is not tuple or len(ident)!=2 or any(type(x) is not int or not 0<=x<2**64 for x in ident) or ident[1]==0:raise ValueError('missing inode')
                self._nobind_identity=ident
            # Preserve bound invocation before placement observation: if the
            # latter fails, the outer owner may attempt exact-invocation stop.
            self.observe_phase='anchor_membership'
            if self.anchor is not None:self.anchor.observe_service_membership(cg)
            self.observe_phase='complete';self.state='observed';self._diag_mark(1)
            return result
        except Exception as exc:
            if isinstance(exc,look.LookupError):self.observe_phase=exc.phase;self.observe_error=exc.category
            else:self.observe_error='other'
            self.state='observation_failed';raise SessionError('process observation unavailable; recovery required') from None
    def admit_no_engine_once(self,*,nobind_attempt=None):
        """Recheck the bound process then write/close the fixed admission frame.

        Private no-engine candidate only; caller owns the exclusive pipe ends,
        a protected root and an independent manager watchdog. Process/root
        snapshots do not establish ownership, admission integrity or isolation.
        This object consumes the writer on both success and recheck failure.
        Neither this action nor a test unblocks the real engine or production.
        """
        if self.state!='observed' or self._bound is None or self._input_consumed:
            raise SessionError('admission unavailable or consumed')
        self._input_consumed=True
        self._diag_mark(2)
        sender=None
        try:
            # Diagnostic markers are not proof that operations succeeded or
            # that a manager side effect/frame did or did not occur.
            self.observe_phase='admission_writer';sender=release._Release(self.in_write)
            self.observe_phase='admission_streams'
            # Probe has a different bounded JSON schema. It is consumed only
            # by its dedicated owner; never pass it to the old driver parser.
            if self.kind not in ('probe','probe_nobind'):self._streams=streams.StreamPair(self.out_read,self.err_read,self.kind)
            self.observe_phase='admission_root_path'
            try:self._verify_root()
            except Exception:
                self.observe_phase=_diagnose_no_engine_root(self.root_fd,self.root,self.root_profile)
                raise
            self.observe_phase='admission_root_contents';self._inspect_root()
            self.observe_phase='admission_recheck'
            result=look._compare_on_bus(self.lib,self.bus,self.owner,self.unit,self.root_fd,
                                         self.in_write,self.out_read,self.err_read,self.root,self.kind,
                                         **({'expected_slice':self.slice_name} if self.slice_name else {}),**({'profile':'target_probe'} if self.kind=='probe' else {'profile':'target_probe_nobind'} if self.kind=='probe_nobind' else {}),unset_names=self._unset_names)
            self.observe_phase='admission_identity'
            if (result.get('invocation'),result.get('cgroup'),result.get('main_pid'))!=self._bound:
                raise ValueError('process identity changed')
            if self.kind=='probe_nobind' and result.get('nobind_host_identity')!=self._nobind_identity:raise ValueError('nobind host changed')
            if self.kind!='probe_nobind' and nobind_attempt is not None:raise ValueError('cross-case attempt')
            self.observe_phase='admission_anchor'
            if self.anchor is not None:self.anchor.observe_service_membership(result['cgroup'])
            self.state='admission_uncertain';self.observe_phase='admission_frame';self._diag_mark(3)
            if self.kind=='probe_nobind':sender.send_nobind_once(nobind_attempt)
            else:sender.send_once()
            self.observe_phase='admission_complete';self.state='released';self._diag_mark(4)
            return {'release':'frame_write_and_close_returned','unit':self.unit,
                    'admission':'not_attested','isolation':'not_verified',
                    'cleanup':'not_observed','engine_launch_authorized':False}
        except BaseException as exc:
            if isinstance(exc,look.LookupError):self.observe_phase=exc.phase;self.observe_error=exc.category
            else:self.observe_error='other'
            self.state='admission_uncertain'
            if sender is not None and sender.state=='ready':
                try:sender.abort()
                except Exception:pass
            elif sender is None:
                # Exclusively owned writer: closing it prevents an accidental
                # later frame; the outer owner handles any unknown close.
                try:os.close(self.in_write)
                except OSError:pass
            raise SessionError('admission unavailable or uncertain; external recovery required') from None
    def read_provisional(self,timeout):
        """Read one candidate line before stop; no EOF/exit/cleanup claim."""
        if self.state!='released' or self._streams is None:
            raise SessionError('stream not available')
        self.state='stream_uncertain'
        result=self._streams.before_stop(timeout)
        if result.get('record')!='provisional':
            raise SessionError('provisional record unavailable; external recovery required')
        self.state='provisional'
        return result
    def read_final(self,timeout):
        """Drain both EOFs after a stop attempt, never attest cleanup."""
        if self.state not in ('stop_observed','stop_uncertain') or self._streams is None or not self._stop_attempted:
            raise SessionError('final drain unavailable')
        result=self._streams.after_stop(timeout)
        if result.get('record')!='received':raise SessionError('final record unavailable; external recovery required')
        return result
    def observe_exit(self):
        """Read sampled manager main-exit only; can never prove cleanup."""
        if self.state not in ('released','provisional','exit_observed') or self._bound is None:
            raise SessionError('binding unavailable; external recovery required')
        inv,cgroup,pid=self._bound
        try:
            result=stop._exit_observation(self.lib,self.bus,self.owner,self.unit,inv,pid,cgroup)
            self.state='exit_observed';return result
        except Exception:
            # No retry of the workload; caller may observe while still under
            # its independent deadline, or trigger outside recovery.
            raise SessionError('exit not yet observed or unavailable') from None
    def stop_once(self):
        """One invocation-addressed stop; only if pre-release bound.

        Independent exclusive owner and watchdog remain prerequisites. A start
        or identity uncertainty cannot justify name-based or guessed cleanup.
        This method cannot independently bound native calls or verify cgroup.
        """
        if self.state not in ('observed','observation_failed','released','provisional','stream_uncertain','admission_uncertain','exit_observed') or self._bound is None or self._stop_attempted:
            raise SessionError('stop not bound or already consumed; external recovery required')
        self._stop_attempted=True
        inv,cgroup,pid=self._bound
        try:
            identity=stop._observation(self.lib,self.bus,self.owner,self.unit,inv)
            if identity.get('cgroup') not in ('',cgroup):raise ValueError('cgroup changed')
            # The call can take effect even if its reply or job event is lost.
            self.state='stop_uncertain'
            result=stop._send_invocation_once(self.lib,self.bus,self.owner,self.unit,inv)
            job=self.tracker.await_job(result['job_path'],5)
            if job.get('job_result')!='done':raise ValueError('stop job not done')
            identity=stop._observation(self.lib,self.bus,self.owner,self.unit,inv)
            if identity.get('state') not in ('inactive','failed') or identity.get('cgroup') not in ('',cgroup):
                raise ValueError('stop not observed')
            self.state='stop_observed'
            return {'stop':'job_done_inactive_snapshot','unit':self.unit,'invocation':inv,
                    'cgroup_cleanup':'not_observed','ownership':'not_proven',
                    'vm_decommission':'not_observed','engine_launch_authorized':False}
        except BaseException:
            self.state='stop_uncertain'
            raise SessionError('stop unavailable or uncertain; no retry, external recovery required') from None
    def close(self):
        self.tracker.close();self.state='closed'
        # Bus, root and stream FDs remain caller-owned; no stop/cleanup implied.


def run():
    if _BLOCKED:raise SessionError('same-bus session blocked; stop and independent watchdog missing')
    raise SessionError('no approved orchestration')
