"""Fixed engine-free post-barrier target probe; cannot admit a real engine.

Caller must have a dedicated monitored, credential-free disposable VM. No
server setup or cleanup is provided. Known-live canaries and an outer watchdog
are mandatory. Protected read-only mount and external writer exclusion are not
proved by the results. No arbitrary paths, network hosts or command inputs.
"""
import json,os
from . import target_boundary_probe as p

# Diagnostic-only fixed addresses: the host VM must create these exact synthetic
# listeners; failing to do so is an invalid experiment, never a pass. The IPv4
# listener is on host loopback: host->child isolation is sampled, not general
# external egress. See the outer canary/route-control plan.
_PATH='/run/astra-target-probe-canary.sock'
_ABSTRACT='\0astra-target-probe-canary-v1'
_IP='127.0.0.1'
_PORT=39081
_PROTECTED='/app/devtools/target_probe_entry.py'
_WORK='/work'
_MAX=2048
class ProbeEntryError(RuntimeError):pass


def _validate(result):
    """Validate fixed-value diagnostic categories; never infer safety."""
    expected={'fd_snapshot':{'null_input_two_pipes_sampled','unexpected_or_nonpipe_fd','unknown'},
      'protected_write_open':{'write_open_denied','write_open_succeeded','unknown'},
      'work_probe':{'created_removed_sampled','unknown','cleanup_unknown'},
      'pathname_socket':{'connected','not_connected','path_missing','path_access_denied','path_operation_denied','path_connection_refused','timeout_unknown','unknown'},
      'abstract_socket':{'connected','not_connected','timeout_unknown','unknown'},
      'network_canary':{'connected','not_connected','timeout_unknown','unknown'},
      'external_canary_liveness':{'not_verified'},'mount_backing':{'not_verified'},
      'egress':{'not_verified'},'isolation':{'not_verified'}}
    if type(result) is not dict or set(result)!=set(expected)|{'engine_launch_authorized','production_approved'}:
        raise ProbeEntryError('record schema')
    if result['engine_launch_authorized'] is not False or result['production_approved'] is not False:
        raise ProbeEntryError('authorization')
    if any(type(result[k]) is not str or result[k] not in values for k,values in expected.items()):
        raise ProbeEntryError('record category')
    return None

def _record(result):
    _validate(result)
    out=json.dumps(result,sort_keys=True,separators=(',',':')).encode('ascii')+b'\n'
    if len(out)>_MAX:raise ProbeEntryError('record bound')
    if os.write(1,out)!=len(out):raise ProbeEntryError('write')


_NOBIND_CASE='no-bind-path-v1'

def _validate_nobind(result, attempt):
    """Exact diagnostic record. Correlation is neither identity nor isolation."""
    from .synthetic_service_barrier import _nobind_attempt
    try:
        token=_nobind_attempt(attempt).hex()
        if type(result) is not dict or set(result)!={'case','attempt','sample'}:raise ValueError('schema')
        if result['case']!=_NOBIND_CASE or result['attempt']!=token:raise ValueError('binding')
        _validate(result['sample'])
        if result['sample']['pathname_socket']!='path_missing':raise ValueError('unsupported sample')
    except (ValueError,TypeError,ProbeEntryError):raise ProbeEntryError('no-bind record invalid') from None

def _record_nobind(sample, attempt):
    from .synthetic_service_barrier import _nobind_attempt
    result={'case':_NOBIND_CASE,'attempt':_nobind_attempt(attempt).hex(),'sample':sample}
    _validate_nobind(result,attempt)
    out=json.dumps(result,sort_keys=True,separators=(',',':')).encode('ascii')+b'\n'
    if len(out)>_MAX or os.write(1,out)!=len(out):raise ProbeEntryError('record write')

def main(*, nobind_attempt=None):
    result=p._sample(_PROTECTED,_WORK,_PATH,_ABSTRACT,_IP,_PORT,after_barrier=True)
    if nobind_attempt is None:_record(result)
    else:_record_nobind(result,nobind_attempt)
    return 0
