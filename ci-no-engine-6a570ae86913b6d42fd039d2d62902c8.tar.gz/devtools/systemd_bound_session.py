"""Private no-release single-connection transient candidate; public blocked.

No end-to-end runner. Caller must provide a protected synthetic VM, exclusive
unit lifecycle and independent stop/watchdog. All results are observations and
ambiguous effects require outer recovery; never retry an uncertain start.
"""
import ctypes as c
import os
from . import systemd_direct_start as direct
from . import systemd_job_tracker as jobs
from . import systemd_manager_identity as manager
from . import systemd_pidfd_lookup as look
from . import systemd_pipe_transport as pipe
from . import synthetic_root_verify as roots
from . import systemd_manager_environment as env
from . import systemd_exact_stop as stop
from . import systemd_no_engine_release as release
from . import systemd_slice_anchor as anchor_mod
from . import outer_stream_pair as streams

_BLOCKED=True
class SessionError(RuntimeError):pass


class _Session:
    """Single-owner, single-threaded state; a close does NOT stop the unit."""
    def __init__(self,lib,bus,owner,unit,kind,root,root_fd,in_write,out_read,err_read,*,slice_name=None,anchor=None):
        if (type(unit) is not str or pipe._UNIT.fullmatch(unit) is None or
            type(kind) is not str or kind not in ('baseline','integration') or
            not pipe._valid_root(root)):
            raise SessionError('invalid session')
        if slice_name is not None and slice_name!=direct._slice_for(unit):raise SessionError('invalid fixed slice')
        if anchor is not None and (type(anchor) is not anchor_mod._Anchor or slice_name is None or
                anchor.name!=slice_name or anchor.lib is not lib or anchor.bus is not bus or anchor.owner!=owner or
                anchor.state!='anchored'):
            raise SessionError('anchor not bound to this session')
        self.slice_name=slice_name;self.anchor=anchor
        # Most recently entered fixed start phase; observation only. Never
        # infer a manager side effect merely from this diagnostic.
        self.start_phase='not_started';self.start_error='not_observed'
        self.lib=lib;self.bus=bus;self.owner=owner;self.unit=unit;self.kind=kind
        self.root=root;self.root_fd=root_fd;self.in_write=in_write;self.out_read=out_read;self.err_read=err_read
        # This session is intentionally limited to the empty-engine control.
        # Never silently repurpose it to admit the genuine binary.
        self.engine_contract='no_engine_control'
        self.tracker=jobs._Tracker(lib,bus,owner,unit);self.state='fresh';self._job=None;self._bound=None;self._stop_attempted=False;self._input_consumed=False;self._streams=None
    def start_once(self,inf,outf,errf):
        """Observe manager, subscribe, send one job and await result.

        Internal marker becomes uncertain immediately before native send. Even
        an exception or negative reply may have side effects. There is no stop
        here: external independently watched owner is mandatory. Never retry.
        """
        if self.state!='fresh':raise SessionError('attempt consumed')
        self.state='preparing';msg=None
        try:
            # Caller-supplied lib must have every native signature configured
            # before using pointer-valued APIs (default ctypes int truncates).
            self.start_phase='proto'
            direct._proto(self.lib);jobs._proto(self.lib);manager._proto(self.lib)
            self.start_phase='manager_before';manager.inspect(self.lib,self.bus,self.owner)
            self.start_phase='subscribe'
            # The anchor's tracker already subscribed on this exact private
            # bus; subscribe() again can return AlreadySubscribed on systemd.
            if self.anchor is None:self.tracker.subscribe()
            else:self.tracker.subscribe(existing=self.anchor.tracker)
            # Revalidate path and no-engine directory immediately before start.
            self.start_phase='root_first';pipe._verify_root(self.root_fd,self.root)
            self.start_phase='root_inspect';roots.inspect_fixed(self.root_fd)
            self.start_phase='environment'
            try:env.inspect(self.lib,self.bus,self.owner,fixed_path_override=True)
            except env.EnvironmentError as exc:
                self.start_error=exc.category if exc.category in env._CATEGORIES else 'env_internal'
                raise
            # Hashing/environment queries may take time; recheck root pathname
            # and empty engine at the latest possible point before message build.
            self.start_phase='root_recheck';pipe._verify_root(self.root_fd,self.root)
            self.start_phase='anchor_recheck'
            if self.anchor is not None:self.anchor.observe_anchor()
            self.start_phase='message_build';msg=direct._build(self.lib,self.bus,self.owner,self.unit,self.kind,self.root,inf,outf,errf,**({'slice_name':self.slice_name} if self.slice_name else {}))
            self.state='start_uncertain'
            self.start_phase='send_uncertain'
            try:sent=direct._send(self.lib,self.bus,msg)
            except direct.StartCallError as exc:
                self.start_error=exc.category;raise
            self._job=sent['job_path']
            self.start_phase='await_job';result=self.tracker.await_job(self._job,10)
            if result['job_result']!='done':
                self.start_phase='job_not_done';raise ValueError('start failed')
            self.start_phase='manager_after';manager.inspect(self.lib,self.bus,self.owner)
            self.state='job_done';self.start_phase='complete'
            return {'start':'job_done_on_same_bus','engine_contract':self.engine_contract,'unit_ownership':'not_proven',
                    'isolation':'not_verified','admission':'not_authorized','cleanup':'not_observed',
                    'engine_launch_authorized':False}
        except BaseException:
            if self.state!='start_uncertain':self.state='failed_no_retry'
            raise SessionError('session start failed or uncertain; external recovery required') from None
        finally:
            if msg is not None and msg.value:self.lib.sd_bus_message_unref(msg)
    def observe(self):
        if self.state!='job_done':raise SessionError('job not complete')
        try:
            result=look._compare_on_bus(self.lib,self.bus,self.owner,self.unit,self.root_fd,
                                         self.in_write,self.out_read,self.err_read,self.root,self.kind,
                                         **({'expected_slice':self.slice_name} if self.slice_name else {}))
            inv=result.get('invocation');cg=result.get('cgroup');pid=result.get('main_pid')
            stop._valid(self.unit,inv)
            if type(cg) is not str or not cg.startswith('/') or type(pid) is not int or pid<=0:
                raise ValueError('sampled identity missing')
            self._bound=(inv,cg,pid)
            # Preserve bound invocation before placement observation: if the
            # latter fails, the outer owner may attempt exact-invocation stop.
            if self.anchor is not None:self.anchor.observe_service_membership(cg)
            self.state='observed'
            return result
        except Exception:
            self.state='observation_failed';raise SessionError('process observation unavailable; recovery required') from None
    def admit_no_engine_once(self):
        """Recheck the bound process then write/close the fixed admission frame.

        Private no-engine candidate only; caller owns the exclusive pipe ends,
        a protected root and an independent manager watchdog. Process/root
        snapshots do not establish ownership, admission integrity or isolation.
        This object consumes the writer on both success and recheck failure.
        Neither this action nor a test unblocks the real engine or production.
        """
        if self.state!='observed' or self._bound is None or self._input_consumed:
            raise SessionError('admission unavailable or consumed')
        self._input_consumed=True
        sender=None
        try:
            sender=release._Release(self.in_write)
            self._streams=streams.StreamPair(self.out_read,self.err_read,self.kind)
            pipe._verify_root(self.root_fd,self.root)
            roots.inspect_fixed(self.root_fd)
            result=look._compare_on_bus(self.lib,self.bus,self.owner,self.unit,self.root_fd,
                                         self.in_write,self.out_read,self.err_read,self.root,self.kind,
                                         **({'expected_slice':self.slice_name} if self.slice_name else {}))
            if (result.get('invocation'),result.get('cgroup'),result.get('main_pid'))!=self._bound:
                raise ValueError('process identity changed')
            if self.anchor is not None:self.anchor.observe_service_membership(result['cgroup'])
            self.state='admission_uncertain'
            sender.send_once()
            self.state='released'
            return {'release':'frame_write_and_close_returned','unit':self.unit,
                    'admission':'not_attested','isolation':'not_verified',
                    'cleanup':'not_observed','engine_launch_authorized':False}
        except BaseException:
            self.state='admission_uncertain'
            if sender is not None and sender.state=='ready':
                try:sender.abort()
                except Exception:pass
            elif sender is None:
                # Exclusively owned writer: closing it prevents an accidental
                # later frame; the outer owner handles any unknown close.
                try:os.close(self.in_write)
                except OSError:pass
            raise SessionError('admission unavailable or uncertain; external recovery required') from None
    def read_provisional(self,timeout):
        """Read one candidate line before stop; no EOF/exit/cleanup claim."""
        if self.state!='released' or self._streams is None:
            raise SessionError('stream not available')
        self.state='stream_uncertain'
        result=self._streams.before_stop(timeout)
        if result.get('record')!='provisional':
            raise SessionError('provisional record unavailable; external recovery required')
        self.state='provisional'
        return result
    def read_final(self,timeout):
        """Drain both EOFs after a stop attempt, never attest cleanup."""
        if self.state not in ('stop_observed','stop_uncertain') or self._streams is None or not self._stop_attempted:
            raise SessionError('final drain unavailable')
        result=self._streams.after_stop(timeout)
        if result.get('record')!='received':raise SessionError('final record unavailable; external recovery required')
        return result
    def observe_exit(self):
        """Read sampled manager main-exit only; can never prove cleanup."""
        if self.state not in ('released','provisional','exit_observed') or self._bound is None:
            raise SessionError('binding unavailable; external recovery required')
        inv,cgroup,pid=self._bound
        try:
            result=stop._exit_observation(self.lib,self.bus,self.owner,self.unit,inv,pid,cgroup)
            self.state='exit_observed';return result
        except Exception:
            # No retry of the workload; caller may observe while still under
            # its independent deadline, or trigger outside recovery.
            raise SessionError('exit not yet observed or unavailable') from None
    def stop_once(self):
        """One invocation-addressed stop; only if pre-release bound.

        Independent exclusive owner and watchdog remain prerequisites. A start
        or identity uncertainty cannot justify name-based or guessed cleanup.
        This method cannot independently bound native calls or verify cgroup.
        """
        if self.state not in ('observed','observation_failed','released','provisional','stream_uncertain','admission_uncertain','exit_observed') or self._bound is None or self._stop_attempted:
            raise SessionError('stop not bound or already consumed; external recovery required')
        self._stop_attempted=True
        inv,cgroup,pid=self._bound
        try:
            identity=stop._observation(self.lib,self.bus,self.owner,self.unit,inv)
            if identity.get('cgroup') not in ('',cgroup):raise ValueError('cgroup changed')
            # The call can take effect even if its reply or job event is lost.
            self.state='stop_uncertain'
            result=stop._send_invocation_once(self.lib,self.bus,self.owner,self.unit,inv)
            job=self.tracker.await_job(result['job_path'],5)
            if job.get('job_result')!='done':raise ValueError('stop job not done')
            identity=stop._observation(self.lib,self.bus,self.owner,self.unit,inv)
            if identity.get('state') not in ('inactive','failed') or identity.get('cgroup') not in ('',cgroup):
                raise ValueError('stop not observed')
            self.state='stop_observed'
            return {'stop':'job_done_inactive_snapshot','unit':self.unit,'invocation':inv,
                    'cgroup_cleanup':'not_observed','ownership':'not_proven',
                    'vm_decommission':'not_observed','engine_launch_authorized':False}
        except BaseException:
            self.state='stop_uncertain'
            raise SessionError('stop unavailable or uncertain; no retry, external recovery required') from None
    def close(self):
        self.tracker.close();self.state='closed'
        # Bus, root and stream FDs remain caller-owned; no stop/cleanup implied.


def run():
    if _BLOCKED:raise SessionError('same-bus session blocked; stop and independent watchdog missing')
    raise SessionError('no approved orchestration')
