"""Real bounded sd-bus GetUnitByPIDFD read-only lookup; NOT launch authority.

Only use under an independently supervised synthetic disposable VM. The caller
owns pidfd and must verify procfs, manager continuity, unit reservation, process
and isolation independently. No start/stop or admission operation is present.
"""
import ctypes
import os
import re
import select
from .systemd_pipe_transport import _UNIT,_valid_root
from .service_proc_observer import _pidfd,_fdinfo,_read

_LIB='libsystemd.so.0'
_DEST=b'org.freedesktop.systemd1'
_PATH=b'/org/freedesktop/systemd1'
_INTERFACE=b'org.freedesktop.systemd1.Manager'
_TIMEOUT_US=2_000_000
class LookupError(RuntimeError):pass


def _proto(lib):
    """Explicit signatures also on variadic functions, before extra args."""
    p=ctypes.c_void_p; s=ctypes.c_char_p; i=ctypes.c_int
    specs={
      'sd_bus_open_system':([ctypes.POINTER(p)],i),
      'sd_bus_set_method_call_timeout':([p,ctypes.c_uint64],i),
      'sd_bus_call_method':([p,s,s,s,s,p,ctypes.POINTER(p),s],i),
      'sd_bus_message_read':([p,s],i),
      'sd_bus_message_read_array':([p,ctypes.c_char,ctypes.POINTER(p),ctypes.POINTER(ctypes.c_size_t)],i),
      'sd_bus_get_property_string':([p,s,s,s,s,p,ctypes.POINTER(p)],i),
      'sd_bus_get_property_trivial':([p,s,s,s,s,p,ctypes.c_char,p],i),
      'sd_bus_get_property':([p,s,s,s,s,p,ctypes.POINTER(p),s],i),
      'sd_bus_message_enter_container':([p,ctypes.c_char,s],i),
      'sd_bus_message_exit_container':([p],i),
      'sd_bus_message_at_end':([p,i],i),
      'sd_bus_message_unref':([p],p),
      'sd_bus_flush_close_unref':([p],p),
    }
    for name,(args,restype) in specs.items():
        fn=getattr(lib,name);fn.argtypes=args;fn.restype=restype


def _method(lib,bus,dest,path,interface,member,signature,*args):
    reply=ctypes.c_void_p()
    r=lib.sd_bus_call_method(bus,dest,path,interface,member,None,ctypes.byref(reply),signature,*args)
    if r<0 or not reply.value:raise ValueError('bus call')
    return reply


def _read_string(lib,reply,kind):
    value=ctypes.c_char_p()
    if lib.sd_bus_message_read(reply,kind,ctypes.byref(value))<=0 or value.value is None:raise ValueError('bus string')
    return value.value.decode('ascii')


def _owner(lib,bus):
    """Get unique owner of manager name; snapshot only, not bus authentication."""
    reply=_method(lib,bus,b'org.freedesktop.DBus',b'/org/freedesktop/DBus',
                  b'org.freedesktop.DBus',b'GetNameOwner',b's',_DEST)
    try:
        name=_read_string(lib,reply,b's')
        if re.fullmatch(r':[0-9]+\.[0-9]+',name) is None:raise ValueError('owner')
        return name
    finally:lib.sd_bus_message_unref(reply)


def _expected_path(unit):
    return '/org/freedesktop/systemd1/unit/'+''.join(chr(x) if chr(x).isalnum() and x<128 else '_%02x'%x for x in unit.encode('ascii'))


def _decode_reply(lib,reply):
    path=_read_string(lib,reply,b'o');unit=_read_string(lib,reply,b's')
    ptr=ctypes.c_void_p();length=ctypes.c_size_t()
    if lib.sd_bus_message_read_array(reply,b'y',ctypes.byref(ptr),ctypes.byref(length))<=0 or length.value!=16 or not ptr.value:
        raise ValueError('invocation')
    # Data belongs to message; copy before unref.
    return path,unit,ctypes.string_at(ptr,16).hex()


def _lookup(pid,pidfd,expected_unit,expected_invocation):
    if (type(pid) is not int or pid<=0 or type(pidfd) is not int or pidfd<0 or
        type(expected_unit) is not str or _UNIT.fullmatch(expected_unit) is None or
        type(expected_invocation) is not str or re.fullmatch('[0-9a-f]{32}',expected_invocation) is None or
        expected_invocation=='0'*32):raise LookupError('invalid lookup')
    bus=reply=None
    try:
        _pidfd(pidfd)
        _fdinfo(_read('/proc/self/fdinfo/'+str(pidfd)),pid)
        if select.select([pidfd],[],[],0)[0]:raise ValueError('exited')
        lib=ctypes.CDLL(_LIB,use_errno=True);_proto(lib);bus=ctypes.c_void_p()
        if lib.sd_bus_open_system(ctypes.byref(bus))<0 or not bus.value:raise ValueError('bus open')
        if lib.sd_bus_set_method_call_timeout(bus,_TIMEOUT_US)<0:raise ValueError('timeout')
        owner=_owner(lib,bus)
        # Address the unique owner, not the mutable well-known name.  Signature
        # h passes the actual pidfd via SCM_RIGHTS; D-Bus duplicates it.
        reply=_method(lib,bus,owner.encode(),_PATH,_INTERFACE,b'GetUnitByPIDFD',b'h',ctypes.c_int(pidfd))
        path,unit,invocation=_decode_reply(lib,reply)
        expected_path=_expected_path(expected_unit)
        if (unit!=expected_unit or path!=expected_path or invocation!=expected_invocation or
            _owner(lib,bus)!=owner or select.select([pidfd],[],[],0)[0]):raise ValueError('identity')
        _fdinfo(_read('/proc/self/fdinfo/'+str(pidfd)),pid)
        return {'manager_pidfd_unit':'matched_snapshot','manager_owner':'stable_on_connection_snapshot',
                'invocation':'matched_snapshot','process_continued':'observed_at_return',
                'other_process_checks':'not_verified','network_mounts':'not_verified',
                'cleanup':'not_observed','admission':'not_authorized','engine_launch_authorized':False}
    except Exception:raise LookupError('manager lookup unavailable') from None
    finally:
        if reply is not None and reply.value:lib.sd_bus_message_unref(reply)
        if bus is not None and bus.value:lib.sd_bus_flush_close_unref(bus)


def lookup(pid,pidfd,unit,invocation):
    """Read-only PIDFD lookup, no PID-number fallback and no admission."""
    return _lookup(pid,pidfd,unit,invocation)


def _property_string(lib,bus,owner,path,interface,member):
    ptr=ctypes.c_void_p()
    ret=lib.sd_bus_get_property_string(bus,owner,path,interface,member,None,ctypes.byref(ptr))
    if ret<0 or not ptr.value:raise ValueError('property')
    try:
        raw=ctypes.string_at(ptr)
        if len(raw)>1024:raise ValueError('property size')
        value=raw.decode('ascii')
        if any(ord(c)<32 or ord(c)>126 for c in value):raise ValueError('property content')
        return value
    finally:
        libc=ctypes.CDLL(None);libc.free.argtypes=[ctypes.c_void_p];libc.free.restype=None;libc.free(ptr)


def _property_number(lib,bus,owner,path,interface,member,kind):
    typ={'u':ctypes.c_uint32,'i':ctypes.c_int32,'b':ctypes.c_int,'t':ctypes.c_uint64}[kind]
    value=typ()
    if lib.sd_bus_get_property_trivial(bus,owner,path,interface,member,None,kind.encode(),ctypes.byref(value))<0:
        raise ValueError('property')
    return value.value


def _property_invocation(lib,bus,owner,path,interface):
    msg=ctypes.c_void_p()
    try:
        if lib.sd_bus_get_property(bus,owner,path,interface,b'InvocationID',None,ctypes.byref(msg),b'ay')<0 or not msg.value:
            raise ValueError('invocation property')
        # sd_bus_get_property already entered the returned variant; the
        # message cursor is at its array, not at another variant.
        ptr=ctypes.c_void_p();size=ctypes.c_size_t()
        if lib.sd_bus_message_read_array(msg,b'y',ctypes.byref(ptr),ctypes.byref(size))<=0 or size.value!=16 or not ptr.value:
            raise ValueError('array')
        value=ctypes.string_at(ptr,16).hex()
        return value
    finally:
        if msg.value:lib.sd_bus_message_unref(msg)


def _property_empty_array(lib,bus,owner,path,interface,member,signature):
    """Require an actual empty array-valued property without logging content."""
    if signature not in (b'as',b'a(sb)',b'a(sasasttttuii)'):raise ValueError('unsupported signature')
    msg=ctypes.c_void_p()
    try:
        if lib.sd_bus_get_property(bus,owner,path,interface,member,None,ctypes.byref(msg),signature)<0 or not msg.value:
            raise ValueError('property')
        if lib.sd_bus_message_enter_container(msg,b'a',signature[1:])<=0:raise ValueError('array')
        # Signature follows the validated outer array. at_end returns positive
        # only when no element remains, zero for any element, negative on error.
        if lib.sd_bus_message_at_end(msg,0)<=0:raise ValueError('nonempty array')
        if lib.sd_bus_message_exit_container(msg)<0:raise ValueError('end')
        return True
    finally:
        if msg.value:lib.sd_bus_message_unref(msg)


def _property_fixed_environment(lib,bus,owner,path,interface):
    """Require only the exact PATH assignment, without disclosing values."""
    msg=ctypes.c_void_p()
    try:
        if lib.sd_bus_get_property(bus,owner,path,interface,b'Environment',None,ctypes.byref(msg),b'as')<0 or not msg.value:raise ValueError('environment property')
        if lib.sd_bus_message_enter_container(msg,b'a',b's')<=0:raise ValueError('environment array')
        item=ctypes.c_char_p()
        if lib.sd_bus_message_read(msg,b's',ctypes.byref(item))<=0 or item.value!=b'PATH=/usr/bin:/bin':raise ValueError('environment mismatch')
        if lib.sd_bus_message_at_end(msg,0)<=0:raise ValueError('environment count')
        if lib.sd_bus_message_exit_container(msg)<0:raise ValueError('environment end')
        return True
    finally:
        if msg.value:lib.sd_bus_message_unref(msg)


def _property_exec_start(lib,bus,owner,path,interface,kind,pid,*,profile="no_engine"):
    """Verify one exact ExecStartEx property, no command execution or authority.

    Status fields/timestamps are consumed but not assumed stable while active;
    selected command arguments, flags and started PID must match. This is an
    already-running manager property snapshot, not pre-exec prevention.
    """
    if type(kind) is not str or kind not in ('baseline','integration') or type(pid) is not int or pid<=0:
        raise ValueError('command expectation')
    if profile not in ('no_engine','genuine') or (profile=='genuine' and kind!='integration'):raise ValueError('profile')
    bootstrap = '/app/devtools/genuine_service_bootstrap.py' if profile=='genuine' else '/app/devtools/synthetic_service_bootstrap.py'
    signature=b'a(sasasttttuii)';msg=ctypes.c_void_p()
    try:
        if lib.sd_bus_get_property(bus,owner,path,interface,b'ExecStartEx',None,ctypes.byref(msg),signature)<0 or not msg.value:
            raise ValueError('command property')
        if lib.sd_bus_message_enter_container(msg,b'a',signature[1:])<=0:raise ValueError('command array')
        if lib.sd_bus_message_enter_container(msg,b'r',signature[2:-1])<=0:raise ValueError('command record')
        if _read_string(lib,msg,b's')!='/usr/bin/python3':raise ValueError('command path')
        def array():
            if lib.sd_bus_message_enter_container(msg,b'a',b's')<=0:raise ValueError('argv array')
            values=[]
            while True:
                item=ctypes.c_char_p();r=lib.sd_bus_message_read(msg,b's',ctypes.byref(item))
                if r<0 or (r>0 and item.value is None):raise ValueError('argv value')
                if r==0:break
                if len(values)>=16 or len(item.value)>1024:raise ValueError('argv bound')
                values.append(item.value.decode('ascii'))
            if lib.sd_bus_message_exit_container(msg)<0:raise ValueError('argv end')
            return values
        if array()!=['/usr/bin/python3','-I','-S','-B',bootstrap,kind]:raise ValueError('argv')
        if array()!=['no-env-expand']:raise ValueError('flags')
        ts=[ctypes.c_uint64() for _ in range(4)];actual=ctypes.c_uint32();code=ctypes.c_int32();status=ctypes.c_int32()
        if lib.sd_bus_message_read(msg,b'ttttuii',*[ctypes.byref(x) for x in (*ts,actual,code,status)])<=0:
            raise ValueError('status')
        if actual.value!=pid:raise ValueError('exec pid')
        if lib.sd_bus_message_exit_container(msg)<0 or lib.sd_bus_message_at_end(msg,0)<=0:
            raise ValueError('extra command')
        if lib.sd_bus_message_exit_container(msg)<0:raise ValueError('command array end')
        return True
    finally:
        if msg.value:lib.sd_bus_message_unref(msg)


def _same_bus_snapshot(lib,bus,owner,unit,kind,expected_slice=None,*,profile="no_engine"):
    """Typed properties on a single uniquely addressed manager connection."""
    if profile not in ('no_engine','genuine') or (profile=='genuine' and kind!='integration'):raise ValueError('profile')
    destination=owner.encode('ascii');path=_expected_path(unit).encode('ascii')
    U=b'org.freedesktop.systemd1.Unit';S=b'org.freedesktop.systemd1.Service'
    def string(iface,name):return _property_string(lib,bus,destination,path,iface,name.encode())
    def number(iface,name,kind):return _property_number(lib,bus,destination,path,iface,name.encode(),kind)
    result={'unit':string(U,'Id'),'load':string(U,'LoadState'),
       'invocation':_property_invocation(lib,bus,destination,path,U),
       'state':string(U,'ActiveState'),'substate':string(U,'SubState'),
       'cgroup':string(S,'ControlGroup'),'slice':string(S,'Slice'),'pid':number(S,'MainPID','u'),
       'type':string(S,'Type'),'user':string(S,'User'),'group':string(S,'Group'),
       'cwd':string(S,'WorkingDirectory'),'restart':string(S,'Restart'),
       'memory_pressure_watch':string(S,'MemoryPressureWatch'),
       'root':string(S,'RootDirectory'),'network':number(S,'PrivateNetwork','b'),
       'devices':number(S,'PrivateDevices','b'),'protect_cgroups':number(S,'ProtectControlGroups','b'),
       'nnp':number(S,'NoNewPrivileges','b'),'protect_system':string(S,'ProtectSystem'),
       'kill_mode':string(S,'KillMode'),
       'memory_max':number(S,'MemoryMax','t'),'tasks_max':number(S,'TasksMax','t'),
       'runtime_max':number(S,'RuntimeMaxUSec','t'),'stop_timeout':number(S,'TimeoutStopUSec','t')}
    if (result['unit']!=unit or result['load']!='loaded' or result['type']!='exec' or
        result['user']!='65534' or result['group']!='65534' or
        result['cwd']!='/work' or result['restart']!='no' or result['memory_pressure_watch']!='skip' or
        any(result[k]!=1 for k in ('network','devices','protect_cgroups','nnp')) or
        result['protect_system']!='strict' or result['kill_mode']!='control-group' or
        result['memory_max']!=1073741824 or result['tasks_max']!=64 or
        result['runtime_max']!=(120000000 if profile=='genuine' else 90000000) or result['stop_timeout']!=3000000 or
        result['state']!='active' or result['substate']!='running' or result['pid']<=0 or
        not result['root'].startswith('/') or not result['cgroup'].startswith('/') or
        re.fullmatch('[0-9a-f]{32}',result['invocation']) is None or result['invocation']=='0'*32 or
        (expected_slice is not None and result['slice']!=expected_slice)):
        raise ValueError('unit properties')
    # Unexpected per-unit environment or environment files could affect the
    # loader before bootstrap sanitizes its process environment.
    if not _property_fixed_environment(lib,bus,destination,path,S):raise ValueError('unit environment')
    for name,sig in ((b'EnvironmentFiles',b'a(sb)'),(b'PassEnvironment',b'as')):
        if not _property_empty_array(lib,bus,destination,path,S,name,sig):raise ValueError('unit environment')
    # These may already have executed before this check. They still must not
    # be silently accepted, especially as stop hooks can execute later.
    sig=b'a(sasasttttuii)'
    for name in (b'ExecConditionEx',b'ExecStartPreEx',b'ExecStartPostEx',b'ExecReloadEx',b'ExecStopEx',b'ExecStopPostEx'):
        if not _property_empty_array(lib,bus,destination,path,S,name,sig):raise ValueError('extra command')
    if not _property_exec_start(lib,bus,destination,path,S,kind,result['pid'],**({'profile':profile} if profile=='genuine' else {})):raise ValueError('start command')
    result['unit_environment']='fixed_path_other_sources_empty_snapshots';result['unit_commands']='fixed_snapshot'
    return result


def _compare_on_bus(lib,bus,owner,unit,root_fd,in_fd,out_fd,err_fd,expected_root=None,kind=None,expected_slice=None,*,profile="no_engine"):
    """Private read-only snapshots on the existing caller-owned connection.

    The sampled manager identity is not authentication or exclusive ownership.
    This function never releases admission or ensures future invariants.
    """
    from . import service_proc_observer as proc
    from . import service_namespace_observer as namespaces
    from . import systemd_manager_identity as manager
    if (type(unit) is not str or _UNIT.fullmatch(unit) is None or
        type(kind) is not str or kind not in ('baseline','integration') or
        profile not in ('no_engine','genuine') or (profile=='genuine' and kind!='integration')):raise LookupError('invalid unit or mode')
    reply=fd=None
    try:
        if _owner(lib,bus)!=owner:raise ValueError('owner changed')
        manager.inspect(lib,bus,owner)
        before=_same_bus_snapshot(lib,bus,owner,unit,kind,expected_slice,**({'profile':profile} if profile=='genuine' else {}))
        # Private session supplies the exact submitted root, not merely an
        # absolute path. Standalone old observation explicitly leaves it unknown.
        if expected_root is not None and (not _valid_root(expected_root)
                                           or before['root']!=expected_root):raise ValueError('manager root mismatch')
        fd=os.pidfd_open(before['pid']);_fdinfo(_read('/proc/self/fdinfo/'+str(fd)),before['pid'])
        if select.select([fd],[],[],0)[0]:raise ValueError('process exited')
        reply=_method(lib,bus,owner.encode(),_PATH,_INTERFACE,b'GetUnitByPIDFD',b'h',ctypes.c_int(fd))
        path,name,invocation=_decode_reply(lib,reply)
        if (path!=_expected_path(unit) or name!=unit or invocation!=before['invocation']):raise ValueError('pidfd binding')
        lib.sd_bus_message_unref(reply);reply=None
        proc.inspect_fixed(before['pid'],fd,root_fd,before['cgroup'],in_fd,out_fd,err_fd,before['invocation'],kind,**({'profile':profile} if profile=='genuine' else {}))
        namespaces.inspect(before['pid'],fd)
        after=_same_bus_snapshot(lib,bus,owner,unit,kind,expected_slice,**({'profile':profile} if profile=='genuine' else {}))
        manager.inspect(lib,bus,owner)
        if before!=after or _owner(lib,bus)!=owner or select.select([fd],[],[],0)[0]:raise ValueError('changed')
        _fdinfo(_read('/proc/self/fdinfo/'+str(fd)),before['pid'])
        return {'unit':'same_owner_property_snapshots_matched','pidfd':'manager_lookup_matched',
                'process':'proc_snapshot_matched','manager_identity':'sampled_not_authenticated',
                'configured_root':'matched_snapshot' if expected_root is not None else 'not_compared',
                'configured_slice':'matched_snapshot' if expected_slice is not None else 'not_compared',
                'start_client_binding':'not_proven','network_mounts':'candidate_snapshots_only',
                # These are sampled identifiers, NOT a proof of ownership.
                'invocation':before['invocation'],'cgroup':before['cgroup'],'main_pid':before['pid'],
                'cleanup':'not_observed','admission':'not_authorized','engine_launch_authorized':False}
    except Exception:raise LookupError('process binding unavailable') from None
    finally:
        if reply is not None and reply.value:lib.sd_bus_message_unref(reply)
        if fd is not None:os.close(fd)


def compare_live_process(unit,root_fd,in_fd,out_fd,err_fd,*,kind):
    """Read-only adapter with its own connection, never admission authority."""
    if (type(unit) is not str or _UNIT.fullmatch(unit) is None or
        type(kind) is not str or kind not in ('baseline','integration')):raise LookupError('invalid unit or mode')
    lib=bus=None
    try:
        lib=ctypes.CDLL(_LIB,use_errno=True);_proto(lib);bus=ctypes.c_void_p()
        if lib.sd_bus_open_system(ctypes.byref(bus))<0 or not bus.value:raise ValueError('bus open')
        if lib.sd_bus_set_method_call_timeout(bus,_TIMEOUT_US)<0:raise ValueError('timeout')
        owner=_owner(lib,bus)
        return _compare_on_bus(lib,bus,owner,unit,root_fd,in_fd,out_fd,err_fd,kind=kind)
    except Exception:raise LookupError('process binding unavailable') from None
    finally:
        if bus is not None and bus.value:lib.sd_bus_flush_close_unref(bus)
