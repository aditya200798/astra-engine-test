"""Local authenticated HTTP client. Never surfaces bodies or raw exceptions."""
import json, http.client, base64, math, re

class ProtocolError(Exception): pass

MAX_RESPONSE = 2_000_000
_CHUNK_LINE = 128
_CHUNKS = 4096

def strict_json(raw):
    def pairs(items):
        out={}
        for k,v in items:
            if k in out: raise ValueError('duplicate key')
            out[k]=v
        return out
    def constant(_): raise ValueError('nonfinite number')
    def finite_float(value):
        parsed=float(value)
        if not math.isfinite(parsed): raise ValueError('nonfinite number')
        return parsed
    return json.loads(raw,object_pairs_hook=pairs,parse_constant=constant,parse_float=finite_float)


def _one(headers,name):
    values=headers.get_all(name) or []
    if len(values)>1: raise ProtocolError('ambiguous response framing')
    return values[0].strip() if values else None


def _framed_body(response):
    """Require bounded, complete fixed-length or simple chunked HTTP body.

    Caller owns the connection and must close it even on rejection. The limit
    bounds bytes, not the total elapsed time against a slowly trickling peer.
    Strict chunked handling intentionally excludes extensions and trailers.
    This does not authenticate the peer or prove HTTP message provenance.
    """
    length=_one(response.headers,'Content-Length')
    transfer=_one(response.headers,'Transfer-Encoding')
    encoding=_one(response.headers,'Content-Encoding')
    if encoding is not None and encoding.lower()!='identity':raise ProtocolError('encoded response unsupported')
    if length is not None and transfer is not None:raise ProtocolError('ambiguous response framing')
    # A 204 has no message body. Permit conventional Content-Length: 0 for
    # compatibility with offline fixtures; transfer coding is never accepted.
    if response.status==204:
        if transfer is not None or (length is not None and length!='0'):raise ProtocolError('invalid no-content response')
        return b''
    if response.status!=200:raise ProtocolError('local HTTP status '+str(response.status))
    if length is not None:
        if re.fullmatch(r'[0-9]{1,9}',length) is None:raise ProtocolError('invalid response length')
        size=int(length)
        if size>MAX_RESPONSE:raise ProtocolError('response too large')
        raw=response.read(size)
        # HTTPResponse.read(n) may return fewer bytes on EOF without raising.
        if len(raw)!=size:raise ProtocolError('incomplete response')
        return raw
    if transfer is None or transfer.lower()!='chunked' or not response.chunked or response.fp is None:
        raise ProtocolError('unframed response unsupported')
    raw=bytearray()
    for _ in range(_CHUNKS):
        line=response.fp.readline(_CHUNK_LINE+1)
        if len(line)>_CHUNK_LINE or re.fullmatch(rb'[0-9A-Fa-f]{1,8}\r\n',line) is None:
            raise ProtocolError('invalid response chunk')
        size=int(line[:-2],16)
        if size>MAX_RESPONSE-len(raw):raise ProtocolError('response too large')
        if size==0:
            if response.fp.read(2)!=b'\r\n':raise ProtocolError('invalid response trailer')
            return bytes(raw)
        chunk=response.fp.read(size+2)
        if len(chunk)!=size+2 or chunk[-2:]!=b'\r\n':raise ProtocolError('incomplete response chunk')
        raw.extend(chunk[:-2])
    raise ProtocolError('response chunk limit')


class Client:
    def __init__(self,port,password,connector=None):
        self.connector=connector; self.port=int(port); self.auth='Basic '+base64.b64encode(('opencode:'+password).encode()).decode('ascii')
    def request(self,method,path,body=None,timeout=10):
        if not path.startswith('/api/') or '\n' in path or '\r' in path: raise ProtocolError('bad route')
        conn=http.client.HTTPConnection('127.0.0.1',self.port,timeout=timeout)
        if self.connector: conn.connect=lambda: setattr(conn,'sock',self.connector())
        headers={'Authorization':self.auth,'Accept':'application/json','Connection':'close'}
        data=None
        if body is not None:
            data=json.dumps(body,separators=(',',':')).encode(); headers['Content-Type']='application/json'
        try:
            conn.request(method,path,body=data,headers=headers); r=conn.getresponse(); raw=_framed_body(r)
            if r.status==204: return None
            return strict_json(raw)
        except ProtocolError: raise
        except Exception: raise ProtocolError('local connection or protocol failure') from None
        finally: conn.close()
