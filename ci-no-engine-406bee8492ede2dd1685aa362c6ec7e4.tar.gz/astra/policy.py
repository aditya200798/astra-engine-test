"""Closed-by-default, read-only policy. This is not OS confinement."""
import re
MODEL = {'providerID': 'xingchi', 'id': 'gpt-6.1-sol'}
TITLE = 'Astra candidate'

def rules_for(names):
    rules = [{'action':'*','resource':'*','effect':'deny'}]
    for name in sorted(names):
        # Wildcards, control characters and backslash are not safe literal patterns.
        if not re.fullmatch(r'[A-Za-z0-9_./-]{1,240}', name) or name.startswith('/') or any(x in ('','.','..') for x in name.split('/')):
            raise ValueError('unsafe filename')
        rules.append({'action':'read','resource':name,'effect':'allow'})
    return rules

def config_for(rules):
    return {'update':'disable','share':'disabled','snapshots':False,'warming':False,
            'formatter':False,'lsp':False,
            'compaction':{'auto':False,'background':False},
            'experimental':{'all_flags':False,'full_codemode':False,'automations':False,'subagent_depth':0},
            'agents':{'build':{'steps':4}},
            'providers':{'xingchi':{'name':'Xingchi','env':['XINGCHI_API_KEY'],
              'package':'@opencode/ai/providers/openai-compatible/responses',
              'settings':{'baseURL':'https://api.xingchiapi.com/v1','timeout':60000},
              'models':{'gpt-6.1-sol':{'name':'GPT 6.1 Sol','capabilities':{'tools':True},
                                      'limit':{'context':32000,'output':2048}}}}},
            'permissions':rules}

def json_equal(a, b):
    """Compare JSON structurally without Python's bool/number equivalence."""
    if type(a) is not type(b): return False
    if isinstance(a, dict): return a.keys() == b.keys() and all(json_equal(a[k], b[k]) for k in a)
    if isinstance(a, list): return len(a) == len(b) and all(json_equal(x, y) for x, y in zip(a,b))
    return a == b

def check_config(entries, expected, *, trusted_directory=None, verify_directory=None):
    """Accept only the source-order used by v2: controlled global dir then inline doc.

    Merely recognizing a pathname is not verification: the caller must check the
    corresponding private host directory separately at each attestation. Other
    sources, duplicates, and reordering remain fatal.
    """
    document={'type':'document','info':expected}
    if trusted_directory is None and isinstance(entries,list) and any(json_equal(entries, x) for x in ([document], [{'type':'document','path':None,'info':expected}])):
        return
    if (not isinstance(entries,list) or len(entries)!=2 or not trusted_directory
        or not callable(verify_directory)):
        raise ValueError('unverified effective config')
    directory, doc = entries
    if not json_equal(directory, {'type':'directory','path':trusted_directory}):
        raise ValueError('unverified effective config')
    if not any(json_equal(doc, x) for x in (document, {'type':'document','path':None,'info':expected})): 
        raise ValueError('unverified effective config')
    if verify_directory() is not True:
        raise ValueError('unverified config directory')

def validate_model(model):
    """Copy a fixed provider/model identity; variant overrides are not admitted."""
    if (not isinstance(model, dict) or set(model) != {'providerID', 'id'} or
        any(not isinstance(model[k], str) or not re.fullmatch(r'[A-Za-z0-9_.-]{1,128}', model[k])
            for k in ('providerID', 'id'))):
        raise ValueError('bad model identity')
    return {'providerID': model['providerID'], 'id': model['id']}

def check_session(data, rules, work, sid=None, *, expected_model=None):
    expected = validate_model(MODEL if expected_model is None else expected_model)
    if not isinstance(data,dict): raise ValueError('bad session')
    ident=data.get('id'); model=data.get('model'); loc=data.get('location')
    if not isinstance(ident,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,200}',ident) or (sid and ident!=sid): raise ValueError('bad session id')
    if data.get('title')!=TITLE or data.get('agent')!='build' or not json_equal(data.get('permissions'),rules): raise ValueError('bad session policy')
    if not isinstance(model,dict) or set(model)-{'providerID','id','variant'} or model.get('providerID')!=expected['providerID'] or model.get('id')!=expected['id'] or model.get('variant','default')!='default': raise ValueError('bad model')
    if not isinstance(loc,dict) or loc.get('directory')!=work or loc.get('workspaceID') is not None or data.get('parentID') is not None or data.get('fork') is not None or data.get('subpath') is not None: raise ValueError('bad location')
    return ident
