"""Durable journal, exclusive lock, and conservative local staging."""
import os, json, stat, tempfile, hashlib, shutil, threading
from pathlib import Path
from .policy import rules_for
from .transport import strict_json

class Store:
    def __init__(self, root):
        self.root=Path(root).absolute()
        if self.root.is_symlink(): raise ValueError('state root is a symlink')
        created=False
        try:
            self.root.mkdir(mode=0o700,parents=False,exist_ok=False); created=True
        except FileExistsError:
            pass
        st=os.lstat(self.root)
        if not stat.S_ISDIR(st.st_mode) or st.st_uid!=os.getuid() or st.st_mode & 0o077:
            raise ValueError('state root must be private')
        marker=self.root/'ASTRA_CANDIDATE_STATE'
        if created:
            fd=os.open(marker,os.O_CREAT|os.O_EXCL|os.O_WRONLY|os.O_NOFOLLOW,0o600)
            try:
                os.write(fd,b'astra-opencode-wip-v1\n'); os.fsync(fd)
            finally: os.close(fd)
        else:
            try:
                fd=os.open(marker,os.O_RDONLY|os.O_NOFOLLOW)
                with os.fdopen(fd,'rb') as f:
                    st=os.fstat(f.fileno())
                    if not stat.S_ISREG(st.st_mode) or st.st_nlink!=1 or st.st_uid!=os.getuid() or f.read(100)!=b'astra-opencode-wip-v1\n':
                        raise ValueError('invalid state marker')
            except OSError:
                raise ValueError('existing directory not reserved by this candidate') from None
        # Repeat the directory barriers on reopen: if creation's prior sync
        # failed after the marker write, validating the marker alone is not a
        # successful durability barrier. Filesystem guarantees still apply.
        for directory in (self.root,self.root.parent):
            d=os.open(directory,os.O_RDONLY|os.O_DIRECTORY)
            try: os.fsync(d)
            finally: os.close(d)
        self.lock=self.root/'running.lock'; self.lock_fd=None
        # Single-process prompt serialization for all Session objects sharing
        # this Store. The separate persistent lock is still required.
        self.prompt_lock=threading.Lock()
    def acquire(self):
        self.lock_fd=os.open(self.lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY|os.O_NOFOLLOW,0o600)
        os.write(self.lock_fd, b'Locked; manual investigation required if not cleanly closed.\n'); os.fsync(self.lock_fd)
        d=os.open(self.root,os.O_RDONLY|os.O_DIRECTORY)
        try: os.fsync(d)
        finally: os.close(d)
    def release(self):
        if self.lock_fd is not None:
            s=os.fstat(self.lock_fd); p=os.lstat(self.lock)
            if (s.st_dev,s.st_ino)!=(p.st_dev,p.st_ino): raise ValueError('lock changed')
            os.unlink(self.lock); os.close(self.lock_fd); self.lock_fd=None
    def write(self,name,obj):
        if name not in ('task.json','session.json'): raise ValueError('bad state name')
        fd,p=tempfile.mkstemp(dir=self.root,prefix='.state-')
        try:
            os.fchmod(fd,0o600)
            with os.fdopen(fd,'w',encoding='utf-8') as f:
                json.dump(obj,f,ensure_ascii=False,separators=(',',':')); f.flush(); os.fsync(f.fileno())
            os.replace(p,self.root/name)
            d=os.open(self.root,os.O_RDONLY|os.O_DIRECTORY)
            try: os.fsync(d)
            finally: os.close(d)
        finally:
            if os.path.exists(p): os.unlink(p)
    def read(self,name):
        if name not in ('task.json','session.json'): raise ValueError('bad state name')
        try:
            fd=os.open(self.root/name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
        except FileNotFoundError: return None
        try:
            st=os.fstat(fd)
            if (not stat.S_ISREG(st.st_mode) or st.st_nlink!=1 or st.st_uid!=os.getuid()
                or st.st_mode & 0o077 or st.st_size>1_000_000): raise ValueError('unsafe state')
            with os.fdopen(fd,'rb',closefd=False) as f: raw=f.read(1_000_001)
            if len(raw)>1_000_000: raise ValueError('unsafe state')
            try: obj=strict_json(raw)
            except (ValueError,UnicodeError,RecursionError): raise ValueError('corrupt state') from None
            if not isinstance(obj,dict): raise ValueError('corrupt state')
            return obj
        finally: os.close(fd)
    def append_event(self, obj):
        fd=os.open(self.root/'events.jsonl',os.O_WRONLY|os.O_APPEND|os.O_CREAT|os.O_NOFOLLOW,0o600)
        st=os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_nlink!=1:
            os.close(fd); raise ValueError('unsafe event file')
        with os.fdopen(fd,'a',encoding='utf-8') as f:
            f.write(json.dumps(obj,ensure_ascii=False,separators=(',',':'))+'\n'); f.flush(); os.fsync(f.fileno())

def inspect_tree(path):
    """Reject links (incl hardlinks), special files, unusual patterns and oversized trees."""
    path=Path(path); names=[]; hashes={}; total=0
    if path.is_symlink() or not path.is_dir(): raise ValueError('workspace must be a real directory')
    for base,dirs,files in os.walk(path,followlinks=False):
        for d in dirs:
            s=os.lstat(Path(base)/d)
            if not stat.S_ISDIR(s.st_mode): raise ValueError('workspace links/special files prohibited')
        for f in files:
            p=Path(base)/f; s=os.lstat(p); rel=p.relative_to(path).as_posix()
            rules_for([rel])
            # Upstream reads instruction files outside its ordinary read tool permission.
            if f in ('AGENTS.md','CLAUDE.md'): raise ValueError('instruction files are not trusted; staging refused')
            if not stat.S_ISREG(s.st_mode) or s.st_nlink!=1: raise ValueError('workspace links/special files prohibited')
            if s.st_size>2_000_000: raise ValueError('file too large')
            total+=s.st_size
            if total>10_000_000 or len(names)>=100: raise ValueError('workspace too large')
            fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
            with os.fdopen(fd,'rb') as h:
                st=os.fstat(h.fileno())
                if (st.st_dev,st.st_ino,st.st_size)!=(s.st_dev,s.st_ino,s.st_size): raise ValueError('workspace changed')
                digest=hashlib.sha256(h.read(2_000_001)).hexdigest()
            names.append(rel); hashes[rel]=digest
    return hashes

def stage(source,dest):
    source=Path(source).absolute(); dest=Path(dest).absolute()
    if source.is_symlink(): raise ValueError('source is a symlink')
    source=source.resolve(strict=True)
    if dest.exists() or dest.is_symlink(): raise ValueError('destination exists')
    if source==dest or source in dest.parents or dest in source.parents: raise ValueError('overlapping directories')
    before=inspect_tree(source)
    # staging is exclusive; no originals are modified. Concurrent source changes can race.
    dest.mkdir(mode=0o700,parents=False)
    try:
        for rel in before:
            target=dest/rel; target.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
            fd=os.open(source/rel,os.O_RDONLY|os.O_NOFOLLOW)
            with os.fdopen(fd,'rb') as f, open(target,'xb') as out:
                if os.fstat(f.fileno()).st_nlink!=1: raise ValueError('source changed')
                shutil.copyfileobj(f,out,65536)
            os.chmod(target,0o600)
        if inspect_tree(source)!=before or inspect_tree(dest)!=before: raise ValueError('source changed during copy')
    except Exception:
        shutil.rmtree(dest,ignore_errors=True); raise
    return before
