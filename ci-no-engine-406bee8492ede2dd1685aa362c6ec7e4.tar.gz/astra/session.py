"""One in-flight task per session, no automatic resubmission, read-only tools."""
import re, json, time, secrets, urllib.parse, math
from .policy import MODEL,TITLE,check_config,check_session,json_equal,validate_model
from .transport import ProtocolError

class Uncertain(Exception): pass

def _remaining(deadline, cap):
    # A socket timeout is not a whole-call deadline. Do not start a new
    # ordinary request when the polling budget has already been consumed.
    left=deadline-time.monotonic()
    if left<=0: raise ProtocolError('poll deadline')
    return min(cap,left)

def _read_input_ok(inp, allowed):
    """Validate observed read arguments consistently, not an execution boundary."""
    return (isinstance(inp,dict) and not (set(inp)-{'path','offset','limit'})
            and isinstance(inp.get('path'),str) and inp['path'] in allowed
            and all(key not in inp or (type(inp[key]) is int and
                    (key!='limit' or inp[key]>=0)) for key in ('offset','limit')))

def _streaming_read_input_ok(raw, allowed):
    """Recognize only complete, bounded, unambiguous allowed read arguments.

    This is an observation, not authorization or proof what the server executes.
    Partial/malformed JSON remains unverifiable and fails closed.
    """
    if not isinstance(raw,str) or len(raw)>16384: return False
    def unique(pairs):
        out={}
        for key,value in pairs:
            if key in out: raise ValueError('duplicate key')
            out[key]=value
        return out
    def bad_constant(_): raise ValueError('non-JSON number')
    try:
        inp=json.loads(raw,object_pairs_hook=unique,parse_constant=bad_constant)
        return _read_input_ok(inp,allowed)
    except (ValueError,TypeError,RecursionError): return False

def msgid(): return 'msg_'+format(int(time.time()*1000)*4096,'012x')+secrets.token_hex(7)
def redact(value,secrets_list):
    if isinstance(value,str):
        for secret in secrets_list:
            if secret:value=value.replace(secret,'[REDACTED]')
        return value
    if isinstance(value,list): return [redact(x,secrets_list) for x in value]
    if isinstance(value,dict): return {redact(k,secrets_list) if isinstance(k,str) else k:redact(v,secrets_list) for k,v in value.items()}
    return value

def check_journals(store, work=None, rules=None):
    """Fail closed on malformed/ambiguous persisted records before network or engine.

    Legacy valid records are the exact dictionaries this candidate already wrote.
    No automatic repair and no defense against deliberate same-UID file edits.
    """
    task=store.read('task.json'); saved=store.read('session.json')
    if task is not None:
        if (set(task)!={'id','session','status','created'}
            or not isinstance(task.get('id'),str) or not re.fullmatch(r'msg_[A-Za-z0-9_-]{1,196}',task['id'])
            or not isinstance(task.get('session'),str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,200}',task['session'])
            or type(task.get('created')) is not int or task['created']<0
            or task.get('status')!='succeeded'):
            raise Uncertain('Unresolved or corrupt task; do not restart or resubmit.')
    if saved is not None:
        if saved.get('creation')=='uncertain':
            raise Uncertain('Previous session creation unresolved; engine not started or recreated.')
        if (set(saved)!={'sid','work','rules'} or not isinstance(saved.get('sid'),str)
            or not re.fullmatch(r'[A-Za-z0-9_-]{1,200}',saved['sid'])
            or not isinstance(saved.get('work'),str) or not isinstance(saved.get('rules'),list)):
            raise ValueError('Corrupt session record; do not recreate.')
        if work is not None and (saved['work']!=work or saved['rules']!=rules):
            raise ValueError('saved session differs')
    if task is not None and (saved is None or task['session']!=saved['sid']):
        raise Uncertain('Task/session journal mismatch; do not restart or resubmit.')
    return saved

class Session:
    def __init__(self,client,store,work,rules,config,clean_env,secret_values, config_attestation=None, *, model=None):
        # Session creation performs remote writes too. Serialize it against
        # creation and prompting on this Store before any journal or network IO.
        if not store.prompt_lock.acquire(blocking=False):
            raise Uncertain('Another session operation is in progress; not sent')
        try:
            self._initialize(client,store,work,rules,config,clean_env,secret_values,config_attestation,model=model)
        finally:
            store.prompt_lock.release()

    def _initialize(self,client,store,work,rules,config,clean_env,secret_values,config_attestation,*,model):
        self.client,self.store,self.work,self.rules=client,store,work,rules
        self.model=validate_model(MODEL if model is None else model)
        self.secrets=secret_values; self.clean_env=clean_env; self.sid=None; self.base=None
        self.config=config; self.config_attestation=config_attestation or {}
        saved=check_journals(store,work,rules)
        self._config()
        if saved is not None:
            self.sid=saved['sid']; self.base='/api/session/'+urllib.parse.quote(self.sid,safe='')
            check_session(client.request('GET',self.base).get('data'),rules,work,self.sid,expected_model=self.model)
        else:
            # Persist intent before the POST; never clear on ambiguous failure.
            # Storage/fsync guarantees depend on the underlying filesystem.
            store.write('session.json',{'creation':'uncertain'})
            result=client.request('POST','/api/session',{'title':TITLE,'agent':'build','model':dict(self.model),'location':{'directory':work},'permissions':rules})
            self.sid=check_session(result.get('data') if isinstance(result,dict) else None,rules,work,expected_model=self.model)
            self.base='/api/session/'+urllib.parse.quote(self.sid,safe='')
            check_session(client.request('GET',self.base).get('data'),rules,work,self.sid,expected_model=self.model)
            store.write('session.json',{'sid':self.sid,'work':work,'rules':rules})
        # Before every prompt and after every process start; never include key or config/password.
        self._environment()
    def _config(self,deadline=None):
        path='/api/config?location%5Bdirectory%5D='+urllib.parse.quote(self.work,safe='')
        entries=(self.client.request('GET',path) if deadline is None else
                 self.client.request('GET',path,timeout=_remaining(deadline,2)))
        check_config(entries,self.config,**self.config_attestation)
    def _environment(self):
        self.client.request('PUT',self.base+'/environment',{'variables':self.clean_env})
    def permissions(self,timeout=10):
        result=self.client.request('GET',self.base+'/permission',timeout=timeout)
        if not isinstance(result,dict) or not isinstance(result.get('data'),list): raise ProtocolError('invalid permission response')
        return result['data']
    def _reject_unexpected(self,deadline):
        timeout=lambda: _remaining(deadline,2)
        result=self.client.request('GET','/api/permission/request?location%5Bdirectory%5D='+urllib.parse.quote(self.work,safe=''),timeout=timeout())
        if not isinstance(result,dict) or not isinstance(result.get('data'),list): raise ProtocolError('invalid location permissions')
        location=result.get('location')
        if not isinstance(location,dict) or location.get('directory')!=self.work: raise ProtocolError('permission location mismatch')
        unexpected=False
        for p in result['data']:
            if not isinstance(p,dict): raise ProtocolError('invalid permission')
            sid=p.get('sessionID'); ident=p.get('id')
            if not isinstance(sid,str) or not re.fullmatch(r'ses_[A-Za-z0-9_-]{1,196}',sid): raise ProtocolError('invalid permission session')
            if not isinstance(ident,str) or not re.fullmatch(r'per[A-Za-z0-9_-]{1,197}',ident): raise ProtocolError('invalid permission')
            self.client.request('POST','/api/session/'+urllib.parse.quote(sid,safe='')+'/permission/'+urllib.parse.quote(ident,safe='')+'/reply',{'decision':'reject'},timeout=timeout())
            unexpected=True
        if unexpected: raise ProtocolError('unexpected permission request')
        # A session-scoped list is checked independently for requests missed by location.
        if self.permissions(timeout=timeout()): raise ProtocolError('permission race or unexpected request')
    def pages(self,deadline=None):
        # A sequence of pages is not an atomic server snapshot. Bound the
        # whole sequence as well as each transport response and reject obvious
        # overlapping/ambiguous IDs before interpreting the current turn.
        cursor=None; seen=set(); ids=set(); out=[]; total=0
        for _ in range(50):
            q='?limit=200&'+('cursor='+urllib.parse.quote(cursor,safe='') if cursor else 'order=asc')
            r=self.client.request('GET',self.base+'/message'+q,timeout=_remaining(deadline,2) if deadline is not None else 10)
            if not isinstance(r,dict) or not isinstance(r.get('data'),list) or not isinstance(r.get('cursor'),dict): raise ProtocolError('invalid message page')
            page=r['data']
            if len(page)>200: raise ProtocolError('message page size')
            try:
                total+=len(json.dumps(page,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode('utf-8'))
            except (TypeError,ValueError,UnicodeError,RecursionError): raise ProtocolError('invalid message page') from None
            if total>10_000_000: raise ProtocolError('message snapshot size')
            for item in page:
                if not isinstance(item,dict) or not isinstance(item.get('id'),str) or not re.fullmatch(r'msg_[A-Za-z0-9_-]{1,196}',item['id']):
                    raise ProtocolError('invalid message id')
                if item['id'] in ids: raise ProtocolError('duplicate message id across pages')
                ids.add(item['id'])
            out.extend(page); cur=r['cursor'].get('next')
            if cur is None: return out
            if not page or not isinstance(cur,str) or not cur or len(cur)>4096 or cur in seen: raise ProtocolError('invalid message cursor')
            seen.add(cur); cursor=cur
        raise ProtocolError('message page limit')
    def prompt(self,text,deadline_seconds=120,poll_interval=.5):
        # Acquire before reading the journal or changing environment. Different
        # Session objects sharing this Store must not race the same task.json.
        # This is not a cross-process lock or an upstream execution boundary.
        if not self.store.prompt_lock.acquire(blocking=False):
            raise Uncertain('Another prompt is in progress; not sent')
        try:
            return self._prompt_once(text,deadline_seconds,poll_interval)
        finally:
            self.store.prompt_lock.release()

    def _prompt_once(self,text,deadline_seconds=120,poll_interval=.5):
        if not isinstance(text,str) or not text.strip() or len(text.encode())>100_000: raise ValueError('empty or oversized prompt')
        if (type(deadline_seconds) not in (int,float) or not math.isfinite(deadline_seconds) or not 0<deadline_seconds<=600
            or type(poll_interval) not in (int,float) or not math.isfinite(poll_interval) or not 0<poll_interval<=600):
            raise ValueError('invalid prompt timing')
        if any(s and s in text for s in self.secrets): raise ValueError('prompt contains active credential; not sent')
        saved=check_journals(self.store,self.work,self.rules)
        if saved is None or saved['sid']!=self.sid: raise Uncertain('Session journal changed; not sent')
        self._config()
        self._environment()
        ident=msgid(); task={'id':ident,'session':self.sid,'status':'sending','created':int(time.time())}
        self.store.write('task.json',task)  # persisted BEFORE request leaves process
        deadline=time.monotonic()+deadline_seconds
        try:
            response=self.client.request('POST',self.base+'/prompt',{'id':ident,'text':text,'files':[],'delivery':'steer'},timeout=_remaining(deadline,30))
            data=response.get('data') if isinstance(response,dict) else None
            if not isinstance(data,dict) or data.get('id')!=ident or data.get('type')!='user': raise ProtocolError('ambiguous admission')
            task['status']='admitted'; self.store.write('task.json',task)
        except Exception:
            # Admission may have succeeded. Polling can reconcile; never resend.
            task['status']='uncertain'; self.store.write('task.json',task)
        latest=[]
        try:
            previous=None
            while time.monotonic()<deadline:
                self._reject_unexpected(deadline)
                messages=self.pages(deadline)
                info=self.client.request('GET',self.base,timeout=_remaining(deadline,2))
                info=info.get('data') if isinstance(info,dict) else None
                check_session(info,self.rules,self.work,self.sid,expected_model=self.model)
                # An idle marker is not individually linked to a prompt by the v2 schema.
                # Demand one unambiguous user marker, a final idle, and stable snapshots.
                indexes=[i for i,m in enumerate(messages) if isinstance(m,dict) and m.get('type')=='user' and m.get('id')==ident]
                if len(indexes)>1: raise ProtocolError('duplicate prompt')
                if not indexes:
                    previous=None; time.sleep(min(poll_interval,max(0,deadline-time.monotonic()))); continue
                admitted=messages[indexes[0]]
                if admitted.get('text')!=text or admitted.get('files',[])!=[] or admitted.get('agents',[])!=[] or admitted.get('skills',[])!=[]:
                    raise ProtocolError('prompt content mismatch')
                user_time=admitted.get('time')
                if not isinstance(user_time,dict) or type(user_time.get('created')) not in (int,float) or not math.isfinite(user_time['created']):
                    raise ProtocolError('invalid prompt timestamp')
                run=messages[indexes[0]+1:]; latest=[]; outcome=None; final_text=False; idle_time=None; last_finish=None; final_parts=[]; final_redacted=False; run_ids={ident}; assistant_times=[]; turn_has_reasoning=False; assistant_count=0; in_progress=False
                for i,m in enumerate(run):
                    if not isinstance(m,dict): raise ProtocolError('invalid message')
                    kind=m.get('type')
                    if not isinstance(m.get('id'),str) or not re.fullmatch(r'msg_[A-Za-z0-9_-]{1,196}',m['id']): raise ProtocolError('invalid message id')
                    if m['id'] in run_ids: raise ProtocolError('duplicate message id')
                    run_ids.add(m['id'])
                    if kind=='assistant':
                        assistant_count+=1
                        final_text=False; final_parts=[]; final_redacted=False
                        mt=m.get('time')
                        if not isinstance(mt,dict) or type(mt.get('created')) not in (int,float) or not math.isfinite(mt['created']): raise ProtocolError('invalid assistant timestamp')
                        completed=mt.get('completed')
                        if mt['created'] < user_time['created']: raise ProtocolError('assistant predates prompt')
                        # Only the final message may be unfinished. Null is not an
                        # omitted optional field; a half-terminal state is ambiguous.
                        active='completed' not in mt and 'finish' not in m
                        if active:
                            if i!=len(run)-1 or 'error' in m or 'retry' in m:
                                raise ProtocolError('ambiguous in-progress assistant')
                            for key in ('firstToken','streamed'):
                                if key in mt and (type(mt[key]) not in (int,float) or not math.isfinite(mt[key]) or mt[key]<mt['created']):
                                    raise ProtocolError('invalid streaming timestamp')
                            in_progress=True
                        else:
                            if (type(completed) not in (int,float) or not math.isfinite(completed)
                                or completed < mt['created']):
                                raise ProtocolError('inconsistent assistant timestamp')
                            assistant_times.append((mt['created'],completed))
                        model=m.get('model')
                        if (not isinstance(model,dict) or set(model)-{'providerID','id','variant'}
                            or model.get('providerID')!=self.model['providerID'] or model.get('id')!=self.model['id']
                            or model.get('variant','default')!='default' or m.get('agent')!='build'):
                            raise ProtocolError('unexpected assistant selection')
                        if m.get('error') is not None or m.get('retry') is not None: raise ProtocolError('assistant error/retry')
                        if not isinstance(m.get('content'),list): raise ProtocolError('invalid content')
                        finish=m.get('finish')
                        if not active and finish not in ('stop','tool-calls'): raise ProtocolError('assistant finish not successful')
                        tool_seen=False; last_finish=finish
                        for part in m['content']:
                            if not isinstance(part,dict): raise ProtocolError('invalid assistant content')
                            ptype=part.get('type')
                            if ptype=='text':
                                if not isinstance(part.get('text'),str): raise ProtocolError('invalid text')
                                if part['text'].strip(): final_text=True
                                clean=redact(part,self.secrets)
                                if clean != part: final_redacted=True
                                if not active: latest.append(clean); final_parts.append(clean)
                            elif ptype=='tool':
                                tool_seen=True
                                pt=part.get('time')
                                if not isinstance(part.get('id'),str) or not part['id'] or not isinstance(pt,dict) or type(pt.get('created')) not in (int,float) or not math.isfinite(pt['created']): raise ProtocolError('invalid tool metadata')
                                # Provider-executed tools bypass local read execution;
                                # if observed, they are not an approved local read.
                                # Absence/false still does not prove provenance.
                                if part.get('executed',False) is not False or ('native' in part and not isinstance(part['native'],dict)):
                                    raise ProtocolError('unverifiable tool execution')
                                if active:
                                    for key in ('ran','completed'):
                                        if key in pt and (type(pt[key]) not in (int,float) or not math.isfinite(pt[key]) or pt[key]<pt['created']): raise ProtocolError('invalid tool timestamp')
                                st=part.get('state')
                                if part.get('name')!='read' or not isinstance(st,dict): raise ProtocolError('unexpected tool observed')
                                allowed=[p for r in self.rules if r.get('action')=='read' and r.get('effect')=='allow' for p in (r['resource'], self.work.rstrip('/')+'/'+r['resource'])]
                                status=st.get('status'); inp=st.get('input')
                                if st.get('error') is not None: raise ProtocolError('read failed')
                                if status=='streaming' and active:
                                    # Upstream publishes the finished raw string while still
                                    # streaming; partial, ambiguous or unauthorized input is not trusted.
                                    if (set(st)!={'status','input'} or 'ran' in pt or 'completed' in pt
                                        or not (inp=='' or _streaming_read_input_ok(inp,allowed))):
                                        raise ProtocolError('unverifiable streaming read')
                                elif status=='running' and active:
                                    if (set(st)!={'status','input','metadata'} or not _read_input_ok(inp,allowed)
                                        or not isinstance(st.get('metadata'),dict)
                                        or 'completed' in pt): raise ProtocolError('unapproved running read')
                                elif status=='completed':
                                    if (set(st)-{'status','input','content','metadata'} or not _read_input_ok(inp,allowed)
                                        or ('metadata' in st and not isinstance(st['metadata'],dict))
                                        or not isinstance(st.get('content'),list) or not st['content']
                                        or not all(isinstance(x,dict) and x.get('type')=='text' and isinstance(x.get('text'),str) for x in st['content'])):
                                        raise ProtocolError('read incomplete or failed')
                                    latest.append(redact(part,self.secrets))
                                else: raise ProtocolError('read incomplete or failed')
                                final_text=False
                            elif ptype=='reasoning':
                                turn_has_reasoning=True
                                if not isinstance(part.get('text'),str): raise ProtocolError('invalid reasoning')
                            else: raise ProtocolError('unknown assistant content')
                        if not active and (finish=='tool-calls') != tool_seen: raise ProtocolError('inconsistent tool finish')
                    elif kind=='idle':
                        if i!=len(run)-1 or outcome is not None: raise ProtocolError('ambiguous idle')
                        marker_time=m.get('time')
                        if not isinstance(marker_time,dict) or type(marker_time.get('created')) not in (int,float) or not math.isfinite(marker_time['created']) or marker_time['created']<user_time['created']:
                            raise ProtocolError('idle predates prompt')
                        idle_time=marker_time['created']
                        if any(completed > idle_time for _,completed in assistant_times):
                            raise ProtocolError('assistant completed after idle')
                        outcome=m.get('outcome')
                        if outcome!='succeeded' or m.get('error') is not None: raise ProtocolError('unsuccessful idle')
                    else:
                        # Includes model/agent/location changes, synthetic and other users.
                        raise ProtocolError('unexpected session message')
                if not in_progress and outcome=='succeeded' and final_text and last_finish=='stop':
                    timing=info.get('time')
                    if (info.get('outcome')!='succeeded' or not isinstance(timing,dict)
                        or type(timing.get('idle')) not in (int,float) or type(timing.get('busy')) not in (int,float)
                        or not math.isfinite(timing['idle']) or not math.isfinite(timing['busy'])
                        or timing['idle'] < max(timing['busy'],idle_time)): raise ProtocolError('session not stably idle')
                    snapshot={'messages':messages,'info':info}
                    if previous is not None and json_equal(previous,snapshot):
                        # Check again immediately before committing: still not an atomic server snapshot.
                        self._reject_unexpected(deadline)
                        self._config(deadline)
                        _remaining(deadline,2) # last read must finish within the budget
                        self.store.append_event({'task':ident,'parts':latest,'outcome':outcome})
                        task['status']=outcome; self.store.write('task.json',task)
                        return {'status':outcome,'parts':latest,'final_parts':final_parts,'final_redacted':final_redacted,
                                'turn_has_reasoning':turn_has_reasoning,'assistant_count':assistant_count,'task_id':ident}
                    previous=snapshot
                else: previous=None
                time.sleep(min(poll_interval,max(0,deadline-time.monotonic())))
        except Exception:
            pass
        # Do not assert interruption succeeded; no replay on next process startup.
        try:self.client.request('POST',self.base+'/interrupt',{},timeout=3)
        except Exception:pass
        task['status']='uncertain'; self.store.write('task.json',task)
        return {'status':'uncertain','parts':latest}
