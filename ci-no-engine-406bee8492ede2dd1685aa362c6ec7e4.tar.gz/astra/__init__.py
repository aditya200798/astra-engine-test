"""Astra OpenCode bridge, experimental and not production hardened."""
