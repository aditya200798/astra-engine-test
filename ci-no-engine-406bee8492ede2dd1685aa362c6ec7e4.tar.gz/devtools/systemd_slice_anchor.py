"""Private systemd slice startup and retained cgroup observations, NOT a supervisor.

No public operation is enabled. Only a separately reviewed, single-writer,
credential-free disposable CI VM owner may use these pieces. In particular,
creating this anchor does not create the independent watchdog, prove ownership,
or fix delayed/ambiguous starts. Never stop a guessed or foreign slice.
"""
import ctypes as c
import os
import stat
from . import cgroup_watchdog as cg
from . import systemd_direct_start as direct
from . import systemd_job_tracker as jobs
from . import systemd_pidfd_lookup as look

_BLOCKED=True
P=c.c_void_p
class AnchorError(RuntimeError):pass


def _build(lib,bus,owner,unit):
    """Build one fixed transient slice start with a connection-bound reference."""
    name=direct._slice_for(unit)
    import re
    if type(owner) is not str or re.fullmatch(r':[0-9]+\.[0-9]+',owner) is None:raise ValueError('owner')
    msg=P()
    try:
        direct._check(lib.sd_bus_message_new_method_call(bus,c.byref(msg),owner.encode(),look._PATH,look._INTERFACE,b'StartTransientUnit'))
        if not msg.value:raise ValueError('message')
        direct._check(lib.sd_bus_message_append(msg,b'ss',c.c_char_p(name.encode()),c.c_char_p(b'fail')))
        direct._check(lib.sd_bus_message_open_container(msg,b'a',b'(sv)'))
        direct._check(lib.sd_bus_message_append(msg,b'(sv)',c.c_char_p(b'AddRef'),c.c_char_p(b'b'),c.c_int(1)))
        direct._check(lib.sd_bus_message_close_container(msg))
        direct._check(lib.sd_bus_message_open_container(msg,b'a',b'(sa(sv))'))
        direct._check(lib.sd_bus_message_close_container(msg))
        return msg
    except BaseException:
        if msg.value:lib.sd_bus_message_unref(msg)
        raise


def _identity(fd):
    s=os.fstat(fd)
    if not stat.S_ISDIR(s.st_mode) or not cg._is_cgroup2(fd):raise ValueError('not cgroup2 directory')
    return s.st_dev,s.st_ino


def _check_group(root_fd,group_fd,name):
    """Compare exact child inode under already-trusted cgroup root FD.

    A held stale inode or same-name replacement fails. This does not establish
    mount identity, ownership, exclusivity, process membership or future state.
    """
    root_id=_identity(root_fd);held=_identity(group_fd)
    if held==root_id:raise ValueError('root cannot be slice')
    named=os.stat(name,dir_fd=root_fd,follow_symlinks=False)
    if not stat.S_ISDIR(named.st_mode) or (named.st_dev,named.st_ino)!=held:raise ValueError('slice replaced')
    return held


def _read_manager(lib,bus,owner,name):
    """Sample fixed slice properties on caller-owned already-checked bus."""
    path=look._expected_path(name).encode();destination=owner.encode()
    u=b'org.freedesktop.systemd1.Unit';s=b'org.freedesktop.systemd1.Slice'
    get=lambda iface,key:look._property_string(lib,bus,destination,path,iface,key.encode())
    snap={'id':get(u,'Id'),'load':get(u,'LoadState'),'state':get(u,'ActiveState'),
          'cgroup':get(s,'ControlGroup'),
          'transient':look._property_number(lib,bus,destination,path,u,b'Transient','b')}
    if snap!={'id':name,'load':'loaded','state':'active','cgroup':'/'+name,'transient':1}:
        raise ValueError('manager slice mismatch')
    return snap


class _Anchor:
    """At most one slice start. Caller retains bus and supervises everything.

    FD access and state observations are private plumbing only: no claim of
    identity authentication, exclusivity, safety, or recovery from lost replies.
    Do not invoke on shared hosts or with real secrets. Caller externally bounds
    native calls and cleans all effects, including ambiguous accepted starts.
    """
    def __init__(self,lib,bus,owner,unit,root_fd):
        self.name=direct._slice_for(unit)
        if type(root_fd) is not int or root_fd<0:raise AnchorError('invalid root')
        self.lib=lib;self.bus=bus;self.owner=owner;self.root_fd=root_fd
        self.state='fresh';self.group_fd=None;self.tracker=None
    def start_once(self):
        if self.state!='fresh':raise AnchorError('attempt consumed')
        self.state='preparing';msg=None
        try:
            _identity(self.root_fd)
            # Occupancy is not ownership. Even a missing path is not an atomic
            # reservation; VM and manager exclusivity remain external duties.
            try:os.stat(self.name,dir_fd=self.root_fd,follow_symlinks=False)
            except FileNotFoundError:pass
            else:raise ValueError('cgroup name exists')
            direct._proto(self.lib);jobs._proto(self.lib)
            self.tracker=jobs._Tracker(self.lib,self.bus,self.owner,self.name)
            self.tracker.subscribe()
            msg=_build(self.lib,self.bus,self.owner,'astra-synthetic-'+self.name[5:-6]+'.service')
            self.state='start_uncertain'
            reply=direct._send(self.lib,self.bus,msg)
            if self.tracker.await_job(reply['job_path'],10).get('job_result')!='done':raise ValueError('job')
            if look._owner(self.lib,self.bus)!=self.owner:raise ValueError('owner changed')
            first=_read_manager(self.lib,self.bus,self.owner,self.name)
            self.group_fd=os.open(self.name,os.O_RDONLY|os.O_DIRECTORY|os.O_CLOEXEC|os.O_NOFOLLOW,dir_fd=self.root_fd)
            _check_group(self.root_fd,self.group_fd,self.name)
            if cg._populated(cg._read(self.group_fd,'cgroup.events')):raise ValueError('not empty')
            second=_read_manager(self.lib,self.bus,self.owner,self.name)
            if second!=first or look._owner(self.lib,self.bus)!=self.owner:raise ValueError('changed')
            _check_group(self.root_fd,self.group_fd,self.name)
            self.state='anchored'
            return {'slice':'manager_and_empty_group_sampled','ownership':'not_proven',
                    'watchdog':'not_started','cleanup':'not_observed','engine_launch_authorized':False}
        except BaseException:
            if self.state!='start_uncertain':self.state='failed_no_retry'
            if self.group_fd is not None:os.close(self.group_fd);self.group_fd=None
            raise AnchorError('slice start or observation uncertain; no retry; external recovery required') from None
        finally:
            if msg is not None and msg.value:self.lib.sd_bus_message_unref(msg)
    def observe_anchor(self):
        """Resample linked cgroup and manager state, without proving ownership."""
        if self.state!='anchored' or self.group_fd is None:raise AnchorError('slice not anchored')
        try:
            if look._owner(self.lib,self.bus)!=self.owner:raise ValueError('owner')
            first=_read_manager(self.lib,self.bus,self.owner,self.name)
            _check_group(self.root_fd,self.group_fd,self.name)
            if _read_manager(self.lib,self.bus,self.owner,self.name)!=first:raise ValueError('changed')
            if look._owner(self.lib,self.bus)!=self.owner:raise ValueError('owner')
            return {'slice':'manager_and_group_sampled','ownership':'not_proven',
                    'watchdog':'not_started','cleanup':'not_observed','engine_launch_authorized':False}
        except BaseException:raise AnchorError('slice anchor unknown; external recovery required') from None

    def observe_service_membership(self,service_cgroup):
        """Sample identity and literal systemd service path below retained slice.

        This does not prove exclusive ownership, prevent movement, or establish
        an independent watchdog. It does not kill, stop or admit anything.
        """
        if self.state!='anchored' or self.group_fd is None:raise AnchorError('slice not anchored')
        try:
            if look._owner(self.lib,self.bus)!=self.owner:raise ValueError('owner')
            _read_manager(self.lib,self.bus,self.owner,self.name)
            _check_group(self.root_fd,self.group_fd,self.name)
            unit='astra-synthetic-'+self.name[5:-6]+'.service'
            if service_cgroup!='/'+self.name+'/'+unit:raise ValueError('service group')
            fd=os.open(unit,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=self.group_fd)
            try:
                _identity(fd)
                named=os.stat(unit,dir_fd=self.group_fd,follow_symlinks=False)
                held=os.fstat(fd)
                if not stat.S_ISDIR(named.st_mode) or (named.st_dev,named.st_ino)!=(held.st_dev,held.st_ino):raise ValueError('service replaced')
            finally:os.close(fd)
            _check_group(self.root_fd,self.group_fd,self.name)
            if look._owner(self.lib,self.bus)!=self.owner:raise ValueError('owner')
            return {'placement':'slice_and_service_group_sampled','ownership':'not_proven',
                    'watchdog':'not_started','cleanup':'not_observed','engine_launch_authorized':False}
        except BaseException:raise AnchorError('slice membership unknown; external recovery required') from None
    def close(self):
        """Drop local references only: never stops the unit or verifies cleanup."""
        if self.group_fd is not None:os.close(self.group_fd);self.group_fd=None
        if self.tracker is not None:self.tracker.close();self.tracker=None
        self.state='closed'


def run():
    if _BLOCKED:raise AnchorError('slice anchor blocked: outside supervisor and recovery not established')
    raise AnchorError('no approved orchestration')
