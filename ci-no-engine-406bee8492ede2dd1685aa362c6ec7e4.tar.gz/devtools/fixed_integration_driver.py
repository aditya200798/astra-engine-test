"""Unapproved developer-only integration driver, launch permanently hard-blocked.

No entry point or switch enables the block. In-memory dependency patching in
unit tests does not authorize execution. This is wiring, not a supervisor,
sandbox, provenance check, CI lock, or production gate. Independent boundary
review and real disposable runtime controls remain prerequisites to any launch.
"""
import asyncio
import os

from .baseline_config_observer import ConfigDirectoryObservation
from .synthetic_integration import OneShotIntegration
from .integration_evidence import summarize

_LAUNCH_BLOCKED = True
_BINARY = '/engine/opencode'
_ARGV = (_BINARY, 'serve', '--stdio', '--hostname', '127.0.0.1', '--port', '0')
_DRIVER_ENV = {'PATH': '/usr/bin:/bin', 'HOME': '/work/home', 'TMPDIR': '/work/tmp',
               'LANG': 'C', 'LC_ALL': 'C'}


class DriverError(RuntimeError):
    pass


class FixedIntegrationDriver:
    """At most one attempt; no command, path or environment supplied by caller.

    Successful wiring observation is not proof of engine, isolation, provenance,
    descendant cleanup, or fixture peer identity. This driver must not run a real
    child without independently reviewed external lifecycle and runtime controls.
    """
    def __init__(self):
        self._used = False
        self.evidence = {'stage': 'not_started', 'engine_launch_authorized': False,
                         'genuine_engine': 'not_attested', 'isolation': 'not_verified',
                         'provenance': 'not_verified', 'descendant_cleanup': 'not_verified',
                         'direct_child_cleanup': 'not_verified', 'spawn': 'not_attempted',
                         'config_observer_close': 'not_opened', 'lease_close': 'not_attempted',
                         'fixture_exit': 'not_entered', 'session_worker_call': 'not_submitted'}

    async def run(self):
        if self._used:
            raise DriverError('driver already attempted; do not replay')
        self._used = True
        if _LAUNCH_BLOCKED:
            self.evidence['stage'] = 'blocked_before_start'
            raise DriverError('integration launch hard-blocked; external controls not verified')
        observation = None
        integration = None
        try:
            self.evidence['stage'] = 'preflight'
            if (os.getuid() != 65534 or os.geteuid() != 65534 or
                os.getgid() != 65534 or os.getegid() != 65534 or
                os.getgroups() != [] or dict(os.environ) != _DRIVER_ENV):
                raise DriverError('driver identity, groups or environment differs')
            observation = ConfigDirectoryObservation('/work')
            self.evidence['config_observer_close'] = 'not_attempted'
            if observation.verify() is not True:
                raise DriverError('config observation failed')
            integration = OneShotIntegration()
            with integration:
                self.evidence['fixture_exit'] = 'pending'
                proc = None
                try:
                    env = integration.environment()
                    self.evidence['stage'] = 'spawning_outcome_uncertain'
                    self.evidence['spawn'] = 'outcome_unknown'
                    proc = await asyncio.create_subprocess_exec(
                        *_ARGV, stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE, cwd='/work/project', env=env,
                        close_fds=True)
                    self.evidence['spawn'] = 'child_handle_obtained'
                    self.evidence['stage'] = 'child_spawned'
                    await integration.run(proc, observation.verify)
                finally:
                    if proc is not None:
                        try:
                            if proc.stdin is None:
                                self.evidence['lease_close'] = 'uncertain'
                            else:
                                try:
                                    proc.stdin.close()
                                    self.evidence['lease_close'] = 'close_requested'
                                except Exception:
                                    self.evidence['lease_close'] = 'uncertain'
                            if proc.returncode is None:
                                try:
                                    proc.kill()
                                except ProcessLookupError:
                                    pass
                                try:
                                    await asyncio.wait_for(proc.wait(), timeout=2)
                                except TimeoutError:
                                    # Direct exit may be recorded while descendants still hold pipes.
                                    # Snapshot below only; external unit cleanup is still mandatory.
                                    pass
                            self.evidence['direct_child_cleanup'] = (
                                'direct_exit_observed' if proc.returncode is not None else 'uncertain')
                        except asyncio.CancelledError:
                            self.evidence['direct_child_cleanup'] = 'uncertain'
                            raise
                        except Exception:
                            self.evidence['direct_child_cleanup'] = 'uncertain'
            self.evidence['fixture_exit'] = 'returned'
            if (not isinstance(integration.evidence, dict) or
                integration.evidence.get('stage') != 'assembled_observation_complete' or
                integration.evidence.get('fixture_final_check') != 'passed' or
                integration.evidence.get('fixture_thread_stopped') is not True or
                integration.evidence.get('session_worker_call') != 'call_completed'):
                raise DriverError('integration evidence incomplete')
            # Same-process claims only: not identity, isolation or cleanup proof.
            self.evidence['integration'] = summarize(integration.evidence)
            self.evidence['stage'] = 'integration_observed_cleanup_pending'
        except asyncio.CancelledError:
            self.evidence['stage'] = 'cancelled_outcome_uncertain'
            raise
        except Exception:
            self.evidence['stage'] = 'failed_outcome_uncertain'
            raise DriverError('integration failed or uncertain; no retry') from None
        finally:
            # Unknown cannot imply that the worker or unit has stopped.
            if integration is not None:
                try:
                    self.evidence['session_worker_call'] = integration.worker.snapshot()
                except Exception:
                    self.evidence['session_worker_call'] = 'unknown'
            if observation is not None:
                if self.evidence['session_worker_call'] == 'unknown':
                    # The worker may still be in verify(); do not close/reuse
                    # its fds here. External unit termination owns this case.
                    self.evidence['config_observer_close'] = 'deferred_to_external_supervisor'
                else:
                    try:
                        observation.close()
                        self.evidence['config_observer_close'] = 'closed'
                    except Exception:
                        self.evidence['config_observer_close'] = 'uncertain'
        if (self.evidence['config_observer_close'] != 'closed' or
            self.evidence['lease_close'] != 'close_requested' or
            self.evidence['direct_child_cleanup'] != 'direct_exit_observed'):
            self.evidence['stage'] = 'failed_cleanup_uncertain'
            raise DriverError('integration cleanup uncertain; no retry')
        self.evidence['stage'] = 'integration_observation_complete'
        return dict(self.evidence)
