"""Private same-bus invocation-targeted stop plumbing; NOT a supervisor.

No public launch/stop, independent timeout, exclusive lifecycle or cleanup
proof. An invocation-bound path is not proof this caller owns that invocation.
"""
import ctypes as c
import re
from . import systemd_pidfd_lookup as look
from . import systemd_pipe_transport as transport
from . import systemd_manager_identity as manager

P=c.c_void_p
class StopError(RuntimeError):pass


def _valid(unit,invocation):
    if (type(unit) is not str or transport._UNIT.fullmatch(unit) is None or
        type(invocation) is not str or re.fullmatch(r'[0-9a-f]{32}',invocation) is None or invocation=='0'*32):
        raise ValueError('identity')


def _expected_invocation_path(invocation):
    """Exact sd_bus_path_encode form for a nonzero lowercase 128-bit ID."""
    if type(invocation) is not str or re.fullmatch(r'[0-9a-f]{32}',invocation) is None or invocation=='0'*32:
        raise ValueError('invocation')
    # The first digit of a D-Bus label must be escaped, subsequent digits may
    # remain literal. IDs beginning a-f need no escaping.
    first=invocation[0]
    component=('_%02x'%ord(first) if first.isdigit() else first)+invocation[1:]
    return '/org/freedesktop/systemd1/unit/'+component


def _invocation_path(lib,bus,owner,invocation):
    """Send exact nonzero 16 bytes to GetUnitByInvocationID, return path."""
    expected=_expected_invocation_path(invocation)
    if type(owner) is not str or re.fullmatch(r':[0-9]+\.[0-9]+',owner) is None:raise ValueError('owner')
    raw=bytes.fromhex(invocation);args=[c.c_int(len(raw))]+[c.c_int(b) for b in raw]
    reply=look._method(lib,bus,owner.encode(),look._PATH,look._INTERFACE,b'GetUnitByInvocationID',b'ay',*args)
    try:
        path=look._read_string(lib,reply,b'o')
        if path!=expected:raise ValueError('unexpected invocation path')
        return path
    finally:lib.sd_bus_message_unref(reply)


def _observation(lib,bus,owner,unit,invocation):
    """Check invocation-addressed ID, state and manager snapshots; not ownership."""
    _valid(unit,invocation)
    if look._owner(lib,bus)!=owner:raise ValueError('owner')
    manager.inspect(lib,bus,owner)
    path=_invocation_path(lib,bus,owner,invocation)
    if path!=_expected_invocation_path(invocation):raise ValueError('lookup')
    dest=owner.encode();p=path.encode();u=b'org.freedesktop.systemd1.Unit';svc=b'org.freedesktop.systemd1.Service'
    ident=look._property_string(lib,bus,dest,p,u,b'Id')
    loaded=look._property_string(lib,bus,dest,p,u,b'LoadState')
    state=look._property_string(lib,bus,dest,p,u,b'ActiveState')
    actual=look._property_invocation(lib,bus,dest,p,u)
    cgroup=look._property_string(lib,bus,dest,p,svc,b'ControlGroup')
    if (ident!=unit or loaded!='loaded' or state not in ('active','activating','deactivating','failed','inactive') or
        actual!=invocation or (cgroup and not cgroup.startswith('/')) or look._owner(lib,bus)!=owner):
        raise ValueError('identity mismatch')
    return {'state':state,'cgroup':cgroup}



def _exit_observation(lib,bus,owner,unit,invocation,main_pid,cgroup):
    """Sample stable exact-invocation main-process exit, never cleanup.

    A read pair isn't atomic and manager authenticity/ownership and cgroup
    exclusivity must be established externally. Unknown/garbage-collected unit,
    owner change, restart or mismatched fields fail closed. PID is the observed
    pre-release main PID, not a pidfd held across these reads. No raw errors.
    """
    try:
        _valid(unit,invocation)
        if type(main_pid) is not int or main_pid<=0 or type(cgroup) is not str or not cgroup.startswith('/'):
            raise ValueError('identity')
        expected=_expected_invocation_path(invocation)
        def sample():
            identity=_observation(lib,bus,owner,unit,invocation)
            if identity['state'] not in ('failed','inactive') or identity['cgroup'] not in ('',cgroup):
                raise ValueError('active or changed')
            dest=owner.encode();path=expected.encode();svc=b'org.freedesktop.systemd1.Service'
            n=lambda name,kind:look._property_number(lib,bus,dest,path,svc,name,kind)
            values=(n(b'ExecMainPID','u'),n(b'ExecMainCode','i'),n(b'ExecMainStatus','i'),n(b'MainPID','u'))
            if (values[0]!=main_pid or values[1]!=1 or not 0<=values[2]<=255 or values[3]!=0):
                raise ValueError('main exit')
            return identity,values
        a=sample();b=sample()
        if a!=b:raise ValueError('changed')
        return {'unit':unit,'invocation':invocation,'exit_kind':'exited','exit_code':a[1][2],
                'state':a[0]['state'],'main_pid':main_pid,'cleanup':'not_observed',
                'ownership':'not_proven','engine_launch_authorized':False}
    except Exception:raise StopError('exit unavailable or changed; external recovery required') from None


def _send_invocation_once(lib,bus,owner,unit,invocation):
    """One Unit.Stop on invocation path; reply is only a queued job.

    Private primitive only. Caller independently owns and binds that exact
    invocation, manager, external watchdog and sole lifecycle. v255 source
    supports invocation-path lookup, but manager authorization may defer and
    race; no atomic conditional-stop guarantee is asserted. Never retry any
    error or lost reply; no name-based fallback. No success means cleanup.
    """
    try:
        _valid(unit,invocation)
        if type(owner) is not str or re.fullmatch(r':[0-9]+\.[0-9]+',owner) is None:raise ValueError('owner')
        path=_expected_invocation_path(invocation).encode()
    except ValueError:raise StopError('invalid stop identity') from None
    reply=None
    try:
        reply=look._method(lib,bus,owner.encode(),path,b'org.freedesktop.systemd1.Unit',b'Stop',b's',c.c_char_p(b'fail'))
        job=look._read_string(lib,reply,b'o')
        if re.fullmatch(r'/org/freedesktop/systemd1/job/[0-9]+',job) is None:raise ValueError('job path')
        return {'stop':'job_enqueued_not_completed','job_path':job,'unit_identity':'not_proven',
                'cleanup':'not_observed','engine_launch_authorized':False}
    except BaseException:raise StopError('stop outcome unknown; do not retry') from None
    finally:
        if reply is not None and reply.value:lib.sd_bus_message_unref(reply)


def run():raise StopError('stop blocked: exclusive lifecycle and watchdog not established')
