"""One-shot baseline assembly for a *prestarted*, already contained process.

Developer-only WIP. This is not a launcher, sandbox, provenance verifier,
CI serialization, budget guard, startup review or cleanup supervisor. The
caller must use a fresh isolated VM and independently supervise descendants.
No real provider, user data, or production-engine gate is used here.
"""
import asyncio
import json

from astra.policy import json_equal, rules_for
from astra.transport import Client
from .baseline_controller import SYNTHETIC_PASSWORD, observe_baseline
from .genuine_run_layout import synthetic_environment
from .listener_observer import DirectListenerObserver
from .synthetic_baseline_gate import check_baseline_info, check_baseline_config
from .synthetic_session_probe import ObservedClient, SessionWorkerEvidence


class BaselineOnlyError(RuntimeError):
    pass


def baseline_config():
    """Fixed restrictive baseline config, with no external provider configured.

    Runtime normalization and startup effects are unverified; the exact-match
    check intentionally fails closed if the genuine server differs.
    """
    return {'update':'disable', 'share':'disabled', 'snapshots':False,
            'warming':False, 'formatter':False, 'lsp':False,
            'compaction':{'auto':False,'background':False},
            'experimental':{'all_flags':False,'full_codemode':False,
                            'automations':False,'subagent_depth':0},
            'agents':{'build':{'steps':4}}, 'providers':{},
            'permissions':rules_for([])}


def baseline_environment():
    """Complete replacement child environment, not merged with the host."""
    env = synthetic_environment()
    env['OPENCODE_CONFIG_CONTENT'] = json.dumps(baseline_config(), separators=(',',':'))
    return env


class BaselineOnly:
    """Observe exactly one already-started child; never launches or retries.

    A successful observation is not an identity attestation or validation of
    startup and cleanup. The direct listener callback is snapshot based. The
    thread used by Client may outlive cancellation. Independent hard cleanup
    is required even on apparent success, especially if exceptions occur.
    """
    def __init__(self):
        self._used = False
        self.worker = SessionWorkerEvidence()
        self.evidence = {'stage':'not_started', 'engine_launch_authorized':False,
                         'genuine_engine':'not_attested', 'isolation':'not_verified',
                         'descendant_cleanup':'not_verified', 'provenance':'not_verified'}

    async def run(self, process, verify_config_directory):
        if self._used:
            raise BaselineOnlyError('baseline already attempted; do not replay')
        self._used = True
        self.evidence['stage'] = 'entered'
        try:
            if not callable(verify_config_directory):
                raise ValueError('config verifier required')
            observer = DirectListenerObserver(process.pid)
            async def exercise(port, info, config):
                self.evidence['stage'] = 'checking_baseline'
                info_check = check_baseline_info(port, process.pid, info)
                config_check = check_baseline_config(config, baseline_config(), verify_config_directory)
                # Independent Astra transport reads, with advisory listener
                # snapshots before/after both. JSON comparison is type strict:
                # Python otherwise equates true with 1 and 1 with 1.0.
                def client_read():
                    client = ObservedClient(Client(port, SYNTHETIC_PASSWORD), port, observer)
                    return (client.request('GET', '/api/info', timeout=2),
                            client.request('GET', '/api/config', timeout=2))
                # asyncio cancellation does not stop a running executor call.
                # A submitted call remains unknown until its wrapper returns.
                self.worker.submit_once()
                got_info, got_config = await asyncio.to_thread(self.worker.invoke, client_read)
                if not json_equal(got_info, info) or not json_equal(got_config, config):
                    raise ValueError('Astra transport baseline mismatch')
                self.evidence['info_check'] = info_check
                self.evidence['config_check'] = config_check
                self.evidence['astra_client_info_matches_baseline'] = True
                self.evidence['astra_client_config_matches_baseline'] = True
                self.evidence['stage'] = 'baseline_checked'
                return {'baseline_checks':'matched', 'astra_info':'matched',
                        'astra_config':'matched'}
            result = await observe_baseline(process, timeout=60, verify_listener=observer,
                                            exercise=exercise)
            if (not isinstance(result,dict) or result.get('streams_complete') is not True or
                type(result.get('direct_exit_code')) is not int or result['direct_exit_code'] != 0 or
                result.get('exercise_result') != {'baseline_checks':'matched','astra_info':'matched',
                                                   'astra_config':'matched'} or
                self.evidence['stage'] != 'baseline_checked' or
                self.worker.snapshot() != 'call_completed'):
                raise ValueError('baseline completion evidence missing')
            self.evidence['stderr_bytes'] = result['stderr_bytes']
            self.evidence['stage'] = 'baseline_observation_complete'
            return dict(self.evidence)
        except asyncio.CancelledError:
            self.evidence['stage'] = 'cancelled_outcome_uncertain'
            raise
        except Exception:
            self.evidence['stage'] = 'failed_outcome_uncertain'
            raise BaselineOnlyError('baseline failed or uncertain; no retry') from None
        finally:
            self.evidence['astra_client_worker_call'] = self.worker.snapshot()
