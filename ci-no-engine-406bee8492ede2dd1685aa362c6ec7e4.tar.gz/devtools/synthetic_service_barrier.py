"""Fixed pre-entry admission rendezvous; not a supervisor or authorization.

Only the existing fixed synthetic bootstrap may call `receive_on_stdin`.
The parent must supply an exclusive private pipe as stdin, bind its other end
and the service invocation, check its real settings, and kill/clean the unit
on any uncertainty. The frame is public protocol data, not authentication.
"""
import fcntl
import os
import select
import stat
import sys
import time

# Complete fixed frame followed by EOF. Single action, no command or data.
_FRAME=b'ASTRA-SYNTHETIC-ADMIT-1\n'
_TIMEOUT=15.0
class BarrierError(RuntimeError): pass

def receive_on_stdin():
    """Require complete frame AND EOF before replacing stdin with /dev/null.

    EOF without the frame, wrong/extra bytes, lost writer, invalid FD and
    deadline all fail before project driver imports. Direct syscalls can hang;
    this timeout is not a hard external watchdog. Success does not validate
    manager properties, caller identity, network, root, or lifecycle.
    """
    fd=0
    try:
        s=os.fstat(fd)
        if not stat.S_ISFIFO(s.st_mode): raise ValueError('not pipe')
        if fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE==os.O_WRONLY: raise ValueError('not readable')
        # The caller must own this open-file description; the flag is shared.
        os.set_blocking(fd,False)
        deadline=time.monotonic()+_TIMEOUT; buf=bytearray()
        while True:
            remaining=deadline-time.monotonic()
            if remaining<=0: raise ValueError('deadline')
            ready,_,_=select.select([fd],[],[],remaining)
            if not ready: raise ValueError('deadline')
            try: data=os.read(fd,len(_FRAME)+1-len(buf))
            except BlockingIOError: continue
            if not data:
                if bytes(buf)!=_FRAME: raise ValueError('incomplete')
                break
            buf.extend(data)
            if len(buf)>len(_FRAME) or not _FRAME.startswith(buf): raise ValueError('unexpected frame')
        # Never let the release descriptor escape into engine/children. The
        # pipe's write end must be closed by the parent to deliver EOF.
        os.close(fd)
        null=os.open('/dev/null',os.O_RDONLY|os.O_CLOEXEC)
        # The inherited fd is now harmless /dev/null, not the admission pipe.
        # Keep standard input available to programs that inherit it across exec.
        if null!=fd:
            try: os.dup2(null,fd,inheritable=True)
            finally: os.close(null)
        else: os.set_inheritable(fd,True)
        sys.stdin=os.fdopen(fd,'r',encoding='ascii',closefd=False)
        return None
    except (OSError,ValueError,TypeError,OverflowError):
        raise BarrierError('prestart admission unavailable') from None
