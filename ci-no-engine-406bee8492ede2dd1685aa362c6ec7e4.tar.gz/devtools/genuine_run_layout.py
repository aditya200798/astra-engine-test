"""Developer-only fresh layout for a future disposable genuine-server harness.

This module does not launch, execute, mount, contain, attest, clean up, or
approve anything. It must only be used with a newly created disposable root
in an independently supervised developer VM, never user data. Returned paths
are for a future mount at /work, not host paths.
"""
import os
import stat

from .baseline_controller import SYNTHETIC_PASSWORD

# No arbitrary file paths or commands. Each directory is an immediate child of
# the already opened empty root; no contents or configuration are written.
DIRECTORIES = ('home', 'config', 'data', 'cache', 'state', 'tmp', 'project')


class LayoutError(RuntimeError):
    pass


def synthetic_environment():
    """Return an exact fixed replacement environment, never merged with os.environ.

    These source-informed settings have NOT been verified against the binary.
    The password is public and only suitable for an isolated synthetic run.
    """
    return {
        'PATH': '/usr/bin:/bin', 'LANG': 'C', 'LC_ALL': 'C',
        'HOME': '/work/home', 'XDG_CONFIG_HOME': '/work/config',
        'XDG_DATA_HOME': '/work/data', 'XDG_CACHE_HOME': '/work/cache',
        'XDG_STATE_HOME': '/work/state', 'TMPDIR': '/work/tmp',
        'OPENCODE_CONFIG_DIR': '/work/config',
        'OPENCODE_SERVER_PASSWORD': SYNTHETIC_PASSWORD,
        'OPENCODE_DISABLE_MODELS_FETCH': '1',
        'OPENCODE_CONFIG_PROJECT_DISABLE': '1',
        'OPENCODE_DISABLE_CLAUDE_CODE': '1',
        'OPENCODE_FILEWATCHER_DISABLE': '1',
        'OPENCODE_DISABLE_FFF': '1',
    }


def prepare_fixed_service_work():
    """Create the fixed /work layout from inside the future service only.

    Public fixed path, no arguments. The previously empty work root must be
    owned by the already-dropped UID/GID 65534 and mode 0700. The path check
    and underlying FD operations are observations, not protection against
    concurrent writers, namespace confusion, ACLs, parent aliases or mounts.
    On failure, dispose the full tree externally; never reuse it. No launch.
    """
    if (os.getuid() != 65534 or os.geteuid() != 65534 or
        os.getgid() != 65534 or os.getegid() != 65534 or os.getgroups() != []):
        raise LayoutError('fixed unprivileged service identity required')
    fd = None
    try:
        flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
        fd = os.open('/work', flags)
        before = os.fstat(fd)
        named = os.stat('/work', follow_symlinks=False)
        if (before.st_dev, before.st_ino) != (named.st_dev, named.st_ino):
            raise LayoutError('work root changed')
        result = prepare_fresh_layout(fd)
        after = os.stat('/work', follow_symlinks=False)
        if (before.st_dev, before.st_ino) != (after.st_dev, after.st_ino):
            raise LayoutError('work root changed; dispose tree')
        return result
    except LayoutError:
        raise
    except (OSError, ValueError, AttributeError):
        raise LayoutError('work initialization failed; dispose tree') from None
    finally:
        if fd is not None: os.close(fd)


def prepare_fresh_layout(root_fd):
    """Create/check seven empty private directories using an existing root FD.

    No recursive deletion is attempted, including on failure: partial contents
    must be disposed of by the VM owner after all processes are stopped. Root
    and each child are inspected without following child symlinks. Calls may
    block in the kernel and must be externally watched. A successful report is
    *not* assurance about parent paths, ACLs, mounts, concurrent same-UID/root
    mutation, process environment or runtime startup.
    """
    if type(root_fd) is not int or root_fd < 0:
        raise LayoutError('open directory descriptor required')
    for flag in ('O_DIRECTORY', 'O_NOFOLLOW', 'O_CLOEXEC'):
        if not hasattr(os, flag):
            raise LayoutError('required OS flags unavailable')
    opened = []
    try:
        root_stat = os.fstat(root_fd)
        if (not stat.S_ISDIR(root_stat.st_mode) or root_stat.st_uid != os.geteuid()
                or stat.S_IMODE(root_stat.st_mode) != 0o700 or os.listdir(root_fd)):
            raise LayoutError('root must be empty owner-private directory')
        for name in DIRECTORIES:
            os.mkdir(name, 0o700, dir_fd=root_fd)
            fd = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW |
                         os.O_CLOEXEC, dir_fd=root_fd)
            opened.append(fd)
            st = os.fstat(fd)
            if (not stat.S_ISDIR(st.st_mode) or st.st_uid != os.geteuid()
                    or stat.S_IMODE(st.st_mode) != 0o700 or os.listdir(fd)):
                raise LayoutError('created directory not empty owner-private')
        # Recheck both names and inode identities to detect normal replacement.
        if set(os.listdir(root_fd)) != set(DIRECTORIES):
            raise LayoutError('unexpected root entries')
        for name, fd in zip(DIRECTORIES, opened):
            st = os.fstat(fd)
            linked = os.stat(name, dir_fd=root_fd, follow_symlinks=False)
            if ((st.st_dev, st.st_ino) != (linked.st_dev, linked.st_ino)
                    or stat.S_IMODE(st.st_mode) != 0o700
                    or st.st_uid != os.geteuid() or os.listdir(fd)):
                raise LayoutError('created directory changed')
        return {'directories': list(DIRECTORIES), 'cwd': '/work/project',
                'environment': synthetic_environment(), 'executed': False,
                'engine_launch_authorized': False, 'cleanup': 'caller_required',
                'isolation': 'not_verified', 'startup': 'not_verified'}
    except LayoutError:
        raise
    except (OSError, ValueError) as exc:
        raise LayoutError('layout preparation failed; cleanup required') from exc
    finally:
        for fd in opened:
            os.close(fd)
