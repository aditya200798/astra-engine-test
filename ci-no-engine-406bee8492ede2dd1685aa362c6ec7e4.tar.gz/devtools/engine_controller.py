"""Disabled genuine-engine controller design: strict lease-output parsing only.

No process, filesystem, network or provider access. A successful parse is not
readiness or isolation. Actual server startup remains intentionally unavailable.
"""
import json
import re
from urllib.parse import urlsplit

MAX_LINE = 8192
MAX_LINES = 64
MAX_TOTAL = 65536


class ObservationError(ValueError):
    pass


def _object_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate object member')
        result[key] = value
    return result


def _invalid_constant(_):
    raise ValueError('invalid JSON constant')


def published_port(line):
    """Parse a single newline-free upstream lease record, returning literal IPv4 port.

    Line must be raw bytes to prevent ambiguous decoding; only the exact record
    shape and literal localhost URL are accepted. This does not contact a server.
    """
    if not isinstance(line, bytes) or not line or len(line) > MAX_LINE:
        raise ObservationError('invalid record length or type')
    if b'\n' in line or b'\r' in line or b'\0' in line:
        raise ObservationError('invalid record controls')
    try:
        obj = json.loads(line.decode('utf-8', errors='strict'), object_pairs_hook=_object_pairs,
                         parse_constant=_invalid_constant)
        if not isinstance(obj, dict) or set(obj) != {'url'} or not isinstance(obj['url'], str):
            raise ValueError('not a lease record')
        url = obj['url']
        if re.fullmatch(r'http://127\.0\.0\.1:[0-9]{1,5}/?', url) is None:
            raise ValueError('unexpected URL')
        parsed = urlsplit(url)
        if not (parsed.scheme == 'http' and parsed.hostname == '127.0.0.1'
                and parsed.username is None and parsed.password is None
                and parsed.path in ('', '/') and not parsed.query and not parsed.fragment
                and parsed.port is not None and 1 <= parsed.port <= 65535):
            raise ValueError('unexpected URL')
        return parsed.port
    except (ValueError, UnicodeError, RecursionError, TypeError):
        raise ObservationError('invalid lease record') from None


class LeaseObservation:
    """Bounded incremental parser for synthetic stdout; second lease is an error.

    Assumes caller supplies stdout only, not stderr. Each nonempty line must be a
    lease record: unexpected logs fail closed rather than guessing. finish() is
    required to notice an unterminated trailing line. EOF does not prove child or
    descendants exited. Buffer limits do not impose an elapsed-time deadline.
    """
    def __init__(self):
        self._partial = bytearray()
        self._total = 0
        self._lines = 0
        self._port = None
        self._failed = False
        self._finished = False

    def feed(self, data):
        if self._failed or self._finished:
            raise ObservationError('observation already closed')
        if not isinstance(data, bytes):
            self._failed = True
            raise ObservationError('expected bytes')
        self._total += len(data)
        if self._total > MAX_TOTAL:
            self._failed = True
            raise ObservationError('total output exceeded')
        self._partial.extend(data)
        try:
            while b'\n' in self._partial:
                line, _, rest = self._partial.partition(b'\n')
                self._partial = bytearray(rest)
                self._lines += 1
                if self._lines > MAX_LINES:
                    raise ObservationError('line count exceeded')
                if self._port is not None:
                    raise ObservationError('unexpected extra output')
                self._port = published_port(bytes(line))
            if self._port is not None and self._partial:
                raise ObservationError('unexpected extra output')
            if len(self._partial) > MAX_LINE:
                raise ObservationError('line length exceeded')
        except ObservationError:
            self._failed = True
            raise

    def port_if_complete(self):
        """Return a published port without waiting for EOF, or None if incomplete.

        This is only a provisional observation: the caller must continue draining
        and feeding output until EOF and fail on later output/errors. It proves
        neither server readiness nor authenticity and never launches anything.
        """
        if self._failed or self._finished:
            raise ObservationError('observation already closed')
        return self._port

    def finish(self):
        if self._failed or self._finished:
            raise ObservationError('observation already closed')
        self._finished = True
        if self._partial or self._port is None:
            raise ObservationError('incomplete lease record')
        return {'port': self._port, 'server_ready': 'not_verified',
                'auth': 'not_verified', 'cleanup': 'not_verified'}


def start(*args, **kwargs):
    """Reserved: deliberately fail before inspecting arguments or doing any I/O."""
    raise RuntimeError('genuine-engine controller disabled: isolation, provenance and startup unverified')
