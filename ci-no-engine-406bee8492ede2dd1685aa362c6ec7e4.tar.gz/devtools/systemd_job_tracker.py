"""Same-connection JobRemoved subscription, import-only and never admission.

Private tracker matches an eventual reply to buffered signals. It neither
starts nor stops units and cannot prove bus/manager authenticity, exclusive
unit ownership, isolation, watchdog readiness or cleanup. Single-threaded use
and an external wall-clock watchdog are mandatory.
"""
import ctypes as c
import re
import time
from . import systemd_pidfd_lookup as look

P=c.c_void_p
CALLBACK=c.CFUNCTYPE(c.c_int,P,P,P)
class TrackerError(RuntimeError):pass
_MAX=128


def _proto(lib):
    look._proto(lib)
    specs={'sd_bus_match_signal':([P,c.POINTER(P),c.c_char_p,c.c_char_p,c.c_char_p,c.c_char_p,CALLBACK,P],c.c_int),
           'sd_bus_slot_unref':([P],P),
           'sd_bus_process':([P,c.POINTER(P)],c.c_int),
           'sd_bus_wait':([P,c.c_uint64],c.c_int),
           'sd_bus_message_get_sender':([P],c.c_char_p)}
    for name,(args,ret) in specs.items():
        fn=getattr(lib,name);fn.argtypes=args;fn.restype=ret


class _Tracker:
    def __init__(self,lib,bus,owner,unit):
        from .systemd_pipe_transport import _UNIT
        if (type(owner) is not str or re.fullmatch(r':[0-9]+\.[0-9]+',owner) is None or
            type(unit) is not str or (_UNIT.fullmatch(unit) is None and re.fullmatch(r'astra[0-9a-f]{32}\.slice',unit) is None) or not bus):raise TrackerError('invalid tracker inputs')
        self.lib=lib;self.bus=bus;self.owner=owner;self.unit=unit;self.events=[]
        self.broken=False;self.subscribed=False;self.slot=P();self.closed=False
        self.callback=CALLBACK(self._on_message)
    def _on_message(self,msg,userdata,error):
        try:
            sender=self.lib.sd_bus_message_get_sender(msg)
            if sender is None or sender.decode('ascii')!=self.owner:return 0
            ident=c.c_uint32();path=c.c_char_p();name=c.c_char_p();result=c.c_char_p()
            if self.lib.sd_bus_message_read(msg,b'uoss',c.byref(ident),c.byref(path),c.byref(name),c.byref(result))<=0:
                raise ValueError('signal')
            event=(ident.value,path.value.decode('ascii'),name.value.decode('ascii'),result.value.decode('ascii'))
            if (re.fullmatch(r'/org/freedesktop/systemd1/job/[0-9]+',event[1]) is None or
                int(event[1].rsplit('/',1)[1])!=event[0] or len(event[2])>256 or len(event[3])>40):
                raise ValueError('signal values')
            if len(self.events)>=_MAX:raise ValueError('event overflow')
            self.events.append(event)
        except BaseException:self.broken=True
        return 0
    def subscribe(self,*,existing=None):
        """Install a fresh match, subscribe once per connection or reuse proof.

        Reuse is only for an extant same-lib/bus/owner successfully subscribed
        tracker with a live match and unchanged owner. No unsubscribe is sent;
        this connection-bound subscription ends when caller closes the bus.
        Separate callbacks and buffered jobs remain bound to their own unit.
        This is not proof of manager authenticity or atomic ownership.
        """
        if self.closed or self.subscribed:raise TrackerError('tracker state')
        try:
            if existing is not None and (type(existing) is not _Tracker or existing is self or
                existing.lib is not self.lib or existing.bus is not self.bus or existing.owner!=self.owner or
                existing.closed or existing.broken or not existing.subscribed or not existing.slot.value):
                raise ValueError('invalid existing subscription')
            r=self.lib.sd_bus_match_signal(self.bus,c.byref(self.slot),self.owner.encode(),look._PATH,
                  look._INTERFACE,b'JobRemoved',self.callback,None)
            if r<0 or not self.slot.value:raise ValueError('match')
            if existing is None:
                reply=look._method(self.lib,self.bus,self.owner.encode(),look._PATH,look._INTERFACE,b'Subscribe',None)
                try:
                    if look._owner(self.lib,self.bus)!=self.owner:raise ValueError('owner changed')
                finally:self.lib.sd_bus_message_unref(reply)
            elif look._owner(self.lib,self.bus)!=self.owner:
                raise ValueError('owner changed')
            self.subscribed=True
        except Exception:
            self.close();raise TrackerError('job subscription unavailable') from None
    def await_job(self,job,timeout):
        """Report a matching completion only, retaining queued early signals.

        This does not assert ownership, execution identity, stop or isolation.
        The fixed time bound cannot interrupt a stuck native syscall.
        """
        if (self.closed or not self.subscribed or type(job) is not str or
            re.fullmatch(r'/org/freedesktop/systemd1/job/[0-9]+',job) is None or
            type(timeout) not in (int,float) or not 0<timeout<=10):raise TrackerError('invalid wait')
        deadline=time.monotonic()+timeout
        try:
            while True:
                if self.broken:raise ValueError('invalid signal')
                matching=[e for e in self.events if e[1]==job]
                if len(matching)>1:raise ValueError('duplicate')
                if matching:
                    _,_,unit,result=matching[0]
                    if unit!=self.unit or result not in ('done','canceled','timeout','failed','dependency','skipped','invalid','assert','unsupported','collected','once'):
                        raise ValueError('mismatch')
                    if look._owner(self.lib,self.bus)!=self.owner:raise ValueError('owner changed')
                    return {'job_result':result,'unit_identity':'not_proven','cleanup':'not_observed','engine_launch_authorized':False}
                left=deadline-time.monotonic()
                if left<=0:raise ValueError('deadline')
                r=self.lib.sd_bus_process(self.bus,None)
                if r<0:raise ValueError('process')
                if r==0 and self.lib.sd_bus_wait(self.bus,c.c_uint64(max(1,min(int(left*1e6),100000))))<0:raise ValueError('wait')
        except Exception:raise TrackerError('job result unknown') from None
    def close(self):
        if self.closed:return
        self.closed=True
        if self.slot.value:self.lib.sd_bus_slot_unref(self.slot);self.slot=P()
        # Subscription is connection-bound; owner closes connection externally.


def run():raise TrackerError('no manager job tracking orchestration approved')
