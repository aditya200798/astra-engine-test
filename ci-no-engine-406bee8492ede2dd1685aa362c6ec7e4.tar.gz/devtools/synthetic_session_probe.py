"""Developer-only building blocks for one fake-provider Session exercise.

No launcher or isolation. Only a credential-free disposable VM with isolated
loopback and an independent hard supervisor may use these. No production gate.
"""
import asyncio
import threading
from pathlib import Path

from astra.policy import check_config, json_equal, rules_for
from astra.session import Session
from astra.storage import Store
from astra.transport import Client, ProtocolError, strict_json
from . import fake_responses as fake
from .baseline_controller import SYNTHETIC_PASSWORD

PROVIDER_ID = 'astra-fixture'
SYNTHETIC_MODEL = {'providerID': PROVIDER_ID, 'id': fake.MODEL}
PROMPT = 'Reply with the synthetic fixture answer.'
WORK = '/work/project'
CONFIG_DIR = '/work/config'
STATE_PARENT = '/work/state'


def synthetic_config(port):
    """Return one fixed localhost-only provider; no caller-supplied URL/key."""
    if type(port) is not int or not 1 <= port <= 65535:
        raise ValueError('invalid fixture port')
    rules = rules_for([])
    config = {'update':'disable', 'share':'disabled', 'snapshots':False,
              'warming':False, 'formatter':False, 'lsp':False,
              'compaction':{'auto':False,'background':False},
              'experimental':{'all_flags':False,'full_codemode':False,
                              'automations':False,'subagent_depth':0},
              'agents':{'build':{'steps':4}},
              'providers':{PROVIDER_ID:{'name':'Astra Synthetic Fixture',
                  'env':['ASTRA_SYNTHETIC_API_KEY'],
                  'package':'@opencode/ai/providers/openai-compatible/responses',
                  'settings':{'baseURL':'http://127.0.0.1:%d/v1' % port,'timeout':10000},
                  'models':{fake.MODEL:{'name':'Astra Synthetic Fixture Model',
                      'capabilities':{'tools':False},
                      'limit':{'context':32000,'output':2048}}}}},
              'permissions':rules}
    return config


def synthetic_server_environment(port):
    """Complete replacement child env only; config/key are synthetic, not private."""
    from .genuine_run_layout import synthetic_environment
    import json
    env = synthetic_environment()
    env['ASTRA_SYNTHETIC_API_KEY'] = fake.SYNTHETIC_KEY
    env['OPENCODE_CONFIG_CONTENT'] = json.dumps(synthetic_config(port), separators=(',',':'))
    return env


def _request_contains_prompt(body):
    # Record only the user part. System prompt shape, other content, exact SDK
    # framing and absence of hidden channels require independent inspection.
    if not isinstance(body, dict) or body.get('model') != fake.MODEL or body.get('stream') is not True:
        return False
    items = body.get('input')
    if not isinstance(items, list): return False
    users = [item for item in items if isinstance(item,dict) and item.get('role') == 'user']
    if len(users) != 1: return False
    content = users[0].get('content')
    return content == PROMPT or (isinstance(content,list) and
        json_equal(content,[{'type':'input_text','text':PROMPT}]))


def _matches_fixture_final_parts(parts):
    """Accept only source-informed encodings for this one fake answer.

    OpenCode may return provider-native item metadata; a strict fake-specific
    allowlist keeps the answer and fixture item identity exact. This is a
    hypothesis based on source, not evidence of any actual server response.
    """
    if type(parts) is not list or len(parts) != 1 or type(parts[0]) is not dict:
        return False
    part = parts[0]
    if set(part) not in ({'type', 'text'}, {'type', 'text', 'native'}):
        return False
    if part['type'] != 'text' or part['text'] != fake.ANSWER:
        return False
    if 'native' in part:
        return json_equal(part['native'], {'itemId': 'msg_astra_fixture'})
    return True


def inspect_result(result, ledger):
    """Conservatively cross-check Session result and in-memory fixture evidence.

    Only trusted synthetic state. Independent snapshots can race; handled count
    excludes unsupported methods, HTTP parse errors and other traffic. Delivery is a local write, never proof of peer receipt.
    Caller must retain the evidence on failure and must never replay this task.
    """
    record = ledger.snapshot()
    diagnostics = ledger.diagnostics()
    if (diagnostics.get('handled_connections') != 1 or
        diagnostics.get('handled_http_requests') != 1 or
        diagnostics.get('handled_rejections') != 0 or
        not isinstance(result,dict) or result.get('status') != 'succeeded' or
        not _matches_fixture_final_parts(result.get('final_parts')) or
        not json_equal(result.get('parts'),result.get('final_parts')) or
        result.get('turn_has_reasoning') is not False or type(result.get('assistant_count')) is not int or
        result['assistant_count'] != 1 or result.get('final_redacted') is not False or not isinstance(record,dict) or
        record.get('valid_attempts') != 1 or
        record.get('response_delivery') != 'write_completed_not_client_receipt'):
        raise ValueError('synthetic result or ledger mismatch')
    try:
        request = strict_json(record['raw'])
    except (ValueError, KeyError, TypeError, UnicodeError, RecursionError):
        raise ValueError('synthetic request invalid') from None
    if not _request_contains_prompt(request):
        raise ValueError('synthetic user request mismatch')
    return {'session_status':'succeeded', 'fixture_valid_attempts':1,
            'fixture_request_sha256':record['sha256'],
            'fixture_response_delivery':record['response_delivery'],
            'fixture_user_prompt_matches':True, 'fixture_handled_http_requests':1,
            'genuine_engine':'not_attested',
            'isolation':'not_verified', 'descendant_cleanup':'not_verified',
            'all_network_traffic':'not_observed', 'tool_read':'not_run'}



class ObservedClient:
    """Fail-sticky listener snapshots around each underlying Astra request.

    A snapshot is not authentication: it races rebinding, PID/FD changes and
    socket transfer. The caller supplies a verifier tied to the server PID in
    the same network namespace. A failed request/observation prohibits any
    further calls through this wrapper, including interrupt or retry: if the
    request escaped, its result is unknown and must not be resubmitted.
    """
    def __init__(self, client, port, verify_listener):
        if type(port) is not int or not 1 <= port <= 65535 or not callable(verify_listener):
            raise ValueError('listener verifier and valid port required')
        self.client = client
        self.port = port
        self.verify_listener = verify_listener
        self.failed = False

    def request(self, method, path, body=None, timeout=10):
        if self.failed:
            raise ProtocolError('synthetic listener observation already failed')
        try:
            if self.verify_listener(self.port) is not True:
                raise ProtocolError('listener not observed before request')
            result = self.client.request(method, path, body, timeout=timeout)
            if self.verify_listener(self.port) is not True:
                raise ProtocolError('listener not observed after request')
            return result
        except Exception:
            # No raw exception or response; a request might have been admitted.
            self.failed = True
            raise ProtocolError('synthetic request or listener observation uncertain') from None

def run_session(server_port, provider_port, ledger, verify_config_directory, verify_listener):
    """Run fixed text prompt once against already-running synthetic setup.

    Caller must establish lifecycle, fixture listener identity, fixed synthetic
    env/config, a fresh private /work/state, isolation and external cleanup.
    Throws on uncertainty and never retries. Failure may leave a submitted
    operation; caller must preserve journal/ledger and not re-execute blindly.
    Config and listener callbacks are advisory and raceable, not an OS boundary.
    """
    if type(server_port) is not int or not 1 <= server_port <= 65535:
        raise ValueError('invalid server port')
    if not callable(verify_config_directory): raise ValueError('config verifier required')
    if not callable(verify_listener): raise ValueError('listener verifier required')
    config = synthetic_config(provider_port)
    rules = rules_for([])
    state_path = Path(STATE_PARENT) / 'astra-synthetic-session'
    # A second invocation must never create/reopen a prior test state. This is
    # not atomic against a same-UID attacker; disposable single writer only.
    if state_path.exists() or state_path.is_symlink():
        raise ValueError('synthetic session state already exists; inspect, do not replay')
    store = Store(state_path)
    store.acquire()
    try:
        client = ObservedClient(Client(server_port, SYNTHETIC_PASSWORD), server_port, verify_listener)
        session = Session(client, store, WORK, rules, config,
            {'PATH':'/usr/bin:/bin','HOME':'/work/home','TMPDIR':'/work/tmp','LANG':'C'},
            [SYNTHETIC_PASSWORD, fake.SYNTHETIC_KEY],
            {'trusted_directory':CONFIG_DIR,'verify_directory':verify_config_directory},
            model=dict(SYNTHETIC_MODEL))
        result = session.prompt(PROMPT, deadline_seconds=20, poll_interval=.1)
        return inspect_result(result, ledger)
    finally:
        store.release()


class SessionWorkerEvidence:
    """Conservative observation of one function call, not process quiescence.

    Unknown covers submitted-but-not-started, running, and lost submission.
    Completion means the wrapped callable returned or raised and the wrapper's
    completion signal was set. It does not prove run_session's store-release
    finally was reached or succeeded, or that the executor thread or process
    stopped. It is not an independent attestation or an external deadline.
    """
    def __init__(self):
        self._lock = threading.Lock()
        self._submitted = False
        self._claimed = False
        self._completed = threading.Event()

    def submit_once(self):
        with self._lock:
            if self._submitted:
                raise ValueError('session worker already submitted; no retry')
            self._submitted = True

    def invoke(self, function, *args):
        with self._lock:
            if not self._submitted or self._claimed:
                raise ValueError('invalid session worker invocation')
            self._claimed = True
        try:
            return function(*args)
        finally:
            self._completed.set()

    def snapshot(self):
        with self._lock:
            if not self._submitted:
                return 'not_submitted'
            return 'call_completed' if self._completed.is_set() else 'unknown'


async def exercise_astra_session(port, info, config, *, provider_port, ledger, verify_config_directory, verify_listener, worker):
    """observe_baseline exercise callback; executor may survive cancellation."""
    if not callable(verify_listener): raise ValueError('listener verifier required')
    expected = synthetic_config(provider_port)
    check_config(config, expected, trusted_directory=CONFIG_DIR,
                 verify_directory=verify_config_directory)
    if not isinstance(worker, SessionWorkerEvidence):
        raise ValueError('session worker evidence required')
    worker.submit_once()
    return await asyncio.to_thread(worker.invoke, run_session, port, provider_port, ledger,
                                   verify_config_directory, verify_listener)
