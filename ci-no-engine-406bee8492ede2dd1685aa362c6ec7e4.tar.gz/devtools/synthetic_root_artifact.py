"""Place a pinned staged artifact in a synthetic root, without executing it.

Only for an exclusively owned disposable VM. Not an isolation, provenance,
mount, runtime, supervisor, cleanup or launch-authorization mechanism.
"""
import hashlib
import os
import stat
from .pinned_engine_stage import BINARY_SHA256, BINARY_SIZE
from .synthetic_root_skeleton import _check_root_entries, _dir, _identity

CHUNK=1024*1024
class ArtifactError(RuntimeError): pass

def _put(source_fd,root_fd,owner,group,size,digest):
    """Private configurable test core; caller disposes full root on any error.

    Caller retains descriptors, supplies a fresh skeleton and excludes all
    concurrent root/same-owner writers. No recursive removal or retry is done.
    """
    if (type(source_fd) is not int or source_fd<0 or type(root_fd) is not int or root_fd<0 or
        type(owner) is not int or owner!=os.geteuid() or type(group) is not int or group!=os.getegid() or
        type(size) is not int or size<=0 or type(digest) is not str or len(digest)!=64 or
        any(c not in '0123456789abcdef' for c in digest)):
        raise ArtifactError('invalid fixed staging input')
    destdir=out=None; touched_dir=False
    def ident(s):
        return (s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
    def no_acl(fd):
        return not any(x in ('system.posix_acl_access','system.posix_acl_default') for x in os.listxattr(fd))
    def read_digest(fd):
        h=hashlib.sha256(); at=0
        while at<size:
            block=os.pread(fd,min(CHUNK,size-at),at)
            if not block: raise ValueError('short file')
            h.update(block); at+=len(block)
        if os.pread(fd,1,at): raise ValueError('long file')
        return h.hexdigest()
    try:
        flags=os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC
        source=os.fstat(source_fd)
        if (not stat.S_ISREG(source.st_mode) or source.st_uid!=owner or source.st_nlink!=1 or
            stat.S_IMODE(source.st_mode)!=0o400 or source.st_size!=size or not no_acl(source_fd)):
            raise ValueError('invalid staged source')
        root_before=_dir(root_fd,owner,group,0o555)
        _check_root_entries(root_fd)
        destdir=os.open('engine',flags,dir_fd=root_fd)
        dest_before=_dir(destdir,owner,group,0o555)
        if (_identity(dest_before)!=_identity(os.stat('engine',dir_fd=root_fd,follow_symlinks=False))
            or os.listdir(destdir)): raise ValueError('invalid destination')
        # An error after this point requires full-tree disposal even if an
        # attempted mode restoration succeeds. Record before mutating.
        touched_dir=True; os.fchmod(destdir,0o700); _dir(destdir,owner,group,0o700)
        out=os.open('opencode',os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=destdir)
        os.fchmod(out,0o400)
        h=hashlib.sha256(); pos=0
        while pos<size:
            b=os.pread(source_fd,min(CHUNK,size-pos),pos)
            if not b: raise ValueError('short source')
            h.update(b); view=memoryview(b)
            while view:
                n=os.write(out,view)
                if n<=0: raise OSError('short write')
                view=view[n:]
            pos+=len(b)
        if (os.pread(source_fd,1,pos) or h.hexdigest()!=digest or
            ident(os.fstat(source_fd))!=ident(source) or read_digest(out)!=digest or not no_acl(out)):
            raise ValueError('copy/source mismatch')
        os.fchmod(out,0o555); os.fsync(out); out_st=os.fstat(out)
        if (not stat.S_ISREG(out_st.st_mode) or out_st.st_uid!=owner or out_st.st_nlink!=1 or
            stat.S_IMODE(out_st.st_mode)!=0o555 or out_st.st_size!=size or not no_acl(out) or
            _identity(out_st)!=_identity(os.stat('opencode',dir_fd=destdir,follow_symlinks=False)) or
            read_digest(out)!=digest or ident(os.fstat(out))!=ident(out_st)):
            raise ValueError('destination mismatch')
        os.fchmod(destdir,0o555); os.fsync(destdir); os.fsync(root_fd)
        if (_identity(_dir(destdir,owner,group,0o555))!=_identity(dest_before) or
            _identity(os.stat('engine',dir_fd=root_fd,follow_symlinks=False))!=_identity(dest_before) or
            os.listdir(destdir)!=['opencode'] or
            _identity(_dir(root_fd,owner,group,0o555))!=_identity(root_before) or
            ident(os.fstat(source_fd))!=ident(source) or ident(os.fstat(out))!=ident(out_st)):
            raise ValueError('final snapshot mismatch')
        _check_root_entries(root_fd)
        return {'engine':'fixed_digest_staged_mode_0555','bytes':size,'sha256':digest,
                'executed':False,'engine_launch_authorized':False,'mounts':'not_created',
                'provenance':'not_verified','isolation':'not_verified','cleanup':'caller_required'}
    except Exception:
        if out is not None:
            try: os.fchmod(out,0o400)
            except OSError: pass
        if destdir is not None and touched_dir:
            try: os.fchmod(destdir,0o555)
            except OSError: pass
        raise ArtifactError('artifact handoff failed; stop and dispose full root') from None
    finally:
        if out is not None: os.close(out)
        if destdir is not None: os.close(destdir)

def place_pinned_artifact(source_fd,root_fd):
    """Root-only, fixed digest and path; never launches, mounts or authorizes.

    FD selection, workload absence, runtime closure, namespaces and full VM
    teardown are independent caller duties, not verified by this helper.
    """
    if os.geteuid()!=0: raise ArtifactError('disposable VM root required')
    return _put(source_fd,root_fd,0,os.getegid(),BINARY_SIZE,BINARY_SHA256)
