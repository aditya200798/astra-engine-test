"""WIP developer-only cgroup-v2 guard for an expendable Linux CI VM.

No command launcher, engine authorization or integration with production.
Creates only a random child cgroup. Use from a SINGLE-THREADED, credential-free
supervisor on a disposable VM, never an Android device or valuable workload.
A watchdog fork outside that child kills the group on owner-pipe EOF, unexpected
input or deadline. This is defense-in-depth, not a guarantee against kernel hangs,
watchdog death, cgroup escapes, missing delegation, VM loss or host interference.
"""
import ctypes
import errno
import os
import secrets
import select
import socket
import signal
import stat
import sys
import time

CGROUP2_SUPER_MAGIC = 0x63677270
LIMITS = {'memory.max': '1073741824', 'pids.max': '64', 'cpu.max': '100000 100000'}


class GuardError(RuntimeError):
    pass


def _is_cgroup2(fd):
    if not sys.platform.startswith('linux'):
        return False
    # Linux statfs fits in this aligned array; f_type is its first long.
    buf = (ctypes.c_long * 64)()
    libc = ctypes.CDLL(None, use_errno=True)
    if libc.fstatfs(fd, ctypes.byref(buf)) != 0:
        return False
    return buf[0] == CGROUP2_SUPER_MAGIC


def _read(fd, name, limit=4096):
    f = os.open(name, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=fd)
    try:
        data = os.read(f, limit + 1)
        if len(data) > limit:
            raise GuardError('oversized cgroup response')
        return data.decode('ascii', errors='strict').strip()
    finally:
        os.close(f)


def _write(fd, name, value):
    f = os.open(name, os.O_WRONLY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=fd)
    try:
        data = value.encode('ascii')
        if os.write(f, data) != len(data):
            raise GuardError('short cgroup write')
    finally:
        os.close(f)


def _populated(text):
    values = []
    for line in text.splitlines():
        fields = line.split()
        if len(fields) == 2 and fields[0] == 'populated':
            values.append(fields[1])
    if len(values) != 1 or values[0] not in ('0', '1'):
        raise GuardError('invalid cgroup.events')
    return values[0] == '1'


def _wait_trigger(read_fd, deadline):
    """EOF, any unexpected message, or timeout means terminate the group."""
    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return 'deadline'
        try:
            readable, _, _ = select.select([read_fd], [], [], remaining)
            if readable:
                return 'pipe_closed' if os.read(read_fd, 1) == b'' else 'unexpected_input'
        except InterruptedError:
            continue


def _child_watch(group_fd, read_fd, ready_fd, deadline):
    # SIGTERM/SIGHUP must not casually disable the watchdog when the parent dies.
    # SIGKILL, host failure, or a stuck syscall still defeat it.
    signal.signal(signal.SIGHUP, signal.SIG_IGN)
    signal.signal(signal.SIGTERM, signal.SIG_IGN)
    os.write(ready_fd, b'R')
    os.close(ready_fd)
    _wait_trigger(read_fd, deadline)
    _write(group_fd, 'cgroup.kill', '1')
    until = time.monotonic() + 3
    while _populated(_read(group_fd, 'cgroup.events')):
        if time.monotonic() >= until:
            return 2
        time.sleep(.02)
    return 0


def _stop_setup_child(pidfd, timeout=1.0):
    """Stop and reap a failed setup child through its pidfd, or return False.

    A pidfd prevents signalling a different process after numerical PID reuse.
    waitid(P_PIDFD) also rejects a non-child before signal; this still assumes
    no other thread or signal handler reaps/forks children during this operation.
    Time limits do not bound kernel syscall latency. False means uncertain.
    """
    if pidfd is None or not hasattr(os, 'P_PIDFD') or not hasattr(signal, 'pidfd_send_signal'):
        return False
    try:
        status = os.waitid(os.P_PIDFD, pidfd, os.WEXITED | os.WNOHANG)
        if status is not None:
            return True
        signal.pidfd_send_signal(pidfd, signal.SIGKILL)
        until = time.monotonic() + timeout
        while time.monotonic() < until:
            status = os.waitid(os.P_PIDFD, pidfd, os.WEXITED | os.WNOHANG)
            if status is not None:
                return True
            time.sleep(.02)
    except (OSError, ChildProcessError):
        return False
    return False


def _require_watchdog_alive(pidfd):
    """Check a pidfd child without reaping; not a lasting liveness guarantee."""
    if not hasattr(os, 'WNOWAIT'):
        raise GuardError('watchdog status unavailable')
    try:
        status = os.waitid(os.P_PIDFD, pidfd, os.WEXITED | os.WNOHANG | os.WNOWAIT)
    except (OSError, ChildProcessError, AttributeError) as exc:
        raise GuardError('watchdog status unavailable') from exc
    if status is not None:
        raise GuardError('watchdog exited after readiness')


def create_guard(parent_fd, timeout=60):
    """Create limited empty child and ready watchdog; does not launch a program.

    Caller supplies a delegated cgroup-v2 parent FD in a disposable CI VM with
    memory, pids and cpu controllers available. Do not call in a threaded
    process (Python fork safety), with exclusive child creation/reaping and no
    SIGCHLD auto-reap or handler that reaps. Requires Linux pidfd support.
    No external task may enter the group until the
    watchdog readiness return. This function exposes the child FD for future
    enrollment plumbing only; it does not verify a PID is blocked or prevent
    external tampering. Never treat it as an engine readiness or sandbox gate.
    """
    if (type(parent_fd) is not int or parent_fd < 0 or type(timeout) not in (int, float)
            or not 5 <= timeout <= 120):
        raise GuardError('invalid arguments')
    if not stat.S_ISDIR(os.fstat(parent_fd).st_mode) or not _is_cgroup2(parent_fd):
        raise GuardError('cgroup-v2 parent required')
    name = 'astra-test-' + secrets.token_hex(16)
    group_fd = None
    pipe_r = pipe_w = ready_r = ready_w = None
    child = None
    pidfd = None
    made = False
    try:
        os.mkdir(name, 0o700, dir_fd=parent_fd)
        made = True
        group_fd = os.open(name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=parent_fd)
        if not _is_cgroup2(group_fd) or _populated(_read(group_fd, 'cgroup.events')):
            raise GuardError('new group is not empty cgroup-v2')
        # Probe required controls and retain hard failure if unavailable.
        for key, value in LIMITS.items():
            _write(group_fd, key, value)
            if _read(group_fd, key) != value:
                raise GuardError('resource limit readback mismatch')
        # Opening without writing checks presence/access; no tasks exist yet.
        kfd = os.open('cgroup.kill', os.O_WRONLY | os.O_NOFOLLOW | os.O_CLOEXEC, dir_fd=group_fd)
        os.close(kfd)
        pipe_r, pipe_w = os.pipe2(os.O_CLOEXEC)
        ready_r, ready_w = os.pipe2(os.O_CLOEXEC)
        deadline = time.monotonic() + timeout
        child = os.fork()
        if child == 0:
            try:
                os.close(pipe_w); os.close(ready_r)
                # Close every inherited descriptor except these three. A strict
                # single-threaded caller avoids concurrent descriptor races.
                keep = {group_fd, pipe_r, ready_w}
                for entry in os.listdir('/proc/self/fd'):
                    fd = int(entry)
                    if fd not in keep:
                        try: os.close(fd)
                        except OSError as exc:
                            if exc.errno != errno.EBADF: raise
                code = _child_watch(group_fd, pipe_r, ready_w, deadline)
            except BaseException:
                code = 3
            os._exit(code)
        # Retain a stable process reference before waiting for readiness.
        # The caller must exclusively own child creation/reaping, including
        # SIGCHLD handling; unsupported kernels fail setup closed.
        if not hasattr(os, 'pidfd_open') or not hasattr(os, 'P_PIDFD') or not hasattr(signal, 'pidfd_send_signal'):
            raise GuardError('pidfd unavailable')
        pidfd = os.pidfd_open(child, 0)
        os.close(pipe_r); pipe_r = None
        os.close(ready_w); ready_w = None
        available, _, _ = select.select([ready_r], [], [], 2)
        if not available or os.read(ready_r, 1) != b'R':
            raise GuardError('watchdog readiness failed')
        os.close(ready_r); ready_r = None
        # A buffered R is not proof the sender is still running. This is only
        # a momentary observation: an external supervisor must monitor through
        # enrollment/release, and exclusive child ownership is still required.
        _require_watchdog_alive(pidfd)
        return Guard(parent_fd, name, group_fd, pipe_w, child, pidfd)
    except BaseException as exc:
        for fd in (pipe_r, pipe_w, ready_r, ready_w):
            if fd is not None:
                try: os.close(fd)
                except OSError: pass
        # Never signal a bare numeric PID here. An unavailable pidfd, lost
        # child status or timed-out reap means an outer supervisor must recover.
        child_stopped = child is None or _stop_setup_child(pidfd)
        if pidfd is not None:
            try: os.close(pidfd)
            except OSError: child_stopped = False
        if group_fd is not None:
            try: os.close(group_fd)
            except OSError: child_stopped = False
        if made and child_stopped:
            try: os.rmdir(name, dir_fd=parent_fd)
            except OSError: child_stopped = False
        if not child_stopped:
            raise GuardError('guard setup failed; cleanup uncertain') from exc
        raise GuardError('guard setup failed') from exc


class Guard:
    """Owner handle: close pipe triggers watchdog kill even on normal completion.

    Caller must exclusively own child reaping and retain parent_fd, never
    duplicate/inherit pidfd or the owner write-end,
    and never let workloads access cgroup control files. No __del__ promise.
    finish is bounded by its own wait loop, but kernel syscalls can still hang.
    """
    def __init__(self, parent_fd, name, group_fd, pipe_w, child, pidfd):
        self.parent_fd, self.name, self.group_fd = parent_fd, name, group_fd
        self.pipe_w, self.child, self.pidfd = pipe_w, child, pidfd
        self.finished = False

    def finish(self, *, outer_channel=None):
        """Stop watchdog, then optionally request an outer observation before removal.

        Legacy no-channel behavior is retained for old synthetic tests and is not
        independent observation. A channel must be a private connected socket to
        a separately trusted outer controller retaining its own cgroup FDs. The
        socket protocol is not authentication or evidence of process isolation.
        Owner and controller each require a separate external deadline/cleanup.
        """
        if self.finished:
            raise GuardError('guard already finished')
        self.finished = True
        try:
            # Owner may already have triggered EOF to start group kill while
            # reaping a separate worker. The only valid sentinel is None.
            if self.pipe_w is not None:
                os.close(self.pipe_w)
                self.pipe_w = None
            until = time.monotonic() + 5
            status = None
            try:
                while time.monotonic() < until:
                    status = os.waitid(os.P_PIDFD, self.pidfd, os.WEXITED | os.WNOHANG)
                    if status is not None:
                        break
                    time.sleep(.02)
            except (OSError, ChildProcessError) as exc:
                raise GuardError('watchdog status or cleanup uncertain') from exc
            if status is None:
                # Signal only the stable pidfd after confirming ownership. Even
                # if reaping works, killed watchdog cannot prove cgroup cleanup.
                _stop_setup_child(self.pidfd)
                raise GuardError('watchdog timed out; cleanup uncertain')
            if status.si_code != os.CLD_EXITED or status.si_status != 0:
                raise GuardError('watchdog or cleanup uncertain')
            try:
                if _populated(_read(self.group_fd, 'cgroup.events')):
                    raise GuardError('cgroup still populated')
                if outer_channel is not None:
                    _exchange_send(outer_channel, b'E')
                    if _exchange_receive(outer_channel, 3) != b'A':
                        raise GuardError('outer acknowledgement missing; cleanup uncertain')
                    # Acknowledgement is a snapshot, not a reservation. Recheck
                    # locally; writable cgroup access still permits racing.
                    if _populated(_read(self.group_fd, 'cgroup.events')):
                        raise GuardError('group repopulated; cleanup uncertain')
                os.rmdir(self.name, dir_fd=self.parent_fd)
                if outer_channel is not None:
                    _exchange_send(outer_channel, b'D')
            except (OSError, UnicodeError) as exc:
                raise GuardError('cgroup removal uncertain') from exc
            return {'group_kill_observed_empty': True, 'group_removed': True,
                    'outer_ack_received': outer_channel is not None,
                    'engine_launch_authorized': False, 'isolation': 'not_verified'}
        finally:
            # Release both FDs on every path; neither close proves cleanup.
            try:
                os.close(self.group_fd)
            finally:
                os.close(self.pidfd)


def _exchange_send(channel, message):
    if not isinstance(channel, socket.socket):
        raise GuardError('connected private socket required')
    try:
        channel.settimeout(3)
        channel.sendall(message)
    except OSError as exc:
        raise GuardError('controller channel failed; cleanup uncertain') from exc


def _exchange_receive(channel, timeout):
    if not isinstance(channel, socket.socket):
        raise GuardError('connected private socket required')
    try:
        channel.settimeout(timeout)
        return channel.recv(1)
    except OSError as exc:
        raise GuardError('controller channel failed; cleanup uncertain') from exc


def outer_observe_ack_and_confirm(parent_fd, group_fd, name, channel):
    """Observe a fixed owner's cleanup, acknowledge empty, confirm name absent.

    Caller is a separate trusted process outside group and retains its own FDs
    and private channel. It must independently bound/kill/reap/recover on any
    error. Verification is advisory: inode/path/event snapshots race group
    replacement and reenrollment; socket peer/process identity isn't attested.
    No authorization or isolation is conferred; no removal on failure here.
    """
    if (type(parent_fd) is not int or type(group_fd) is not int or
            not isinstance(name, str) or len(name) != 43 or
            not name.startswith('astra-test-') or
            any(c not in '0123456789abcdef' for c in name[11:])):
        raise GuardError('invalid outer group identity')
    try:
        if _exchange_receive(channel, 5) != b'E':
            raise GuardError('owner readiness missing; cleanup uncertain')
        st = os.fstat(group_fd)
        linked = os.stat(name, dir_fd=parent_fd, follow_symlinks=False)
        if (not stat.S_ISDIR(st.st_mode) or not _is_cgroup2(group_fd) or
                (st.st_dev, st.st_ino) != (linked.st_dev, linked.st_ino) or
                _populated(_read(group_fd, 'cgroup.events'))):
            raise GuardError('outer observation failed; cleanup uncertain')
        _exchange_send(channel, b'A')
        if _exchange_receive(channel, 5) != b'D':
            raise GuardError('owner removal report missing; cleanup uncertain')
        try:
            os.stat(name, dir_fd=parent_fd, follow_symlinks=False)
        except FileNotFoundError:
            return {'outer_empty_observed': True, 'outer_name_absent_observed': True,
                    'engine_launch_authorized': False, 'isolation': 'not_verified'}
        raise GuardError('group name still present; cleanup uncertain')
    except (OSError, UnicodeError) as exc:
        raise GuardError('outer observation failed; cleanup uncertain') from exc
