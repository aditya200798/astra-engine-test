"""Private fixed no-engine worker supervisor, NOT an authorization or sandbox.

A parent process supervises the existing _ControlFlow worker and, only after
an anchor FD handoff, forks a watchdog outside that slice. It never guesses a
cgroup by name to kill. Only for an exclusively owned disposable synthetic VM;
public run remains blocked. Delayed manager jobs, monitor death, group escape,
kernel stalls, colliding names and VM teardown remain external residual risks.
"""
import array
import json
import os
import re
import select
import signal
import socket
import time
from . import cgroup_watchdog as cg
from . import synthetic_control_flow as flow
from . import systemd_slice_anchor as anchor
from . import systemd_manager_environment as env

_BLOCKED=True
class SupervisorError(RuntimeError):pass

# Fixed diagnostic categories only: never forward a worker exception or path.
_FLOW_STAGES=('not_observed','root_unknown','manager_unknown','anchor_uncertain','owner_uncertain','owner_returned_cleanup_unverified','anchor_close_uncertain')
_OWNER_STAGES=('not_observed','pipe_creation','start_uncertain','observe','admission_uncertain','provisional','exit','stop','final','finished')
_OWNER_REASONS=('not_observed','not_completed','descriptor_close_uncertain','operation_failed_or_uncertain','session_close_uncertain','inner_exit_mismatch','cleanup_unverified')
_START_PHASES=('not_observed','not_started','proto','manager_before','subscribe','root_first','root_inspect','environment','root_recheck','anchor_recheck','message_build','send_uncertain','await_job','job_not_done','manager_after','complete')
_START_ERRORS=('not_observed','invalid_argument','permission','timeout','connection','fork_mismatch','resource','exists','io','not_found','not_supported','busy','other','no_reply')+env._CATEGORIES
_RECORDS=('not_observed','received','received_diagnostic_only')
_STOPS=('not_observed','job_done_inactive_snapshot')

def _worker_diagnostics(info):
    fields=(('stage',_FLOW_STAGES),('owner_stage',_OWNER_STAGES),('owner_reason',_OWNER_REASONS),('start_phase',_START_PHASES),('start_error',_START_ERRORS),('record',_RECORDS),('stop',_STOPS))
    out={}
    for key,allowed in fields:
        value=info.get(key,'not_observed')
        if type(value) is not str or value not in allowed:raise SupervisorError('invalid diagnostic')
        out[key]=value
    return out


def _send_anchor(channel,fd):
    """Worker sends one held directory FD and waits for exact parent ACK."""
    if channel.sendmsg([b'A'],[(socket.SOL_SOCKET,socket.SCM_RIGHTS,array.array('i',[fd]))])!=1:
        raise SupervisorError('anchor send uncertain')
    channel.settimeout(5)
    if channel.recv(2)!=b'G':raise SupervisorError('watchdog readiness unavailable')
    channel.settimeout(None)


def _recv_anchor(channel):
    """Receive one FD, close every received FD on any malformed message."""
    data,anc,flags,_=channel.recvmsg(2,socket.CMSG_SPACE(8*array.array('i').itemsize),socket.MSG_CMSG_CLOEXEC)
    received=[]
    try:
        for level,kind,payload in anc:
            if level!=socket.SOL_SOCKET or kind!=socket.SCM_RIGHTS or len(payload)%array.array('i').itemsize:
                raise SupervisorError('unexpected ancillary data')
            fds=array.array('i');fds.frombytes(payload);received.extend(fds)
        if data!=b'A' or flags&(socket.MSG_CTRUNC|socket.MSG_TRUNC) or len(received)!=1:
            raise SupervisorError('bad anchor handoff')
        fd=received.pop();return fd
    finally:
        for fd in received:
            try:os.close(fd)
            except OSError:pass


def _watch_fork(group_fd,deadline):
    """Return watchdog pidfd and only parent-owned trigger writer.

    Single-threaded process and exclusive child reaping are prerequisites. A
    child stuck in a kernel syscall cannot be forcibly bounded by Python.
    """
    r=w=ready_r=ready_w=pidfd=None;pid=None
    try:
        r,w=os.pipe2(os.O_CLOEXEC);ready_r,ready_w=os.pipe2(os.O_CLOEXEC)
        pid=os.fork()
        if pid==0:
            try:
                keep={group_fd,r,ready_w}
                for item in os.listdir('/proc/self/fd'):
                    fd=int(item)
                    if fd not in keep:
                        try:os.close(fd)
                        except OSError:pass
                rc=cg._child_watch(group_fd,r,ready_w,deadline)
            except BaseException:rc=3
            os._exit(rc)
        pidfd=os.pidfd_open(pid,0);os.close(r);r=None;os.close(ready_w);ready_w=None
        wait=max(0,min(2,deadline-time.monotonic()))
        rr,_,_=select.select([ready_r,pidfd],[],[],wait)
        if pidfd in rr or ready_r not in rr or os.read(ready_r,1)!=b'R':raise SupervisorError('watchdog did not become ready')
        cg._require_watchdog_alive(pidfd)
        os.close(ready_r);ready_r=None
        result=(pidfd,w);pidfd=w=None;return result
    finally:
        for fd in (r,w,ready_r,ready_w):
            if fd is not None:
                try:os.close(fd)
                except OSError:pass
        if pid is not None and pidfd is not None:
            cg._stop_setup_child(pidfd);os.close(pidfd)
        # If pidfd_open itself failed, never signal a bare pid. Setup is
        # uncertain; outer VM teardown is required, and admission is blocked.


def _wait_reap(pidfd,timeout):
    end=time.monotonic()+timeout
    while time.monotonic()<end:
        try:status=os.waitid(os.P_PIDFD,pidfd,os.WEXITED|os.WNOHANG)
        except (OSError,ChildProcessError):return None
        if status is not None:return (status.si_code,status.si_status)
        time.sleep(.02)
    return None


def _fallback_once(root_fd, group_fd, name):
    """One separately bounded retained-FD kill attempt, never a guessed path.

    Caller must first signal/reap the fixed worker and establish this exact FD
    was checked before admission. A stale group fails linkage. This is only
    best effort: late manager jobs, escaped processes and kernel stalls remain
    unknown. The parent must itself have an outside recovery deadline.
    """
    pidfd=None;pid=None
    try:
        anchor._check_group(root_fd,group_fd,name)
        pid=os.fork()
        if pid==0:
            try:
                # Retain only the exact group; do not retain trigger endpoints.
                for item in os.listdir('/proc/self/fd'):
                    fd=int(item)
                    if fd!=group_fd:
                        try:os.close(fd)
                        except OSError:pass
                cg._write(group_fd,'cgroup.kill','1')
                deadline=time.monotonic()+3
                while cg._populated(cg._read(group_fd,'cgroup.events')):
                    if time.monotonic()>=deadline:os._exit(2)
                    time.sleep(.02)
                os._exit(0)
            except BaseException:os._exit(3)
        pidfd=os.pidfd_open(pid,0)
        status=_wait_reap(pidfd,4)
        if status is None:cg._stop_setup_child(pidfd)
        if status==(os.CLD_EXITED,0):return 'kill_returned_empty_sampled'
        return 'outcome_uncertain'
    except BaseException:
        # Never signal a bare numeric PID, even if pidfd acquisition failed.
        return 'outcome_uncertain'
    finally:
        if pidfd is not None:os.close(pidfd)


def _worker(child,controller):
    """Run fixed flow once in worker; only fixed categorical packet leaves it."""
    try:
        result=controller._run_once(_anchor_channel=child)
        packet=json.dumps(result,separators=(',',':'),sort_keys=True).encode('ascii')
        if len(packet)>4096:raise ValueError('large result')
        child.sendall(b'R'+packet)
    except BaseException:pass
    finally:
        child.close()
        os._exit(0)


def _supervise(controller,timeout=120,*,staging_guard=None):
    # Preserve the original no-engine-only public-private contract.
    if type(controller) is not flow._ControlFlow:
        raise SupervisorError('invalid or unavailable supervision')
    return _supervise_common(controller,timeout,staging_guard=staging_guard,genuine=False)


def _supervise_common(controller,timeout=120,*,staging_guard=None,genuine=False):
    """One actual fixed flow; exact-FD watchdog and pidfd worker observation.

    This does NOT create an exclusive VM, verify parent provenance, establish
    atomic ownership, recover an ambiguous slice start, cancel late jobs, or
    authorize any workload. It needs a further external deadline/recovery.
    A supplied ready `staging_guard` is consumed; it must be a separately
    created empty delegated group whose watchdog stays outside that group.
    Real staging requires it, but this private fixture-compatible function
    still accepts None. Neither group is an authorization or sandbox.
    Never run on user device, shared host, or with real secrets.
    """
    # Include validation and guard admission in the supervisor's deadline.
    start=time.monotonic()
    from . import genuine_control_flow as genuine_flow
    if (type(genuine) is not bool or
        (genuine and type(controller) is not genuine_flow._ControlFlow) or
        (not genuine and type(controller) is not flow._ControlFlow)):
        raise SupervisorError('invalid or unavailable supervision')
    if controller._used:raise SupervisorError('attempt already consumed')
    # Consume before all later validation; rejected setup cannot be replayed.
    controller._used=True
    if (controller.cgroup_root_fd is None or controller.slice_name is None or
        (genuine and staging_guard is None) or
        type(timeout) not in (int,float) or not 0.1<=timeout<=120 or
        not hasattr(os,'pidfd_open') or not hasattr(os,'P_PIDFD') or
        not hasattr(signal,'pidfd_send_signal')):
        raise SupervisorError('invalid or unavailable supervision')
    # The optional staging guard is needed for any real staging operation.
    # Omission preserves prior private fixture tests, never a launch approval.
    # Guard belongs exclusively to this one call and is consumed in finally.
    if staging_guard is not None:
        try:
            if type(staging_guard) is not cg.Guard or staging_guard.finished:
                raise ValueError('guard')
            anchor._check_group(staging_guard.parent_fd,staging_guard.group_fd,staging_guard.name)
            if cg._populated(cg._read(staging_guard.group_fd,'cgroup.events')):
                raise ValueError('group not empty')
            cg._require_watchdog_alive(staging_guard.pidfd)
        except BaseException:
            raise SupervisorError('staging guard unavailable; caller must dispose') from None
    result={'stage':'setup_uncertain','worker':'not_observed','watchdog':'not_started',
            'anchor':'not_observed','fallback':'not_attempted','staging':'not_guarded',
            'staging_fallback':'not_attempted','control':'unknown','cleanup':'not_verified',
            'isolation':'not_verified','vm_decommission':'not_observed',
            'engine_launch_authorized':False,'production_approved':False,
            'flow_stage':'not_observed','owner_stage':'not_observed','owner_reason':'not_observed','start_phase':'not_observed','start_error':'not_observed',
            'record':'not_observed','stop':'not_observed'}
    parent=child=None;worker_fd=watch_fd=watch_w=group_fd=None;pid=None;worker_status=watch_status=None
    deadline=start+timeout;got_packet=False;channel_open=True;anchor_checked=False
    try:
        parent,child=socket.socketpair(socket.AF_UNIX,socket.SOCK_SEQPACKET|socket.SOCK_CLOEXEC)
        pid=os.fork()
        if pid==0:
            parent.close();controller._used=False
            # Do not inherit unrelated parent descriptors, in particular any
            # controller/runner channel or future watchdog trigger writer.
            keep={child.fileno(),controller.source_fd,controller.package_fd,
                  controller.root_fd,controller.cgroup_root_fd}
            if genuine:keep.add(controller.engine_fd)
            for item in os.listdir('/proc/self/fd'):
                fd=int(item)
                if fd not in keep:
                    try:os.close(fd)
                    except OSError:pass
            if staging_guard is not None:
                # No staging, subprocess or manager call before parent has
                # enrolled this blocked child and sampled the watchdog alive.
                try:
                    child.settimeout(5)
                    if child.recv(2)!=b'S':os._exit(7)
                    child.settimeout(None)
                except BaseException:os._exit(7)
            _worker(child,controller)
        child.close();child=None
        worker_fd=os.pidfd_open(pid,0)
        if staging_guard is not None:
            # Child is blocked, has not forked, and exclusive reaping keeps
            # the numeric PID stable through this cgroup.procs write.
            cg._require_watchdog_alive(staging_guard.pidfd)
            cg._require_watchdog_alive(worker_fd)
            anchor._check_group(staging_guard.parent_fd,staging_guard.group_fd,staging_guard.name)
            cg._write(staging_guard.group_fd,'cgroup.procs',str(pid))
            members=cg._read(staging_guard.group_fd,'cgroup.procs').split()
            if str(pid) not in members:raise SupervisorError('staging enrollment unavailable')
            cg._require_watchdog_alive(worker_fd)
            cg._require_watchdog_alive(staging_guard.pidfd)
            if time.monotonic()>=deadline:raise SupervisorError('deadline before staging release')
            if parent.send(b'S')!=1:raise SupervisorError('staging release uncertain')
            result['staging']='enrolled_sampled'
        parent.setblocking(False);result['stage']='waiting_for_anchor'
        while True:
            left=deadline-time.monotonic()
            if left<=0:result['stage']='deadline';break
            watched=[worker_fd]+([parent] if channel_open else [])+([watch_fd] if watch_fd is not None else [])+([staging_guard.pidfd] if staging_guard is not None else [])
            ready,_,_=select.select(watched,[],[],left)
            if not ready:result['stage']='deadline';break
            if staging_guard is not None and staging_guard.pidfd in ready:
                result['stage']='staging_watchdog_died';break
            if watch_fd is not None and watch_fd in ready:
                result['stage']='watchdog_died';break
            if parent in ready:
                if group_fd is None:
                    # A result can precede anchor on early staging/bus failure.
                    # It is diagnostic only and cannot upgrade control.
                    try:head=parent.recv(1,socket.MSG_PEEK)
                    except OSError:head=b''
                    if head==b'R':
                        packet=parent.recv(4097)
                        if len(packet)>4096 or not packet.startswith(b'R'):raise SupervisorError('bad early packet')
                        info=json.loads(packet[1:].decode('ascii'))
                        if type(info) is not dict or info.get('control')!='unknown' or info.get('engine_launch_authorized') is not False or info.get('production_approved') is not False:raise SupervisorError('bad early result')
                        diagnostic=_worker_diagnostics(info)
                        result['flow_stage']=diagnostic['stage'];result['owner_stage']=diagnostic['owner_stage']
                        result['owner_reason']=diagnostic['owner_reason'];result['start_phase']=diagnostic['start_phase'];result['start_error']=diagnostic['start_error'];result['record']=diagnostic['record'];result['stop']=diagnostic['stop']
                        result['stage']='early_worker_result';got_packet=True;channel_open=False
                        continue
                    try:group_fd=_recv_anchor(parent)
                    except (SupervisorError,OSError):result['stage']='anchor_handoff_failed';break
                    anchor._check_group(controller.cgroup_root_fd,group_fd,controller.slice_name)
                    if cg._populated(cg._read(group_fd,'cgroup.events')):raise SupervisorError('anchor not empty')
                    anchor_checked=True
                    result['anchor']='held_group_sampled';result['stage']='watchdog_setup'
                    watch_fd,watch_w=_watch_fork(group_fd,deadline)
                    result['watchdog']='ready_sampled'
                    cg._require_watchdog_alive(watch_fd)
                    # send only after watchdog readiness, no retries on failure
                    if time.monotonic()>=deadline:raise SupervisorError('deadline before service admission')
                    if parent.send(b'G')!=1:raise SupervisorError('ack uncertain')
                    result['stage']='worker_running'
                else:
                    packet=parent.recv(4097)
                    if not packet:
                        if not got_packet:result['stage']='worker_channel_closed';result['control']='unknown'
                        # Channel EOF can precede waitable process exit.
                        # Stop polling its permanent EOF; await child exit.
                        channel_open=False
                        if not got_packet:break
                        continue
                    if len(packet)>4096 or not packet.startswith(b'R') or got_packet:raise SupervisorError('bad worker packet')
                    info=json.loads(packet[1:].decode('ascii'))
                    if (type(info) is not dict or info.get('engine_launch_authorized') is not False or
                        info.get('production_approved') is not False or info.get('control') not in (('unknown','blocked_genuine_entry_record_and_exit_sampled','synthetic_inner_returned_cleanup_unverified') if genuine else ('unknown','blocked_entry_record_and_exit_sampled'))):
                        raise SupervisorError('bad worker result')
                    if genuine:
                        digest=info.get('fixture_request_sha256')
                        if (info['control']=='synthetic_inner_returned_cleanup_unverified' and
                            (type(digest) is not str or re.fullmatch('[0-9a-f]{64}',digest) is None)) or (info['control']!='synthetic_inner_returned_cleanup_unverified' and digest is not None):
                            raise SupervisorError('invalid synthetic digest')
                        result['fixture_request_sha256']=digest
                    diagnostic=_worker_diagnostics(info)
                    result['flow_stage']=diagnostic['stage'];result['owner_stage']=diagnostic['owner_stage']
                    result['owner_reason']=diagnostic['owner_reason'];result['start_phase']=diagnostic['start_phase'];result['start_error']=diagnostic['start_error'];result['record']=diagnostic['record'];result['stop']=diagnostic['stop']
                    result['control']=info['control'];got_packet=True;result['stage']='worker_result_received'
                    # Result is provisional until process exit and watchdog action.
            if worker_fd in ready:
                result['worker']='exited_sampled'
                # A result packet may already be queued even if select only
                # reported pidfd readiness. Drain it on the next iteration.
                if not got_packet and channel_open and parent not in ready:continue
                if not got_packet:result['control']='unknown'
                break
    except BaseException:
        result['stage']='supervision_uncertain';result['control']='unknown'
    finally:
        if child is not None:child.close()
        if parent is not None:parent.close()
        if worker_fd is not None:
            # Do not reap before signaling an unexited child; pidfd is stable.
            try:
                status=os.waitid(os.P_PIDFD,worker_fd,os.WEXITED|os.WNOHANG|os.WNOWAIT)
                if status is None:signal.pidfd_send_signal(worker_fd,signal.SIGKILL)
            except (OSError,ChildProcessError):result['control']='unknown'
        # Trigger the watchdog immediately after the pidfd signal, rather than
        # waiting for a possibly hung worker before starting cleanup.
        if watch_w is not None:
            try:os.close(watch_w)
            except OSError:result['control']='unknown'
        # Trigger staging kill immediately even if the worker's wait stalls.
        # finish() can then wait/reap without keeping the group live.
        if staging_guard is not None:
            try:
                os.close(staging_guard.pipe_w)
                staging_guard.pipe_w=None
            except OSError:result['control']='unknown'
        if worker_fd is not None:
            worker_status=_wait_reap(worker_fd,3)
            if worker_status is None:result['worker']='reap_uncertain';result['control']='unknown'
            else:result['worker']='reaped'
            os.close(worker_fd)
        if watch_fd is not None:
            watch_status=_wait_reap(watch_fd,4)
            if watch_status==(os.CLD_EXITED,0):result['watchdog']='kill_returned_empty_sampled'
            else:
                result['watchdog']='outcome_uncertain';result['control']='unknown'
                if watch_status is None:cg._stop_setup_child(watch_fd)
            os.close(watch_fd)
        # A failed/missing watchdog cannot give an empty observation. Attempt
        # one linked exact-FD kill only after a worker was actually reaped;
        # no outcome from this fallback upgrades any control/cleanup result.
        if (anchor_checked and group_fd is not None and worker_status is not None and
            watch_status!=(os.CLD_EXITED,0)):
            result['fallback']=_fallback_once(controller.cgroup_root_fd,group_fd,controller.slice_name)
            result['control']='unknown'
        if group_fd is not None:os.close(group_fd)
        # This separate group includes staging worker and descendants, not the
        # manager-owned service. Finish triggers its watchdog and samples empty.
        # A duplicate exact FD survives finish for one diagnostic fallback.
        if staging_guard is not None:
            duplicate=None
            try:
                duplicate=os.dup(staging_guard.group_fd)
                staging_guard.finish()
                result['staging']='kill_returned_empty_removed_sampled'
            except BaseException:
                result['staging']='cleanup_uncertain';result['control']='unknown'
                if duplicate is not None and worker_status is not None:
                    result['staging_fallback']=_fallback_once(staging_guard.parent_fd,duplicate,staging_guard.name)
            finally:
                if duplicate is not None:os.close(duplicate)
        # Parent cannot safely signal/reap a bare PID when pidfd_open failed.
        if pid is not None and worker_fd is None:result['worker']='pidfd_unavailable';result['control']='unknown'
    if (worker_status!=(os.CLD_EXITED,0) or not got_packet or watch_status!=(os.CLD_EXITED,0) or
        result['stage']!='worker_result_received' or
        (staging_guard is not None and result['staging']!='kill_returned_empty_removed_sampled')):result['control']='unknown'
    if genuine:
        if result['control']!='synthetic_inner_returned_cleanup_unverified':result['fixture_request_sha256']=None
        # Even a successful sample cannot settle an accepted late manager job.
        result['late_start']='not_reconciled'
        result['external_recovery']='required'
    return result


def run():
    if _BLOCKED:raise SupervisorError('private supervisor blocked: independent recovery and isolation unverified')
    raise SupervisorError('no approved orchestration')
