"""WIP developer-only lease/HTTP lifecycle for a *pre-contained* child.

No executable launcher, filesystem isolation or cleanup supervisor is provided.
Only synthetic credentials/data in a fresh independently isolated runtime.
Not connected to production and not a security boundary. See README.
"""
import asyncio
import base64
import json
import math
import re

from .engine_controller import LeaseObservation

MAX_HEADERS = 16384
MAX_BODY = 262144
MAX_STDERR = 65536
# This is intentionally public and synthetic, not a credential to protect.
SYNTHETIC_PASSWORD = 'astra-disposable-synthetic-only'


class BaselineError(RuntimeError):
    pass


def _json(raw):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError('duplicate')
            result[key] = value
        return result

    def finite(value):
        number = float(value)
        if not math.isfinite(number):
            raise ValueError('nonfinite')
        return number
    try:
        return json.loads(raw.decode('utf-8'), object_pairs_hook=pairs,
                          parse_constant=lambda _: (_ for _ in ()).throw(ValueError()),
                          parse_float=finite)
    except (ValueError, UnicodeError, RecursionError):
        raise BaselineError('invalid response JSON') from None


async def _line(reader, remaining):
    try:
        line = await reader.readuntil(b'\r\n')
    except (asyncio.IncompleteReadError, asyncio.LimitOverrunError):
        raise BaselineError('invalid HTTP line') from None
    if len(line) > remaining or b'\0' in line:
        raise BaselineError('HTTP headers exceeded')
    return line


async def _response(reader):
    """Strict limited HTTP/1.x framing; no 1xx, trailers, compression or redirects."""
    used = 0
    status_line = await _line(reader, MAX_HEADERS)
    used += len(status_line)
    match = re.fullmatch(rb'HTTP/1\.[01] ([0-9]{3})(?: [\x20-\x7e]*)?\r\n', status_line)
    if not match:
        raise BaselineError('invalid HTTP status')
    status = int(match[1])
    if status not in (200, 401):
        raise BaselineError('unexpected HTTP status')
    headers = {}
    while True:
        line = await _line(reader, MAX_HEADERS - used)
        used += len(line)
        if line == b'\r\n':
            break
        match = re.fullmatch(rb'([!#$%&\'*+.^_`|~0-9A-Za-z-]+):[ \t]*([^\r\n]*)\r\n', line)
        if not match or any(c < 32 and c != 9 or c == 127 for c in match[2]):
            raise BaselineError('invalid HTTP header')
        name = match[1].lower()
        if name in headers:
            raise BaselineError('duplicate HTTP header')
        headers[name] = match[2].strip().lower()
    if b'content-encoding' in headers and headers[b'content-encoding'] != b'identity':
        raise BaselineError('encoded body unsupported')
    length, transfer = headers.get(b'content-length'), headers.get(b'transfer-encoding')
    if length is not None and transfer is not None:
        raise BaselineError('ambiguous framing')
    if length is not None:
        if not re.fullmatch(rb'[0-9]{1,9}', length) or int(length) > MAX_BODY:
            raise BaselineError('invalid body length')
        try:
            body = await reader.readexactly(int(length))
        except asyncio.IncompleteReadError:
            raise BaselineError('truncated HTTP body') from None
    elif transfer == b'chunked':
        body = bytearray()
        for _ in range(4096):
            line = await _line(reader, 128)
            value = line[:-2]
            if not re.fullmatch(rb'[0-9A-Fa-f]{1,8}', value):
                raise BaselineError('invalid chunk')
            size = int(value, 16)
            if size > MAX_BODY - len(body):
                raise BaselineError('body exceeded')
            if not size:
                if await _line(reader, 2) != b'\r\n':
                    raise BaselineError('trailers unsupported')
                return status, bytes(body)
            try:
                chunk = await reader.readexactly(size + 2)
            except asyncio.IncompleteReadError:
                raise BaselineError('truncated chunk') from None
            if chunk[-2:] != b'\r\n':
                raise BaselineError('invalid chunk delimiter')
            body.extend(chunk[:-2])
        raise BaselineError('chunk count exceeded')
    else:
        # HTTP/1.0 close-delimited responses are intentionally unsupported.
        raise BaselineError('unsupported HTTP framing')
    return status, bytes(body)


async def _request(port, path, *, authenticated):
    if (type(port) is not int or not 1 <= port <= 65535 or
            path not in ('/api/info', '/api/config') or
            authenticated not in (True, False, 'wrong') or
            type(authenticated) not in (bool, str)):
        raise BaselineError('invalid request')
    reader, writer = await asyncio.open_connection('127.0.0.1', port, limit=MAX_HEADERS)
    try:
        auth = b''
        if authenticated:
            password = 'intentionally-wrong-synthetic-password' if authenticated == 'wrong' else SYNTHETIC_PASSWORD
            token = base64.b64encode(('opencode:' + password).encode('ascii'))
            auth = b'Authorization: Basic ' + token + b'\r\n'
        writer.write(b'GET ' + path.encode('ascii') + b' HTTP/1.1\r\nHost: 127.0.0.1:' +
                     str(port).encode('ascii') + b'\r\nAccept: application/json\r\n' + auth +
                     b'Connection: close\r\n\r\n')
        await writer.drain()
        return await _response(reader)
    finally:
        writer.close()
        # No wait_closed: peer may not cooperate. Overall outer watchdog still required.


async def observe_baseline(process, *, timeout=15.0, verify_listener=None, exercise=None):
    """Drive one fixed synthetic-auth baseline against an already-launched child.

    process must be an asyncio subprocess with stdin/stdout/stderr pipes. This
    function is unsafe to use without an independently isolated disposable
    runtime and a supervisor that kills/reaps *all* descendants on every exit.
    timeout is not an OS watchdog. Never replay ambiguous operations. Config
    and info are returned only for the synthetic test, not authenticated facts.
    Optional synchronous verify_listener(port) snapshots before and after each
    request may block the event loop and do not authenticate the HTTP peer; the
    caller is responsible for their validity. No callback means no observation.
    Optional exercise(port, info, config) is awaited while the server is live,
    stdout/stderr are drained, and the total deadline applies. It must be a
    trusted developer-only synthetic coroutine; it may cause external effects,
    block or suppress cancellation, and requires the same external supervisor.
    No result implies endpoint authenticity or successful containment.
    """
    try:
        valid_timeout = type(timeout) in (int, float) and math.isfinite(timeout) and 0 < timeout <= 60
    except OverflowError:
        valid_timeout = False
    if not valid_timeout:
        raise ValueError('invalid timeout')
    if exercise is not None and not callable(exercise):
        raise ValueError('exercise must be callable')
    if not all(getattr(process, attr, None) is not None for attr in ('stdin', 'stdout', 'stderr')):
        raise ValueError('process pipes required')
    lease = LeaseObservation()
    loop = asyncio.get_running_loop()
    port_future = loop.create_future()
    failure = loop.create_future()
    stderr_count = 0

    async def stdout_drain():
        try:
            while True:
                data = await process.stdout.read(4096)
                if not data:
                    result = lease.finish()
                    if not port_future.done():
                        port_future.set_result(result['port'])
                    return
                lease.feed(data)
                port = lease.port_if_complete()
                if port is not None and not port_future.done():
                    port_future.set_result(port)
        except Exception:
            if not failure.done(): failure.set_result('stdout failure')

    async def stderr_drain():
        nonlocal stderr_count
        try:
            while True:
                data = await process.stderr.read(4096)
                if not data: return
                stderr_count += len(data)
                if stderr_count > MAX_STDERR:
                    raise ValueError('limit')
        except Exception:
            if not failure.done(): failure.set_result('stderr failure')

    async def guarded(awaitable):
        task = asyncio.ensure_future(awaitable)
        try:
            done, _ = await asyncio.wait((task, failure), return_when=asyncio.FIRST_COMPLETED)
            if failure in done:
                raise BaselineError(failure.result())
            return task.result()
        finally:
            if not task.done():
                task.cancel()
                await asyncio.gather(task, return_exceptions=True)

    async def request_checked(port, path, authenticated):
        # Each snapshot is advisory, not an identity/security guarantee; races
        # can occur between the check and the HTTP connect/response.
        if verify_listener is not None:
            try:
                if verify_listener(port) is not True:
                    raise ValueError('listener not observed')
            except Exception:
                raise BaselineError('listener observation failed') from None
        result = await _request(port, path, authenticated=authenticated)
        if verify_listener is not None:
            try:
                if verify_listener(port) is not True:
                    raise ValueError('listener not observed')
            except Exception:
                raise BaselineError('listener observation failed') from None
        return result

    out_task = asyncio.create_task(stdout_drain())
    err_task = asyncio.create_task(stderr_drain())
    try:
        async with asyncio.timeout(timeout):
            port = await guarded(port_future)
            status, _ = await guarded(request_checked(port, '/api/info', authenticated=False))
            if status != 401: raise BaselineError('unauthenticated request not rejected')
            status, _ = await guarded(request_checked(port, '/api/info', authenticated='wrong'))
            if status != 401: raise BaselineError('wrong credential info not rejected')
            status, raw = await guarded(request_checked(port, '/api/info', authenticated=True))
            if status != 200: raise BaselineError('authenticated info not accepted')
            info = _json(raw)
            status, _ = await guarded(request_checked(port, '/api/config', authenticated=False))
            if status != 401: raise BaselineError('unauthenticated config not rejected')
            status, _ = await guarded(request_checked(port, '/api/config', authenticated='wrong'))
            if status != 401: raise BaselineError('wrong credential config not rejected')
            status, raw = await guarded(request_checked(port, '/api/config', authenticated=True))
            if status != 200: raise BaselineError('authenticated config not accepted')
            config = _json(raw)
            if not isinstance(info, dict) or not isinstance(config, list):
                raise BaselineError('unexpected response shape')
            exercise_result = None
            if exercise is not None:
                try:
                    exercise_result = await guarded(exercise(port, info, config))
                except (asyncio.CancelledError, TimeoutError):
                    raise
                except Exception:
                    raise BaselineError('synthetic integration exercise failed') from None
            process.stdin.close()
            await guarded(asyncio.gather(out_task, err_task))
            code = await guarded(process.wait())
            if code != 0: raise BaselineError('server exit failure')
            return {'unauth_info_status': 401, 'unauth_config_status': 401,
                    'wrong_info_status': 401, 'wrong_config_status': 401, 'auth_info_status': 200,
                    'auth_config_status': 200, 'info': info, 'config': config,
                    'stderr_bytes': stderr_count, 'streams_complete': True,
                    'direct_exit_code': code, 'exercise_result': exercise_result,
                    'descendant_cleanup': 'not_verified',
                    'isolation': 'not_verified', 'provenance': 'not_verified',
                    'listener_observation': ('callback_returned_true_before_and_after_each_request' if verify_listener is not None
                                             else 'not_performed')}
    except (TimeoutError, ConnectionError, OSError, asyncio.IncompleteReadError):
        raise BaselineError('baseline timed out or I/O failed') from None
    finally:
        try:
            process.stdin.close()
        except Exception:
            pass  # cleanup supervisor must treat incomplete cleanup as uncertain
        for task in (out_task, err_task):
            if not task.done(): task.cancel()
        await asyncio.gather(out_task, err_task, return_exceptions=True)
