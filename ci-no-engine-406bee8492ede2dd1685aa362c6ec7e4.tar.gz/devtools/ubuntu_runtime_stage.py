"""Fixed Ubuntu Python runtime copier; no execution, mount or authorization.

Uses candidate .deb hashes and per-file selections recorded in a fixed manifest.
Only for a fresh, private, disposable synthetic VM root and trusted single owner.
Acquisition/signature validation, root selection and deletion remain external.
"""
import hashlib
import io
import json
import os
import pathlib
import select
import time
import stat
import subprocess
import tarfile
from .synthetic_root_skeleton import _check_root_entries, _dir, _identity

MANIFEST_SHA256='8a39141e08fade8761e8d204d4acc7724ed7609c782dab1eca9d0d81d525c3bb'
_MANIFEST=pathlib.Path(__file__).resolve().parents[1]/'docs/ubuntu-runtime-manifest-20261119.json'
_DPKG='/usr/bin/dpkg-deb'
_MAX_ARCHIVE=8_000_000
_MAX_TAR=32_000_000
_MAX_FILE=9_000_000
_MAX_TOTAL=45_000_000
_UNPACK_TIMEOUT=20.0
_EXTRAS={'usr/bin/python3':'python3.12',
         'usr/lib64/ld-linux-x86-64.so.2':'../lib/x86_64-linux-gnu/ld-linux-x86-64.so.2'}
class RuntimeStageError(RuntimeError): pass


def _no_acl(fd):
    return not any(x in ('system.posix_acl_access','system.posix_acl_default') for x in os.listxattr(fd))

def _id(st):
    return (st.st_dev,st.st_ino,st.st_mode,st.st_uid,st.st_gid,st.st_nlink,st.st_size,st.st_mtime_ns,st.st_ctime_ns)

def _manifest():
    raw=_MANIFEST.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=MANIFEST_SHA256: raise ValueError('manifest digest')
    obj=json.loads(raw)
    if (type(obj) is not dict or obj.get('schema')!='astra-ubuntu-noble-x64-runtime-20261119-v1'
        or type(obj.get('packages')) is not dict or type(obj.get('entries')) is not list): raise ValueError('manifest schema')
    return obj

def _read_package(fd,expected):
    before=os.fstat(fd)
    if (not stat.S_ISREG(before.st_mode) or before.st_nlink!=1 or
        before.st_size!=expected['size'] or not 0<before.st_size<=_MAX_ARCHIVE or not _no_acl(fd)):
        raise ValueError('package metadata')
    chunks=[]; pos=0; h=hashlib.sha256()
    while pos<before.st_size:
        data=os.pread(fd,min(65536,before.st_size-pos),pos)
        if not data: raise ValueError('short package')
        chunks.append(data); h.update(data); pos+=len(data)
    if os.pread(fd,1,pos) or h.hexdigest()!=expected['sha256'] or _id(os.fstat(fd))!=_id(before):
        raise ValueError('package changed')
    return b''.join(chunks)

def _decompress_deb(raw):
    """Pinned caller-controlled bytes via anonymous memfd; no package install.

    The absolute host dpkg-deb binary is a prerequisite, not authenticated by
    this function. Output is capped during reads, stderr rejects; direct-child
    kill/reap is best effort. Separate cgroup/resource watchdog still required.
    """
    if not hasattr(os,'memfd_create'): raise ValueError('memfd unavailable')
    fd=os.memfd_create('astra-ubuntu-package',os.MFD_CLOEXEC)
    try:
        # The outside worker intentionally closes all inherited stdio. If the
        # memfd becomes fd 0, Popen(stdin=DEVNULL) replaces it in the child
        # despite pass_fds, so dpkg-deb reads /dev/null, not the package.
        # Always retain a CLOEXEC descriptor above stdio before spawning.
        if fd < 3:
            import fcntl
            moved=fcntl.fcntl(fd,fcntl.F_DUPFD_CLOEXEC,3)
            os.close(fd)
            fd=moved
        view=memoryview(raw)
        while view:
            n=os.write(fd,view)
            if n<=0: raise OSError('short memfd write')
            view=view[n:]
        os.lseek(fd,0,os.SEEK_SET)
        proc=subprocess.Popen([_DPKG,'--fsys-tarfile',f'/proc/self/fd/{fd}'],pass_fds=(fd,),
                              env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C'},cwd='/',
                              stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                              start_new_session=True,close_fds=True)
        try:
            streams={proc.stdout.fileno():'out',proc.stderr.fileno():'err'}
            for stream in (proc.stdout,proc.stderr): os.set_blocking(stream.fileno(),False)
            pending=set(streams); out=bytearray(); deadline=time.monotonic()+_UNPACK_TIMEOUT
            while pending or proc.poll() is None:
                left=deadline-time.monotonic()
                if left<=0: raise ValueError('unpack deadline')
                ready,_,_=select.select(list(pending),[],[],min(left,0.05))
                for which in ready:
                    limit=_MAX_TAR+1-len(out) if streams[which]=='out' else 1
                    try: block=os.read(which,min(65536,limit))
                    except BlockingIOError: continue
                    if not block: pending.remove(which)
                    elif streams[which]=='err': raise ValueError('unpack stderr')
                    else:
                        out.extend(block)
                        if len(out)>_MAX_TAR: raise ValueError('unpack output limit')
            if proc.returncode!=0: raise ValueError('unpack exit')
            return bytes(out)
        finally:
            if proc.poll() is None:
                try: proc.kill()
                except ProcessLookupError: pass
            try: proc.wait(timeout=2)
            except (OSError,subprocess.TimeoutExpired): pass
            proc.stdout.close(); proc.stderr.close()

    finally: os.close(fd)

def _payloads(package_fd,manifest,unpack):
    if type(package_fd) is not int or package_fd<0: raise ValueError('package directory fd')
    ds=os.fstat(package_fd)
    if not stat.S_ISDIR(ds.st_mode) or not _no_acl(package_fd): raise ValueError('package directory')
    entries=manifest['entries']; packages=manifest['packages']
    if (len(entries)!=584 or len(packages)!=17 or len({e['path'] for e in entries})!=len(entries)):
        raise ValueError('manifest cardinality')
    wanted={name:{} for name in packages}
    for e in entries:
        path=e['path']; pkg=e['package']
        if (pkg not in wanted or type(path) is not str or not path.startswith('usr/') or
            any(p in ('','.','..') for p in path.split('/')) or e['kind'] not in ('file','symlink')):
            raise ValueError('invalid manifest entry')
        wanted[pkg][path]=e
    result={}; total=0
    for pkg,meta in sorted(packages.items()):
        fd=os.open(pkg+'.deb',os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK,dir_fd=package_fd)
        try: raw=_read_package(fd,meta)
        finally: os.close(fd)
        tar=unpack(raw)
        if type(tar) is not bytes or len(tar)>_MAX_TAR: raise ValueError('tar bound')
        seen=set()
        with tarfile.open(fileobj=io.BytesIO(tar),mode='r:') as archive:
            for m in archive:
                path=m.name[2:] if m.name.startswith('./') else m.name
                if path not in wanted[pkg]: continue
                if path in seen: raise ValueError('duplicate selected member')
                seen.add(path); spec=wanted[pkg][path]
                if spec['kind']=='symlink':
                    if not m.issym() or m.linkname!=spec['target']: raise ValueError('link mismatch')
                    result[path]=('symlink',m.linkname,None)
                else:
                    if not m.isfile() or m.size!=spec['size'] or not 0<=m.size<=_MAX_FILE:
                        raise ValueError('member metadata')
                    f=archive.extractfile(m)
                    if f is None: raise ValueError('missing content')
                    data=f.read(_MAX_FILE+1); total+=len(data)
                    if (len(data)!=m.size or total>_MAX_TOTAL or hashlib.sha256(data).hexdigest()!=spec['sha256']):
                        raise ValueError('member digest')
                    result[path]=('file',data,spec['mode'])
        if seen!=set(wanted[pkg]): raise ValueError('missing selected member')
    return result

def _install(package_fd,root_fd,unpack):
    """Actual fixed copy; private unpack injection only for negative tests.

    Caller excludes concurrent root/same-UID writers. On any failure stop and
    dispose the *whole* tree; this function deliberately does not delete it.
    """
    if type(root_fd) is not int or root_fd<0: raise RuntimeStageError('root fd')
    opened={}; usr=None; touched=False
    flags=os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC
    try:
        manifest=_manifest(); payloads=_payloads(package_fd,manifest,unpack)
        owner,group=os.geteuid(),os.getegid()
        root_before=_dir(root_fd,owner,group,0o555); _check_root_entries(root_fd)
        usr=os.open('usr',flags|os.O_DIRECTORY,dir_fd=root_fd)
        if (_identity(_dir(usr,owner,group,0o555))!=_identity(os.stat('usr',dir_fd=root_fd,follow_symlinks=False))
            or os.listdir(usr)): raise ValueError('usr is not empty')
        # Construct exactly fixed path directories under the checked empty usr.
        paths=set(payloads)|set(_EXTRAS); dirs={''}
        for path in paths:
            if not path.startswith('usr/'): raise ValueError('bad output path')
            parts=path.split('/')[1:-1]
            for i in range(1,len(parts)+1): dirs.add('/'.join(parts[:i]))
        touched=True; os.fchmod(usr,0o700); opened['']=usr
        for path in sorted(dirs- {''},key=lambda p:(p.count('/'),p)):
            parent,_,name=path.rpartition('/'); os.mkdir(name,0o700,dir_fd=opened[parent])
            fd=os.open(name,flags|os.O_DIRECTORY,dir_fd=opened[parent]); opened[path]=fd; os.fchmod(fd,0o700)
            st=_dir(fd,owner,group,0o700)
            if _identity(st)!=_identity(os.stat(name,dir_fd=opened[parent],follow_symlinks=False)):
                raise ValueError('directory changed')
        links={**{p:v[1] for p,v in payloads.items() if v[0]=='symlink'},**_EXTRAS}
        for path,(kind,data,mode) in sorted(payloads.items()):
            if kind!='file': continue
            rel=path[4:]; parent,_,name=rel.rpartition('/')
            fd=os.open(name,os.O_RDWR|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=opened[parent])
            try:
                view=memoryview(data)
                while view:
                    n=os.write(fd,view)
                    if n<=0: raise OSError('short write')
                    view=view[n:]
                os.fchmod(fd,int(mode,8)); os.fsync(fd); st=os.fstat(fd)
                if (not stat.S_ISREG(st.st_mode) or st.st_uid!=owner or st.st_nlink!=1 or
                    stat.S_IMODE(st.st_mode)!=int(mode,8) or st.st_size!=len(data) or not _no_acl(fd) or
                    _identity(st)!=_identity(os.stat(name,dir_fd=opened[parent],follow_symlinks=False))):
                    raise ValueError('file metadata')
                digest=hashlib.sha256(); pos=0
                while pos<st.st_size:
                    block=os.pread(fd,min(65536,st.st_size-pos),pos)
                    if not block: raise ValueError('short output')
                    digest.update(block); pos+=len(block)
                if digest.digest()!=hashlib.sha256(data).digest() or _id(os.fstat(fd))!=_id(st):
                    raise ValueError('output changed')
            finally: os.close(fd)
        for path,target in sorted(links.items()):
            rel=path[4:]; parent,_,name=rel.rpartition('/'); os.symlink(target,name,dir_fd=opened[parent])
            st=os.stat(name,dir_fd=opened[parent],follow_symlinks=False)
            if not stat.S_ISLNK(st.st_mode) or st.st_uid!=owner or os.readlink(name,dir_fd=opened[parent])!=target:
                raise ValueError('output link')
        expected={p:set() for p in dirs}
        for path in dirs-{''}:
            parent,_,name=path.rpartition('/'); expected[parent].add(name)
        for path in paths:
            parent,_,name=path[4:].rpartition('/'); expected[parent].add(name)
        for path,fd in opened.items():
            if set(os.listdir(fd))!=expected[path] or not _no_acl(fd): raise ValueError('unexpected output')
        for path in sorted(dirs,key=lambda x:(-x.count('/'),x!='',x),reverse=False):
            if path=='': continue
            os.fchmod(opened[path],0o555); os.fsync(opened[path]); _dir(opened[path],owner,group,0o555)
        os.fchmod(usr,0o555); os.fsync(usr); os.fsync(root_fd); _dir(usr,owner,group,0o555)
        if _identity(os.stat('usr',dir_fd=root_fd,follow_symlinks=False))!=_identity(os.fstat(usr)):
            raise ValueError('usr replaced')
        _check_root_entries(root_fd)
        if _identity(_dir(root_fd,owner,group,0o555))!=_identity(root_before): raise ValueError('root replaced')
        return {'runtime':'fixed_candidate_bytes_copied','packages':len(manifest['packages']),
                'files':sum(v[0]=='file' for v in payloads.values()),'links':len(links),
                'executed':False,'engine_launch_authorized':False,'target_runtime':'not_tested',
                'mounts':'not_created','provenance':'requires_external_archive_verification',
                'isolation':'not_verified','cleanup':'caller_required'}
    except Exception:
        if usr is not None and touched:
            try: os.fchmod(usr,0o555)
            except OSError: pass
        raise RuntimeStageError('runtime staging failed; stop and dispose full root') from None
    finally:
        for path,fd in opened.items():
            if path!='': os.close(fd)
        if usr is not None: os.close(usr)

def stage_fixed_ubuntu_runtime(package_fd,root_fd):
    """Public root-only, fixed snapshot; no caller-supplied paths or commands."""
    if os.geteuid()!=0: raise RuntimeStageError('disposable VM root required')
    return _install(package_fd,root_fd,_decompress_deb)
