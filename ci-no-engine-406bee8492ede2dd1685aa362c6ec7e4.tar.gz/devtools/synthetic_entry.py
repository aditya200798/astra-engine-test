"""Blocked, synthetic-only fixed driver entry; NOT a supervisor or sandbox.

The outside supervisor owns startup, output collection, timeout and unit cleanup.
This module never changes the driver's hard block or production gate. Its one
bounded record describes only local observations, not containment or release.
"""
import asyncio
import json
import re
import sys

from .fixed_integration_driver import DriverError, FixedIntegrationDriver

# Fixed allowlist: no raw exception, PID, port, config, prompt or endpoint data.
_ALLOWED = {
    'stage': frozenset(('not_started', 'blocked_before_start', 'preflight',
        'spawning_outcome_uncertain', 'child_spawned', 'cancelled_outcome_uncertain',
        'failed_outcome_uncertain', 'integration_observed_cleanup_pending',
        'failed_cleanup_uncertain', 'integration_observation_complete')),
    'spawn': frozenset(('not_attempted', 'outcome_unknown', 'child_handle_obtained')),
    'direct_child_cleanup': frozenset(('not_verified', 'uncertain', 'direct_exit_observed')),
    'config_observer_close': frozenset(('not_opened', 'not_attempted', 'closed',
        'uncertain', 'deferred_to_external_supervisor')),
    'lease_close': frozenset(('not_attempted', 'uncertain', 'close_requested')),
    'fixture_exit': frozenset(('not_entered', 'pending', 'returned')),
    'session_worker_call': frozenset(('not_submitted', 'unknown', 'call_completed')),
}


def _report(evidence, outcome):
    """Project a finite allowlist; missing/malformed values become unknown."""
    if type(evidence) is not dict:
        evidence = {}
    fields = {}
    for key, allowed in _ALLOWED.items():
        value = evidence.get(key)
        fields[key] = value if type(value) is str and value in allowed else 'unknown'
    # Complete inner observations are not external attestation.
    projected = None
    if outcome == 'returned':
        summary = evidence.get('integration')
        expected = {'baseline_auth_and_config_checks':'matched', 'baseline_streams_and_direct_exit':'matched',
            'session_status':'succeeded', 'fixture_handled_requests':1, 'fixture_valid_attempts':1,
            'fixture_user_prompt_matches':True, 'fixture_response_delivery':'write_completed_not_client_receipt',
            'fixture_final_check':'passed', 'session_worker_call':'call_completed',
            'endpoint_identity':'not_authenticated', 'binary_provenance':'not_verified',
            'isolation':'not_verified', 'descendant_cleanup':'not_verified',
            'all_network_traffic':'not_observed', 'tool_read':'not_run'}
        required = {'stage':'integration_observation_complete', 'spawn':'child_handle_obtained',
            'direct_child_cleanup':'direct_exit_observed', 'config_observer_close':'closed',
            'lease_close':'close_requested', 'fixture_exit':'returned', 'session_worker_call':'call_completed'}
        valid = (type(summary) is dict and set(summary) == set(expected) | {'fixture_request_sha256','stderr_bytes'}
            and all(type(summary.get(k)) is type(v) and summary.get(k) == v for k,v in expected.items())
            and all(fields.get(k) == v for k,v in required.items()))
        if valid:
            digest, count = summary.get('fixture_request_sha256'), summary.get('stderr_bytes')
            valid = (type(digest) is str and re.fullmatch('[0-9a-f]{64}',digest) is not None
                and type(count) is int and 0 <= count <= 65536)
        if valid: projected = dict(summary)
        else: outcome = 'invalid_return'
    return {'schema': 'astra-synthetic-inner-v1', 'outcome': outcome,
            'observations': fields, 'synthetic_evidence': projected, 'synthetic_only': True,
            'engine_launch_authorized': False, 'unit_cleanup': 'not_observed',
            'vm_decommission': 'not_observed', 'production_approved': False}


async def _once():
    driver = FixedIntegrationDriver()
    try:
        await driver.run()
        outcome = 'returned'
    except asyncio.CancelledError:
        outcome = 'cancelled'
    except DriverError:
        outcome = 'driver_error'
    except Exception:
        outcome = 'internal_error'
    return _report(driver.evidence, outcome)


def main():
    # No parameters, external paths, raw errors or selectable action. Executor
    # shutdown can still wait forever: the external service deadline is mandatory.
    if len(sys.argv) != 1:
        return 2
    try:
        result = asyncio.run(_once())
        line = json.dumps(result, sort_keys=True, separators=(',', ':'), ensure_ascii=True)
        if len(line) > 2048:
            return 2
        sys.stdout.write(line + '\n')
        sys.stdout.flush()
        return 0 if result['outcome'] == 'returned' else 1
    except (Exception, KeyboardInterrupt):
        # Missing or truncated output is an unknown to the outside supervisor.
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
