"""No-argument blocked baseline entry; not a supervisor or an attestation."""
import asyncio
import json
import sys
from .fixed_baseline_driver import DriverError, FixedBaselineDriver

_ALLOWED = {
 'stage': ('not_started','blocked_before_start','preflight','spawning_outcome_uncertain','child_spawned',
           'baseline_observed_cleanup_pending','baseline_observation_complete','cancelled_outcome_uncertain',
           'failed_outcome_uncertain','failed_cleanup_uncertain'),
 'spawn': ('not_attempted','outcome_unknown','child_handle_obtained'),
 'direct_child_cleanup': ('not_verified','uncertain','direct_exit_observed'),
 'config_observer_close': ('not_opened','not_attempted','closed','uncertain','deferred_to_external_supervisor'),
 'lease_close': ('not_attempted','uncertain','close_requested'),
 'astra_client_worker_call': ('not_submitted','unknown','call_completed')}


def _matches(d, expected):
    return type(d) is dict and all(k in d and type(d[k]) is type(v) and d[k] == v for k,v in expected.items())


def _report(evidence, outcome):
    e = evidence if type(evidence) is dict else {}
    fields = {k: e.get(k) if type(e.get(k)) is str and e[k] in vals else 'unknown' for k,vals in _ALLOWED.items()}
    projection = None
    if outcome == 'returned':
        b = e.get('baseline')
        ok = _matches(fields, {'stage':'baseline_observation_complete','spawn':'child_handle_obtained',
              'direct_child_cleanup':'direct_exit_observed','config_observer_close':'closed',
              'lease_close':'close_requested','astra_client_worker_call':'call_completed'})
        ok = ok and _matches(b, {'stage':'baseline_observation_complete','astra_client_info_matches_baseline':True,
                                  'astra_client_config_matches_baseline':True})
        info = b.get('info_check') if type(b) is dict else None
        config = b.get('config_check') if type(b) is dict else None
        ok = ok and _matches(info, {'version_statement_matches':True,'pid_statement_matches':True,
             'url_statement_matches':True,'tmp_statement_matches':True,'endpoint_identity':'not_authenticated',
             'binary_provenance':'not_verified'})
        ok = ok and _matches(config, {'effective_config':'matched_expected_sources_and_document','startup_safety':'not_verified'})
        count = b.get('stderr_bytes') if type(b) is dict else None
        ok = ok and type(count) is int and 0 <= count <= 65536
        if ok:
            projection = {'baseline_info_and_config':'matched','astra_transport_comparison':'matched','stderr_bytes':count,
                'endpoint_identity':'not_authenticated','binary_provenance':'not_verified','startup_safety':'not_verified',
                'descendant_cleanup':'not_verified','all_network_traffic':'not_observed'}
        else: outcome = 'invalid_return'
    return {'schema':'astra-synthetic-baseline-inner-v1','outcome':outcome,'observations':fields,
       'synthetic_evidence':projection,'synthetic_only':True,'engine_launch_authorized':False,
       'unit_cleanup':'not_observed','vm_decommission':'not_observed','production_approved':False}


async def _once():
    d = FixedBaselineDriver()
    try: await d.run(); outcome = 'returned'
    except asyncio.CancelledError: outcome = 'cancelled'
    except DriverError: outcome = 'driver_error'
    except Exception: outcome = 'internal_error'
    return _report(d.evidence,outcome)


def main():
    if len(sys.argv) != 1: return 2
    try:
        r = asyncio.run(_once())
        s = json.dumps(r,sort_keys=True,separators=(',',':'),ensure_ascii=True)
        if len(s) > 2048: return 2
        sys.stdout.write(s+'\n'); sys.stdout.flush()
        return 0 if r['outcome'] == 'returned' else 1
    except (Exception,KeyboardInterrupt): return 2


if __name__ == '__main__': raise SystemExit(main())
