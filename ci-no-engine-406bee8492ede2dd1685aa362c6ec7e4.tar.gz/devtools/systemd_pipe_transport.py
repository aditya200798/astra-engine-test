"""Fixed no-engine systemd --pipe transport, WIP; NOT an isolation boundary.

Private `_start` executes a systemd-run client with fixed arguments and a fresh
root FD. Public run() is hard-blocked; no status/control plane, release, cleanup
or engine launch is implemented. Authorized use requires an exclusive protected
VM, manager policy review, collision-safe name reservation and independent
watchdog; never use on the user's device or a shared host.
"""
import os
import re
import stat
import subprocess
from .synthetic_root_skeleton import _check_root_entries,_dir

_SYSTEMD_RUN='/usr/bin/systemd-run'
_LAUNCH_BLOCKED=True
_UNIT=re.compile(r'astra-synthetic-[0-9a-f]{32}\.service\Z')
_CLIENT_ENV={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','SYSTEMD_PAGER':'cat'}

class TransportError(RuntimeError): pass


def _valid_root(root):
    # Fixed root path grammar avoids systemd unit specifiers, whitespace,
    # escaping and ambiguous relative path normalization.
    return type(root) is str and re.fullmatch(r'/(?:[A-Za-z0-9_-]+/)*[A-Za-z0-9_-]+',root) is not None


def _argv(unit,kind,root):
    if (type(unit) is not str or _UNIT.fullmatch(unit) is None or
        type(kind) is not str or kind not in ('baseline','integration') or
        type(root) is not str or not root.startswith('/') or not _valid_root(root)):
        raise TransportError('fixed unit arguments invalid')
    return [_SYSTEMD_RUN,'--system','--no-ask-password','--pipe','--quiet',
            '--expand-environment=no','--unit='+unit,'--service-type=exec',
            '--property=RootDirectory='+root,
            '--property=User=65534','--property=Group=65534',
            '--property=SupplementaryGroups=',
            '--property=NoNewPrivileges=yes','--property=CapabilityBoundingSet=',
            '--property=AmbientCapabilities=',
            '--property=PrivateNetwork=yes','--property=PrivateDevices=yes',
            '--property=ProtectSystem=strict','--property=ReadWritePaths=+/work',
            '--property=MountAPIVFS=yes','--property=ProtectControlGroups=yes',
            '--property=KillMode=control-group','--property=TimeoutStopSec=3s',
            '--property=RuntimeMaxSec=90s','--property=LimitCORE=0',
            '--property=MemoryMax=1G','--property=TasksMax=64',
            '--working-directory=/work','--', '/usr/bin/python3','-I','-S','-B',
            '/app/devtools/synthetic_service_bootstrap.py',kind]


def _identity(st):return (st.st_dev,st.st_ino)


def _verify_root(root_fd,root_path):
    """Compare already-open root with its fixed path; no boundary proof."""
    if type(root_fd) is not int or root_fd<0: raise ValueError('root fd')
    if not _valid_root(root_path):
        raise ValueError('root path')
    held=_dir(root_fd,os.geteuid(),os.getegid(),0o555)
    _check_root_entries(root_fd)
    path=os.stat(root_path,follow_symlinks=False)
    if not stat.S_ISDIR(path.st_mode) or _identity(path)!=_identity(held): raise ValueError('root mismatch')
    # The no-engine control must not contain even a synthetic engine artifact.
    engine=os.open('engine',os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC,dir_fd=root_fd)
    try:
        _dir(engine,os.geteuid(),os.getegid(),0o555)
        if os.listdir(engine): raise ValueError('engine present')
    finally: os.close(engine)
    return None


class Client:
    """Owned child/pipe handles; not a unit reservation or cleanup authority.

    The three pipes have exactly one parent endpoint. Caller's direct child is
    systemd-run, not the service. No admission frame is provided here. Parent
    must close input on failures, coordinate a separate exact-unit stop, drain
    both outputs and retain unknown if any process/unit/tree observation is lost.
    """
    def __init__(self,process):self.process=process;self._closed=False
    @property
    def stdin(self):return self.process.stdin
    @property
    def stdout(self):return self.process.stdout
    @property
    def stderr(self):return self.process.stderr
    def close_input(self):
        if self.process.stdin is not None and not self.process.stdin.closed:self.process.stdin.close()
    def terminate_client(self,timeout=2):
        """Kill/reap only own client. This cannot stop/verify a service."""
        if type(timeout) not in (int,float) or not 0<timeout<=5: raise TransportError('invalid timeout')
        try:
            self.close_input()
            if self.process.poll() is None:self.process.kill()
            self.process.wait(timeout=timeout)
            return {'client':'exited','unit':'not_stopped_by_client_kill',
                    'cleanup':'unknown','engine_launch_authorized':False}
        except (OSError,subprocess.TimeoutExpired):
            return {'client':'unknown','unit':'not_stopped_by_client_kill',
                    'cleanup':'unknown','engine_launch_authorized':False}
        finally:
            for stream in (self.process.stdout,self.process.stderr):
                if stream is not None and not stream.closed:stream.close()
            self._closed=True


def _start(root_fd,root_path,unit,kind):
    """Start ONE client; caller owns all lifecycle and exclusive name claim.

    This is not a public entry point, authorization, or a sandbox. Root path
    must have been created by the trusted caller, be protected from mutation,
    and be stable in manager mount namespace; this function only samples it.
    Client-start acceptance is NOT manager acceptance: lost/rejected start is
    ambiguous and exact-unit recovery must be owned independently. A child may
    continue after parent death. Never retry an uncertain start.
    """
    try:
        _verify_root(root_fd,root_path)
        args=_argv(unit,kind,root_path)
        proc=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                              env=_CLIENT_ENV,cwd='/',close_fds=True,start_new_session=True,bufsize=0)
        return Client(proc)
    except Exception:
        raise TransportError('client start uncertain; independent recovery required') from None


def run():
    """No arguments: no caller can enable a manager transport through run()."""
    if _LAUNCH_BLOCKED: raise TransportError('no-engine manager transport not approved or wired')
    raise TransportError('live control plane and recovery not implemented')
