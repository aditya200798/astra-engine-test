"""Fixed-address private sd-bus connection candidate. NOT a launcher.

Only a separately supervised, credential-free disposable VM owner may use this
private helper. The public entry stays hard-blocked. Native calls may hang;
caller needs an independent external deadline and cleanup. No unit operation.
"""
import ctypes as c
from . import systemd_pidfd_lookup as look
from . import systemd_direct_start as direct
from . import systemd_job_tracker as jobs
from . import systemd_manager_identity as manager

P=c.c_void_p
_ADDRESS=b'unix:path=/run/dbus/system_bus_socket'
_BLOCKED=True
class BusError(RuntimeError):pass


def _proto(lib):
    direct._proto(lib);jobs._proto(lib);manager._proto(lib)
    specs={'sd_bus_new':([c.POINTER(P)],c.c_int),
           'sd_bus_set_address':([P,c.c_char_p],c.c_int),
           'sd_bus_set_bus_client':([P,c.c_int],c.c_int),
           'sd_bus_negotiate_fds':([P,c.c_int],c.c_int),
           'sd_bus_start':([P],c.c_int),
           'sd_bus_can_send':([P,c.c_char],c.c_int)}
    for name,(args,ret) in specs.items():
        fn=getattr(lib,name);fn.argtypes=args;fn.restype=ret


def _open():
    """Open one fixed broker address, configure ctypes, check owner and FDs.

    The returned library/bus/owner are caller-owned and must stay in the same
    process/thread and be closed by `_close`. Address removes the environment
    override, but does not authenticate the socket, namespace or PID 1.
    """
    lib=bus=None
    try:
        lib=c.CDLL(look._LIB,use_errno=True);_proto(lib);bus=P()
        if lib.sd_bus_new(c.byref(bus))<0 or not bus.value:raise ValueError('new')
        # Invoke sequentially: constructing a tuple of function results would
        # execute sd_bus_start even when fixed-address configuration failed.
        if lib.sd_bus_set_address(bus,_ADDRESS)<0:raise ValueError('address')
        if lib.sd_bus_set_bus_client(bus,1)<0:raise ValueError('bus client')
        if lib.sd_bus_negotiate_fds(bus,1)<0:raise ValueError('fd setup')
        if lib.sd_bus_start(bus)<0:raise ValueError('connect')
        if lib.sd_bus_set_method_call_timeout(bus,look._TIMEOUT_US)<0:raise ValueError('timeout')
        owner=look._owner(lib,bus)
        if lib.sd_bus_can_send(bus,b'h')<=0:raise ValueError('fd negotiation')
        manager.inspect(lib,bus,owner)
        return lib,bus,owner
    except BaseException:
        if bus is not None and bus.value:lib.sd_bus_flush_close_unref(bus)
        raise BusError('fixed bus unavailable') from None


def _close(lib,bus):
    if bus is not None and bus.value:lib.sd_bus_flush_close_unref(bus)


def run():
    if _BLOCKED:raise BusError('private bus blocked; lifecycle and watchdog unverified')
    raise BusError('no approved orchestration')
