"""Assemble fixed empty-engine control root; not a runner or safety gate.

All descriptors are caller-owned. The caller must ensure exclusive trusted
source/package/root directories, protected ancestors and mounts, fresh VM,
independent deadline/resource watchdog, and full disposal on any failure.
No engine artifact, service, mount or workload is created or launched here.
"""
from . import synthetic_root_skeleton as skeleton
from . import ubuntu_runtime_stage as runtime
from . import synthetic_root_verify as verify

_BLOCKED=True
class ControlRootError(RuntimeError):pass


def _assemble(source_fd,package_fd,root_fd,work_uid,work_gid):
    """Private composition for a fresh empty root; never retry a failed tree."""
    if (any(type(x) is not int or x<0 for x in (source_fd,package_fd,root_fd,work_uid,work_gid))
        or len({source_fd,package_fd,root_fd})!=3):
        raise ControlRootError('invalid descriptors')
    try:
        skeleton._assemble(source_fd,root_fd,work_uid,work_gid)
        runtime._install(package_fd,root_fd,runtime._decompress_deb)
        observed=verify._inspect(root_fd,work_uid,work_gid)
        if (observed.get('app_and_runtime')!='fixed_tree_hashes_matched_snapshot' or
            observed.get('engine')!='empty_snapshot' or
            observed.get('work')!='empty_identity_snapshot'):
            raise ValueError('incomplete observation')
        return {'root':'fixed_no_engine_tree_sampled','engine':'empty_snapshot',
                'work':'empty_identity_snapshot','files':observed['files'],'links':observed['links'],
                'executed':False,'mounts':'not_created','isolation':'not_verified',
                'protected_ancestors':'not_verified','provenance':'not_verified_here',
                'cleanup':'caller_required','engine_launch_authorized':False}
    except Exception:
        raise ControlRootError('control root failed; dispose whole tree; do not reuse') from None


def run():
    if _BLOCKED:raise ControlRootError('root assembly blocked: independent VM supervisor not established')
    raise ControlRootError('no approved orchestration')
