"""Source-informed identity/config gate for the synthetic developer harness.

An accepted JSON statement does not authenticate a binary or listener and is
not an isolation, startup, cleanup, budget or CI-serialization check. The source
schema may differ from the released binary: fail closed rather than guess.
"""
from astra.policy import check_config


class SyntheticBaselineGateError(ValueError):
    pass


def check_baseline_info(port, pid, info):
    """Check only bounded public expected fields; never include returned data.

    URL and pid are statements by the HTTP endpoint, not peer authentication.
    /work/tmp/opencode follows pinned Node source and exact VM layout. No broad
    guarantees about unknown additional server fields, processes or network.
    """
    if (type(port) is not int or not 1 <= port <= 65535 or
        type(pid) is not int or pid <= 0 or not isinstance(info, dict)):
        raise SyntheticBaselineGateError('baseline info mismatch')
    paths = info.get('paths')
    if (info.get('version') != '2.3.2' or type(info.get('pid')) is not int or
        info['pid'] != pid or info.get('urls') != ['http://127.0.0.1:%d' % port] or
        not isinstance(paths, dict) or paths.get('tmp') != '/work/tmp/opencode'):
        raise SyntheticBaselineGateError('baseline info mismatch')
    return {'version_statement_matches': True, 'pid_statement_matches': True,
            'url_statement_matches': True, 'tmp_statement_matches': True,
            'endpoint_identity': 'not_authenticated', 'binary_provenance': 'not_verified'}


def check_baseline_config(entries, expected, verify_directory):
    """Use the existing strict policy; path verification remains caller-supplied."""
    if not callable(verify_directory):
        raise SyntheticBaselineGateError('config verifier required')
    try:
        check_config(entries, expected, trusted_directory='/work/config',
                     verify_directory=verify_directory)
    except Exception:
        raise SyntheticBaselineGateError('baseline config mismatch') from None
    return {'effective_config': 'matched_expected_sources_and_document',
            'startup_safety': 'not_verified'}
