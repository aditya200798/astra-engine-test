"""Fixed public Ubuntu snapshot acquisition, NOT execution or authorization.

Caller supplies existing package directory and the fixed repository evidence.
Pinning only reproduces a historical snapshot under recorded provenance; it
is not signature validation, freshness, or proof of a safe runtime. Public entry
stays blocked; acquisition is not a complete CI/VM supervisor.
"""
import gzip
import hashlib
import os
import re
import stat
import urllib.error
import urllib.request
from . import ubuntu_runtime_stage as runtime

_BLOCKED=True
_LISTS=(('download-list','2b5c2e7d1b8f31b3ee1a85dc55298d85ffdb49aa6847511a0ef8dcb7e4d1a520'),
        ('extra-list','cf207d9321ad0e4294c36b3413db6ced6afb04a22007fd7c114a4906cab52187'))
_INDEXES=(('Packages.gz','c108418cc68852ebfaaff0049f90d59ec3fc39c62e6cf9518b25546bf7c29d68',1_799_510),
          ('BasePackages.gz','e0d7e4cbb09d2aa7f9e104a1488817417bc9d85f3e5d9a21156a52ec641ae531',1_808_488))
_BASE='https://archive.ubuntu.com/ubuntu/'
_MAX_INDEX=16_000_000
class AcquireError(RuntimeError):pass


def _read_exact(fd,limit):
    chunks=[];total=0
    while total<=limit:
        b=os.read(fd,min(65536,limit+1-total))
        if not b:break
        chunks.append(b);total+=len(b)
    if total>limit:raise ValueError('oversize')
    return b''.join(chunks)


def _evidence(fd,name,digest,limit,size=None):
    if type(fd) is not int or fd<0 or not stat.S_ISDIR(os.fstat(fd).st_mode):raise ValueError('evidence dir')
    f=os.open(name,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=fd)
    try:
        before=os.fstat(f)
        if not stat.S_ISREG(before.st_mode) or before.st_nlink!=1:raise ValueError('evidence file')
        data=_read_exact(f,limit);after=os.fstat(f)
        if runtime._id(before)!=runtime._id(after) or (size is not None and len(data)!=size) or hashlib.sha256(data).hexdigest()!=digest:
            raise ValueError('evidence digest')
        return data
    finally:os.close(f)


def _index(data):
    # Bounded decompression, and canonical one-paragraph package records.
    import io
    with gzip.GzipFile(fileobj=io.BytesIO(data)) as f:
        raw=f.read(_MAX_INDEX+1)
    if len(raw)>_MAX_INDEX:raise ValueError('index bound')
    result={}
    for paragraph in raw.split(b'\n\n'):
        fields={}
        for line in paragraph.splitlines():
            if line.startswith((b' ',b'\t')):continue
            key,sep,value=line.partition(b': ')
            if sep and key in (b'Package',b'Filename',b'Size',b'SHA256'):
                if key in fields:raise ValueError('duplicate index field')
                fields[key]=value
        if all(k in fields for k in (b'Package',b'Filename',b'Size',b'SHA256')):
            ident=(fields[b'Package'].decode('ascii'),fields[b'Filename'].decode('ascii'))
            if ident in result:raise ValueError('duplicate package identity')
            result[ident]=(int(fields[b'Size']),fields[b'SHA256'].decode('ascii'))
    return result


def _plan(evidence_fd):
    manifest=runtime._manifest(); packages=manifest['packages'];rows={}
    for name,digest in _LISTS:
        text=_evidence(evidence_fd,name,digest,8192).decode('ascii')
        for line in text.splitlines():
            fields=line.split()
            if len(fields)!=4:raise ValueError('list')
            key,path,sha,size=fields
            if (key in rows or key not in packages or not re.fullmatch(r'[a-z0-9][a-z0-9+.-]{0,80}',key) or
                not re.fullmatch(r'pool/main/[A-Za-z0-9+~._/-]+\.deb',path) or
                any(p in ('','.','..') for p in path.split('/')) or
                not re.fullmatch(r'[0-9a-f]{64}',sha) or not size.isdigit() or
                int(size)!=packages[key]['size'] or sha!=packages[key]['sha256'] or
                not 0<int(size)<=runtime._MAX_ARCHIVE):raise ValueError('list mismatch')
            rows[key]=(path,int(size),sha)
    if set(rows)!=set(packages):raise ValueError('package set')
    indexes=[_index(_evidence(evidence_fd,n,d,s,s)) for n,d,s in _INDEXES]
    for key,(path,size,sha) in rows.items():
        if not any(index.get((key,path))==(size,sha) for index in indexes):raise ValueError('index mismatch')
    return rows


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):return None


def _download(path,size):
    # Default TLS verifier, direct request (no environment-configured proxies),
    # fixed host/path and no redirects. Hash verification follows independently.
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),_NoRedirect())
    request=urllib.request.Request(_BASE+path,headers={'Accept-Encoding':'identity','User-Agent':'astra-synthetic-snapshot/1'})
    with opener.open(request,timeout=12) as response:
        if response.status!=200 or response.geturl()!=_BASE+path:raise ValueError('HTTP status')
        encoding=response.headers.get('Content-Encoding','identity').lower()
        if encoding!='identity':raise ValueError('encoding')
        declared=response.headers.get('Content-Length')
        if declared is not None and (not declared.isdigit() or int(declared)!=size):raise ValueError('length')
        raw=response.read(size+1)
        if len(raw)!=size:raise ValueError('length')
        return raw


def _write_new(package_fd,name,data):
    fd=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o400,dir_fd=package_fd)
    try:
        os.fchmod(fd,0o400);view=memoryview(data)
        while view:
            n=os.write(fd,view)
            if n<=0:raise ValueError('short write')
            view=view[n:]
        os.fsync(fd)
    finally:os.close(fd)


def _acquire(evidence_fd,package_fd):
    """One fixed snapshot, no secrets, no replacement/cleanup on failure.

    Must run in an independently bounded fetch phase, before network isolation;
    all input/output directories and ancestors are caller-protected. Any partial
    destination must be disposed, never reused or resumed. No arbitrary URL or
    executable accepted. Same-UID privileged writers and process crashes are
    external risks; socket timeout is not a total wall-clock bound.
    """
    if (type(evidence_fd) is not int or type(package_fd) is not int or
        min(evidence_fd,package_fd)<0 or evidence_fd==package_fd):raise AcquireError('invalid directory descriptors')
    try:
        st=os.fstat(package_fd)
        if (not stat.S_ISDIR(st.st_mode) or st.st_uid!=os.geteuid() or
            stat.S_IMODE(st.st_mode)!=0o700 or not runtime._no_acl(package_fd) or os.listdir(package_fd)):
            raise ValueError('destination')
        rows=_plan(evidence_fd)
        for key,(path,size,digest) in sorted(rows.items()):
            data=_download(path,size)
            if type(data) is not bytes or len(data)!=size or hashlib.sha256(data).hexdigest()!=digest:raise ValueError('download mismatch')
            _write_new(package_fd,key+'.deb',data)
        if set(os.listdir(package_fd))!={key+'.deb' for key in rows}:raise ValueError('unexpected entry')
        for key in sorted(rows):
            fd=os.open(key+'.deb',os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK,dir_fd=package_fd)
            try:runtime._read_package(fd,{'size':rows[key][1],'sha256':rows[key][2]})
            finally:os.close(fd)
        os.fsync(package_fd)
        return {'packages':'fixed_17_downloads_rehashed','provenance':'historical_snapshot_only',
                'freshness':'not_checked','signatures':'not_reverified_here','execution':False,
                'cleanup':'caller_required','engine_launch_authorized':False}
    except BaseException:
        raise AcquireError('snapshot acquisition failed; dispose destination; do not retry') from None


def run():
    if _BLOCKED:raise AcquireError('acquisition blocked: CI owner and fetch boundary not established')
    raise AcquireError('no approved workflow')
