"""Fixed no-engine release pipe primitive, not a service supervisor.

Private local plumbing only. Never call against a real manager until the
separately reviewed owner, independent watchdog and isolation have been
established. This module cannot grant engine or production authorization.
"""
import fcntl
import os
import stat
from .synthetic_service_barrier import _FRAME

_BLOCKED=True
class ReleaseError(RuntimeError):pass

class _Release:
    """Own one anonymous pipe writer and issue at most one fixed frame.

    Caller guarantees exclusive descriptor ownership, no aliases/writers,
    independently bound service/reader and outer cleanup. No callbacks or
    observation results are accepted here as an authorization substitute.
    The fixed frame is public protocol data. This is not an admission gate.
    """
    def __init__(self,fd):
        if type(fd) is not int or fd<0:raise ReleaseError('invalid writer')
        try:
            s=os.fstat(fd)
            if (not stat.S_ISFIFO(s.st_mode) or
                fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE!=os.O_WRONLY or
                len(_FRAME)>os.fpathconf(fd,'PC_PIPE_BUF')):
                raise ValueError('wrong writer')
            os.set_blocking(fd,False)
        except (OSError,ValueError,OverflowError):raise ReleaseError('writer unavailable') from None
        self._fd=fd;self.state='ready'
    def _close(self):
        fd=self._fd;self._fd=None
        if fd is not None:os.close(fd)
    def abort(self):
        """Close without frame; EOF depends on no other writers existing."""
        if self.state!='ready':raise ReleaseError('release consumed')
        self.state='abort_uncertain'
        try:self._close()
        except OSError:raise ReleaseError('close outcome unknown; recovery required') from None
        self.state='aborted'
        return {'frame':'not_written','eof':'not_observed','cleanup':'not_observed','engine_launch_authorized':False}
    def send_once(self):
        """One nonblocking fixed-frame write then close; no retry, no receipt claim."""
        if self.state!='ready':raise ReleaseError('release consumed')
        self.state='release_uncertain'
        try:
            if os.write(self._fd,_FRAME)!=len(_FRAME):raise OSError('short write')
            self._close()
        except BaseException:
            try:self._close()
            except OSError:pass
            raise ReleaseError('release outcome unknown; never retry; external recovery required') from None
        self.state='sent'
        return {'frame':'write_and_close_returned','eof':'not_observed','admission':'not_attested',
                'cleanup':'not_observed','engine_launch_authorized':False}

def run():
    if _BLOCKED:raise ReleaseError('no-engine release blocked: independent lifecycle not established')
    raise ReleaseError('no approved orchestration')
