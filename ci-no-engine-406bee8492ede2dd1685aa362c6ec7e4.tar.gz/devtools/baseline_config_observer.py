"""Developer-only advisory observation of the fixed baseline config directory.

No server launch, sandbox, external filesystem audit, or runtime authorization.
Use only in an externally supervised synthetic disposable VM. This observation
cannot stop a same-UID workload from writing between checks or during startup.
"""
import os
import stat


class ConfigObservationError(RuntimeError):
    pass


class ConfigDirectoryObservation:
    """Hold inode snapshots for a fresh private work root and empty config.

    Observation is raceable and fails closed on changed names, ownership, modes,
    entries or inaccessible paths. Root and config must be owned by this UID
    and exactly mode 0700. The caller must ensure a fresh synthetic work root,
    no other writers, namespace and mount controls and independent supervision.
    Does not verify other config sources, mounts, parent directories, ACLs or
    any prior reads. Close when finished; this is not an attestation or gate.
    """
    def __init__(self, root='/work'):
        self._root_fd = None
        self._config_fd = None
        self._closed = False
        self._root = root
        try:
            if not isinstance(root, str) or not os.path.isabs(root) or '\0' in root:
                raise ValueError('absolute root required')
            flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
            self._root_fd = os.open(root, flags)
            self._config_fd = os.open('config', flags, dir_fd=self._root_fd)
            self._root_id = self._identity(os.fstat(self._root_fd))
            self._config_id = self._identity(os.fstat(self._config_fd))
            if not self.verify():
                raise ValueError('initial observation failed')
        except (OSError, ValueError, TypeError):
            self.close()
            raise ConfigObservationError('config observation unavailable') from None

    @staticmethod
    def _identity(st):
        return (st.st_dev, st.st_ino)

    @staticmethod
    def _private_dir(st):
        return (stat.S_ISDIR(st.st_mode) and st.st_uid == os.geteuid()
                and stat.S_IMODE(st.st_mode) == 0o700)

    def verify(self):
        """Return only an advisory boolean; do not disclose contents or paths."""
        if self._closed:
            return False
        try:
            # lstat avoids following replacement symlinks for the root leaf and
            # the config leaf. The caller remains responsible for ancestors.
            root_fd_stat = os.fstat(self._root_fd)
            root_name_stat = os.stat(self._root, follow_symlinks=False)
            config_fd_stat = os.fstat(self._config_fd)
            config_name_stat = os.stat('config', dir_fd=self._root_fd, follow_symlinks=False)
            root_stats = (root_fd_stat, root_name_stat)
            config_stats = (config_fd_stat, config_name_stat)
            return (all(self._private_dir(st) and self._identity(st) == self._root_id for st in root_stats)
                    and all(self._private_dir(st) and self._identity(st) == self._config_id for st in config_stats)
                    and os.listdir(self._config_fd) == [])
        except (OSError, ValueError, TypeError):
            return False

    def close(self):
        if not self._closed:
            self._closed = True
            for name in ('_config_fd', '_root_fd'):
                fd = getattr(self, name, None)
                if fd is not None:
                    os.close(fd)
                    setattr(self, name, None)

    def __enter__(self):
        if self._closed:
            raise ConfigObservationError('observation closed')
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False
