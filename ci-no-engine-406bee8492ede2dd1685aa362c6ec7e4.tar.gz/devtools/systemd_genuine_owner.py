"""Private fixed genuine session owner, NOT a standalone supervisor.

Runs the actual session and owns six anonymous pipe ends. Caller must provide
an exclusive disposable VM, fixed protected root, single unit lifecycle and
independently supervised watchdog/recovery *before* invoking this private helper.
No executable is unblocked. Public entry deliberately remains closed.
"""
import os
import time
import json
from . import strict_inner_collector as collector
from . import systemd_genuine_session as bound
from . import genuine_vm_root as root

_BLOCKED=True
class OwnerError(RuntimeError):pass


def _drive_once(lib,bus,owner,unit,custody,*,slice_name=None,anchor=None):
    """Connect one real session; no name-based recovery, no retries.

    Caller owns bus/root and must independently bound native calls and stop
    ambiguous starts, including when this process is killed. No authorization,
    watchdog, root staging, cgroup check or cleanup is furnished here. Return
    only categorical evidence, not a claim of launch success or containment.
    """
    if (type(custody) is not root._Custody or custody.state!='assembled'):
        raise OwnerError('assembled pinned custody required')
    fds={}; session=None; result={
        'control':'unknown','stage':'pipe_creation','reason':'not_completed','start_phase':'not_started','start_error':'not_observed',
        'exit':'not_observed','stop':'not_observed','record':'not_observed',
        'cgroup_cleanup':'not_observed','vm_decommission':'not_observed',
        'isolation':'not_verified','engine_launch_authorized':False,
        'production_approved':False, 'fixture_request_sha256':None}
    provisional=False; exit_info=None
    def close_key(key):
        fd=fds.pop(key,None)
        if fd is not None:
            try:os.close(fd)
            except OSError:result['reason']='descriptor_close_uncertain'
    try:
        for read,write in (('input_read','input_write'),('output_read','output_write'),('error_read','error_write')):
            r,w=os.pipe2(os.O_CLOEXEC);fds[read]=r;fds[write]=w
        session=bound._Session(lib,bus,owner,unit,custody,
                               fds['input_write'],fds['output_read'],fds['error_read'],
                               **({'slice_name':slice_name} if slice_name is not None else {}),
                               **({'anchor':anchor} if anchor is not None else {}))
        result['stage']='start_uncertain'
        try:session.start_once(fds['input_read'],fds['output_write'],fds['error_write'])
        finally:
            # Original service endpoints are never needed again in this owner;
            # a sent sd-bus message or manager may hold duplicates.
            for k in ('input_read','output_write','error_write'):close_key(k)
        if result['reason']=='descriptor_close_uncertain':raise OwnerError('close')
        result['stage']='observe';session.observe()
        result['stage']='admission_uncertain'
        # Transfer sole close authority before call; never close a potentially
        # reassigned integer if the session already consumed it.
        try:
            session.admit_genuine_once()
        finally:
            # Transfer happens only once the session actually consumed it.
            # If rejected before consumption, the owner retains and closes it.
            if session._input_consumed:
                fds.pop('input_write',None)
        result['stage']='provisional';session.read_provisional(100);provisional=True
        result['stage']='exit';deadline=time.monotonic()+10
        while True:
            try:exit_info=session.observe_exit();break
            except bound.SessionError:
                if time.monotonic()>=deadline:raise
                time.sleep(.05)
        result['exit']='sampled_normal_exit';result['stage']='stop'
        session.stop_once();result['stop']='job_done_inactive_snapshot'
        result['stage']='final';final=session.read_final(5);result['record']='received'
        inner=final.get('inner');code=exit_info.get('exit_code')
        # Revalidate the complete canonical record, even though the real stream
        # reader already parses it. Never trust a mocked or alternate transport.
        raw=(json.dumps(inner,sort_keys=True,separators=(',',':'),ensure_ascii=True)+'\n').encode('ascii')
        inner=collector.parse(raw,'integration')
        if (inner['outcome']=='driver_error' and
            inner['observations']['stage']=='blocked_before_start' and type(code) is int and code==1):
            result['control']='blocked_genuine_entry_record_and_exit_sampled';result['reason']='cleanup_unverified'
        elif inner['outcome']=='returned' and type(code) is int and code==0:
            # Provisional same-process synthetic observation ONLY. Stop and
            # EOF were sampled; no cgroup/VM cleanup, provenance or authorization.
            result['fixture_request_sha256']=inner['synthetic_evidence']['fixture_request_sha256']
            result['control']='synthetic_inner_returned_cleanup_unverified';result['reason']='cleanup_unverified'
        else:
            result['reason']='inner_exit_mismatch'
        result['stage']='finished'
    except BaseException:
        if result['reason']!='descriptor_close_uncertain':result['reason']='operation_failed_or_uncertain'
        # Stop at most once, only with already bound invocation. Unknown start
        # cannot be recovered here; external supervisor owns that risk.
        if session is not None and not session._stop_attempted and session._bound is not None:
            try:session.stop_once();result['stop']='job_done_inactive_snapshot'
            except BaseException:pass
        # Final may still be useful after a failed stop; it remains diagnostic
        # and cannot upgrade the control result after an earlier failure.
        if (session is not None and provisional and session._stop_attempted
            and session._streams is not None and session._streams.stage=='provisional_done'):
            try:
                session.read_final(5);result['record']='received_diagnostic_only'
            except BaseException:pass
    finally:
        if session is not None:
            # Private fixed marker, not a guarantee that a manager call ran.
            result['start_phase']=session.start_phase;result['start_error']=session.start_error
            try:session.close()
            except BaseException:result['reason']='session_close_uncertain';result['control']='unknown'
        for k in tuple(fds):close_key(k)
        if result['reason'] in ('descriptor_close_uncertain','session_close_uncertain'):
            result['control']='unknown'
        if result['control']!='synthetic_inner_returned_cleanup_unverified':
            result['fixture_request_sha256']=None
    return result


def run():
    if _BLOCKED:raise OwnerError('genuine owner blocked: independent watchdog and recovery not established')
    raise OwnerError('no approved orchestration')
