"""Genuine-specific fixed root assembly, without a launch or authorization.

Private composition for a fresh exclusive credential-free disposable VM only.
The pinned archive must be staged separately to one root-owned 0400 file. A
failed or interrupted attempt contaminates the entire tree: dispose it only
under independent VM lifecycle control; do not retry it. This does not mount,
run, stop, supervise, attest provenance, or enable any integration gate.
"""
import os
from . import synthetic_root_skeleton as skeleton
from . import ubuntu_runtime_stage as runtime
from . import synthetic_root_artifact as artifact
from . import synthetic_root_verify as verify
from . import pinned_engine_stage as pinned

_BLOCKED = True

class GenuineRootError(RuntimeError):
    pass


def _assemble(source_fd, package_fd, root_fd, engine_fd, work_uid, work_gid,
              *, binary_size, binary_sha256):
    """Actual FD-only composition, configurable artifact solely for inert tests.

    All fds remain caller-owned, with protected ancestors, exclusive writers,
    no live processes or mounts, and independent deadline/VM cleanup. A verified
    snapshot is not a mount guarantee or an approval to execute the image.
    """
    if (any(type(x) is not int or x < 0 for x in
            (source_fd, package_fd, root_fd, engine_fd, work_uid, work_gid)) or
            len({source_fd, package_fd, root_fd, engine_fd}) != 4 or
            type(binary_size) is not int or binary_size <= 0 or
            type(binary_sha256) is not str or len(binary_sha256) != 64 or
            any(c not in '0123456789abcdef' for c in binary_sha256)):
        raise GenuineRootError('invalid composition inputs')
    try:
        skeleton._assemble(source_fd, root_fd, work_uid, work_gid)
        runtime._install(package_fd, root_fd, runtime._decompress_deb)
        # Recheck exact empty root before touching engine. Existing no-engine
        # verification remains unchanged and cannot admit the resulting tree.
        before = verify._inspect(root_fd, work_uid, work_gid)
        if (before.get('app_and_runtime') != 'fixed_tree_hashes_matched_snapshot' or
                before.get('engine') != 'empty_snapshot' or
                before.get('work') != 'empty_identity_snapshot'):
            raise ValueError('invalid empty root')
        placed = artifact._put(engine_fd, root_fd, os.geteuid(), os.getegid(),
                               binary_size, binary_sha256)
        if (placed.get('engine') != 'fixed_digest_staged_mode_0555' or
                placed.get('executed') is not False or
                placed.get('engine_launch_authorized') is not False):
            raise ValueError('artifact placement mismatch')
        after = verify._inspect(root_fd, work_uid, work_gid,
                                (binary_size, binary_sha256))
        if (after.get('app_and_runtime') != 'fixed_tree_hashes_matched_snapshot' or
                after.get('engine') != 'fixed_digest_snapshot' or
                after.get('work') != 'empty_identity_snapshot' or
                after.get('engine_launch_authorized') is not False):
            raise ValueError('invalid final root')
        return {'root': 'fixed_genuine_tree_sampled', 'engine': 'fixed_digest_snapshot',
                'work': 'empty_identity_snapshot', 'files': after['files'],
                'links': after['links'], 'executed': False,
                'mounts': 'not_created', 'isolation': 'not_verified',
                'provenance': 'not_verified', 'cleanup': 'caller_required',
                'engine_launch_authorized': False, 'production_approved': False}
    except Exception:
        raise GenuineRootError('root assembly failed; dispose whole tree; no retry') from None


def _assemble_pinned(source_fd, package_fd, root_fd, engine_fd):
    """Fixed UID and artifact, still no runtime authorization or supervisor."""
    if os.geteuid() != 0:
        raise GenuineRootError('disposable VM root required')
    return _assemble(source_fd, package_fd, root_fd, engine_fd, 65534, 65534,
                     binary_size=pinned.BINARY_SIZE, binary_sha256=pinned.BINARY_SHA256)


def run():
    if _BLOCKED:
        raise GenuineRootError('genuine VM root blocked: independent supervisor and review missing')
    raise GenuineRootError('no approved orchestration')

class _Custody:
    """One-shot actual FD custody and root assembly; not a launcher.

    Private parameterized form is for inert fixture tests only. Duplicates are
    CLOEXEC but share open file descriptions; hashing uses pread and does not
    change a caller's offset. This owns its duplicates until close(), including
    on failure; caller must dispose a partial tree after all workers stop.
    Snapshots do not make paths, mounts, inode contents, or VM ownership stable.
    """
    def __init__(self, source_fd, package_fd, root_fd, engine_fd, root_path,
                 work_uid, work_gid, *, binary_size, binary_sha256):
        import fcntl
        import stat
        from .systemd_pipe_transport import _valid_root
        self._fds = []
        self.state = 'constructing'
        if (any(type(x) is not int or x < 0 for x in
                (source_fd, package_fd, root_fd, engine_fd, work_uid, work_gid)) or
            len({source_fd, package_fd, root_fd, engine_fd}) != 4 or
            not _valid_root(root_path) or type(binary_size) is not int or binary_size <= 0 or
            type(binary_sha256) is not str or len(binary_sha256) != 64 or
            any(c not in '0123456789abcdef' for c in binary_sha256)):
            raise GenuineRootError('invalid custody inputs')
        try:
            for fd in (source_fd, package_fd, root_fd, engine_fd):
                self._fds.append(fcntl.fcntl(fd, fcntl.F_DUPFD_CLOEXEC, 3))
            stats = [os.fstat(fd) for fd in self._fds]
            if (not all(stat.S_ISDIR(s.st_mode) for s in stats[:3]) or
                not stat.S_ISREG(stats[3].st_mode) or
                len({(s.st_dev,s.st_ino) for s in stats}) != 4 or
                fcntl.fcntl(self._fds[3], fcntl.F_GETFL) & os.O_ACCMODE != os.O_RDONLY):
                raise ValueError('descriptor type or alias')
            self.root_path = root_path
            self.work_uid, self.work_gid = work_uid, work_gid
            self.binary_size, self.binary_sha256 = binary_size, binary_sha256
            self._engine_identity = self._metadata(stats[3])
            self._check_engine()
            self._check_root_path()
            self.state = 'fresh'
        except BaseException:
            self.close()
            raise GenuineRootError('custody setup failed; no assembly attempted') from None

    @staticmethod
    def _metadata(s):
        return (s.st_dev,s.st_ino,s.st_mode,s.st_uid,s.st_gid,s.st_nlink,
                s.st_size,s.st_mtime_ns,s.st_ctime_ns)

    def _check_engine(self):
        import hashlib
        import stat
        fd=self._fds[3]; before=os.fstat(fd)
        if (self._metadata(before) != self._engine_identity or
            not stat.S_ISREG(before.st_mode) or before.st_uid != os.geteuid() or
            before.st_nlink != 1 or stat.S_IMODE(before.st_mode) != 0o400 or
            before.st_size != self.binary_size or not skeleton._no_acl(fd)):
            raise ValueError('staged engine metadata changed')
        digest=hashlib.sha256(); pos=0
        while pos < self.binary_size:
            block=os.pread(fd,min(1048576,self.binary_size-pos),pos)
            if not block: raise ValueError('short engine')
            digest.update(block);pos+=len(block)
        if (os.pread(fd,1,pos) or digest.hexdigest()!=self.binary_sha256 or
            self._metadata(os.fstat(fd)) != self._engine_identity):
            raise ValueError('staged engine changed')

    def _check_root_path(self):
        import stat
        held=os.fstat(self._fds[2]); named=os.stat(self.root_path,follow_symlinks=False)
        if (not stat.S_ISDIR(named.st_mode) or
            (held.st_dev,held.st_ino)!=(named.st_dev,named.st_ino)):
            raise ValueError('root path changed')

    def assemble_once(self):
        if self.state != 'fresh': raise GenuineRootError('custody attempt consumed')
        self.state='assembly_uncertain'
        try:
            self._check_engine();self._check_root_path()
            result=_assemble(*self._fds,self.work_uid,self.work_gid,
                             binary_size=self.binary_size,binary_sha256=self.binary_sha256)
            if result.get('root')!='fixed_genuine_tree_sampled': raise ValueError('root result')
            self._check_root_path();self._check_engine()
            observation=verify._inspect(self._fds[2],self.work_uid,self.work_gid,
                                         (self.binary_size,self.binary_sha256))
            if observation.get('engine')!='fixed_digest_snapshot': raise ValueError('engine result')
            self._check_root_path()
            self.state='assembled'
            return result
        except BaseException:
            self.state='failed'
            raise GenuineRootError('assembly uncertain; dispose tree; no retry') from None

    def recheck(self):
        """Rehash the actual held engine and whole root; never authorizes start."""
        if self.state != 'assembled': raise GenuineRootError('custody unavailable')
        try:
            self._check_root_path();self._check_engine()
            result=verify._inspect(self._fds[2],self.work_uid,self.work_gid,
                                   (self.binary_size,self.binary_sha256))
            self._check_root_path();self._check_engine()
            if (result.get('engine')!='fixed_digest_snapshot' or
                result.get('app_and_runtime')!='fixed_tree_hashes_matched_snapshot' or
                result.get('work')!='empty_identity_snapshot' or
                result.get('engine_launch_authorized') is not False):
                raise ValueError('root observation')
            return result
        except BaseException:
            self.state='failed'
            raise GenuineRootError('custody recheck failed; no retry') from None

    def close(self):
        """Close owned duplicates only; not a stop or tree cleanup."""
        fds,self._fds=self._fds,[]
        self.state='closed'
        errors=False
        for fd in fds:
            try: os.close(fd)
            except OSError: errors=True
        if errors: raise GenuineRootError('descriptor close uncertain')


def _pinned_custody(source_fd, package_fd, root_fd, engine_fd, root_path):
    """Fixed root-owned engine pin; no general input or launch authorization."""
    if os.geteuid()!=0: raise GenuineRootError('disposable VM root required')
    return _Custody(source_fd, package_fd, root_fd, engine_fd, root_path,65534,65534,
                    binary_size=pinned.BINARY_SIZE,binary_sha256=pinned.BINARY_SHA256)
