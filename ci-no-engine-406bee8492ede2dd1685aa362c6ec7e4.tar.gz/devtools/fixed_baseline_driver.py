"""Unapproved WIP fixed inner baseline driver, developer testing only.

The launch hard block is intentional and independent from the production gate.
No public switch enables it. Do not change/remove it to run a genuine binary:
the outer VM supervisor and critical isolation/review/CI controls do not exist.
No command-line entry point. Unit tests replace dependencies only in memory.
"""
import asyncio
import os

from .baseline_config_observer import ConfigDirectoryObservation
from .baseline_only import BaselineOnly, baseline_environment

# Not a safety boundary against source modification. Unit tests patch it only
# to inspect wiring without executing a subprocess. Keep True for every run.
_LAUNCH_BLOCKED = True
_BINARY = '/engine/opencode'
_ARGV = (_BINARY, 'serve', '--stdio', '--hostname', '127.0.0.1', '--port', '0')
_DRIVER_ENV = {'PATH':'/usr/bin:/bin', 'HOME':'/work/home', 'TMPDIR':'/work/tmp',
               'LANG':'C', 'LC_ALL':'C'}


class DriverError(RuntimeError):
    pass


class FixedBaselineDriver:
    """One attempt only, no retries and no injected command/path/environment.

    Caller must arrange a *separate* external supervisor before this block may
    ever be reconsidered. Preflight checks below are merely snapshots; they do
    not prove namespaces, mount immutability, provenance, absence of secrets or
    cleanup. The server is expected to be the actual direct child in the same
    PID and network namespaces; a wrapper is not substituted for its PID.
    """
    def __init__(self):
        self._used = False
        self.evidence = {'stage':'not_started', 'engine_launch_authorized':False,
                         'genuine_engine':'not_attested', 'isolation':'not_verified',
                         'descendant_cleanup':'not_verified', 'provenance':'not_verified',
                         'direct_child_cleanup':'not_verified', 'spawn':'not_attempted',
                         'config_observer_close':'not_opened', 'lease_close':'not_attempted',
                         'astra_client_worker_call':'not_submitted'}

    async def run(self):
        if self._used:
            raise DriverError('driver already attempted; do not replay')
        self._used = True
        if _LAUNCH_BLOCKED:
            self.evidence['stage'] = 'blocked_before_start'
            raise DriverError('baseline launch hard-blocked; external controls not verified')
        proc = None
        observation = None
        baseline = None
        try:
            self.evidence['stage'] = 'preflight'
            if (os.getuid() != 65534 or os.geteuid() != 65534 or
                os.getgid() != 65534 or os.getegid() != 65534 or
                os.getgroups() != [] or dict(os.environ) != _DRIVER_ENV):
                raise DriverError('driver identity, groups or environment differs')
            observation = ConfigDirectoryObservation('/work')
            self.evidence['config_observer_close'] = 'not_attempted'
            if observation.verify() is not True:
                raise DriverError('config observation failed')
            self.evidence['stage'] = 'spawning_outcome_uncertain'
            self.evidence['spawn'] = 'outcome_unknown'
            # Constant absolute executable and arguments, not a shell. The
            # caller must provide the correct read-only mount, fresh layout,
            # independent PID/cgroup tracking and pre-enrollment externally.
            proc = await asyncio.create_subprocess_exec(
                *_ARGV, stdin=asyncio.subprocess.PIPE, stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE, cwd='/work/project',
                env=baseline_environment(), close_fds=True)
            self.evidence['spawn'] = 'child_handle_obtained'
            self.evidence['stage'] = 'child_spawned'
            baseline = BaselineOnly()
            result = await baseline.run(proc, observation.verify)
            self.evidence['stage'] = 'baseline_observed_cleanup_pending'
            self.evidence['baseline'] = result
        except asyncio.CancelledError:
            self.evidence['stage'] = 'cancelled_outcome_uncertain'
            raise
        except Exception:
            self.evidence['stage'] = 'failed_outcome_uncertain'
            raise DriverError('baseline failed or uncertain; no retry') from None
        finally:
            # Closing the observer must not prevent child cleanup. Both errors
            # are reflected, never hidden by a successful baseline result.
            if baseline is not None:
                try:
                    self.evidence['astra_client_worker_call'] = baseline.worker.snapshot()
                except Exception:
                    self.evidence['astra_client_worker_call'] = 'unknown'
            if observation is not None:
                if self.evidence['astra_client_worker_call'] == 'unknown':
                    # A submitted call can still access borrowed resources.
                    # Do not close/reuse FDs; outside unit cleanup is mandatory.
                    self.evidence['config_observer_close'] = 'deferred_to_external_supervisor'
                else:
                    try:
                        observation.close()
                        self.evidence['config_observer_close'] = 'closed'
                    except Exception:
                        self.evidence['config_observer_close'] = 'uncertain'
            if proc is not None:
                try:
                    if proc.stdin is None:
                        self.evidence['lease_close'] = 'uncertain'
                    else:
                        try:
                            proc.stdin.close()
                            self.evidence['lease_close'] = 'close_requested'
                        except Exception:
                            self.evidence['lease_close'] = 'uncertain'
                    if proc.returncode is None:
                        try:
                            proc.kill()
                        except ProcessLookupError:
                            pass  # It may have exited concurrently; wait checks.
                        try:
                            await asyncio.wait_for(proc.wait(), timeout=2)
                        except TimeoutError:
                            # Direct exit may be recorded while descendants still hold pipes.
                            # Snapshot below only; external unit cleanup is still mandatory.
                            pass
                    self.evidence['direct_child_cleanup'] = (
                        'direct_exit_observed' if proc.returncode is not None else 'uncertain')
                except asyncio.CancelledError:
                    self.evidence['direct_child_cleanup'] = 'uncertain'
                    self.evidence['stage'] = 'cancelled_outcome_uncertain'
                    raise
                except Exception:
                    self.evidence['direct_child_cleanup'] = 'uncertain'
        # Only a normal baseline AND locally observed cleanup can yield an
        # observation-complete result. It is not a containment, provenance,
        # descendant cleanup or engine-success report. The separate outer
        # supervisor must account for an unknown spawn and all descendants.
        if (self.evidence['astra_client_worker_call'] != 'call_completed' or
            self.evidence['config_observer_close'] != 'closed' or
            self.evidence['lease_close'] != 'close_requested' or
            self.evidence['direct_child_cleanup'] != 'direct_exit_observed'):
            self.evidence['stage'] = 'failed_cleanup_uncertain'
            raise DriverError('baseline cleanup uncertain; no retry')
        self.evidence['stage'] = 'baseline_observation_complete'
        return dict(self.evidence)
