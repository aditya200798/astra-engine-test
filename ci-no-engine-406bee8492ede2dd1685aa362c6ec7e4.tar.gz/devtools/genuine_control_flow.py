"""Private genuine blocked-driver control flow. Not a safety gate or launcher.

Only a disposable, exclusively controlled, independently supervised VM could
host this. Accepted late systemd jobs and whole-VM teardown remain UNKNOWN.
Public entry stays blocked; this module does not enable the genuine driver.
"""
import os
import re
from . import genuine_vm_root as root
from . import systemd_private_bus as bus
from . import systemd_genuine_owner as owner
from . import systemd_slice_anchor as anchor_mod
from . import systemd_pipe_transport as transport
from . import synthetic_no_engine_supervisor as supervisor

_BLOCKED=True
class ControlFlowError(RuntimeError):pass

class _ControlFlow:
    """One consumed attempt, keeping all four source FDs through worker fork.

    Caller must exclusively hold FDs and immutable paths through the call.
    A worker dies before handing the slice FD to its monitor => UNKNOWN; never
    guess a stop or retry. Root custody duplicates and rechecks engine/tree.
    """
    def __init__(self,source_fd,package_fd,root_fd,engine_fd,root_path,unit,*,slice_name,cgroup_root_fd):
        fds=(source_fd,package_fd,root_fd,engine_fd,cgroup_root_fd)
        if (any(type(x) is not int or x<0 for x in fds) or len(set(fds))!=5 or
            not transport._valid_root(root_path) or type(unit) is not str or
            transport._UNIT.fullmatch(unit) is None or
            slice_name!=owner.bound.direct._slice_for(unit)):
            raise ControlFlowError('invalid fixed control inputs')
        self.source_fd,self.package_fd,self.root_fd,self.engine_fd,self.cgroup_root_fd=fds
        self.root_path,self.unit,self.slice_name=root_path,unit,slice_name
        self._used=False

    def _run_once(self,*,_anchor_channel=None):
        if self._used:raise ControlFlowError('attempt consumed; do not retry')
        self._used=True
        result={'stage':'root_unknown','control':'unknown','record':'not_observed','stop':'not_observed',
                'owner_stage':'not_observed','owner_reason':'not_observed','start_phase':'not_observed',
                'start_error':'not_observed','cleanup':'not_verified','late_start':'not_reconciled',
                'vm_decommission':'not_observed','isolation':'not_verified',
                'engine_launch_authorized':False,'production_approved':False,'fixture_request_sha256':None}
        lib=connection=anchor=custody=None
        try:
            # No unsupervised service start: anchor ACK is mandatory.
            if _anchor_channel is None:raise ValueError('supervisor required')
            custody=root._pinned_custody(self.source_fd,self.package_fd,self.root_fd,self.engine_fd,self.root_path)
            staged=custody.assemble_once()
            if staged.get('root')!='fixed_genuine_tree_sampled' or staged.get('engine')!='fixed_digest_snapshot':
                raise ValueError('root')
            result['stage']='manager_unknown'
            lib,connection,manager=bus._open()
            result['stage']='anchor_uncertain'
            anchor=anchor_mod._Anchor(lib,connection,manager,self.unit,self.cgroup_root_fd)
            anchor.start_once()
            supervisor._send_anchor(_anchor_channel,anchor.group_fd)
            result['stage']='owner_uncertain'
            observation=owner._drive_once(lib,connection,manager,self.unit,custody,
                                          slice_name=self.slice_name,anchor=anchor)
            if type(observation) is not dict:raise ValueError('owner response')
            for key,allowed in (
                ('stage',supervisor._OWNER_STAGES),('reason',supervisor._OWNER_REASONS),
                ('start_phase',supervisor._START_PHASES),('start_error',supervisor._START_ERRORS),
                ('record',supervisor._RECORDS),('stop',supervisor._STOPS)):
                value=observation.get(key,'not_observed')
                if type(value) is not str or value not in allowed:raise ValueError('owner diagnostic')
                result[('owner_'+key) if key in ('stage','reason') else key]=value
            control=observation.get('control'); digest=observation.get('fixture_request_sha256')
            if (control not in ('unknown','blocked_genuine_entry_record_and_exit_sampled','synthetic_inner_returned_cleanup_unverified') or
                observation.get('engine_launch_authorized') is not False or
                observation.get('production_approved') is not False or
                (control=='synthetic_inner_returned_cleanup_unverified' and
                 (type(digest) is not str or re.fullmatch('[0-9a-f]{64}',digest) is None)) or
                (control!='synthetic_inner_returned_cleanup_unverified' and digest is not None)):
                raise ValueError('owner result')
            result['fixture_request_sha256']=digest
            result['control']=control;result['stage']='owner_returned_cleanup_unverified'
        except BaseException:
            result['control']='unknown'
        finally:
            if anchor is not None:
                try:anchor.close()
                except BaseException:result['control']='unknown';result['stage']='anchor_close_uncertain'
            if connection is not None:
                try:bus._close(lib,connection)
                except BaseException:result['control']='unknown'
            if custody is not None:
                try:custody.close()
                except BaseException:result['control']='unknown'
        if result['control']!='synthetic_inner_returned_cleanup_unverified':result['fixture_request_sha256']=None
        return result

def run():
    if _BLOCKED:raise ControlFlowError('genuine control blocked; outside recovery unverified')
    raise ControlFlowError('no approved orchestration')
