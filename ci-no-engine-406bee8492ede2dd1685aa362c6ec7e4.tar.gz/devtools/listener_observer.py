"""Best-effort Linux direct-child listener observation, not endpoint authentication.

Use only for synthetic-only disposable Linux tests, in the process's own network
namespace and with an independently enforced boundary/supervisor. A snapshot can
race socket transfer, process reuse or close/rebind. Never treat it as a security
boundary or permission to execute a binary. This module never launches processes.
"""
import os
import re

MAX_PROC_BYTES = 2 * 1024 * 1024
MAX_FDS = 4096


class ListenerObservationError(RuntimeError):
    pass


def _read(path):
    with open(path, 'rb') as f:
        data = f.read(MAX_PROC_BYTES + 1)
    if len(data) > MAX_PROC_BYTES:
        raise ListenerObservationError('proc limit')
    return data


def _start_time(pid):
    # comm can contain spaces and right parentheses: the last ')' closes it.
    data = _read('/proc/%d/stat' % pid)
    close = data.rfind(b')')
    if close < 0:
        raise ListenerObservationError('invalid stat')
    fields = data[close + 1:].split()
    if len(fields) < 20 or not fields[19].isdigit():
        raise ListenerObservationError('invalid stat')
    return int(fields[19])  # field 22, fields starts at field 3


def _listeners(port):
    hits = []
    for family in ('tcp', 'tcp6'):
        lines = _read('/proc/net/' + family).splitlines()
        if not lines:
            raise ListenerObservationError('missing network table')
        for line in lines[1:]:
            columns = line.split()
            if len(columns) < 10:
                raise ListenerObservationError('invalid network table')
            local = columns[1].split(b':')
            if len(local) != 2 or not re.fullmatch(rb'[0-9A-Fa-f]{4}', local[1]):
                raise ListenerObservationError('invalid local endpoint')
            if int(local[1], 16) == port and columns[3] == b'0A':
                if not columns[9].isdigit():
                    raise ListenerObservationError('invalid inode')
                hits.append((family, local[0].upper(), int(columns[9])))
    return hits


class DirectListenerObserver:
    """Snapshot Linux listener inode ownership by a direct PID, fail closed.

    The PID's start time and its network namespace are captured at creation and
    rechecked for each observation. Caller must instantiate promptly after spawn
    and keep the child unreaped. Does not eliminate PID/FD/network TOCTOU races.
    """
    def __init__(self, pid):
        if type(pid) is not int or pid <= 0:
            raise ListenerObservationError('invalid pid')
        self.pid = pid
        try:
            self.start_time = _start_time(pid)
            self.namespace = os.stat('/proc/%d/ns/net' % pid)
            own = os.stat('/proc/self/ns/net')
            if (self.namespace.st_dev, self.namespace.st_ino) != (own.st_dev, own.st_ino):
                raise ListenerObservationError('different network namespace')
        except (OSError, ValueError) as exc:
            raise ListenerObservationError('process observation unavailable') from exc

    def __call__(self, port):
        if type(port) is not int or not 1 <= port <= 65535:
            raise ListenerObservationError('invalid port')
        try:
            if _start_time(self.pid) != self.start_time:
                raise ListenerObservationError('process changed')
            current_ns = os.stat('/proc/%d/ns/net' % self.pid)
            own_ns = os.stat('/proc/self/ns/net')
            key = lambda st: (st.st_dev, st.st_ino)
            if key(current_ns) != key(self.namespace) or key(own_ns) != key(self.namespace):
                raise ListenerObservationError('network namespace changed')
            hits = _listeners(port)
            if len(hits) != 1 or hits[0][:2] != ('tcp', b'0100007F'):
                raise ListenerObservationError('not sole loopback listener')
            inode = hits[0][2]
            base = '/proc/%d/fd' % self.pid
            sockets = set()
            with os.scandir(base) as entries:
                for count, item in enumerate(entries, 1):
                    if count > MAX_FDS:
                        raise ListenerObservationError('fd limit')
                    if not item.name.isdigit():
                        raise ListenerObservationError('invalid fd')
                    try:
                        target = os.readlink(base + '/' + item.name)
                    except FileNotFoundError:
                        # A closed FD can hide the endpoint in a racing snapshot.
                        raise ListenerObservationError('fd changed') from None
                    match = re.fullmatch(r'socket:\[([0-9]+)\]', target)
                    if match:
                        sockets.add(int(match[1]))
            if inode not in sockets or _start_time(self.pid) != self.start_time:
                raise ListenerObservationError('listener owner not observed')
            if _listeners(port) != hits:
                raise ListenerObservationError('listener changed')
            return True
        except (OSError, ValueError) as exc:
            raise ListenerObservationError('listener observation unavailable') from exc
