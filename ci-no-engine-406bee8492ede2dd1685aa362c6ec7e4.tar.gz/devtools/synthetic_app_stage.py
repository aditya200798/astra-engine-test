"""Stage pinned synthetic Python sources, not a launcher, root or sandbox.

Caller owns source/destination descriptors, excludes concurrent writers and
must dispose the synthetic tree after all processes stop. This snapshots local
reviewed bytes, not upstream provenance or a runtime admission decision.
"""
import hashlib
import os
import stat

MANIFEST = {
    'astra/__init__.py': 'c2a5d744820c3c777a6431749c9f4e05fa039b75bcf9efe31eda0d96324d927e',
    'astra/policy.py': 'ad56393d7a1c7d7ea35ed22a014adb76d3e812ab93cab1efaf2e1acdd08aebe5',
    'astra/session.py': 'a16d94915cdd99f818c01d1f6d47d89785e9c3bd7fa6ae3a2e84b7df8f0979f9',
    'astra/storage.py': '06815d63cff5a11b4dc2e2cb7acee6b98003ec474062a265f5624e96749e8df0',
    'astra/transport.py': 'd7a09599d564c5866f3a4416d45e04be9db61ee78a774dd1bc5551a5ae382e84',
    'devtools/baseline_config_observer.py': '2a82557e15de4e7e31e2c6a3b04acbcb3879f7583305953ab725cebd91378fcb',
    'devtools/baseline_controller.py': '076312d081942cd43fa88f4fcdfc686c005ed7ae274360a9ed0cf98d17758c7f',
    'devtools/baseline_entry.py': 'a07276b6beac6a037bb1776d51b8d427b580dc81969703840be7c3f9c750176f',
    'devtools/baseline_only.py': 'b3cf1d862583ea02de5229bc80a3cb62c78bd9041ef027c3f06a022f855cdc56',
    'devtools/engine_controller.py': '25cf11a4fef1113b62991697c59aeef1dccdd03813184f6ecd721ec0592f4b86',
    'devtools/fake_responses.py': '706bc293518a225526d7c3c9ab60756362241085d16f4a09ac7c2d1f3bcf34e6',
    'devtools/fixed_baseline_driver.py': '2f0afe8303be8e8975d1c358b5a5adb09686a70308fc9951e2017f2306d0cdf5',
    'devtools/fixed_integration_driver.py': 'a3c7ea5965fecfa1342bb7b97dcc313d7168651e2db288135f5f3323eb2fa86d',
    'devtools/genuine_service_bootstrap.py': 'fee3d9d02b89427be58dd6385021e0d266c23174fcfcab1033dbafd1a52cecc2',
    'devtools/genuine_run_layout.py': '9ff8bfb2f342a8c08059f7b290e592bf6a44802dc5f57a0715497b13a116defb',
    'devtools/integration_evidence.py': 'b641c82f8fdfb38973d68967b7ecd011fd932f2823a4513e1e5c2b013905c6be',
    'devtools/listener_observer.py': 'e7f995542b6fe28894ef095d59e1c9295092b9bd79c3243747b6b6f18512095a',
    'devtools/synthetic_baseline_gate.py': '2813481a66f7b9a7f1cef3936b5b138db2d3fb378c487f57a2b3cb2c08788a4c',
    'devtools/synthetic_entry.py': '26dd3eb4b91aea582bb5a53237e9288b181c359d60a2b4d08c0e4692ff6ea6d7',
    'devtools/synthetic_integration.py': '64163bbc5bc468be0f95893eb25e722cf981e547fa958ab30183e7bd432dc252',
    'devtools/synthetic_service_barrier.py': 'a184fb2f054d36f36dfda3e987e4fab3c8f6ffa503621f971a7c081ae166676d',
    'devtools/synthetic_service_bootstrap.py': '09c4d75ad70ad091fbde09bffc907da4b721aeb816c570021cebcfa7038fc798',
    'devtools/synthetic_session_probe.py': 'a5616067d74bd9efc49c2f226efb4ea06c79f55584b4ac6dfd6b672cfc760196',
}
MAX_SOURCE=1_000_000
MAX_TOTAL=4_000_000
class StageError(RuntimeError): pass

def _identity(st):
    return (st.st_dev,st.st_ino,st.st_mode,st.st_uid,st.st_nlink,st.st_size,st.st_mtime_ns,st.st_ctime_ns)

def stage_into_empty_private_directory(source_fd, destination_fd):
    """FD-only fixed copy; rollback is best effort, never a containment proof.

    No symlink leaves, hardlinked source files or nonempty/nonprivate output.
    Only destination leaves are created. No guarantees about parent paths,
    ACLs, concurrent root/same-UID writers, mounts or writable aliases.
    """
    if type(source_fd) is not int or type(destination_fd) is not int or min(source_fd,destination_fd)<0:
        raise StageError('directory descriptors required')
    sources={}; dirs={}; made=[]; payloads={}; success=False; uncertain=False
    try:
        if not all(hasattr(os,x) for x in ('O_NOFOLLOW','O_DIRECTORY','O_CLOEXEC')): raise ValueError('unsupported')
        src=os.fstat(source_fd); dst=os.fstat(destination_fd)
        if (not stat.S_ISDIR(src.st_mode) or not stat.S_ISDIR(dst.st_mode) or dst.st_uid!=os.geteuid()
            or stat.S_IMODE(dst.st_mode)!=0o700 or os.listdir(destination_fd)):
            raise ValueError('invalid destination')
        flags=os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC
        for package in ('astra','devtools'): sources[package]=os.open(package,flags,dir_fd=source_fd)
        total=0
        for path,want in sorted(MANIFEST.items()):
            package,name=path.split('/')
            fd=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK,dir_fd=sources[package])
            try:
                before=os.fstat(fd)
                if not stat.S_ISREG(before.st_mode) or before.st_nlink!=1 or not 0<=before.st_size<=MAX_SOURCE:
                    raise ValueError('invalid source')
                data=bytearray()
                while len(data)<=MAX_SOURCE:
                    part=os.read(fd,min(65536,MAX_SOURCE+1-len(data)))
                    if not part: break
                    data.extend(part)
                total+=len(data); named=os.stat(name,dir_fd=sources[package],follow_symlinks=False)
                if (len(data)!=before.st_size or total>MAX_TOTAL or _identity(os.fstat(fd))!=_identity(before)
                    or (named.st_dev,named.st_ino)!=(before.st_dev,before.st_ino)
                    or hashlib.sha256(data).hexdigest()!=want): raise ValueError('source changed')
                payloads[path]=bytes(data)
            finally: os.close(fd)
        for package in ('astra','devtools'):
            os.mkdir(package,0o700,dir_fd=destination_fd); made.append((None,package))
            dirs[package]=os.open(package,flags,dir_fd=destination_fd); os.fchmod(dirs[package],0o700)
        for path,data in sorted(payloads.items()):
            package,name=path.split('/')
            fd=os.open(name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=dirs[package])
            made.append((package,name))
            try:
                view=memoryview(data)
                while view:
                    written=os.write(fd,view)
                    if written<=0: raise OSError('write failed')
                    view=view[written:]
                os.fchmod(fd,0o400); os.fsync(fd); st=os.fstat(fd)
                if not stat.S_ISREG(st.st_mode) or st.st_nlink!=1 or st.st_size!=len(data) or stat.S_IMODE(st.st_mode)!=0o400:
                    raise ValueError('invalid staged file')
            finally: os.close(fd)
        for fd in dirs.values(): os.fsync(fd)
        os.fsync(destination_fd); success=True
        return {'files':len(payloads),'bytes':sum(map(len,payloads.values())),
                'manifest':'fixed_local_digests_matched','executable_started':False,
                'engine_launch_authorized':False,'isolation':'not_verified',
                'provenance':'not_verified','runtime_dependencies':'not_staged',
                'cleanup':'caller_required'}
    except (OSError,ValueError,TypeError,KeyError):
        raise StageError('app stage failed; inspect destination and do not launch') from None
    finally:
        if not success:
            for package,name in reversed(made):
                try:
                    if package is None: os.rmdir(name,dir_fd=destination_fd)
                    else: os.unlink(name,dir_fd=dirs[package])
                except OSError: uncertain=True
        for fd in dirs.values(): os.close(fd)
        for fd in sources.values(): os.close(fd)
        if uncertain: raise StageError('app stage failed; rollback uncertain; dispose destination') from None
