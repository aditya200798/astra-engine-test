"""Read-only same-bus owner credentials and bus-socket peer observation.

This is a sampled check for the fixed synthetic CI candidate, NOT a proof of
host origin, a privileged manager authority, reservation, admission or cleanup.
"""
import ctypes as c
import os
import re
import select
import socket
import struct
from . import systemd_pidfd_lookup as look

P=c.c_void_p
class IdentityError(RuntimeError):pass
# v255 sd-bus.h: SD_BUS_CREDS_PID and SD_BUS_CREDS_EUID. No AUGMENT.
_MASK=(1<<0)|(1<<4)


def _proto(lib):
    specs={'sd_bus_get_fd':([P],c.c_int),
           'sd_bus_get_name_creds':([P,c.c_char_p,c.c_uint64,c.POINTER(P)],c.c_int),
           'sd_bus_creds_get_pid':([P,c.POINTER(c.c_int)],c.c_int),
           'sd_bus_creds_get_euid':([P,c.POINTER(c.c_uint32)],c.c_int),
           'sd_bus_creds_unref':([P],P)}
    for name,(args,ret) in specs.items():
        fn=getattr(lib,name);fn.argtypes=args;fn.restype=ret


def _socket_peer(fd):
    """Inspect duplicate socket, not a configurable path; return peer uid.

    Caller keeps the original open and exclusively owns it; no daemon or socket
    path identity, PID of broker, mount namespace or hostile-root claim follows.
    """
    if type(fd) is not int or fd<0:raise ValueError('fd')
    dup=os.dup(fd)
    try:
        with socket.socket(fileno=dup) as s:
            dup=-1
            if s.family!=socket.AF_UNIX or s.getsockopt(socket.SOL_SOCKET,socket.SO_TYPE)!=socket.SOCK_STREAM:
                raise ValueError('socket type')
            raw=s.getsockopt(socket.SOL_SOCKET,socket.SO_PEERCRED,struct.calcsize('3i'))
            pid,uid,gid=struct.unpack('3i',raw)
            if pid<=0 or uid<0 or gid<0:raise ValueError('peer creds')
            return uid
    finally:
        if dup>=0:os.close(dup)


def _manager_creds(lib,bus,owner):
    creds=P();pid=c.c_int();uid=c.c_uint32()
    try:
        if lib.sd_bus_get_name_creds(bus,owner.encode('ascii'),_MASK,c.byref(creds))<0 or not creds.value:
            raise ValueError('credentials')
        if lib.sd_bus_creds_get_pid(creds,c.byref(pid))<0 or lib.sd_bus_creds_get_euid(creds,c.byref(uid))<0:
            raise ValueError('missing credentials')
        return pid.value,uid.value
    finally:
        if creds.value:lib.sd_bus_creds_unref(creds)


def inspect(lib,bus,owner):
    """Require root UNIX broker peer and sampled manager PID 1/euid 0.

    PID 1 is interpreted in the observer's PID/proc namespaces. Caller must
    verify these are the intended VM namespaces and the socket and broker are
    trusted; SO_PEERCRED=0 and bus-reported PID 1 are not self-authenticating.
    A PIDFD pins PID 1 for the sampling window, not the manager bus connection.
    Native calls and syscalls require an external supervisor/deadline.
    """
    if type(owner) is not str or re.fullmatch(r':[0-9]+\.[0-9]+',owner) is None or not bus:
        raise IdentityError('invalid observation')
    pidfd=None
    try:
        _proto(lib)
        if look._owner(lib,bus)!=owner:raise ValueError('owner')
        fd=lib.sd_bus_get_fd(bus)
        if _socket_peer(fd)!=0:raise ValueError('broker uid')
        if _manager_creds(lib,bus,owner)!=(1,0):raise ValueError('manager credentials')
        pidfd=os.pidfd_open(1,0);look._pidfd(pidfd)
        look._fdinfo(look._read('/proc/self/fdinfo/'+str(pidfd)),1)
        if select.select([pidfd],[],[],0)[0]:raise ValueError('manager exited')
        if (look._owner(lib,bus)!=owner or _manager_creds(lib,bus,owner)!=(1,0) or
            _socket_peer(fd)!=0 or select.select([pidfd],[],[],0)[0]):raise ValueError('changed')
        return {'bus_socket':'unix_stream_root_peer_snapshot','manager':'bus_reports_pid1_root_snapshot',
                'pid1':'pidfd_alive_snapshot','manager_authenticity':'not_proven','reservation':'not_proven',
                'cleanup':'not_observed','engine_launch_authorized':False}
    except Exception:raise IdentityError('manager identity unavailable') from None
    finally:
        if pidfd is not None:os.close(pidfd)
