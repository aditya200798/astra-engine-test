"""Read-only sampled namespace/mount information, NOT admission or sandbox.

Only a trusted externally supervised disposable VM caller may use this module.
A passing snapshot neither proves no egress nor authorizes process execution.
"""
import os
import re
import select
from .service_proc_observer import _pidfd,_fdinfo,_read,_stat_start

_MAX=1_048_576
class NamespaceError(RuntimeError):pass


def _interfaces(raw):
    lines=raw.decode('ascii').splitlines()
    if len(lines)<3 or 'Inter-' not in lines[0] or 'face' not in lines[1]:raise ValueError('header')
    names=[]
    for line in lines[2:]:
        left,sep,right=line.partition(':')
        if not sep or not left.strip() or len(right.split())!=16 or any(not v.isdigit() for v in right.split()):
            raise ValueError('interface')
        names.append(left.strip())
    if names!=['lo']:raise ValueError('extra interfaces')


def _mounts(raw):
    """Restrictive candidate shape; may reject a legitimate target manager."""
    if type(raw) is not bytes or len(raw)>_MAX:raise ValueError('size')
    rows={};ids=set()
    for line in raw.decode('ascii').splitlines():
        fields=line.split();
        if fields.count('-')!=1:raise ValueError('separator')
        i=fields.index('-')
        if i<6 or len(fields)!=i+4 or not fields[0].isdigit() or not fields[1].isdigit():raise ValueError('shape')
        if fields[0] in ids or not re.fullmatch(r'[0-9]+:[0-9]+',fields[2]):raise ValueError('id')
        ids.add(fields[0]);root,mount=fields[3],fields[4]
        if '\\' in root or '\\' in mount or not root.startswith('/') or not mount.startswith('/'):
            raise ValueError('escaped or invalid path')
        options=fields[5].split(',')
        if len(set(options))!=len(options) or ('ro' in options)==('rw' in options):raise ValueError('options')
        if any(x.startswith(('shared:','master:','propagate_from:')) for x in fields[6:i]):raise ValueError('propagation')
        if mount in rows:raise ValueError('stacked mount')
        rows[mount]=(set(options),fields[i+1])
    # Unknown mounts, including overmounts or writable aliases, are rejected.
    # This is a candidate, not a claim systemd mounts exactly this topology.
    allowed={'/','/app','/usr','/work','/dev','/dev/pts','/dev/shm','/proc',
             '/proc/sys','/proc/sysrq-trigger','/sys','/sys/fs/cgroup','/run','/run/host/os-release'}
    if not {'/','/work','/dev','/proc'}.issubset(rows) or set(rows)-allowed:raise ValueError('unexpected mount')
    for path in ('/','/app','/usr','/sys','/sys/fs/cgroup','/proc/sys','/proc/sysrq-trigger','/run/host/os-release'):
        if path in rows and 'ro' not in rows[path][0]:raise ValueError('writable protected mount')
    if 'rw' not in rows['/work'][0]:raise ValueError('work readonly')
    if rows['/proc'][1]!='proc' or rows['/dev'][1]!='tmpfs':raise ValueError('fs type')
    # systemd MountAPIVFS may mount a fresh tmpfs at /run. No network or
    # backing-store assurance is implied by its reported filesystem type.
    if '/run' in rows and rows['/run'][1]!='tmpfs':raise ValueError('run type')
    return len(rows)


def inspect(pid,pidfd):
    """Compare target/observer net + mount namespaces and sample target data.

    Uses no setns, no sockets and no mutation. Caller must bind this same live
    process to its manager and a trusted private root independently. Network
    interface list does NOT establish address/routes/loopback operation or all
    egress; mountinfo doesn't identify underlying host path aliases or future
    changes. Syscalls may hang: caller needs an external deadline/watchdog.
    """
    if type(pid) is not int or pid<=0 or type(pidfd) is not int or pidfd<0:
        raise NamespaceError('invalid input')
    try:
        _pidfd(pidfd)
        _fdinfo(_read('/proc/self/fdinfo/'+str(pidfd)),pid)
        if select.select([pidfd],[],[],0)[0]:raise ValueError('exited')
        base='/proc/'+str(pid); start=_stat_start(_read(base+'/stat'),pid)
        def ns(path):
            st=os.stat(path);return st.st_dev,st.st_ino
        target_net=ns(base+'/ns/net');target_mnt=ns(base+'/ns/mnt')
        if target_net==ns('/proc/self/ns/net') or target_mnt==ns('/proc/self/ns/mnt'):
            raise ValueError('namespace not distinct')
        _interfaces(_read(base+'/net/dev',_MAX));count=_mounts(_read(base+'/mountinfo',_MAX))
        if (target_net!=ns(base+'/ns/net') or target_mnt!=ns(base+'/ns/mnt') or
            _stat_start(_read(base+'/stat'),pid)!=start or select.select([pidfd],[],[],0)[0]):
            raise ValueError('process changed')
        _fdinfo(_read('/proc/self/fdinfo/'+str(pidfd)),pid)
        return {'network_namespace':'distinct_snapshot','network_interfaces':'loopback_only_snapshot',
                'mount_namespace':'distinct_snapshot','mount_layout':'candidate_shape_snapshot',
                'mount_count':count,'routes_egress':'not_verified','mount_backing_aliases':'not_verified',
                'cleanup':'not_observed','admission':'not_authorized','engine_launch_authorized':False}
    except Exception:raise NamespaceError('namespace observation unavailable') from None
