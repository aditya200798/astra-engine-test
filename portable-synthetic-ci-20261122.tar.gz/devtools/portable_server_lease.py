"""Synthetic-only child lease and continuous bounded output observation.

No program launcher, credential store, endpoint authentication or sandbox.
External supervision and separately checked listener ownership remain necessary.
"""
import math
import os
import selectors
import signal
import subprocess
import threading
import time
from .engine_controller import LeaseObservation, ObservationError

class LeaseError(RuntimeError):pass

def _deadline(timeout, maximum):
    if type(timeout) not in (int,float) or not math.isfinite(timeout) or not 0<timeout<=maximum:
        raise LeaseError('invalid deadline')
    return time.monotonic()+timeout

class SyntheticLease:
    """One child, one lease; background reader owns the parser and selector.

    Caller owns launch and external hard supervision. Sticky failure does not
    authenticate the port or prevent a request already in flight. Descendant
    cleanup and containment remain unverified even if the direct child exits.
    """
    def __init__(self,child):
        if any(getattr(child,n,None) is None for n in ('stdin','stdout','stderr')) or type(getattr(child,'pid',None)) is not int or child.pid<=0:
            raise LeaseError('child pipes required')
        self.child=child;self._parser=LeaseObservation();self._used=False;self._closed=False
        self._condition=threading.Condition();self._port=None;self._error=None
        self._out_done=False;self._err_done=False;self._stderr_count=0;self._stop=threading.Event()
        self._selector=selectors.DefaultSelector()
        try:
            for name in ('stdout','stderr'):
                stream=getattr(child,name);os.set_blocking(stream.fileno(),False)
                self._selector.register(stream,selectors.EVENT_READ,name)
            self._thread=threading.Thread(target=self._read,name='astra-synthetic-lease',daemon=True)
            self._thread.start()
        except BaseException:
            self._selector.close();raise

    def _read(self):
        try:
            while not self._stop.is_set() and self._selector.get_map():
                for key,_ in self._selector.select(.1):
                    try:data=os.read(key.fd,4096)
                    except BlockingIOError:continue
                    with self._condition:
                        if not data:
                            self._selector.unregister(key.fileobj)
                            if key.data=='stdout':
                                self._parser.finish();self._out_done=True
                            else:self._err_done=True
                        elif key.data=='stdout':
                            self._parser.feed(data)
                            self._port=self._parser.port_if_complete()
                        else:
                            self._stderr_count+=len(data)
                            if self._stderr_count>65536:raise LeaseError('stderr limit')
                        self._condition.notify_all()
        except (OSError,ObservationError,LeaseError,ValueError):
            with self._condition:
                self._error='output observation failed';self._condition.notify_all()
        finally:
            self._selector.close()
            with self._condition:self._condition.notify_all()

    def wait_port(self,timeout=20.0):
        deadline=_deadline(timeout,60)
        with self._condition:
            if self._used or self._closed:raise LeaseError('lease already consumed')
            self._used=True
            while True:
                if self._error:raise LeaseError(self._error)
                if self._port is not None:
                    if self.child.poll() is not None:raise LeaseError('child already exited; outcome unknown')
                    return self._port
                if self._out_done or self.child.poll() is not None:raise LeaseError('child exited before lease')
                remaining=deadline-time.monotonic()
                if remaining<=0:raise LeaseError('startup timeout; outcome unknown')
                self._condition.wait(min(remaining,.1))

    def healthy(self):
        """Fail closed on sampled reader errors/exits; not endpoint attestation."""
        with self._condition:
            return (not self._closed and self._used and self._port is not None and
                    self._error is None and not self._out_done and self.child.poll() is None)

    def finish(self,timeout=4.0):
        deadline=_deadline(timeout,30)
        with self._condition:
            if self._closed:raise LeaseError('lease already closed')
            self._closed=True
        try:self.child.stdin.close()
        except OSError:pass
        try:
            with self._condition:
                while not self._error and not (self._out_done and self._err_done):
                    remaining=deadline-time.monotonic()
                    if remaining<=0:break
                    self._condition.wait(min(remaining,.1))
                error=self._error;out_done=self._out_done;err_done=self._err_done
            try:code=self.child.wait(timeout=max(0.,deadline-time.monotonic()))
            except subprocess.TimeoutExpired:code=None
            if error:raise LeaseError('output or process outcome uncertain')
            return {'direct_exit_observed':code is not None,'exit_code':code,
                    'lease_stream_complete':out_done,'stderr_stream_complete':err_done,
                    'descendants':'not_verified','isolation':'not_verified'}
        finally:
            if self.child.poll() is None:
                for sig in (signal.SIGTERM,signal.SIGKILL):
                    try:
                        if os.getpgid(self.child.pid)==self.child.pid:os.killpg(self.child.pid,sig)
                    except (ProcessLookupError,PermissionError):pass
                    try:self.child.wait(timeout=1);break
                    except subprocess.TimeoutExpired:pass
            self._stop.set();self._thread.join(timeout=1)
            if not self._thread.is_alive():
                for stream in (self.child.stdout,self.child.stderr):
                    try:stream.close()
                    except OSError:pass
