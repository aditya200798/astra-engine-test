"""Synthetic-only portable assembly for an externally launched child.

Not a launcher, product entrypoint, sandbox, peer authentication or cleanup
supervisor. Run only with invented data and an independent hard supervisor.
One attempt per object. Failures are uncertain; preserve state and do not replay.
"""
import asyncio,base64,threading
from . import coding_fake_responses as fixture
from .baseline_config_observer import ConfigDirectoryObservation
from .baseline_controller import _response,_json
from .listener_observer import DirectListenerObserver
from .portable_coding_synthetic import PortableCodingProbe
from .portable_server_lease import SyntheticLease

class AssemblyError(RuntimeError):pass

async def _request(port,path,password):
    """Fixed bounded HTTP baseline request; credentials never enter logs."""
    reader,writer=await asyncio.open_connection('127.0.0.1',port,limit=16384)
    try:
        auth=b'' if password is None else b'Authorization: Basic '+base64.b64encode(('opencode:'+password).encode('ascii'))+b'\r\n'
        writer.write(b'GET '+path.encode('ascii')+b' HTTP/1.1\r\nHost: 127.0.0.1:'+str(port).encode('ascii')+b'\r\nAccept: application/json\r\n'+auth+b'Connection: close\r\n\r\n')
        await writer.drain()
        return await _response(reader)
    finally:writer.close()

class PortableSyntheticAssembly:
    """Enter fixture first, launch externally with environment(), then run(child).

    __exit__ finalizes the fake fixture. A returned candidate is provisional
    until scope exit completes and evidence stage is assembly_complete. A hung
    worker, server handler, signal or kernel syscall requires an external hard
    watchdog. No output is an independent attestation or production approval.
    """
    def __init__(self,root):
        self.root=root;self._server=None;self._thread=None;self._obs=None
        self._entered=False;self._used=False;self._closed=False;self._thread_failed=False
        self.evidence={'stage':'not_started','spawn':'externally_owned',
                       'isolation':'not_verified','descendant_cleanup':'not_verified',
                       'genuine_engine':'not_attested','production_approved':False}
    def __enter__(self):
        if self._entered or self._closed:raise AssemblyError('already used')
        self._entered=True
        try:
            self._server=fixture.CodingHTTPServer(('127.0.0.1',0))
            self.probe=PortableCodingProbe(self.root,self._server.server_address[1])
            self._obs=ConfigDirectoryObservation(self.root)
            def serve():
                try:self._server.serve_forever(poll_interval=.05)
                except Exception:self._thread_failed=True
            self._thread=threading.Thread(target=serve,name='astra-portable-fixture',daemon=True);self._thread.start()
            self.evidence['stage']='fixture_started'
            return self
        except BaseException:
            if self._obs is not None:self._obs.close()
            if self._server is not None:self._server.server_close()
            self._closed=True
            raise AssemblyError('assembly setup failed') from None
    def environment(self):
        if not self._entered or self._used or self._closed:raise AssemblyError('environment unavailable')
        return self.probe.environment()
    def run(self,child):
        if not self._entered or self._used or self._closed:raise AssemblyError('assembly already used')
        self._used=True;self.evidence['stage']='started_outcome_uncertain';lease=None
        try:
            lease=SyntheticLease(child);observer=DirectListenerObserver(child.pid)
            port=lease.wait_port(20)
            def verified(p):
                return lease.healthy() and observer(p) is True and lease.healthy()
            async def baseline():
                results={}
                for path in ('/api/info','/api/config'):
                    for label,password,expected in (('none',None,401),('wrong','intentionally-wrong-synthetic-password',401),('correct',self.probe._password,200)):
                        if verified(port) is not True:raise AssemblyError('listener unobserved')
                        status,raw=await asyncio.wait_for(_request(port,path,password),timeout=5)
                        if verified(port) is not True or status!=expected:raise AssemblyError('baseline mismatch')
                        if label=='correct':results[path]=_json(raw)
                return results
            result=asyncio.run(baseline());info=result['/api/info'];config=result['/api/config']
            if (type(info) is not dict or info.get('version')!='2.3.2' or type(info.get('pid')) is not int or info['pid']!=child.pid
                or info.get('urls')!=['http://127.0.0.1:%d'%port] or type(info.get('paths')) is not dict
                or info['paths'].get('tmp')!=self.root+'/tmp/opencode'):
                raise AssemblyError('baseline info mismatch')
            session=self.probe.run_once(port,config,self._server.ledger,self._obs.verify,verified)
            if not lease.healthy():raise AssemblyError('server output observation failed')
            cleanup=lease.finish();lease=None
            if not (cleanup['direct_exit_observed'] is True and cleanup['exit_code']==0
                    and cleanup['lease_stream_complete'] is True and cleanup['stderr_stream_complete'] is True):
                raise AssemblyError('direct child or stream completion uncertain')
            self.evidence['stage']='session_complete_fixture_pending'
            self.evidence['session']=session
            self.evidence['direct_child_exit']='observed_zero'
            return dict(session)
        except Exception:
            self.evidence['stage']='failed_outcome_uncertain'
            raise AssemblyError('synthetic run failed or uncertain; do not replay') from None
        finally:
            if lease is not None:
                try:lease.finish()
                except Exception:pass
    def __exit__(self,exc_type,exc,tb):
        self._closed=True
        try:
            if self._thread is not None and self._thread.is_alive():
                self._server.shutdown();self._thread.join(timeout=4)
            stopped=self._thread is not None and not self._thread.is_alive() and not self._thread_failed
            if self._server is not None:self._server.server_close()
            if self._obs is not None:self._obs.close()
            diag=self._server.ledger.diagnostics()
            valid=(stopped and diag.get('handled_connections')==1 and diag.get('handled_http_requests')==1
                   and diag.get('handled_rejections')==0 and diag.get('refused_connections')==0 and diag.get('wall_timeouts')==0)
            self.evidence['fixture_final']='passed' if valid else 'failed_or_unknown'
            if exc_type is None and self.evidence['stage']=='session_complete_fixture_pending' and valid:
                self.evidence['stage']='assembly_complete'
            else:
                self.evidence['stage']='failed_outcome_uncertain'
                if exc_type is None:raise AssemblyError('fixture completion uncertain')
        except AssemblyError:raise
        except Exception:
            self.evidence['stage']='failed_outcome_uncertain'
            if exc_type is None:raise AssemblyError('fixture cleanup uncertain') from None
        return False
