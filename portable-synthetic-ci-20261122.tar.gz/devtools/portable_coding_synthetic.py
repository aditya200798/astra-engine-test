"""Unwired fixed synthetic coding bridge; not a launcher or sandbox.

Caller owns an already-running fake provider and supervised synthetic server.
No real keys, user project, model or production use. Filesystem observations
and callback success are sampled, not peer authentication or confinement.
"""
import json, os, secrets, stat
from pathlib import Path
from astra import coding,coding_exchange,coding_session_exchange
from astra.policy import check_config,rules_for
from astra.session import Session
from astra.storage import Store
from astra.transport import Client
from . import coding_integration_scenario as scenario
from . import fake_responses as fake
from . import synthetic_session_probe as base
from .genuine_run_layout import DIRECTORIES,prepare_fresh_layout

class PortableProbeError(RuntimeError):pass

class PortableCodingProbe:
    """Fixed invented source and response; single attempt, including failure.

    Initialization modifies only an existing empty private root. Caller must
    independently manage server/provider startup, process deadlines and cleanup.
    No deletion or blind replay; journals and partial state remain on failure.
    """
    def __init__(self,root,provider_port):
        if type(provider_port) is not int or not 1<=provider_port<=65535:raise PortableProbeError('invalid port')
        if (type(root) is not str or not os.path.isabs(root) or '\0' in root or
            os.path.normpath(root)!=root or os.path.realpath(root)!=root):raise PortableProbeError('canonical absolute root required')
        fd=os.open(root,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
        try:
            st=os.fstat(fd);named=os.stat(root,follow_symlinks=False)
            if (not stat.S_ISDIR(st.st_mode) or st.st_uid!=os.geteuid() or
                stat.S_IMODE(st.st_mode)!=0o700 or (st.st_dev,st.st_ino)!=(named.st_dev,named.st_ino)):
                raise PortableProbeError('private root required')
            prepare_fresh_layout(fd)
        finally:os.close(fd)
        self.root=root;self.provider_port=provider_port;self._password=secrets.token_hex(32);self._used=False
    def _path(self,name):
        if name not in DIRECTORIES:raise PortableProbeError('invalid fixed directory')
        return os.path.join(self.root,name)
    def environment(self):
        """Exact replacement env, never merge host credentials or proxy vars."""
        return {'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','HOME':self._path('home'),
                'XDG_CONFIG_HOME':self._path('config'),'XDG_DATA_HOME':self._path('data'),
                'XDG_CACHE_HOME':self._path('cache'),'XDG_STATE_HOME':self._path('state'),
                'TMPDIR':self._path('tmp'),'OPENCODE_CONFIG_DIR':self._path('config'),
                'OPENCODE_SERVER_PASSWORD':self._password,'OPENCODE_DISABLE_MODELS_FETCH':'1',
                'OPENCODE_CONFIG_PROJECT_DISABLE':'1','OPENCODE_DISABLE_CLAUDE_CODE':'1',
                'OPENCODE_FILEWATCHER_DISABLE':'1','OPENCODE_DISABLE_FFF':'1',
                'ASTRA_SYNTHETIC_API_KEY':fake.SYNTHETIC_KEY,
                'OPENCODE_CONFIG_CONTENT':json.dumps(base.synthetic_config(self.provider_port),separators=(',',':'))}
    def run_once(self,server_port,config_entries,ledger,verify_config_directory,verify_listener):
        if self._used:raise PortableProbeError('attempt already consumed')
        self._used=True
        if type(server_port) is not int or not 1<=server_port<=65535 or not callable(verify_config_directory) or not callable(verify_listener):raise PortableProbeError('invalid server or observer')
        config=base.synthetic_config(self.provider_port)
        check_config(config_entries,config,trusted_directory=self._path('config'),verify_directory=verify_config_directory)
        if verify_listener(server_port) is not True:raise PortableProbeError('server not observed')
        root=Path(self._path('state'))/'astra-coding-synthetic'
        root.mkdir(mode=0o700,parents=False,exist_ok=False)
        source=root/'source';source.mkdir(mode=0o700)
        fd=os.open(source/'main.py',os.O_CREAT|os.O_EXCL|os.O_WRONLY|os.O_NOFOLLOW,0o600)
        with os.fdopen(fd,'wb') as f:f.write(scenario.SOURCE);f.flush();os.fsync(f.fileno())
        task=root/'candidate';coding.create(source,task)
        prepared=coding_exchange.prepare(task,scenario.INSTRUCTION,['main.py'],acknowledged=True)
        if prepared['request_sha256']!=scenario.PROMPT_SHA256 or prepared['revision']!=0:raise PortableProbeError('fixed prompt mismatch')
        store=Store(root/'session');store.acquire()
        try:
            client=base.ObservedClient(Client(server_port,self._password),server_port,verify_listener)
            clean={'PATH':'/usr/bin:/bin','HOME':self._path('home'),'TMPDIR':self._path('tmp'),'LANG':'C'}
            session=Session(client,store,self._path('project'),rules_for([]),config,clean,
                [self._password,fake.SYNTHETIC_KEY],{'trusted_directory':self._path('config'),'verify_directory':verify_config_directory},model=dict(base.SYNTHETIC_MODEL))
            out=coding_session_exchange._run_private(task,prepared['exchange_id'],session,lambda _:True,lambda _:True,deadline_seconds=20,poll_interval=.1,review_paths=['main.py'])
            rec,diag=ledger.snapshot(),ledger.diagnostics();review=out.get('review',{});report=review.get('report',{})
            if (out.get('status')!='candidate_revision_created' or out.get('request_sha256')!=scenario.PROMPT_SHA256
                or out.get('source_applied') is not False or out.get('code_executed') is not False
                or out.get('candidate',{}).get('result',{}).get('revision')!=1 or review.get('status')!='completed'
                or report.get('revision')!=1 or report.get('python_syntax',{}).get('status')!='compile_passed'
                or (source/'main.py').read_bytes()!=scenario.SOURCE or (task/'revisions/000001/tree/main.py').read_bytes()!=b'answer = 2\n'
                or type(rec) is not dict or rec.get('valid_attempts')!=1 or rec.get('response_delivery')!='write_completed_not_client_receipt'
                or not scenario.matches_request(rec.get('raw')) or diag.get('handled_connections')!=1 or diag.get('handled_http_requests')!=1
                or diag.get('handled_rejections')!=0 or diag.get('refused_connections')!=0 or diag.get('wall_timeouts')!=0):
                raise PortableProbeError('coding result or fixture evidence mismatch')
            return {'session_status':'succeeded','candidate':'revision_1_static_python_passed','source_apply':'not_done',
                    'candidate_execution':'not_done','fixture_valid_attempts':1,'fixture_user_prompt_matches':True,
                    'fixture_response_delivery':'write_completed_not_client_receipt','genuine_engine':'not_attested',
                    'isolation':'not_verified','descendant_cleanup':'not_verified','all_network_traffic':'not_observed'}
        finally:store.release()
