"""Fixed CI-only synthetic launcher. Never use with real data or credentials.

Must run under independently bounded, disposable, network-restricted Docker.
No production integration, no authentication or cleanup claims. No retries.
"""
import hashlib,json,os,stat,subprocess,sys
from .portable_synthetic_orchestrator import PortableSyntheticAssembly

_IMAGE='/engine/opencode'
_SIZE=247667816
_SHA='0e214ccebc6f0dd8775be65104b8a9de0585427b8911ad838c9fd83d1c812e2d'
_ROOT='/work'

def _check_binary():
    st=os.stat(_IMAGE,follow_symlinks=False)
    if not stat.S_ISREG(st.st_mode) or st.st_size!=_SIZE:raise ValueError('binary metadata')
    h=hashlib.sha256()
    with open(_IMAGE,'rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    if h.hexdigest()!=_SHA:raise ValueError('binary hash')

def main():
    if len(sys.argv)!=1:raise ValueError('no arguments')
    if (os.getuid(),os.geteuid(),os.getgid(),os.getegid(),os.getgroups())!=(65534,65534,65534,65534,[]):
        raise ValueError('CI identity')
    _check_binary();child=None;assembly=PortableSyntheticAssembly(_ROOT)
    try:
        with assembly:
            child=subprocess.Popen([_IMAGE,'serve','--stdio','--hostname','127.0.0.1','--port','0'],
                cwd=_ROOT+'/project',env=assembly.environment(),stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True,close_fds=True)
            assembly.run(child)
        if assembly.evidence.get('stage')!='assembly_complete':raise ValueError('incomplete')
        evidence={'outcome':'fixed_candidate_reviewed','fixture_final':assembly.evidence['fixture_final'],
                  'direct_child_exit':assembly.evidence['direct_child_exit'],
                  'source_apply':'not_done','candidate_execution':'not_done','synthetic_only':True,
                  'engine_identity':'archive_hash_observed','endpoint_identity':'not_authenticated',
                  'isolation':'not_verified','descendants':'not_verified','production_approved':False}
        print(json.dumps(evidence,sort_keys=True,separators=(',',':')),flush=True)
        return 0
    finally:
        if child is not None and child.poll() is None:
            child.kill()
            try:child.wait(timeout=2)
            except subprocess.TimeoutExpired:pass

if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception:
        print('{"outcome":"failed_or_uncertain","synthetic_only":true,"production_approved":false}',flush=True)
        raise SystemExit(1)
