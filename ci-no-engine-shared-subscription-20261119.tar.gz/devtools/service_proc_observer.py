"""Read-only PIDFD/proc snapshot for an already-running synthetic bootstrap.

No manager binding, launch, admission, cgroup mutation, network test, cleanup
or authorization. A caller must independently verify PIDFD-to-unit/invocation,
unit reservation, correct procfs, environment, mount/network and watchdog.
"""
import fcntl
import hashlib
import os
import re
import select
import stat

_LIMIT=65536
class ProcObservationError(RuntimeError):pass


def _stat_start(raw,pid):
    if type(raw) is not bytes or len(raw)>_LIMIT:raise ValueError('stat')
    close=raw.rfind(b')'); prefix=raw[:close+1];fields=raw[close+1:].split()
    if close<0 or not prefix.startswith(str(pid).encode()+b' (') or len(fields)<20 or not fields[19].isdigit():raise ValueError('stat')
    if fields[0] in (b'Z',b'X',b'x'):raise ValueError('dead')
    return int(fields[19])


def _status(raw,uid,gid):
    if type(raw) is not bytes or len(raw)>_LIMIT:raise ValueError('status')
    fields={}
    for line in raw.decode('ascii').splitlines():
        key,sep,val=line.partition(':')
        if not sep or key in fields:raise ValueError('status fields')
        fields[key]=val.strip()
    if fields.get('Uid','').split()!=[str(uid)]*4 or fields.get('Gid','').split()!=[str(gid)]*4:
        raise ValueError('identity')
    if fields.get('Groups')!='' or fields.get('NoNewPrivs')!='1':raise ValueError('groups/nnp')
    for key in ('CapInh','CapPrm','CapEff','CapBnd','CapAmb'):
        val=fields.get(key,'')
        if not re.fullmatch('[0-9a-fA-F]{1,32}',val) or int(val,16)!=0:raise ValueError('capabilities')
    if fields.get('Threads')!='1':raise ValueError('threads')


def _initial_environment(raw,expected_invocation=None,expected_pid=None):
    """Restrict execve-time environment; do not return or log its content.

    PROC environ is the initial memory area, not necessarily the current
    Python environment and may be altered by a sufficiently privileged task.
    Target compatibility is unverified; any unfamiliar variable fails closed.
    """
    allowed={'PATH','LANG','USER','LOGNAME','HOME','SHELL','INVOCATION_ID','SYSTEMD_EXEC_PID'}
    if type(raw) is not bytes or not raw or len(raw)>_LIMIT or not raw.endswith(b'\0'):
        raise ValueError('initial environment')
    fields={}
    for item in raw[:-1].split(b'\0'):
        key,sep,value=item.partition(b'=')
        if not sep:raise ValueError('entry')
        name=key.decode('ascii');val=value.decode('ascii')
        if (name not in allowed or name in fields or not re.fullmatch(r'[A-Z_][A-Z0-9_]*',name) or
            any(ord(x)<32 or ord(x)>126 for x in val)):
            raise ValueError('environment field')
        fields[name]=val
    if 'INVOCATION_ID' in fields and (re.fullmatch(r'[0-9a-f]{32}',fields['INVOCATION_ID']) is None or fields['INVOCATION_ID']=='0'*32):
        raise ValueError('invocation')
    if 'SYSTEMD_EXEC_PID' in fields and (not fields['SYSTEMD_EXEC_PID'].isdigit() or int(fields['SYSTEMD_EXEC_PID'])<=0):
        raise ValueError('exec pid')
    if 'LANG' in fields and fields['LANG'] not in ('C','C.UTF-8','C.utf8','en_US.UTF-8'):
        raise ValueError('locale')
    if expected_invocation is not None and (type(expected_invocation) is not str or
        re.fullmatch(r'[0-9a-f]{32}',expected_invocation) is None or expected_invocation=='0'*32 or
        fields.get('INVOCATION_ID')!=expected_invocation):raise ValueError('invocation binding')
    if expected_pid is not None and (type(expected_pid) is not int or expected_pid<=0 or
        fields.get('SYSTEMD_EXEC_PID')!=str(expected_pid)):raise ValueError('pid binding')
    return None


def _command(raw,kind):
    # This is a proc snapshot of process-controlled memory, not authentication.
    if type(kind) is not str or kind not in ('baseline','integration'):raise ValueError('kind')
    expected=(b'/usr/bin/python3\0-I\0-S\0-B\0'
              b'/app/devtools/synthetic_service_bootstrap.py\0'+kind.encode('ascii')+b'\0')
    if type(raw) is not bytes or raw!=expected:raise ValueError('unexpected bootstrap command')


def _cgroup(raw,expected):
    if type(expected) is not str or not expected.startswith('/') or '\n' in expected:raise ValueError('cgroup')
    lines=raw.decode('ascii').splitlines()
    unified=[line for line in lines if line.startswith('0::')]
    if unified!=['0::'+expected]:raise ValueError('cgroup')


def _pidfd(fd):
    # Linux pidfs (v6.9+) names the link pidfd:[inode]; older kernels use
    # anon_inode:[pidfd]. Both remain advisory, never sole authentication.
    link=os.readlink('/proc/self/fd/'+str(fd))
    if link!='anon_inode:[pidfd]' and re.fullmatch(r'pidfd:\[[0-9]+\]',link) is None:
        raise ValueError('not pidfd')


def _fdinfo(raw,pid):
    vals=[]
    for line in raw.decode('ascii').splitlines():
        key,sep,val=line.partition(':')
        if sep and key=='Pid':vals.append(val.strip())
    if vals!=[str(pid)]:raise ValueError('pidfd target')


def _file_digest(path,limit):
    fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NONBLOCK)
    try:
        st=os.fstat(fd)
        if not stat.S_ISREG(st.st_mode) or st.st_size<=0 or st.st_size>limit:raise ValueError('exe')
        h=hashlib.sha256();remaining=st.st_size
        while remaining:
            chunk=os.read(fd,min(65536,remaining))
            if not chunk:raise ValueError('exe short')
            h.update(chunk);remaining-=len(chunk)
        if os.read(fd,1):raise ValueError('exe long')
        after=os.fstat(fd)
        if (st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns,st.st_ctime_ns)!=(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns,after.st_ctime_ns):
            raise ValueError('exe changed')
        return h.hexdigest()
    finally:os.close(fd)


def _read(path,limit=_LIMIT):
    fd=os.open(path,os.O_RDONLY|os.O_CLOEXEC|os.O_NOFOLLOW)
    try:
        buf=bytearray()
        while len(buf)<=limit:
            data=os.read(fd,min(8192,limit+1-len(buf)))
            if not data:break
            buf.extend(data)
        if len(buf)>limit:raise ValueError('proc limit')
        return bytes(buf)
    finally:os.close(fd)


def _pipe(fd,access):
    st=os.fstat(fd)
    if not stat.S_ISFIFO(st.st_mode) or (fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE)!=access:
        raise ValueError('pipe')
    return st.st_ino


def _inspect(pid,pidfd,root_fd,cgroup,in_fd,out_fd,err_fd,uid,gid,exe_digest,invocation=None,kind=None):
    """Private parameterized core. FDs remain caller-owned and are never signalled.

    Caller excludes hostile writers, externally bounds syscalls and keeps the
    exact process/manager unit alive. procfs/pidfd and mount aliases can race;
    these sampled checks never form a complete admission or isolation proof.
    """
    if (any(type(x) is not int or x<0 for x in (pidfd,root_fd,in_fd,out_fd,err_fd,uid,gid))
        or type(pid) is not int or pid<=0 or len({in_fd,out_fd,err_fd})!=3
        or type(exe_digest) is not str or re.fullmatch('[0-9a-f]{64}',exe_digest) is None):
        raise ProcObservationError('invalid observation inputs')
    try:
        _pidfd(pidfd)
        _fdinfo(_read('/proc/self/fdinfo/'+str(pidfd)),pid)
        if select.select([pidfd],[],[],0)[0]:raise ValueError('process exited')
        base='/proc/'+str(pid);start=_stat_start(_read(base+'/stat'),pid)
        _status(_read(base+'/status'),uid,gid);_cgroup(_read(base+'/cgroup'),cgroup)
        _initial_environment(_read(base+'/environ'),invocation,pid if invocation is not None else None)
        if kind is not None:_command(_read(base+'/cmdline'),kind)
        root=os.stat(base+'/root');expected=os.fstat(root_fd)
        if not stat.S_ISDIR(expected.st_mode) or (root.st_dev,root.st_ino)!=(expected.st_dev,expected.st_ino):
            raise ValueError('root')
        # Private peer pipe descriptions have opposite endpoint access modes.
        in_ino=_pipe(in_fd,os.O_WRONLY);out_ino=_pipe(out_fd,os.O_RDONLY);err_ino=_pipe(err_fd,os.O_RDONLY)
        if len({in_ino,out_ino,err_ino})!=3:raise ValueError('alias')
        nums=sorted(os.listdir(base+'/fd'))
        if nums!=['0','1','2']:raise ValueError('fd set')
        for n,ino,mode in ((0,in_ino,os.O_RDONLY),(1,out_ino,os.O_WRONLY),(2,err_ino,os.O_WRONLY)):
            if os.readlink(base+'/fd/'+str(n))!='pipe:['+str(ino)+']':raise ValueError('fd target')
            info=_read(base+'/fdinfo/'+str(n)).decode('ascii');found=[]
            for line in info.splitlines():
                if line.startswith('flags:'):found.append(line.split(':',1)[1].strip())
            if len(found)!=1 or int(found[0],8)&os.O_ACCMODE!=mode:raise ValueError('fd flags')
        if _file_digest(base+'/exe',16_000_000)!=exe_digest:raise ValueError('executable')
        if (_stat_start(_read(base+'/stat'),pid)!=start or
            select.select([pidfd],[],[],0)[0] or _fdinfo(_read('/proc/self/fdinfo/'+str(pidfd)),pid) is not None):
            raise ValueError('process changed')
        _status(_read(base+'/status'),uid,gid);_cgroup(_read(base+'/cgroup'),cgroup)
        _initial_environment(_read(base+'/environ'),invocation,pid if invocation is not None else None)
        if kind is not None:_command(_read(base+'/cmdline'),kind)
        return {'process':'pidfd_proc_samples_match','uid_gid':'matched_snapshot',
                'capabilities':'zero_snapshot','no_new_privs':'snapshot',
                'initial_exec_environment':'allowlist_and_unit_ids_snapshot' if invocation is not None else 'allowlist_snapshot',
                'bootstrap_argv':'fixed_snapshot' if kind is not None else 'not_compared',
                'root_inode':'matched_snapshot','cgroup':'matched_snapshot',
                'three_pipes':'matched_snapshot','executable_digest':'matched_snapshot',
                'manager_unit_binding':'not_verified','mounts_network':'not_verified',
                'admission':'not_authorized','engine_launch_authorized':False}
    except Exception:raise ProcObservationError('process observation unavailable') from None


def inspect_fixed(pid,pidfd,root_fd,cgroup,in_fd,out_fd,err_fd,invocation,kind):
    """Fixed UID/GID and authenticated candidate executable digest; read-only."""
    if (type(kind) is not str or kind not in ('baseline','integration') or type(invocation) is not str or
        re.fullmatch(r'[0-9a-f]{32}',invocation) is None or invocation=='0'*32):
        raise ProcObservationError('invocation required')
    return _inspect(pid,pidfd,root_fd,cgroup,in_fd,out_fd,err_fd,65534,65534,
                    'e50d468e8b0adfb05733f5b87b3cff34829c4a8c1aea50c865aa8bdfe4bb150f',invocation,kind)
