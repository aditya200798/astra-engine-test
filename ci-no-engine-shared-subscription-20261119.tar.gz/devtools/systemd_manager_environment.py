"""Read-only sampled systemd-manager effective environment, never launch gate.

Requires a caller-owned bus and independently trusted owner/VM. Check does not
change manager defaults or expose values, and is not atomic with a later start.
"""
import ctypes as c
import re
from . import systemd_pidfd_lookup as look

P=c.c_void_p
class EnvironmentError(RuntimeError):pass
_LIMIT=65536
_COUNT=128


def _decode_assignment(raw):
    if type(raw) is not bytes or len(raw)>4096:raise ValueError('assignment')
    key,sep,value=raw.partition(b'=')
    if not sep:raise ValueError('assignment')
    name=key.decode('ascii');val=value.decode('ascii')
    if re.fullmatch('[A-Z_][A-Z0-9_]*',name) is None or any(ord(x)<32 or ord(x)>126 for x in val):raise ValueError('entry')
    # Global manager inputs are deliberately narrower than eventual service
    # variables which systemd itself synthesizes; no arbitrary values needed.
    if name=='PATH':
        parts=val.split(':')
        if not parts or any(x not in ('/usr/local/sbin','/usr/local/bin','/usr/sbin','/usr/bin','/sbin','/bin') for x in parts):raise ValueError('path')
    elif name=='LANG':
        if val not in ('C','C.UTF-8','C.utf8','en_US.UTF-8'):raise ValueError('locale')
    else:raise ValueError('unexpected global variable')
    return name


def _property(lib,bus,owner):
    """Read manager Environment (`as`) from actual sd-bus property message."""
    msg=P()
    try:
        if lib.sd_bus_get_property(bus,owner,look._PATH,look._INTERFACE,b'Environment',None,c.byref(msg),b'as')<0 or not msg.value:
            raise ValueError('property')
        if lib.sd_bus_message_enter_container(msg,b'a',b's')<=0:raise ValueError('array')
        names=set();total=0
        while True:
            value=c.c_char_p();r=lib.sd_bus_message_read(msg,b's',c.byref(value))
            if r<0:raise ValueError('entry')
            if r==0:break
            if value.value is None:raise ValueError('missing')
            raw=value.value;total+=len(raw)+1
            if total>_LIMIT or len(names)>=_COUNT:raise ValueError('size')
            name=_decode_assignment(raw)
            if name in names:raise ValueError('duplicate')
            names.add(name)
        if lib.sd_bus_message_exit_container(msg)<0:raise ValueError('array end')
        return len(names)
    finally:
        if msg.value:lib.sd_bus_message_unref(msg)


def inspect(lib,bus,owner):
    """Get and validate twice on same unique owner; no values are returned.

    `Environment` is systemd's effective manager global environment, not proof
    of unit environment, generator behavior or no concurrent changes. Any
    errors or changed count fail closed; exact values may still change while
    remaining within allowed choices. Caller must exclude concurrent writers,
    verify the manager/bus independently and apply an external deadline.
    """
    if type(owner) is not str or re.fullmatch(r':[0-9]+\.[0-9]+',owner) is None or not bus:
        raise EnvironmentError('invalid input')
    try:
        if look._owner(lib,bus)!=owner:raise ValueError('owner')
        first=_property(lib,bus,owner.encode())
        second=_property(lib,bus,owner.encode())
        if first!=second or look._owner(lib,bus)!=owner:raise ValueError('changed')
        return {'manager_global_environment':'allowlisted_two_snapshots',
                'unit_environment':'not_verified','pre_exec_atomicity':'not_proven',
                'engine_launch_authorized':False}
    except Exception:raise EnvironmentError('manager environment unavailable') from None
