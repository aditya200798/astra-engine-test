"""One in-flight task per session, no automatic resubmission, read-only tools."""
import re, json, time, secrets, urllib.parse, math
from .policy import MODEL,TITLE,check_config,check_session,json_equal,validate_model
from .transport import ProtocolError

class Uncertain(Exception): pass

def msgid(): return 'msg_'+format(int(time.time()*1000)*4096,'012x')+secrets.token_hex(7)
def redact(value,secrets_list):
    if isinstance(value,str):
        for secret in secrets_list:
            if secret:value=value.replace(secret,'[REDACTED]')
        return value
    if isinstance(value,list): return [redact(x,secrets_list) for x in value]
    if isinstance(value,dict): return {redact(k,secrets_list) if isinstance(k,str) else k:redact(v,secrets_list) for k,v in value.items()}
    return value

class Session:
    def __init__(self,client,store,work,rules,config,clean_env,secret_values, config_attestation=None, *, model=None):
        self.client,self.store,self.work,self.rules=client,store,work,rules
        self.model=validate_model(MODEL if model is None else model)
        self.secrets=secret_values; self.clean_env=clean_env; self.sid=None; self.base=None
        self.config=config; self.config_attestation=config_attestation or {}
        pending=store.read('task.json')
        if pending and pending.get('status') != 'succeeded':
            raise Uncertain('Unresolved task; do not restart or resubmit. Inspect task.json and engine data.')
        self._config()
        saved=store.read('session.json')
        if saved:
            if saved.get('work')!=work or saved.get('rules')!=rules or not isinstance(saved.get('sid'),str): raise ValueError('saved session differs')
            self.sid=saved['sid']; self.base='/api/session/'+urllib.parse.quote(self.sid,safe='')
            check_session(client.request('GET',self.base).get('data'),rules,work,self.sid,expected_model=self.model)
        else:
            result=client.request('POST','/api/session',{'title':TITLE,'agent':'build','model':dict(self.model),'location':{'directory':work},'permissions':rules})
            self.sid=check_session(result.get('data') if isinstance(result,dict) else None,rules,work,expected_model=self.model)
            self.base='/api/session/'+urllib.parse.quote(self.sid,safe='')
            check_session(client.request('GET',self.base).get('data'),rules,work,self.sid,expected_model=self.model)
            store.write('session.json',{'sid':self.sid,'work':work,'rules':rules})
        # Before every prompt and after every process start; never include key or config/password.
        self._environment()
    def _config(self):
        entries=self.client.request('GET','/api/config?location%5Bdirectory%5D='+urllib.parse.quote(self.work,safe=''))
        check_config(entries,self.config,**self.config_attestation)
    def _environment(self):
        self.client.request('PUT',self.base+'/environment',{'variables':self.clean_env})
    def permissions(self,timeout=10):
        result=self.client.request('GET',self.base+'/permission',timeout=timeout)
        if not isinstance(result,dict) or not isinstance(result.get('data'),list): raise ProtocolError('invalid permission response')
        return result['data']
    def _reject_unexpected(self,deadline):
        timeout=lambda: max(.05,min(2,deadline-time.monotonic()))
        result=self.client.request('GET','/api/permission/request?location%5Bdirectory%5D='+urllib.parse.quote(self.work,safe=''),timeout=timeout())
        if not isinstance(result,dict) or not isinstance(result.get('data'),list): raise ProtocolError('invalid location permissions')
        location=result.get('location')
        if not isinstance(location,dict) or location.get('directory')!=self.work: raise ProtocolError('permission location mismatch')
        unexpected=False
        for p in result['data']:
            if not isinstance(p,dict): raise ProtocolError('invalid permission')
            sid=p.get('sessionID'); ident=p.get('id')
            if not isinstance(sid,str) or not re.fullmatch(r'ses_[A-Za-z0-9_-]{1,196}',sid): raise ProtocolError('invalid permission session')
            if not isinstance(ident,str) or not re.fullmatch(r'per[A-Za-z0-9_-]{1,197}',ident): raise ProtocolError('invalid permission')
            self.client.request('POST','/api/session/'+urllib.parse.quote(sid,safe='')+'/permission/'+urllib.parse.quote(ident,safe='')+'/reply',{'decision':'reject'},timeout=timeout())
            unexpected=True
        if unexpected: raise ProtocolError('unexpected permission request')
        # A session-scoped list is checked independently for requests missed by location.
        if self.permissions(timeout=timeout()): raise ProtocolError('permission race or unexpected request')
    def pages(self,deadline=None):
        cursor=None; seen=set(); out=[]
        for _ in range(50):
            q='?limit=200&'+('cursor='+urllib.parse.quote(cursor,safe='') if cursor else 'order=asc')
            if deadline is not None and time.monotonic()>=deadline: raise ProtocolError('poll deadline')
            r=self.client.request('GET',self.base+'/message'+q,timeout=max(.05,min(2,deadline-time.monotonic())) if deadline else 10)
            if not isinstance(r,dict) or not isinstance(r.get('data'),list) or not isinstance(r.get('cursor'),dict): raise ProtocolError('invalid message page')
            out.extend(r['data']); cur=r['cursor'].get('next')
            if cur is None: return out
            if not isinstance(cur,str) or not cur or cur in seen: raise ProtocolError('invalid message cursor')
            seen.add(cur); cursor=cur
        raise ProtocolError('message page limit')
    def prompt(self,text,deadline_seconds=120,poll_interval=.5):
        if not isinstance(text,str) or not text.strip() or len(text.encode())>100_000: raise ValueError('empty or oversized prompt')
        if any(s and s in text for s in self.secrets): raise ValueError('prompt contains active credential; not sent')
        old=self.store.read('task.json')
        if old and old.get('status') != 'succeeded': raise Uncertain('Unresolved previous task; not sent')
        self._config()
        self._environment()
        ident=msgid(); task={'id':ident,'session':self.sid,'status':'sending','created':int(time.time())}
        self.store.write('task.json',task)  # persisted BEFORE request leaves process
        deadline=time.monotonic()+deadline_seconds
        try:
            response=self.client.request('POST',self.base+'/prompt',{'id':ident,'text':text,'files':[],'delivery':'steer'},timeout=max(.05,min(30,deadline-time.monotonic())))
            data=response.get('data') if isinstance(response,dict) else None
            if not isinstance(data,dict) or data.get('id')!=ident or data.get('type')!='user': raise ProtocolError('ambiguous admission')
            task['status']='admitted'; self.store.write('task.json',task)
        except Exception:
            # Admission may have succeeded. Polling can reconcile; never resend.
            task['status']='uncertain'; self.store.write('task.json',task)
        latest=[]
        try:
            previous=None
            while time.monotonic()<deadline:
                self._reject_unexpected(deadline)
                messages=self.pages(deadline)
                info=self.client.request('GET',self.base,timeout=max(.05,min(2,deadline-time.monotonic())))
                info=info.get('data') if isinstance(info,dict) else None
                check_session(info,self.rules,self.work,self.sid,expected_model=self.model)
                # An idle marker is not individually linked to a prompt by the v2 schema.
                # Demand one unambiguous user marker, a final idle, and stable snapshots.
                indexes=[i for i,m in enumerate(messages) if isinstance(m,dict) and m.get('type')=='user' and m.get('id')==ident]
                if len(indexes)>1: raise ProtocolError('duplicate prompt')
                if not indexes:
                    previous=None; time.sleep(min(poll_interval,max(0,deadline-time.monotonic()))); continue
                admitted=messages[indexes[0]]
                if admitted.get('text')!=text or admitted.get('files',[])!=[] or admitted.get('agents',[])!=[] or admitted.get('skills',[])!=[]:
                    raise ProtocolError('prompt content mismatch')
                user_time=admitted.get('time')
                if not isinstance(user_time,dict) or type(user_time.get('created')) not in (int,float) or not math.isfinite(user_time['created']):
                    raise ProtocolError('invalid prompt timestamp')
                run=messages[indexes[0]+1:]; latest=[]; outcome=None; final_text=False; idle_time=None; last_finish=None; final_parts=[]; final_redacted=False; run_ids={ident}; assistant_times=[]; turn_has_reasoning=False; assistant_count=0
                for i,m in enumerate(run):
                    if not isinstance(m,dict): raise ProtocolError('invalid message')
                    kind=m.get('type')
                    if not isinstance(m.get('id'),str) or not re.fullmatch(r'msg_[A-Za-z0-9_-]{1,196}',m['id']): raise ProtocolError('invalid message id')
                    if m['id'] in run_ids: raise ProtocolError('duplicate message id')
                    run_ids.add(m['id'])
                    if kind=='assistant':
                        assistant_count+=1
                        final_text=False; final_parts=[]; final_redacted=False
                        mt=m.get('time')
                        if not isinstance(mt,dict) or type(mt.get('created')) not in (int,float) or not math.isfinite(mt['created']): raise ProtocolError('invalid assistant timestamp')
                        completed=mt.get('completed')
                        if (type(completed) not in (int,float) or not math.isfinite(completed)
                            or mt['created'] < user_time['created'] or completed < mt['created']):
                            raise ProtocolError('inconsistent assistant timestamp')
                        assistant_times.append((mt['created'],completed))
                        model=m.get('model')
                        if (not isinstance(model,dict) or set(model)-{'providerID','id','variant'}
                            or model.get('providerID')!=self.model['providerID'] or model.get('id')!=self.model['id']
                            or model.get('variant','default')!='default' or m.get('agent')!='build'):
                            raise ProtocolError('unexpected assistant selection')
                        if m.get('error') is not None or m.get('retry') is not None: raise ProtocolError('assistant error/retry')
                        if not isinstance(m.get('content'),list): raise ProtocolError('invalid content')
                        finish=m.get('finish')
                        if finish not in ('stop','tool-calls'): raise ProtocolError('assistant finish not successful')
                        tool_seen=False; last_finish=finish
                        for part in m['content']:
                            if not isinstance(part,dict): raise ProtocolError('invalid assistant content')
                            ptype=part.get('type')
                            if ptype=='text':
                                if not isinstance(part.get('text'),str): raise ProtocolError('invalid text')
                                if part['text'].strip(): final_text=True
                                clean=redact(part,self.secrets)
                                if clean != part: final_redacted=True
                                latest.append(clean); final_parts.append(clean)
                            elif ptype=='tool':
                                tool_seen=True
                                pt=part.get('time')
                                if not isinstance(part.get('id'),str) or not isinstance(pt,dict) or type(pt.get('created')) not in (int,float) or not math.isfinite(pt['created']): raise ProtocolError('invalid tool metadata')
                                st=part.get('state')
                                if part.get('name')!='read' or not isinstance(st,dict): raise ProtocolError('unexpected tool observed')
                                # A completed read must have a real result, not merely a status tag.
                                if (st.get('status')!='completed' or not isinstance(st.get('input'),dict)
                                    or not isinstance(st.get('content'),list) or not st['content']
                                    or not all(isinstance(x,dict) and x.get('type')=='text' and isinstance(x.get('text'),str) for x in st['content'])
                                    or not isinstance(st['input'].get('path'),str)
                                    or st['input']['path'] not in [p for r in self.rules if r.get('action')=='read' and r.get('effect')=='allow' for p in (r['resource'], self.work.rstrip('/')+'/'+r['resource'])]
                                    or st.get('error') is not None): raise ProtocolError('read incomplete or failed')
                                final_text=False
                                latest.append(redact(part,self.secrets))
                            elif ptype=='reasoning':
                                turn_has_reasoning=True
                                if not isinstance(part.get('text'),str): raise ProtocolError('invalid reasoning')
                            else: raise ProtocolError('unknown assistant content')
                        if (finish=='tool-calls') != tool_seen: raise ProtocolError('inconsistent tool finish')
                    elif kind=='idle':
                        if i!=len(run)-1 or outcome is not None: raise ProtocolError('ambiguous idle')
                        marker_time=m.get('time')
                        if not isinstance(marker_time,dict) or type(marker_time.get('created')) not in (int,float) or not math.isfinite(marker_time['created']) or marker_time['created']<user_time['created']:
                            raise ProtocolError('idle predates prompt')
                        idle_time=marker_time['created']
                        if any(completed > idle_time for _,completed in assistant_times):
                            raise ProtocolError('assistant completed after idle')
                        outcome=m.get('outcome')
                        if outcome!='succeeded' or m.get('error') is not None: raise ProtocolError('unsuccessful idle')
                    else:
                        # Includes model/agent/location changes, synthetic and other users.
                        raise ProtocolError('unexpected session message')
                if outcome=='succeeded' and final_text and last_finish=='stop':
                    timing=info.get('time')
                    if (info.get('outcome')!='succeeded' or not isinstance(timing,dict)
                        or type(timing.get('idle')) not in (int,float) or type(timing.get('busy')) not in (int,float)
                        or not math.isfinite(timing['idle']) or not math.isfinite(timing['busy'])
                        or timing['idle'] < max(timing['busy'],idle_time)): raise ProtocolError('session not stably idle')
                    snapshot={'messages':messages,'info':info}
                    if previous is not None and json_equal(previous,snapshot):
                        # Check again immediately before committing: still not an atomic server snapshot.
                        self._reject_unexpected(deadline)
                        self._config()
                        self.store.append_event({'task':ident,'parts':latest,'outcome':outcome})
                        task['status']=outcome; self.store.write('task.json',task)
                        return {'status':outcome,'parts':latest,'final_parts':final_parts,'final_redacted':final_redacted,
                                'turn_has_reasoning':turn_has_reasoning,'assistant_count':assistant_count,'task_id':ident}
                    previous=snapshot
                else: previous=None
                time.sleep(min(poll_interval,max(0,deadline-time.monotonic())))
        except Exception:
            pass
        # Do not assert interruption succeeded; no replay on next process startup.
        try:self.client.request('POST',self.base+'/interrupt',{},timeout=3)
        except Exception:pass
        task['status']='uncertain'; self.store.write('task.json',task)
        return {'status':'uncertain','parts':latest}
