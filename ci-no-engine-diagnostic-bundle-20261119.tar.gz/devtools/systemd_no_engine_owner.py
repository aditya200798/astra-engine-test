"""Private fixed no-engine session owner, NOT a standalone supervisor.

Runs the actual session and owns six anonymous pipe ends. Caller must provide
an exclusive disposable VM, fixed protected root, single unit lifecycle and
independently supervised watchdog/recovery *before* invoking this private helper.
No executable is unblocked. Public entry deliberately remains closed.
"""
import os
import time
from . import systemd_bound_session as bound

_BLOCKED=True
class OwnerError(RuntimeError):pass


def _drive_once(lib,bus,owner,unit,kind,root,root_fd,*,slice_name=None,anchor=None):
    """Connect one real session; no name-based recovery, no retries.

    Caller owns bus/root and must independently bound native calls and stop
    ambiguous starts, including when this process is killed. No authorization,
    watchdog, root staging, cgroup check or cleanup is furnished here. Return
    only categorical evidence, not a claim of launch success or containment.
    """
    fds={}; session=None; result={
        'control':'unknown','stage':'pipe_creation','reason':'not_completed',
        'exit':'not_observed','stop':'not_observed','record':'not_observed',
        'cgroup_cleanup':'not_observed','vm_decommission':'not_observed',
        'isolation':'not_verified','engine_launch_authorized':False,
        'production_approved':False}
    provisional=False; exit_info=None
    def close_key(key):
        fd=fds.pop(key,None)
        if fd is not None:
            try:os.close(fd)
            except OSError:result['reason']='descriptor_close_uncertain'
    try:
        for read,write in (('input_read','input_write'),('output_read','output_write'),('error_read','error_write')):
            r,w=os.pipe2(os.O_CLOEXEC);fds[read]=r;fds[write]=w
        session=bound._Session(lib,bus,owner,unit,kind,root,root_fd,
                               fds['input_write'],fds['output_read'],fds['error_read'],
                               **({'slice_name':slice_name} if slice_name is not None else {}),
                               **({'anchor':anchor} if anchor is not None else {}))
        result['stage']='start_uncertain'
        try:session.start_once(fds['input_read'],fds['output_write'],fds['error_write'])
        finally:
            # Original service endpoints are never needed again in this owner;
            # a sent sd-bus message or manager may hold duplicates.
            for k in ('input_read','output_write','error_write'):close_key(k)
        if result['reason']=='descriptor_close_uncertain':raise OwnerError('close')
        result['stage']='observe';session.observe()
        result['stage']='admission_uncertain'
        # Transfer sole close authority before call; never close a potentially
        # reassigned integer if the session already consumed it.
        try:
            session.admit_no_engine_once()
        finally:
            # Transfer happens only once the session actually consumed it.
            # If rejected before consumption, the owner retains and closes it.
            if session._input_consumed:
                fds.pop('input_write',None)
        result['stage']='provisional';session.read_provisional(5);provisional=True
        result['stage']='exit';deadline=time.monotonic()+5
        while True:
            try:exit_info=session.observe_exit();break
            except bound.SessionError:
                if time.monotonic()>=deadline:raise
                time.sleep(.05)
        result['exit']='sampled_normal_exit';result['stage']='stop'
        session.stop_once();result['stop']='job_done_inactive_snapshot'
        result['stage']='final';final=session.read_final(5);result['record']='received'
        inner=final.get('inner');code=exit_info.get('exit_code')
        if (type(inner) is not dict or inner.get('outcome')!='driver_error' or
            type(inner.get('observations')) is not dict or
            inner['observations'].get('stage')!='blocked_before_start' or
            type(code) is not int or code!=1):
            result['reason']='inner_exit_mismatch'
        else:
            result['control']='blocked_entry_record_and_exit_sampled';result['reason']='cleanup_unverified'
        result['stage']='finished'
    except BaseException:
        if result['reason']!='descriptor_close_uncertain':result['reason']='operation_failed_or_uncertain'
        # Stop at most once, only with already bound invocation. Unknown start
        # cannot be recovered here; external supervisor owns that risk.
        if session is not None and not session._stop_attempted and session._bound is not None:
            try:session.stop_once();result['stop']='job_done_inactive_snapshot'
            except BaseException:pass
        # Final may still be useful after a failed stop; it remains diagnostic
        # and cannot upgrade the control result after an earlier failure.
        if (session is not None and provisional and session._stop_attempted
            and session._streams is not None and session._streams.stage=='provisional_done'):
            try:
                session.read_final(5);result['record']='received_diagnostic_only'
            except BaseException:pass
    finally:
        if session is not None:
            try:session.close()
            except BaseException:result['reason']='session_close_uncertain';result['control']='unknown'
        for k in tuple(fds):close_key(k)
        if result['reason'] in ('descriptor_close_uncertain','session_close_uncertain'):
            result['control']='unknown'
    return result


def run():
    if _BLOCKED:raise OwnerError('no-engine owner blocked: independent watchdog and recovery not established')
    raise OwnerError('no approved orchestration')
