"""Fixed sd-bus StartTransientUnit request builder, never a launch gate.

No public start/stop. Imported only for future reviewed disposable synthetic VM
control. A reply is merely an enqueued job. Collision/exclusive ownership,
manager authentication, bounded independent stop and cleanup remain unresolved.
"""
import ctypes as c
import fcntl
import os
import re
import stat
from .systemd_pipe_transport import _UNIT,_valid_root
from . import systemd_pidfd_lookup as look

_BLOCKED=True
P=c.c_void_p
class StartError(RuntimeError):pass


def _proto(lib):
    look._proto(lib)
    specs={'sd_bus_message_new_method_call':([P,c.POINTER(P),c.c_char_p,c.c_char_p,c.c_char_p,c.c_char_p],c.c_int),
           'sd_bus_message_append':([P,c.c_char_p],c.c_int),
           'sd_bus_message_open_container':([P,c.c_char,c.c_char_p],c.c_int),
           'sd_bus_message_close_container':([P],c.c_int),
           'sd_bus_call':([P,P,c.c_uint64,P,c.POINTER(P)],c.c_int)}
    for name,(args,ret) in specs.items():
        fn=getattr(lib,name);fn.argtypes=args;fn.restype=ret


def _check(result):
    if result<0:raise ValueError('message operation')


def _inputs(unit,kind,root,inf,outf,errf,slice_name=None):
    if (type(unit) is not str or _UNIT.fullmatch(unit) is None or
        kind not in ('baseline','integration') or type(kind) is not str or not _valid_root(root) or
        any(type(fd) is not int or fd<0 for fd in (inf,outf,errf)) or len({inf,outf,errf})!=3):
        raise ValueError('inputs')
    if slice_name is not None and slice_name!=_slice_for(unit):raise ValueError('slice identity')
    inodes=[]
    for fd,expected in ((inf,os.O_RDONLY),(outf,os.O_WRONLY),(errf,os.O_WRONLY)):
        st=os.fstat(fd)
        if not stat.S_ISFIFO(st.st_mode) or fcntl.fcntl(fd,fcntl.F_GETFL)&os.O_ACCMODE != expected:
            raise ValueError('pipe direction')
        inodes.append((st.st_dev,st.st_ino))
    if len(set(inodes))!=3:raise ValueError('pipe aliases')


def _slice_for(unit):
    """Single root-level slice candidate derived from one exact unit.

    This is naming only, not a reservation, exclusive ownership or proof the
    manager placed anything under the intended cgroup.
    """
    if type(unit) is not str or _UNIT.fullmatch(unit) is None:raise ValueError('unit')
    return 'astra'+unit[len('astra-synthetic-'):-len('.service')]+'.slice'


def _build(lib,bus,owner,unit,kind,root,inf,outf,errf,slice_name=None):
    """Construct but do not send a fixed message; caller owns returned msg.

    owner is a sampled manager unique name, NOT authenticated identity. Pipe
    descriptors belong to caller; library may duplicate them. Validated root
    grammar is not proof of root ownership, completeness, mounting or isolation.
    """
    _inputs(unit,kind,root,inf,outf,errf,slice_name)
    if type(owner) is not str or re.fullmatch(r':[0-9]+\.[0-9]+',owner) is None:raise ValueError('owner')
    msg=P()
    def open_(kind,signature):_check(lib.sd_bus_message_open_container(msg,kind,signature))
    def close():_check(lib.sd_bus_message_close_container(msg))
    def append(signature,*values):_check(lib.sd_bus_message_append(msg,signature,*values))
    def property_(name,signature,value):
        if signature==b's':v=c.c_char_p(value.encode('ascii'))
        elif signature==b'b':v=c.c_int(value)
        elif signature==b't':v=c.c_uint64(value)
        elif signature==b'h':v=c.c_int(value)
        else:raise ValueError('signature')
        append(b'(sv)',c.c_char_p(name.encode('ascii')),c.c_char_p(signature),v)
    try:
        _check(lib.sd_bus_message_new_method_call(bus,c.byref(msg),owner.encode(),look._PATH,look._INTERFACE,b'StartTransientUnit'))
        if not msg.value:raise ValueError('message')
        append(b'ss',c.c_char_p(unit.encode()),c.c_char_p(b'fail'))
        open_(b'a',b'(sv)')
        for name,value in (('Type','exec'),('RootDirectory',root),('User','65534'),('Group','65534'),
                           ('ProtectSystem','strict'),('KillMode','control-group'),('WorkingDirectory','/work'),
                           ('MemoryPressureWatch','skip')):
            property_(name,b's',value)
        if slice_name is not None:property_('Slice',b's',slice_name)
        for name in ('NoNewPrivileges','PrivateNetwork','PrivateDevices','MountAPIVFS','ProtectControlGroups','AddRef'):
            property_(name,b'b',1)
        for name,value in (('CapabilityBoundingSet',0),('AmbientCapabilities',0),('TimeoutStopUSec',3000000),
                           ('RuntimeMaxUSec',90000000),('LimitCORE',0),('MemoryMax',1073741824),('TasksMax',64)):
            property_(name,b't',value)
        # ReadWritePaths is an array of strings with the root-relative '+' prefix.
        open_(b'r',b'sv');append(b's',c.c_char_p(b'ReadWritePaths'));open_(b'v',b'as');open_(b'a',b's')
        append(b's',c.c_char_p(b'+/work'));close();close();close()
        for name,fd in (('StandardInputFileDescriptor',inf),('StandardOutputFileDescriptor',outf),('StandardErrorFileDescriptor',errf)):
            property_(name,b'h',fd)
        # Same ExecStartEx a(sasas) encoding as systemd-run --expand-environment=no.
        open_(b'r',b'sv');append(b's',c.c_char_p(b'ExecStartEx'));open_(b'v',b'a(sasas)');open_(b'a',b'(sasas)');open_(b'r',b'sasas')
        append(b's',c.c_char_p(b'/usr/bin/python3'));open_(b'a',b's')
        for arg in (b'/usr/bin/python3',b'-I',b'-S',b'-B',b'/app/devtools/synthetic_service_bootstrap.py',kind.encode()):append(b's',c.c_char_p(arg))
        close();open_(b'a',b's');append(b's',c.c_char_p(b'no-env-expand'));close();close();close();close();close()
        close() # top-level properties
        open_(b'a',b'(sa(sv))');close() # no auxiliary units
        return msg
    except BaseException:
        if msg.value:lib.sd_bus_message_unref(msg)
        raise


def _send(lib,bus,msg):
    """Send once: all errors/invalid replies are ambiguous; never retry.

    Private plumbing only. Caller must own VM, exact name and independent
    recovery even if this call is interrupted; no response means unknown.
    """
    reply=P()
    try:
        r=lib.sd_bus_call(bus,msg,c.c_uint64(2_000_000),None,c.byref(reply))
        if r<0 or not reply.value:raise ValueError('unknown')
        job=look._read_string(lib,reply,b'o')
        if re.fullmatch(r'/org/freedesktop/systemd1/job/[0-9]+',job) is None:raise ValueError('job')
        return {'start':'job_enqueued_not_completed','job_path':job,
                'unit_ownership':'not_proven','cleanup':'not_observed','engine_launch_authorized':False}
    except BaseException:raise StartError('start outcome unknown; no retry') from None
    finally:
        if reply.value:lib.sd_bus_message_unref(reply)


def run():
    if _BLOCKED:raise StartError('direct start blocked; ownership and recovery not established')
    raise StartError('no approved start/stop orchestration')
